<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Logging function
function logDebug($message, $data = null) {
    error_log("[DAILY_TRANSACTIONS] " . $message . ($data ? " | Data: " . print_r($data, true) : ""));
}

try {
    // Lấy shopId từ nhiều nguồn
    $shopId = $_GET['shopId'] ?? $_POST['shopId'] ?? $_GET['shop_id'] ?? $_SESSION['shop_id'] ?? '';
    $date = $_GET['date'] ?? $_POST['date'] ?? date('Y-m-d'); // Mặc định là hôm nay
    
    if (empty($shopId)) {
        $raw_input = file_get_contents('php://input');
        $input = json_decode($raw_input, true);
        $shopId = $input['shopId'] ?? $input['shop_id'] ?? '';
        $date = $input['date'] ?? $date;
        
        if (empty($shopId)) {
            throw new Exception('Shop ID không được để trống.');
        }
    }

    logDebug("Request received", ['shopId' => $shopId, 'date' => $date]);

    // Kiểm tra cấu trúc database
    $checkDeletedAtStmt = $pdo->prepare("SHOW COLUMNS FROM contracts LIKE 'deleted_at'");
    $checkDeletedAtStmt->execute();
    $hasDeletedAt = $checkDeletedAtStmt->rowCount() > 0;

    $checkDeletedTableStmt = $pdo->prepare("SHOW TABLES LIKE 'deleted_contracts'");
    $checkDeletedTableStmt->execute();
    $hasDeletedTable = $checkDeletedTableStmt->rowCount() > 0;

    $transactions = [];

    // 1. Lấy các giao dịch thanh toán trong ngày - SỬA TÊN BẢNG
    if ($hasDeletedAt) {
        $paymentQuery = "
            SELECT 
                pt.id,
                pt.payment_date as transaction_date,
                pt.amount_paid as amount,
                'payment' as transaction_type,
                'Thanh toán kỳ' as description,
                c.contract_number,
                c.customer_name,
                c.customer_phone,
                pt.note,
                'completed' as status,
                pt.created_at
            FROM payment_transactions pt
            INNER JOIN contracts c ON pt.contract_id = c.id
            WHERE c.shop_id = ? 
              AND c.deleted_at IS NULL
              AND pt.status = 'completed'
              AND DATE(pt.payment_date) = ?
            ORDER BY pt.payment_date DESC
        ";
    } else {
        $paymentQuery = "
            SELECT 
                pt.id,
                pt.payment_date as transaction_date,
                pt.amount_paid as amount,
                'payment' as transaction_type,
                'Thanh toán kỳ' as description,
                c.contract_number,
                c.customer_name,
                c.customer_phone,
                pt.note,
                'completed' as status,
                pt.created_at
            FROM payment_transactions pt
            INNER JOIN contracts c ON pt.contract_id = c.id
            WHERE c.shop_id = ? 
              AND pt.status = 'completed'
              AND DATE(pt.payment_date) = ?
            ORDER BY pt.payment_date DESC
        ";
    }

    $paymentStmt = $pdo->prepare($paymentQuery);
    $paymentStmt->execute([$shopId, $date]);
    $payments = $paymentStmt->fetchAll(PDO::FETCH_ASSOC);

    logDebug("Payments found", ['count' => count($payments)]);

    foreach ($payments as $payment) {
        $transactions[] = [
            'id' => 'payment_' . $payment['id'],
            'time' => date('H:i', strtotime($payment['transaction_date'])),
            'type' => 'income',
            'description' => $payment['description'],
            'customer' => $payment['customer_name'] ?? 'N/A',
            'contract' => $payment['contract_number'] ?? 'N/A',
            'phone' => $payment['customer_phone'] ?? '',
            'amount' => (float)$payment['amount'],
            'note' => $payment['note'] ?? '',
            'created_at' => $payment['created_at']
        ];
    }

    // 2. Lấy các hợp đồng mới được tạo trong ngày
    if ($hasDeletedAt) {
        $newContractQuery = "
            SELECT 
                id,
                from_date as transaction_date,
                total_money_received as amount,
                'new_contract' as transaction_type,
                'Hợp đồng mới' as description,
                contract_number,
                customer_name,
                customer_phone,
                note,
                'active' as status,
                created_at
            FROM contracts 
            WHERE shop_id = ? 
              AND deleted_at IS NULL
              AND DATE(from_date) = ?
            ORDER BY from_date DESC
        ";
    } else {
        $newContractQuery = "
            SELECT 
                id,
                from_date as transaction_date,
                total_money_received as amount,
                'new_contract' as transaction_type,
                'Hợp đồng mới' as description,
                contract_number,
                customer_name,
                customer_phone,
                note,
                'active' as status,
                created_at
            FROM contracts 
            WHERE shop_id = ? 
              AND DATE(from_date) = ?
            ORDER BY from_date DESC
        ";
    }

    $newContractStmt = $pdo->prepare($newContractQuery);
    $newContractStmt->execute([$shopId, $date]);
    $newContracts = $newContractStmt->fetchAll(PDO::FETCH_ASSOC);

    logDebug("New contracts found", ['count' => count($newContracts)]);

    foreach ($newContracts as $contract) {
        $transactions[] = [
            'id' => 'contract_' . $contract['id'],
            'time' => date('H:i', strtotime($contract['transaction_date'])),
            'type' => 'expense', // Hợp đồng mới = chi tiền
            'description' => $contract['description'],
            'customer' => $contract['customer_name'] ?? 'N/A',
            'contract' => $contract['contract_number'] ?? 'N/A',
            'phone' => $contract['customer_phone'] ?? '',
            'amount' => (float)$contract['amount'],
            'note' => $contract['note'] ?? '',
            'created_at' => $contract['created_at']
        ];
    }

    // 3. Lấy các hợp đồng đã đóng trong ngày (nếu có bảng deleted_contracts) - SỬA TÊN CỘT
    if ($hasDeletedTable) {
        $closedContractStmt = $pdo->prepare("
            SELECT 
                id,
                deleted_at as transaction_date,
                total_paid as amount,
                'closed_contract' as transaction_type,
                'Đóng hợp đồng' as description,
                code_id as contract_number,
                customer_name,
                customer_phone,
                deletion_reason as note,
                deletion_status as status,
                original_created_at as created_at
            FROM deleted_contracts 
            WHERE shop_id = ? 
              AND deletion_status = 'closed'
              AND DATE(deleted_at) = ?
            ORDER BY deleted_at DESC
        ");

        $closedContractStmt->execute([$shopId, $date]);
        $closedContracts = $closedContractStmt->fetchAll(PDO::FETCH_ASSOC);

        logDebug("Closed contracts found", ['count' => count($closedContracts)]);

        foreach ($closedContracts as $contract) {
            $transactions[] = [
                'id' => 'closed_' . $contract['id'],
                'time' => date('H:i', strtotime($contract['transaction_date'])),
                'type' => 'income', // Đóng hợp đồng = thu tiền về
                'description' => $contract['description'],
                'customer' => $contract['customer_name'] ?? 'N/A',
                'contract' => $contract['contract_number'] ?? 'N/A',
                'phone' => $contract['customer_phone'] ?? '',
                'amount' => (float)$contract['amount'],
                'note' => $contract['note'] ?? '',
                'created_at' => $contract['created_at']
            ];
        }
    }

    // Sắp xếp theo thời gian (mới nhất trước)
    usort($transactions, function($a, $b) {
        return strtotime($b['created_at']) - strtotime($a['created_at']);
    });

    // Tính tổng kết
    $totalIncome = 0;
    $totalExpense = 0;
    $transactionCount = count($transactions);

    foreach ($transactions as $transaction) {
        if ($transaction['type'] === 'income') {
            $totalIncome += $transaction['amount'];
        } else {
            $totalExpense += $transaction['amount'];
        }
    }

    $netAmount = $totalIncome - $totalExpense;

    logDebug("Summary calculated", [
        'count' => $transactionCount,
        'total_income' => $totalIncome,
        'total_expense' => $totalExpense,
        'net_amount' => $netAmount
    ]);

    // Trả về response theo cấu trúc mong muốn
    $response = [
        'success' => true,
        'data' => [
            'transactions' => $transactions,
            'summary' => [
                'date' => $date,
                'total_transactions' => $transactionCount,
                'total_income' => round($totalIncome, 2),
                'total_expense' => round($totalExpense, 2),
                'net_amount' => round($netAmount, 2)
            ]
        ],
        'timestamp' => date('Y-m-d H:i:s'),
        'database_info' => [
            'has_deleted_at_column' => $hasDeletedAt,
            'has_deleted_contracts_table' => $hasDeletedTable
        ]
    ];

    logDebug("Response prepared", ['transaction_count' => $transactionCount]);
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    error_log("Daily Transactions Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Lỗi: ' . $e->getMessage(),
        'error_details' => [
            'shop_id' => $shopId ?? 'not_set',
            'date' => $date ?? 'not_set',
            'timestamp' => date('Y-m-d H:i:s'),
            'file' => __FILE__,
            'line' => $e->getLine()
        ]
    ], JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    error_log("Daily Transactions Database Error: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage(),
        'error_details' => [
            'shop_id' => $shopId ?? 'not_set',
            'timestamp' => date('Y-m-d H:i:s'),
            'sql_error' => $e->getCode()
        ]
    ], JSON_UNESCAPED_UNICODE);
}
?>