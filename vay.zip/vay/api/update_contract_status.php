<?php
/**
 * Script để cập nhật trạng thái hợp đồng tự động
 * Chạy bằng cron job hàng ngày vào 00:00
 * 
 * Cron job command:
 * 0 0 * * * /usr/bin/php /path/to/update_contract_status.php
 */

require_once 'database.php';

// Thiết lập timezone
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Log file để theo dõi quá trình thực thi
//$logFile = __DIR__ . '/logs/contract_status_update_' . date('Y-m-d') . '.log';

// Tạo thư mục logs nếu chưa có
// if (!is_dir(__DIR__ . '/logs')) {
//     mkdir(__DIR__ . '/logs', 0755, true);
// }

function writeLog($message) {
    //global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    //file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND | LOCK_EX);
    echo "[$timestamp] $message\n";
}


function calculateDetailedStatus($contract) {
    $today = new DateTime();
    $today->setTime(0, 0, 0); // Đặt về đầu ngày

    // Tính toán ngày bắt đầu và các thông số cơ bản
    $fromDate = new DateTime($contract['from_date']);
    $loanDays = (int)($contract['loan_time'] ?? 0);
    $frequency = (int)($contract['frequency'] ?? 1);
    $totalPeriods = (int)($contract['total_periods'] ?? 0);
    $paidPeriods = (int)($contract['paid_periods'] ?? 0);

    // Tính ngày kết thúc hợp đồng (ngày trả gốc)
    $endDate = clone $fromDate;
    $endDate->add(new DateInterval("P{$loanDays}D"));
    $endDate->sub(new DateInterval('P1D')); // Trừ 1 ngày vì ngày đầu đã được tính

    // KIỂM TRA CÁC TRƯỜNG HỢP ƯU TIÊN CAO NHẤT

    // 1. Kiểm tra nếu đã thanh toán đủ số kỳ (hoàn thành)
    if ($totalPeriods > 0 && $paidPeriods >= $totalPeriods) {
        return [
            'status' => 'Đã hoàn thành'
        ];
    }

    // 2. Kiểm tra nếu hôm nay là ngày kết thúc hợp đồng
    if ($today->format('Y-m-d') === $endDate->format('Y-m-d')) {
        return [
            'status' => 'Trả gốc hôm nay'
        ];
    }

    // 3. Kiểm tra nếu hợp đồng đã quá ngày kết thúc - PHẢI KIỂM TRA TRƯỚC KHI XỬ LÝ LOGIC KỲ THANH TOÁN
    if ($today > $endDate) {
        return [
            'status' => 'Quá hạn'
        ];
    }

    // XỬ LÝ CÁC TRẠNG THÁI TRONG QUÁ TRÌNH VAY (CHỈ KHI CHƯA QUÁ NGÀY KẾT THÚC)

    // 4. Tìm kỳ thanh toán tiếp theo chưa được thanh toán
    $nextUnpaidPeriod = findNextUnpaidPeriod($contract, $fromDate, $frequency, $paidPeriods, $totalPeriods);

    // 5. Nếu không có kỳ thanh toán nào chưa thanh toán (đã hoàn thành tất cả)
    if (!$nextUnpaidPeriod) {
        return [
            'status' => 'Đã hoàn thành'
        ];
    }

    // 6. Xử lý logic dựa trên kỳ thanh toán tiếp theo
    $nextPaymentDate = $nextUnpaidPeriod['date'];
    $daysDiff = $today->diff($nextPaymentDate);
    $daysDiffValue = (int)$daysDiff->format('%r%a'); // Lấy số ngày có dấu

    // Logic trạng thái dựa trên ngày thanh toán tiếp theo (chỉ khi trong thời hạn hợp đồng)
    if ($daysDiffValue < 0) {
        // Đã qua ngày thanh toán - Chậm họ (nhưng vẫn trong thời hạn hợp đồng)
        return [
            'status' => 'Chậm họ'
        ];
    } else if ($daysDiffValue == 0) {
        // Hôm nay phải đóng - Đến ngày đóng họ
        return [
            'status' => 'Đến ngày đóng họ'
        ];
    } else if ($daysDiffValue == 1) {
        // Ngày mai phải đóng - Ngày mai đóng họ
        return [
            'status' => 'Ngày mai đóng họ'
        ];
    } else {
        // Còn thời gian - Đang vay
        return [
            'status' => 'Đang vay'
        ];
    }
}
function findNextUnpaidPeriod($contract, $fromDate, $frequency, $paidPeriods, $totalPeriods) {
    // Nếu đã thanh toán đủ số kỳ
    if ($paidPeriods >= $totalPeriods) {
        return null;
    }

    // Tính ngày thanh toán của kỳ tiếp theo (kỳ đầu tiên chưa thanh toán)
    $nextPeriodIndex = $paidPeriods; // Index của kỳ tiếp theo (0-based)
    $nextPaymentDate = clone $fromDate;
    $nextPaymentDate->add(new DateInterval("P" . ($nextPeriodIndex * $frequency) . "D"));

    return [
        'period' => $nextPeriodIndex + 1,
        'date' => $nextPaymentDate
    ];
}

function getContractData($pdo, $contractId) {
    try {
        // Query để lấy thông tin hợp đồng kèm theo thông tin thanh toán
        $sql = "
            SELECT 
                c.*,
                -- Tính tổng số kỳ dựa trên loan_time và frequency
                CEIL(c.loan_time / c.frequency) as total_periods,
                -- Tính số kỳ đã thanh toán từ payment_schedules
                COALESCE(
                    (SELECT COUNT(*) 
                     FROM payment_schedules ps 
                     WHERE ps.contract_id = c.id 
                     AND ps.status = 'paid'), 0
                ) as paid_periods,
                -- Tính tổng số tiền đã thu từ payment_schedules
                COALESCE(
                    (SELECT SUM(amount_paid) 
                     FROM payment_schedules ps 
                     WHERE ps.contract_id = c.id 
                     AND ps.status = 'paid'), 0
                ) as paid_amount,
                -- Tính số tiền còn lại
                (c.total_money - COALESCE(
                    (SELECT SUM(amount_paid) 
                     FROM payment_schedules ps 
                     WHERE ps.contract_id = c.id 
                     AND ps.status = 'paid'), 0
                )) as remaining_amount,
                -- Tính số tiền mỗi kỳ
                ROUND(c.total_money / CEIL(c.loan_time / c.frequency), 2) as money_per_period
            FROM contracts c
            WHERE c.id = ?
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$contractId]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        writeLog("Lỗi khi lấy dữ liệu hợp đồng ID $contractId: " . $e->getMessage());
        return null;
    }
}

function updateContractStatus($pdo, $contractId, $newStatus) {
    try {
        // CHỈ cập nhật current_status, KHÔNG cập nhật next_payment_date
        $sql = "UPDATE contracts SET 
                current_status = :status,
                updated_at = CURRENT_TIMESTAMP 
                WHERE id = :id";
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':status' => $newStatus,
            ':id' => $contractId
        ]);
        
        return $result;
    } catch (Exception $e) {
        writeLog("Lỗi khi cập nhật trạng thái hợp đồng ID $contractId: " . $e->getMessage());
        return false;
    }
}

function processContractStatusUpdate($pdo) {
    writeLog("Bắt đầu quá trình cập nhật trạng thái hợp đồng");
    
    try {
        // Lấy danh sách tất cả hợp đồng
        $sql = "SELECT id FROM contracts ORDER BY id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        
        $contractIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $totalContracts = count($contractIds);
        
        writeLog("Tìm thấy $totalContracts hợp đồng cần xử lý");
        
        $updatedCount = 0;
        $errorCount = 0;
        $statusCounts = [];
        
        foreach ($contractIds as $contractId) {
            // Lấy dữ liệu hợp đồng đầy đủ
            $contract = getContractData($pdo, $contractId);
            
            if (!$contract) {
                writeLog("Không thể lấy dữ liệu cho hợp đồng ID: $contractId");
                $errorCount++;
                continue;
            }
            
            // Tính toán trạng thái mới
            $statusResult = calculateDetailedStatus($contract);
            $newStatus = $statusResult['status'];
            
            // Đếm số lượng theo trạng thái
            if (!isset($statusCounts[$newStatus])) {
                $statusCounts[$newStatus] = 0;
            }
            $statusCounts[$newStatus]++;
            
            // ✅ FIX: Luôn cập nhật trạng thái (không so sánh với trạng thái cũ)
            $success = updateContractStatus($pdo, $contractId, $newStatus);
            
            if ($success) {
                $updatedCount++;
                writeLog("Cập nhật hợp đồng {$contract['code_id']} (ID: $contractId): -> '$newStatus'");
            } else {
                $errorCount++;
                writeLog("Lỗi cập nhật hợp đồng {$contract['code_id']} (ID: $contractId)");
            }
        }
        
        // Tổng kết
        writeLog("=== KẾT QUẢ CẬP NHẬT TRẠNG THÁI ===");
        writeLog("Tổng số hợp đồng đã xử lý: $totalContracts");
        writeLog("Số hợp đồng đã cập nhật: $updatedCount");
        writeLog("Số hợp đồng lỗi: $errorCount");
        
        writeLog("=== THỐNG KÊ THEO TRẠNG THÁI ===");
        foreach ($statusCounts as $status => $count) {
            writeLog("$status: $count hợp đồng");
        }
        
        return [
            'success' => true,
            'total_processed' => $totalContracts,
            'updated' => $updatedCount,
            'errors' => $errorCount,
            'status_counts' => $statusCounts
        ];
        
    } catch (Exception $e) {
        writeLog("Lỗi trong quá trình cập nhật: " . $e->getMessage());
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}



// Main execution
try {
    writeLog("=== BẮT ĐẦU CRON JOB CẬP NHẬT TRẠNG THÁI HỢP ĐỒNG ===");
    writeLog("Thời gian thực thi: " . date('Y-m-d H:i:s'));
    
    // Kiểm tra kết nối database
    if (!$pdo) {
        throw new Exception("Không thể kết nối database");
    }
    
    writeLog("Kết nối database thành công");
    
    // Thực hiện cập nhật
    $result = processContractStatusUpdate($pdo);
    
    if ($result['success']) {
        writeLog("Hoàn thành cập nhật trạng thái hợp đồng thành công");
        
        // Gửi thông báo qua email nếu cần (tùy chọn)
        if (function_exists('sendStatusUpdateNotification')) {
            sendStatusUpdateNotification($result);
        }
    } else {
        writeLog("Cập nhật trạng thái thất bại: " . $result['error']);
        
        // Gửi cảnh báo lỗi qua email nếu cần (tùy chọn)
        if (function_exists('sendErrorNotification')) {
            sendErrorNotification($result['error']);
        }
    }
    
} catch (Exception $e) {
    writeLog("LỖI NGHIÊM TRỌNG: " . $e->getMessage());
    writeLog("Stack trace: " . $e->getTraceAsString());
    
    // Gửi cảnh báo nghiêm trọng qua email nếu cần
    if (function_exists('sendCriticalErrorNotification')) {
        sendCriticalErrorNotification($e->getMessage());
    }
} finally {
    writeLog("=== KẾT THÚC CRON JOB ===");
    writeLog(""); // Dòng trống để phân tách các lần chạy
}

// Hàm gửi thông báo qua email (tùy chọn - cần cấu hình SMTP)
function sendStatusUpdateNotification($result) {
    // Implement email notification nếu cần
    // Ví dụ sử dụng PHPMailer hoặc mail() function
    /*
    $subject = "Contract Status Update - " . date('Y-m-d');
    $message = "
        Cập nhật trạng thái hợp đồng hoàn tất:
        - Tổng số hợp đồng: {$result['total_processed']}
        - Đã cập nhật: {$result['updated']}
        - Lỗi: {$result['errors']}
    ";
    
    // mail('admin@yoursite.com', $subject, $message);
    */
}

function sendErrorNotification($error) {
    // Implement error notification nếu cần
}

function sendCriticalErrorNotification($error) {
    // Implement critical error notification nếu cần
}
?>