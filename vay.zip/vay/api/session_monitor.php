<?php
    require_once 'database.php';
session_start();
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');

    $sessionToken = $_GET['session_token'] ?? '';

    if (empty($sessionToken)) {
        echo json_encode(['valid' => false]);
        exit;
    }

    try {
        // Get current session
        $stmt = $pdo->prepare("SELECT user_id FROM user_sessions WHERE session_token = ? AND is_active = TRUE");
        $stmt->execute([$sessionToken]);
        $currentSession = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$currentSession) {
            echo json_encode(['valid' => false]);
            exit;
        }
        
        // Check if there are other active sessions for the same user
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM user_sessions WHERE user_id = ? AND is_active = TRUE AND session_token != ?");
        $stmt->execute([$currentSession['user_id'], $sessionToken]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result['count'] > 0) {
            // Invalidate current session
            $stmt = $pdo->prepare("UPDATE user_sessions SET is_active = FALSE WHERE session_token = ?");
            $stmt->execute([$sessionToken]);
            
            echo json_encode(['valid' => false, 'message' => 'Session invalidated due to concurrent login']);
        } else {
            echo json_encode(['valid' => true]);
        }
        
    } catch (Exception $e) {
        echo json_encode(['valid' => false]);
    }
    ?>