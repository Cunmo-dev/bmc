<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON và thoát
function jsonResponse($data) {
    // Clear any previous output
    if (ob_get_level()) {
        ob_clean();
    }
    
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

// Debug thông tin ban đầu
logDebug("Get Shops Started", [
    'method' => $_SERVER['REQUEST_METHOD'],
    'session_id' => session_id(),
    'user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'NOT SET',
    'get_data' => $_GET
]);
//đây là code để chuyển về trang chủ
define('BASE_PATH', '/vay/');
// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    logDebug("Login check failed", $_SESSION);
    
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Lấy action từ GET parameter
$action = isset($_GET['action']) ? trim($_GET['action']) : 'list';

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        logDebug("PDO connection not found");
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy user_id từ session
    $currentUserId = $_SESSION['user_id'];
    logDebug("Processing with user_id", $currentUserId);
    
    if ($action === 'list') {
        // Lấy danh sách shops của user hiện tại
        $query = "SELECT 
                    id,
                    shop_id,
                    shop_name,
                    total_money_in_safe,
                    status,
                    created_at,
                    updated_at
                FROM shops 
                WHERE user_id = ? 
                ORDER BY created_at DESC";
        
        $stmt = $pdo->prepare($query);
        
        if (!$stmt) {
            logDebug("Prepare query failed", $pdo->errorInfo());
            throw new Exception("Lỗi prepare statement");
        }
        
        $stmt->execute([$currentUserId]);
        $shops = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        logDebug("Found shops", count($shops));
        
        // Format dữ liệu cho frontend
        $formattedShops = [];
        $rowIndex = 1;
        
        foreach ($shops as $shop) {
            $formattedShops[] = [
                'row_id' => $rowIndex++,
                'id' => $shop['id'],
                'shop_id' => $shop['shop_id'],
                'name' => $shop['shop_name'],
                'total_money' => $shop['total_money_in_safe'],
                'total_money_formatted' => number_format($shop['total_money_in_safe'], 0, ',', ','),
                'created_date' => date('d/m/Y', strtotime($shop['created_at'])),
                'status' => $shop['status'],
                'status_text' => $shop['status'] == 1 ? 'Đang hoạt động' : 'Tạm dừng',
                'status_class' => $shop['status'] == 1 ? 'success' : 'warning'
            ];
        }
        
        jsonResponse([
            'success' => true,
            'message' => 'Lấy danh sách cửa hàng thành công!',
            'data' => $formattedShops,
            'total' => count($formattedShops)
        ]);
        
    } elseif ($action === 'delete') {
        // Xóa shop
        $shopId = isset($_GET['shop_id']) ? intval($_GET['shop_id']) : 0;
        
        if ($shopId <= 0) {
            jsonResponse([
                'success' => false,
                'message' => 'ID cửa hàng không hợp lệ!'
            ]);
        }
        
        // Kiểm tra shop có thuộc về user hiện tại không
        $checkQuery = "SELECT COUNT(*) FROM shops WHERE id = ? AND user_id = ?";
        $checkStmt = $pdo->prepare($checkQuery);
        $checkStmt->execute([$shopId, $currentUserId]);
        
        if ($checkStmt->fetchColumn() == 0) {
            jsonResponse([
                'success' => false,
                'message' => 'Bạn không có quyền xóa cửa hàng này!'
            ]);
        }
        
        // Xóa shop
        $deleteQuery = "DELETE FROM shops WHERE id = ? AND user_id = ?";
        $deleteStmt = $pdo->prepare($deleteQuery);
        $deleteResult = $deleteStmt->execute([$shopId, $currentUserId]);
        
        if ($deleteResult && $deleteStmt->rowCount() > 0) {
            logDebug("Shop deleted", $shopId);
            
            jsonResponse([
                'success' => true,
                'message' => 'Xóa cửa hàng thành công!'
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => 'Không thể xóa cửa hàng!'
            ]);
        }
        
    } elseif ($action === 'get_detail') {
        // Lấy chi tiết shop để edit
        $shopId = isset($_GET['shop_id']) ? intval($_GET['shop_id']) : 0;
        
        if ($shopId <= 0) {
            jsonResponse([
                'success' => false,
                'message' => 'ID cửa hàng không hợp lệ!'
            ]);
        }
        
        $query = "SELECT * FROM shops WHERE id = ? AND user_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$shopId, $currentUserId]);
        $shop = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$shop) {
            jsonResponse([
                'success' => false,
                'message' => 'Không tìm thấy cửa hàng!'
            ]);
        }
        
        jsonResponse([
            'success' => true,
            'message' => 'Lấy thông tin cửa hàng thành công!',
            'data' => [
                'id' => $shop['id'],
                'shop_id' => $shop['shop_id'],
                'shop_name' => $shop['shop_name'],
                'total_money' => $shop['total_money_in_safe'],
                'status' => $shop['status']
            ]
        ]);
        
    } else {
        jsonResponse([
            'success' => false,
            'message' => 'Hành động không hợp lệ!'
        ]);
    }

} catch (PDOException $e) {
    // Log error chi tiết để debug
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>