<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// DEBUG: Log để kiểm tra
error_log("=== UPLOAD NEW CONTRACTS API DEBUG ===");
error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Request URI: " . $_SERVER['REQUEST_URI']);
error_log("POST data: " . print_r($_POST, true));

// Kiểm tra action
if (!isset($_POST['action']) || $_POST['action'] !== 'upload_new_contracts') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Action không hợp lệ']);
    exit();
}

// Lấy dữ liệu contracts
if (!isset($_POST['contracts']) || empty($_POST['contracts'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dữ liệu contracts không tồn tại']);
    exit();
}

$contractsJson = $_POST['contracts'];
$contracts = json_decode($contractsJson, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    error_log("JSON Error: " . json_last_error_msg());
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Lỗi JSON: ' . json_last_error_msg()]);
    exit();
}

if (empty($contracts) || !is_array($contracts)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dữ liệu contracts không hợp lệ']);
    exit();
}

error_log("Received " . count($contracts) . " contracts to process");

// Xử lý upload contracts
handleUploadNewContracts($pdo, $contracts);

function handleUploadNewContracts($pdo, $contracts) {
    error_log("=== PROCESSING NEW CONTRACTS ===");
    
    $totalContracts = count($contracts);
    $successCount = 0;
    $errorCount = 0;
    $duplicateCount = 0;
    $errors = [];
    
    try {
        $pdo->beginTransaction();
        
        // Prepared statement for checking existing contracts based on business logic
        $checkStmt = $pdo->prepare("
            SELECT COUNT(*) FROM contracts 
            WHERE customer_name = ? 
            AND user_id = ? 
            AND shop_id = ? 
            AND total_money = ? 
            AND from_date = ?
        ");
        
        // Prepared statement for inserting contracts
        $sql = "INSERT INTO contracts (
            user_id, shop_id, code_id, type_id, customer_id, customer_name, 
            customer_phone, customer_number_card, customer_address, customer_card_date, 
            customer_place, total_money, total_money_received, rate_type, loan_time, 
            frequency, from_date, is_before, note, staff_id, edit_loan, created_at
        ) VALUES (
            :user_id, :shop_id, :code_id, :type_id, :customer_id, :customer_name,
            :customer_phone, :customer_number_card, :customer_address, :customer_card_date,
            :customer_place, :total_money, :total_money_received, :rate_type, :loan_time,
            :frequency, :from_date, :is_before, :note, :staff_id, :edit_loan, CURRENT_TIMESTAMP
        )";
        
        $stmt = $pdo->prepare($sql);
        
        foreach ($contracts as $index => $contract) {
            try {
                // Validate required fields
                $validationErrors = validateContractData($contract);
                if (!empty($validationErrors)) {
                    $errorCount++;
                    $errors[] = "Contract " . ($index + 1) . ": " . implode(', ', $validationErrors);
                    continue;
                }
                
                // Convert date format if needed - MOVED BEFORE duplicate check
                $fromDate = convertDateFormat($contract['fromDate']);
                $customerCardDate = !empty($contract['customerCardDate']) ? convertDateFormat($contract['customerCardDate']) : null;
                
                // Check for duplicate contract based on business logic (same customer, amount, date)
                $checkStmt->execute([
                    trim($contract['customerName']),
                    $contract['userId'],
                    $contract['shopId'],
                    (float)$contract['totalMoney'],
                    $fromDate
                ]);
                
                $existingCount = $checkStmt->fetchColumn();
                
                if ($existingCount > 0) {
                    $duplicateCount++;
                    $errors[] = "Contract " . ($index + 1) . " (Customer: {$contract['customerName']}, Amount: {$contract['totalMoney']}): Hợp đồng tương tự đã tồn tại, bỏ qua";
                    error_log("Duplicate contract found: Customer=" . $contract['customerName'] . ", Amount=" . $contract['totalMoney'] . ", Date=" . $fromDate);
                    continue;
                }
                
                // Prepare data for insertion
                $executeData = [
                    ':user_id' => trim($contract['userId']),
                    ':shop_id' => trim($contract['shopId']),
                    ':code_id' => trim($contract['codeId']),
                    ':type_id' => (int)$contract['typeId'],
                    ':customer_id' => (int)($contract['customerId'] ?? 0),
                    ':customer_name' => trim($contract['customerName']),
                    ':customer_phone' => trim($contract['customerPhone'] ?? ''),
                    ':customer_number_card' => trim($contract['customerNumberCard'] ?? ''),
                    ':customer_address' => trim($contract['customerAddress'] ?? ''),
                    ':customer_card_date' => $customerCardDate,
                    ':customer_place' => trim($contract['customerPlace'] ?? ''),
                    ':total_money' => (float)$contract['totalMoney'],
                    ':total_money_received' => (float)($contract['totalMoneyReceived'] ?? 0),
                    ':rate_type' => (int)$contract['rateType'],
                    ':loan_time' => (int)$contract['loanTime'],
                    ':frequency' => (int)$contract['frequency'],
                    ':from_date' => $fromDate,
                    ':is_before' => isset($contract['isBefore']) && $contract['isBefore'] ? 1 : 0,
                    ':note' => trim($contract['note'] ?? ''),
                    ':staff_id' => trim($contract['staffId'] ?? ''),
                    ':edit_loan' => (int)($contract['editLoan'] ?? 0)
                ];
                
                error_log("Processing contract " . ($index + 1) . ": " . $contract['codeId']);
                
                // Execute insert
                $stmt->execute($executeData);
                $contractId = $pdo->lastInsertId();
                
                // Tạo lịch trả nợ tự động
                $paymentScheduleResult = createPaymentScheduleForContract($pdo, $contractId);
                
                $successCount++;
                error_log("Successfully created contract ID: $contractId with payment schedule");
                
            } catch(PDOException $e) {
                $errorCount++;
                $errorMessage = "Contract " . ($index + 1) . " - Database error: " . $e->getMessage();
                $errors[] = $errorMessage;
                error_log($errorMessage);
            } catch(Exception $e) {
                $errorCount++;
                $errorMessage = "Contract " . ($index + 1) . " - Error: " . $e->getMessage();
                $errors[] = $errorMessage;
                error_log($errorMessage);
            }
        }
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Upload hoàn thành',
            'total_contracts' => $totalContracts,
            'success_count' => $successCount,
            'error_count' => $errorCount,
            'duplicate_count' => $duplicateCount,
            'errors' => $errors,
            'summary' => [
                'processed' => $totalContracts,
                'created' => $successCount,
                'duplicates_skipped' => $duplicateCount,
                'errors' => $errorCount
            ]
        ]);
        
    } catch(PDOException $e) {
        $pdo->rollBack();
        error_log("Transaction Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    } catch(Exception $e) {
        $pdo->rollBack();
        error_log("General Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
    }
}

function validateContractData($contract) {
    $errors = [];
    
    // Check required fields
    $requiredFields = [
        'userId' => 'User ID',
        'shopId' => 'Shop ID',
        'codeId' => 'Mã hợp đồng',
        'typeId' => 'Loại hợp đồng',
        'customerName' => 'Tên khách hàng',
        'totalMoney' => 'Tổng tiền',
        'totalMoneyReceived' => 'Tiền giao khách',
        'rateType' => 'Loại lãi suất',
        'loanTime' => 'Thời gian vay',
        'frequency' => 'Tần suất',
        'fromDate' => 'Ngày bắt đầu'
    ];
    
    foreach ($requiredFields as $field => $fieldName) {
        if (!isset($contract[$field]) || $contract[$field] === '' || $contract[$field] === null) {
            $errors[] = "$fieldName không được để trống";
        }
    }
    
    // Validate business logic
    if (isset($contract['totalMoney']) && $contract['totalMoney'] <= 0) {
        $errors[] = "Tổng tiền phải lớn hơn 0";
    }
    
    if (isset($contract['totalMoneyReceived']) && $contract['totalMoneyReceived'] <= 0) {
        $errors[] = "Tiền giao khách phải lớn hơn 0";
    }
    
    if (isset($contract['totalMoney']) && isset($contract['totalMoneyReceived']) && 
        $contract['totalMoneyReceived'] >= $contract['totalMoney']) {
        $errors[] = "Tiền giao khách phải nhỏ hơn tổng tiền";
    }
    
    if (isset($contract['loanTime']) && $contract['loanTime'] <= 0) {
        $errors[] = "Thời gian vay phải lớn hơn 0";
    }
    
    if (isset($contract['frequency']) && $contract['frequency'] <= 0) {
        $errors[] = "Tần suất phải lớn hơn 0";
    }
    
    return $errors;
}

/**
 * Function để tự động tạo lịch trả nợ cho hợp đồng
 */
function createPaymentScheduleForContract($pdo, $contractId) {
    error_log("=== CREATE PAYMENT SCHEDULE FOR CONTRACT $contractId ===");
    
    try {
        // Lấy thông tin từ bảng contracts
        $contractStmt = $pdo->prepare("SELECT * FROM contracts WHERE id = ?");
        $contractStmt->execute([$contractId]);
        $contract = $contractStmt->fetch();
        
        if (!$contract) {
            throw new Exception("Không tìm thấy hợp đồng với ID: $contractId");
        }
        
        // Lấy thông tin lãi suất từ contract_types (nếu có)
        $interestRate = 0.0;
        $penaltyRate = 0.0;
        
        if ($contract['rate_type'] > 0) {
            $typeStmt = $pdo->prepare("SELECT interest_rate, penalty_rate FROM contract_types WHERE id = ?");
            $typeStmt->execute([$contract['rate_type']]);
            $typeInfo = $typeStmt->fetch();
            
            if ($typeInfo) {
                $interestRate = (float)$typeInfo['interest_rate'];
                $penaltyRate = (float)$typeInfo['penalty_rate'];
            }
        }
        
        // Tính toán các thông số
        $totalMoney = (float)$contract['total_money'];
        $loanTime = (int)$contract['loan_time'];
        $frequency = (int)$contract['frequency'];
        $fromDate = $contract['from_date'];
        
        // Bước 1: Tính số kỳ trả nợ
        $totalPeriods = ceil($loanTime / $frequency);
        
        // Bước 2: Tính số tiền mỗi kỳ đầu
        $theoreticalAmount = $totalMoney * $frequency / $loanTime;
        $amountPerPeriod = floor($theoreticalAmount / $frequency) * $frequency;
        $numEqualPeriods = $totalPeriods - 1; // Số kỳ đầu bằng nhau
        $totalEqualAmount = $numEqualPeriods * $amountPerPeriod;
        
        // Bước 3: Tính số tiền kỳ cuối
        $lastPayment = $totalMoney - $totalEqualAmount;
        
        error_log("Contract ID: $contractId, Total Periods: $totalPeriods, Amount per period: $amountPerPeriod, Last payment: $lastPayment");
        
        // Tạo lịch trả cho từng kỳ
        $insertStmt = $pdo->prepare("
            INSERT INTO payment_schedules (
                contract_id, user_id, shop_id, code_id, customer_id,
                period_number, from_date, to_date, due_date,
                amount_due, amount_remaining, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        
        $schedulesCreated = 0;
        
        for ($i = 1; $i <= $totalPeriods; $i++) {
            // Tính ngày bắt đầu và kết thúc của kỳ
            $periodFromDate = date('Y-m-d', strtotime($fromDate . " + " . (($i - 1) * $frequency) . " days"));
            $periodToDate = date('Y-m-d', strtotime($periodFromDate . " + " . ($frequency - 1) . " days"));
            $dueDate = $periodToDate; // Ngày đáo hạn là ngày cuối của kỳ
            
            // Gán số tiền cho kỳ hiện tại
            $currentAmount = ($i == $totalPeriods) ? $lastPayment : $amountPerPeriod;
            $currentAmount = round($currentAmount, 2); // Làm tròn để tránh lỗi số thập phân
            
            $insertStmt->execute([
                $contract['id'],
                $contract['user_id'],
                $contract['shop_id'],
                $contract['code_id'],
                $contract['customer_id'],
                $i,
                $periodFromDate,
                $periodToDate,
                $dueDate,
                $currentAmount,
                $currentAmount
            ]);
            
            $schedulesCreated++;
            error_log("Created schedule period $i: $periodFromDate to $periodToDate, due: $dueDate, amount: $currentAmount");
        }
        
        return [
            'success' => true,
            'message' => "Đã tạo $schedulesCreated kỳ trả nợ",
            'total_periods' => $totalPeriods,
            'amount_per_period' => $amountPerPeriod,
            'last_payment' => $lastPayment
        ];
        
    } catch (Exception $e) {
        error_log("Payment Schedule Creation Error: " . $e->getMessage());
        throw $e;
    }
}

function convertDateFormat($dateString) {
    if (empty($dateString)) {
        return null;
    }
    
    // Nếu đã đúng format YYYY-MM-DD thì giữ nguyên
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateString)) {
        return $dateString;
    }
    
    // Chuyển từ DD/MM/YYYY sang YYYY-MM-DD
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $dateString, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        // Validate date
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        } else {
            error_log("Invalid date: $dateString");
            return null;
        }
    }
    
    // Chuyển từ DD-MM-YYYY sang YYYY-MM-DD
    if (preg_match('/^(\d{1,2})-(\d{1,2})-(\d{4})$/', $dateString, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        // Validate date
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        } else {
            error_log("Invalid date: $dateString");
            return null;
        }
    }
    
    error_log("Cannot convert date format: $dateString");
    return null;
}
?>