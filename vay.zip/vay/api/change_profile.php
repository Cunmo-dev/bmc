<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON và thoát
function jsonResponse($data) {
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

// Debug thông tin ban đầu
logDebug("Change Profile Started", [
    'method' => $_SERVER['REQUEST_METHOD'],
    'session_id' => session_id(),
    'user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'NOT SET',
    'post_data' => $_POST
]);

define('BASE_PATH', '/vay/');

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    logDebug("Login check failed", $_SESSION);
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Chỉ xử lý POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        logDebug("PDO connection not found");
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy user_id từ session
    $currentUserId = $_SESSION['user_id'];
    
    // Lấy dữ liệu từ POST với validation an toàn hơn
    $currentPassword = isset($_POST['current_password']) ? trim($_POST['current_password']) : '';
    $newPassword = isset($_POST['new_password']) ? trim($_POST['new_password']) : '';
    $confirmPassword = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : '';
    $displayName = isset($_POST['display_name']) ? trim($_POST['display_name']) : '';

    logDebug("Change Profile Request", [
        'user_id' => $currentUserId,
        'has_current_password' => !empty($currentPassword),
        'has_new_password' => !empty($newPassword),
        'has_display_name' => !empty($displayName)
    ]);

    // Validate dữ liệu
    $errors = [];

    // Mật khẩu hiện tại là bắt buộc
    if (empty($currentPassword)) {
        $errors[] = 'Vui lòng nhập mật khẩu hiện tại';
    }

    // Nếu có nhập mật khẩu mới thì validate
    if (!empty($newPassword)) {
        if (strlen($newPassword) < 6) {
            $errors[] = 'Mật khẩu mới phải có ít nhất 6 ký tự';
        }
        
        if ($newPassword !== $confirmPassword) {
            $errors[] = 'Mật khẩu xác nhận không khớp';
        }
    }

    // Phải có ít nhất một thay đổi
    if (empty($newPassword) && empty($displayName)) {
        $errors[] = 'Vui lòng nhập thông tin cần thay đổi';
    }

    // Validate display name nếu có
    if (!empty($displayName)) {
        if (mb_strlen($displayName) < 2) {
            $errors[] = 'Tên hiển thị phải có ít nhất 2 ký tự';
        }
        
        if (mb_strlen($displayName) > 100) {
            $errors[] = 'Tên hiển thị không được quá 100 ký tự';
        }
    }

    if (!empty($errors)) {
        jsonResponse([
            'success' => false,
            'message' => implode('<br>', $errors)
        ]);
    }

    // Lấy thông tin user hiện tại và verify mật khẩu
    $getUserQuery = "SELECT id, user_id, username, password, email, username FROM users WHERE user_id = ?";
    $getUserStmt = $pdo->prepare($getUserQuery);
    
    if (!$getUserStmt) {
        logDebug("Prepare get user query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare statement cho get user");
    }
    
    $getUserStmt->execute([$currentUserId]);
    $userData = $getUserStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$userData) {
        jsonResponse([
            'success' => false,
            'message' => 'Không tìm thấy thông tin người dùng!'
        ]);
    }

    // Verify mật khẩu hiện tại
    if (!password_verify($currentPassword, $userData['password'])) {
        logDebug("Password verification failed", [
            'user_id' => $currentUserId,
            'username' => $userData['username']
        ]);
        
        jsonResponse([
            'success' => false,
            'message' => 'Mật khẩu hiện tại không đúng!'
        ]);
    }

    // Bắt đầu transaction để đảm bảo data consistency
    $pdo->beginTransaction();

    try {
        $updateParts = [];
        $updateParams = [];
        $updateMessages = [];

        // Cập nhật tên hiển thị nếu có
        if (!empty($displayName)) {
            // Kiểm tra tên đã được sử dụng chưa (trừ chính user hiện tại)
            $checkNameQuery = "SELECT COUNT(*) FROM users WHERE username = ? AND user_id != ?";
            $checkNameStmt = $pdo->prepare($checkNameQuery);
            $checkNameStmt->execute([$displayName, $currentUserId]);
            
            if ($checkNameStmt->fetchColumn() > 0) {
                $pdo->rollBack();
                jsonResponse([
                    'success' => false,
                    'message' => 'Tên hiển thị đã được sử dụng bởi người dùng khác!'
                ]);
            }

            $updateParts[] = "username = ?";
            $updateParams[] = $displayName;
            $updateMessages[] = 'tên hiển thị';
        }

        // Cập nhật mật khẩu nếu có
        if (!empty($newPassword)) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $updateParts[] = "password = ?";
            $updateParams[] = $hashedPassword;
            $updateMessages[] = 'mật khẩu';
        }

        if (empty($updateParts)) {
            $pdo->rollBack();
            jsonResponse([
                'success' => false,
                'message' => 'Không có thông tin nào để cập nhật!'
            ]);
        }

        // Thêm updated_at
        $updateParts[] = "updated_at = NOW()";
        
        // Thêm user_id vào params cuối cùng cho WHERE clause
        $updateParams[] = $currentUserId;

        // Tạo câu query update
        $updateQuery = "UPDATE users SET " . implode(", ", $updateParts) . " WHERE user_id = ?";
        $updateStmt = $pdo->prepare($updateQuery);
        
        if (!$updateStmt) {
            throw new Exception("Lỗi prepare statement cho update user");
        }
        
        logDebug("Update Query", [
            'query' => $updateQuery,
            'params' => $updateParams
        ]);

        $updateResult = $updateStmt->execute($updateParams);

        if (!$updateResult) {
            throw new Exception("Không thể cập nhật thông tin!");
        }

        // Nếu có cập nhật tên, cần cập nhật session
        if (!empty($displayName)) {
            $_SESSION['username'] = $displayName;
        }

        // Commit transaction
        $pdo->commit();
        
        $messageText = 'Cập nhật ' . implode(' và ', $updateMessages) . ' thành công!';
        
        logDebug("Profile updated successfully", [
            'user_id' => $currentUserId,
            'updated_fields' => $updateMessages
        ]);
        
        jsonResponse([
            'success' => true,
            'message' => $messageText,
            'reload' => !empty($displayName) // Reload trang nếu đổi tên để cập nhật UI
        ]);

    } catch (Exception $e) {
        // Rollback nếu có lỗi
        $pdo->rollBack();
        throw $e;
    }

} catch (PDOException $e) {
    // Rollback nếu đang trong transaction
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    // Log error chi tiết để debug
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    // Kiểm tra lỗi duplicate entry cho username
    if (strpos($e->getMessage(), 'Duplicate entry') !== false && strpos($e->getMessage(), 'username') !== false) {
        jsonResponse([
            'success' => false,
            'message' => 'Tên hiển thị đã được sử dụng!'
        ]);
    }
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    // Rollback nếu đang trong transaction
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>