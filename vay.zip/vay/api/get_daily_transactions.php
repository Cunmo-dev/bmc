<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

error_log("=== DAILY TRANSACTIONS API DEBUG ===");
error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Request URI: " . $_SERVER['REQUEST_URI']);

$raw_input = file_get_contents('php://input');
error_log("Raw Input: " . $raw_input);

// Debug session
error_log("Session debug: " . json_encode([
    'user_id' => $_SESSION['user_id'] ?? 'null',
    'staff_id' => $_SESSION['staff_id'] ?? 'null', 
    'shop_id' => $_SESSION['shop_id'] ?? 'null',
    'username' => $_SESSION['username'] ?? 'null'
]));

$input = json_decode($raw_input, true);
$action = $input['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'get_daily_transactions':
        getDailyTransactions($pdo, $input);
        break;
    case 'get_transaction_summary':
        getTransactionSummary($pdo, $input);
        break;
    case 'get_recent_payments':
        getRecentPayments($pdo, $input);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Action không hợp lệ']);
        break;
}

/**
 * Xác định thông tin user/staff hiện tại và shop_id
 */
function getCurrentUserInfo($input) {
    // Ưu tiên input truyền vào, sau đó mới đến session
    $shop_id = $input['shop_id'] ?? $_SESSION['shop_id'] ?? null;
    $user_id = $input['user_id'] ?? $_SESSION['user_id'] ?? null;
    $staff_id = $input['staff_id'] ?? $_SESSION['staff_id'] ?? null;
    
    $result = [
        'shop_id' => $shop_id,
        'user_id' => null,
        'staff_id' => null,
        'current_user_type' => null,
        'current_user_id' => null
    ];
    
    // Xác định loại user hiện tại
    if (!empty($user_id)) {
        $result['user_id'] = $user_id;
        $result['current_user_type'] = 'owner';
        $result['current_user_id'] = $user_id;
    } elseif (!empty($staff_id)) {
        $result['staff_id'] = $staff_id;
        $result['current_user_type'] = 'staff';
        $result['current_user_id'] = $staff_id;
    }
    
    error_log("Current user info: " . json_encode($result));
    return $result;
}

/**
 * Lấy shop_id từ staff nếu cần thiết
 */
function getShopIdFromStaff($pdo, $staff_id) {
    try {
        $stmt = $pdo->prepare("SELECT shop_id FROM staff WHERE staff_id = ? LIMIT 1");
        $stmt->execute([$staff_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['shop_id'] : null;
    } catch (Exception $e) {
        error_log("Error getting shop_id from staff: " . $e->getMessage());
        return null;
    }
}

/**
 * Lấy danh sách giao dịch trong ngày - UPDATED WITH DELETED CONTRACTS
 */
function getDailyTransactions($pdo, $input) {
    try {
        // Lấy ngày từ input hoặc dùng ngày hôm nay
        $date = $input['date'] ?? date('Y-m-d');
        $limit = $input['limit'] ?? 50; // Tăng limit để chứa cả deleted contracts
        
        // Xác định thông tin user hiện tại
        $userInfo = getCurrentUserInfo($input);
        
        // Nếu là staff mà chưa có shop_id, lấy từ database
        if ($userInfo['current_user_type'] === 'staff' && empty($userInfo['shop_id'])) {
            $userInfo['shop_id'] = getShopIdFromStaff($pdo, $userInfo['staff_id']);
        }
        
        error_log("Getting daily transactions for date: $date");
        error_log("User info: " . json_encode($userInfo));

        // Array để chứa tất cả giao dịch
        $allTransactions = [];

        // 1. Lấy giao dịch thường từ bảng transactions
        $regularTransactions = getRegularTransactions($pdo, $date, $userInfo, $limit);
        $allTransactions = array_merge($allTransactions, $regularTransactions);

        // 2. Lấy payment transactions nếu cần
        if (empty($regularTransactions)) {
            $paymentTransactions = getPaymentTransactionsOfDay($pdo, $date, $userInfo, $limit);
            $allTransactions = array_merge($allTransactions, $paymentTransactions);
        }

        // 3. Lấy deleted contracts (đóng/xóa hợp đồng) trong ngày
        $deletedContracts = getDeletedContractsOfDay($pdo, $date, $userInfo, $limit);
        $allTransactions = array_merge($allTransactions, $deletedContracts);

        // 4. Sắp xếp tất cả theo thời gian tạo (mới nhất trước)
        usort($allTransactions, function($a, $b) {
            $timeA = strtotime($a['created_at'] ?? $a['deleted_at'] ?? '1970-01-01');
            $timeB = strtotime($b['created_at'] ?? $b['deleted_at'] ?? '1970-01-01');
            return $timeB - $timeA; // Sắp xếp giảm dần
        });

        // 5. Giới hạn số lượng kết quả
        $allTransactions = array_slice($allTransactions, 0, $limit);

        // 6. Lấy tổng kết ngày
        $summary = getDailySummary($pdo, $date, $userInfo);

        echo json_encode([
            'success' => true,
            'data' => $allTransactions,
            'summary' => $summary,
            'date' => $date,
            'total_count' => count($allTransactions),
            'debug_info' => [
                'user_info' => $userInfo,
                'regular_count' => count($regularTransactions),
                'payment_count' => count($paymentTransactions ?? []),
                'deleted_count' => count($deletedContracts)
            ]
        ]);

    } catch (PDOException $e) {
        error_log("Database Error in getDailyTransactions: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    } catch (Exception $e) {
        error_log("General Error in getDailyTransactions: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()]);
    }
}

/**
 * Lấy giao dịch thường từ bảng transactions
 */
function getRegularTransactions($pdo, $date, $userInfo, $limit = 20) {
    try {
        $sql = "
            SELECT 
                t.id,
                t.transaction_code,
                t.transaction_type,
                t.category,
                t.amount,
                t.description,
                t.payment_method,
                t.created_by,
                t.transaction_date,
                DATE_FORMAT(t.created_at, '%H:%i') as formatted_time,
                DATE_FORMAT(t.created_at, '%d/%m/%Y %H:%i:%s') as formatted_datetime,
                t.reference_id,
                t.shop_id as transaction_shop_id,
                t.created_at,
                
                -- Thông tin khách hàng (nếu có) từ hợp đồng
                c.customer_name,
                c.customer_phone,
                
                -- Thông tin thanh toán (nếu có) từ payment_transactions
                pt.schedule_id,
                pt.payment_date as actual_payment_date,
                ps.period_number,
                
                -- Thông tin user tạo - JOIN cả users và staff
                COALESCE(u.username, s.username, 'Unknown') as created_by_username,
                COALESCE(u.store_name, s.full_name, '') as store_name,
                
                -- Phân loại nguồn
                'transaction' as source_type
                
            FROM transactions t
            LEFT JOIN contracts c ON t.reference_id = c.id AND t.category IN ('loan_disbursement', 'contract_related', 'payment')
            LEFT JOIN payment_transactions pt ON t.reference_id = pt.id AND t.category = 'payment'
            LEFT JOIN payment_schedules ps ON pt.schedule_id = ps.id
            LEFT JOIN users u ON t.created_by = u.user_id
            LEFT JOIN staff s ON t.created_by = s.staff_id
            WHERE DATE(t.transaction_date) = :date
        ";

        $params = [':date' => $date];

        // Thêm điều kiện shop_id nếu có
        if (!empty($userInfo['shop_id'])) {
            $sql .= " AND t.shop_id = :shop_id";
            $params[':shop_id'] = $userInfo['shop_id'];
        }

        // Điều kiện user/staff
        if ($userInfo['current_user_type'] === 'staff' && !empty($userInfo['staff_id'])) {
            $sql .= " AND t.created_by = :staff_id";
            $params[':staff_id'] = $userInfo['staff_id'];
        }

        $sql .= " ORDER BY t.created_at DESC LIMIT :limit";
        $params[':limit'] = $limit;

        $stmt = $pdo->prepare($sql);
        
        foreach ($params as $key => $value) {
            if ($key === ':limit') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        error_log("Error getting regular transactions: " . $e->getMessage());
        return [];
    }
}

/**
 * Lấy các hợp đồng bị xóa/đóng trong ngày - NEW FUNCTION
 */
function getDeletedContractsOfDay($pdo, $date, $userInfo, $limit = 20) {
    try {
        $sql = "
            SELECT 
                dc.id,
                CONCAT('DC_', dc.id) as transaction_code,
                CASE 
                    WHEN dc.deletion_status = 'closed' THEN 'contract_closure'
                    ELSE 'contract_deletion'
                END as transaction_type,
                'contract_action' as category,
                dc.total_money as amount,
                CONCAT(
                    CASE 
                        WHEN dc.deletion_status = 'closed' THEN 'Đóng hợp đồng: '
                        ELSE 'Xóa hợp đồng: '
                    END,
                    dc.customer_name, ' (', dc.code_id, ')'
                ) as description,
                'system' as payment_method,
                dc.deleted_by as created_by,
                DATE(dc.deleted_at) as transaction_date,
                DATE_FORMAT(dc.deleted_at, '%H:%i') as formatted_time,
                DATE_FORMAT(dc.deleted_at, '%d/%m/%Y %H:%i:%s') as formatted_datetime,
                dc.original_contract_id as reference_id,
                dc.shop_id as transaction_shop_id,
                dc.deleted_at as created_at,
                
                -- Thông tin khách hàng
                dc.customer_name,
                dc.customer_phone,
                
                -- Thông tin bổ sung
                NULL as schedule_id,
                NULL as actual_payment_date,
                NULL as period_number,
                
                -- Thông tin người thực hiện
                dc.deleted_by as created_by_username,
                dc.deleted_by as store_name,
                
                -- Phân loại nguồn
                'deleted_contract' as source_type,
                
                -- Thông tin đặc biệt cho deleted contracts
                dc.deletion_status,
                dc.total_paid,
                dc.amount_remaining,
                CASE 
                    WHEN dc.deletion_status = 'closed' THEN dc.completion_date
                    ELSE dc.deleted_at
                END as action_date
                
            FROM deleted_contracts dc
            WHERE DATE(dc.deleted_at) = :date
        ";

        $params = [':date' => $date];

        // Thêm điều kiện shop_id
        if (!empty($userInfo['shop_id'])) {
            $sql .= " AND dc.shop_id = :shop_id";
            $params[':shop_id'] = $userInfo['shop_id'];
        }

        // Điều kiện user/staff - chỉ áp dụng nếu cần hạn chế quyền
        // Thường thì việc đóng/xóa hợp đồng nên hiển thị cho tất cả trong shop
        
        $sql .= " ORDER BY dc.deleted_at DESC LIMIT :limit";
        $params[':limit'] = $limit;

        $stmt = $pdo->prepare($sql);
        
        foreach ($params as $key => $value) {
            if ($key === ':limit') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        error_log("Error getting deleted contracts: " . $e->getMessage());
        return [];
    }
}

/**
 * Lấy giao dịch thanh toán từ bảng payment_transactions - EXISTING FUNCTION
 */
function getPaymentTransactionsOfDay($pdo, $date, $userInfo, $limit = 20) {
    try {
        $sql = "
            SELECT 
                pt.id,
                CONCAT('PT_', pt.id) as transaction_code,
                'income' as transaction_type,
                'payment' as category,
                pt.amount_paid as amount,
                CONCAT('Thanh toán kỳ ', COALESCE(ps.period_number, '?'), ' - ', c.customer_name) as description,
                pt.payment_method,
                CASE 
                    WHEN pt.user_id IS NOT NULL THEN pt.user_id
                    WHEN pt.staff_id IS NOT NULL THEN pt.staff_id
                    ELSE NULL
                END as created_by,
                pt.payment_date as transaction_date,
                DATE_FORMAT(pt.created_at, '%H:%i') as formatted_time,
                DATE_FORMAT(pt.created_at, '%d/%m/%Y %H:%i:%s') as formatted_datetime,
                pt.contract_id as reference_id,
                pt.shop_id as transaction_shop_id,
                pt.created_at,
                
                -- Thông tin khách hàng
                c.customer_name,
                c.customer_phone,
                
                -- Thông tin thanh toán
                pt.schedule_id,
                pt.payment_date as actual_payment_date,
                ps.period_number,
                
                -- Thông tin user - JOIN cả users và staff
                COALESCE(u.username, s.username, 'Unknown') as created_by_username,
                COALESCE(u.store_name, s.full_name, '') as store_name,
                
                -- Phân loại nguồn
                'payment_transaction' as source_type
                
            FROM payment_transactions pt
            JOIN contracts c ON pt.contract_id = c.id
            LEFT JOIN payment_schedules ps ON pt.schedule_id = ps.id
            LEFT JOIN users u ON pt.user_id = u.user_id
            LEFT JOIN staff s ON pt.staff_id = s.staff_id
            WHERE DATE(pt.payment_date) = :date 
            AND pt.status = 'completed'
        ";

        $params = [':date' => $date];

        if (!empty($userInfo['shop_id'])) {
            $sql .= " AND pt.shop_id = :shop_id";
            $params[':shop_id'] = $userInfo['shop_id'];
        }

        if ($userInfo['current_user_type'] === 'staff' && !empty($userInfo['staff_id'])) {
            $sql .= " AND pt.staff_id = :staff_id";
            $params[':staff_id'] = $userInfo['staff_id'];
        }

        $sql .= " ORDER BY pt.created_at DESC LIMIT :limit";
        $params[':limit'] = $limit;

        $stmt = $pdo->prepare($sql);
        
        foreach ($params as $key => $value) {
            if ($key === ':limit') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        error_log("Error getting payment transactions: " . $e->getMessage());
        return [];
    }
}

/**
 * Lấy tổng kết giao dịch trong ngày - UPDATED
 */
function getDailySummary($pdo, $date, $userInfo) {
    try {
        // Tổng thu chi từ bảng transactions
        $sql = "
            SELECT 
                SUM(CASE WHEN transaction_type = 'income' THEN amount ELSE 0 END) as total_income,
                SUM(CASE WHEN transaction_type = 'expense' THEN amount ELSE 0 END) as total_expense,
                COUNT(*) as total_transactions
            FROM transactions 
            WHERE DATE(transaction_date) = :date
        ";

        $params = [':date' => $date];

        if (!empty($userInfo['shop_id'])) {
            $sql .= " AND shop_id = :shop_id";
            $params[':shop_id'] = $userInfo['shop_id'];
        }

        if ($userInfo['current_user_type'] === 'staff' && !empty($userInfo['staff_id'])) {
            $sql .= " AND created_by = :staff_id";
            $params[':staff_id'] = $userInfo['staff_id'];
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $summary = $stmt->fetch(PDO::FETCH_ASSOC);

        // Thêm thu từ payment_transactions
        $paymentSql = "
            SELECT 
                SUM(amount_paid) as payment_income,
                COUNT(*) as payment_count
            FROM payment_transactions pt
            WHERE DATE(pt.payment_date) = :date 
            AND pt.status = 'completed'
        ";

        $paymentParams = [':date' => $date];

        if (!empty($userInfo['shop_id'])) {
            $paymentSql .= " AND pt.shop_id = :shop_id";
            $paymentParams[':shop_id'] = $userInfo['shop_id'];
        }

        if ($userInfo['current_user_type'] === 'staff' && !empty($userInfo['staff_id'])) {
            $paymentSql .= " AND pt.staff_id = :staff_id";
            $paymentParams[':staff_id'] = $userInfo['staff_id'];
        }

        $paymentStmt = $pdo->prepare($paymentSql);
        $paymentStmt->execute($paymentParams);
        $paymentSummary = $paymentStmt->fetch(PDO::FETCH_ASSOC);

        // Thêm thống kê deleted contracts
        $deletedSql = "
            SELECT 
                COUNT(*) as deleted_count,
                COUNT(CASE WHEN deletion_status = 'closed' THEN 1 END) as closed_count,
                COUNT(CASE WHEN deletion_status = 'deleted' THEN 1 END) as deleted_count_only
            FROM deleted_contracts dc
            WHERE DATE(dc.deleted_at) = :date
        ";

        $deletedParams = [':date' => $date];

        if (!empty($userInfo['shop_id'])) {
            $deletedSql .= " AND dc.shop_id = :shop_id";
            $deletedParams[':shop_id'] = $userInfo['shop_id'];
        }

        $deletedStmt = $pdo->prepare($deletedSql);
        $deletedStmt->execute($deletedParams);
        $deletedSummary = $deletedStmt->fetch(PDO::FETCH_ASSOC);

        // Tổng hợp
        $totalIncome = ($summary['total_income'] ?? 0) + ($paymentSummary['payment_income'] ?? 0);
        $totalExpense = $summary['total_expense'] ?? 0;
        $netAmount = $totalIncome - $totalExpense;
        $totalCount = ($summary['total_transactions'] ?? 0) + ($paymentSummary['payment_count'] ?? 0) + ($deletedSummary['deleted_count'] ?? 0);

        return [
            'total_income' => $totalIncome,
            'total_expense' => $totalExpense,
            'net_amount' => $netAmount,
            'total_transactions' => $totalCount,
            'payment_income' => $paymentSummary['payment_income'] ?? 0,
            'payment_count' => $paymentSummary['payment_count'] ?? 0,
            'transactions_income' => $summary['total_income'] ?? 0,
            'transactions_count' => $summary['total_transactions'] ?? 0,
            'contracts_closed' => $deletedSummary['closed_count'] ?? 0,
            'contracts_deleted' => $deletedSummary['deleted_count_only'] ?? 0,
            'total_contract_actions' => $deletedSummary['deleted_count'] ?? 0
        ];

    } catch (Exception $e) {
        error_log("Error getting daily summary: " . $e->getMessage());
        return [
            'total_income' => 0,
            'total_expense' => 0,
            'net_amount' => 0,
            'total_transactions' => 0,
            'contracts_closed' => 0,
            'contracts_deleted' => 0,
            'total_contract_actions' => 0
        ];
    }
}

/**
 * Lấy tổng quan giao dịch theo khoảng thời gian - EXISTING
 */
function getTransactionSummary($pdo, $input) {
    try {
        $from_date = $input['from_date'] ?? date('Y-m-d', strtotime('-7 days'));
        $to_date = $input['to_date'] ?? date('Y-m-d');
        $userInfo = getCurrentUserInfo($input);
        
        if ($userInfo['current_user_type'] === 'staff' && empty($userInfo['shop_id'])) {
            $userInfo['shop_id'] = getShopIdFromStaff($pdo, $userInfo['staff_id']);
        }

        $sql = "
            SELECT 
                DATE(transaction_date) as date,
                SUM(CASE WHEN transaction_type = 'income' THEN amount ELSE 0 END) as daily_income,
                SUM(CASE WHEN transaction_type = 'expense' THEN amount ELSE 0 END) as daily_expense,
                COUNT(*) as daily_count
            FROM transactions 
            WHERE DATE(transaction_date) BETWEEN :from_date AND :to_date
        ";

        $params = [
            ':from_date' => $from_date,
            ':to_date' => $to_date
        ];

        if (!empty($userInfo['shop_id'])) {
            $sql .= " AND shop_id = :shop_id";
            $params[':shop_id'] = $userInfo['shop_id'];
        }

        if ($userInfo['current_user_type'] === 'staff' && !empty($userInfo['staff_id'])) {
            $sql .= " AND created_by = :staff_id";
            $params[':staff_id'] = $userInfo['staff_id'];
        }

        $sql .= " GROUP BY DATE(transaction_date) ORDER BY DATE(transaction_date) DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $summary = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => $summary,
            'period' => [
                'from' => $from_date,
                'to' => $to_date
            ],
            'user_info' => $userInfo
        ]);

    } catch (Exception $e) {
        error_log("Error in getTransactionSummary: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
    }
}

/**
 * Lấy các khoản thanh toán gần đây - EXISTING
 */
function getRecentPayments($pdo, $input) {
    try {
        $limit = $input['limit'] ?? 10;
        $userInfo = getCurrentUserInfo($input);
        
        if ($userInfo['current_user_type'] === 'staff' && empty($userInfo['shop_id'])) {
            $userInfo['shop_id'] = getShopIdFromStaff($pdo, $userInfo['staff_id']);
        }

        $sql = "
            SELECT 
                pt.id,
                pt.transaction_code,
                pt.amount_paid,
                pt.payment_date,
                pt.payment_method,
                pt.created_at,
                c.customer_name,
                c.code_id as contract_code,
                ps.period_number,
                DATE_FORMAT(pt.created_at, '%H:%i') as formatted_time,
                DATE_FORMAT(pt.created_at, '%d/%m/%Y') as formatted_date
            FROM payment_transactions pt
            JOIN contracts c ON pt.contract_id = c.id
            LEFT JOIN payment_schedules ps ON pt.schedule_id = ps.id
            WHERE pt.status = 'completed'
        ";

        $params = [];

        if (!empty($userInfo['shop_id'])) {
            $sql .= " AND pt.shop_id = :shop_id";
            $params[':shop_id'] = $userInfo['shop_id'];
        }

        if ($userInfo['current_user_type'] === 'staff' && !empty($userInfo['staff_id'])) {
            $sql .= " AND pt.staff_id = :staff_id";
            $params[':staff_id'] = $userInfo['staff_id'];
        }

        $sql .= " ORDER BY pt.created_at DESC LIMIT :limit";
        $params[':limit'] = $limit;

        $stmt = $pdo->prepare($sql);
        
        foreach ($params as $key => $value) {
            if ($key === ':limit') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => $payments,
            'total_count' => count($payments),
            'user_info' => $userInfo
        ]);

    } catch (Exception $e) {
        error_log("Error in getRecentPayments: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
    }
}
?>