<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

try {
    // Lấy parameters từ GET request
    $query = $_GET['query'] ?? '';
    $userId = $_GET['userId'] ?? null;
    $shopId = $_GET['shopId'] ?? null;
    $limit = (int)($_GET['limit'] ?? 5);
    
    // Validate input
    if (empty($query)) {
        echo json_encode(['success' => false, 'message' => 'Query không được để trống']);
        exit();
    }
    
    if (strlen($query) < 2) {
        echo json_encode(['success' => false, 'message' => 'Query phải có ít nhất 2 ký tự']);
        exit();
    }
    
    // Validate limit
    if ($limit < 1 || $limit > 20) {
        $limit = 5;
    }
    
    // Chuẩn bị WHERE conditions
    $whereConditions = [];
    $queryParams = [];
    
    // Filter theo shop và user
    if ($shopId) {
        $whereConditions[] = "c.shop_id = :shop_id";
        $queryParams[':shop_id'] = $shopId;
    }
    
    if ($userId) {
        $whereConditions[] = "c.user_id = :user_id";
        $queryParams[':user_id'] = $userId;
    }
    
    // Search conditions - tìm kiếm trong tên khách hàng, mã hợp đồng, và SĐT
    $searchConditions = [
        "c.customer_name LIKE :search1",
        "c.code_id LIKE :search2", 
        "c.customer_phone LIKE :search3"
    ];
    
    $whereConditions[] = "(" . implode(" OR ", $searchConditions) . ")";
    $queryParams[':search1'] = "%$query%";
    $queryParams[':search2'] = "%$query%";
    $queryParams[':search3'] = "%$query%";
    
    $whereClause = empty($whereConditions) ? '' : 'WHERE ' . implode(' AND ', $whereConditions);
    
    // SQL query để lấy suggestions
    $sql = "SELECT DISTINCT
                c.id,
                c.code_id,
                c.customer_name,
                c.customer_phone,
                CASE 
                    WHEN c.code_id LIKE :search_code THEN CONCAT(c.code_id, ' - ', c.customer_name)
                    WHEN c.customer_name LIKE :search_name THEN CONCAT(c.customer_name, ' (', c.code_id, ')')
                    WHEN c.customer_phone LIKE :search_phone THEN CONCAT(c.customer_phone, ' - ', c.customer_name)
                    ELSE CONCAT(c.code_id, ' - ', c.customer_name)
                END as display_text,
                CASE 
                    WHEN c.code_id LIKE :search_code2 THEN c.code_id
                    WHEN c.customer_name LIKE :search_name2 THEN c.customer_name
                    WHEN c.customer_phone LIKE :search_phone2 THEN c.customer_phone
                    ELSE c.code_id
                END as value
            FROM contracts c
            $whereClause
            ORDER BY 
                CASE 
                    WHEN c.code_id = :exact_query THEN 1
                    WHEN c.customer_name = :exact_query2 THEN 2
                    WHEN c.code_id LIKE :starts_with THEN 3
                    WHEN c.customer_name LIKE :starts_with2 THEN 4
                    ELSE 5
                END,
                c.created_at DESC
            LIMIT :limit";
    
    // Thêm các parameters cho ordering
    $queryParams[':search_code'] = "%$query%";
    $queryParams[':search_name'] = "%$query%";
    $queryParams[':search_phone'] = "%$query%";
    $queryParams[':search_code2'] = "%$query%";
    $queryParams[':search_name2'] = "%$query%";
    $queryParams[':search_phone2'] = "%$query%";
    $queryParams[':exact_query'] = $query;
    $queryParams[':exact_query2'] = $query;
    $queryParams[':starts_with'] = "$query%";
    $queryParams[':starts_with2'] = "$query%";
    $queryParams[':limit'] = $limit;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($queryParams);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format kết quả cho frontend
    $suggestions = [];
    foreach ($results as $row) {
        $suggestions[] = [
            'id' => $row['id'],
            'code_id' => $row['code_id'],
            'customer_name' => $row['customer_name'],
            'customer_phone' => $row['customer_phone'],
            'display_text' => $row['display_text'],
            'value' => $row['value']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'suggestions' => $suggestions,
        'query' => $query,
        'total' => count($suggestions)
    ]);
    
} catch(Exception $e) {
    error_log("Error in get_search_suggestions.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Có lỗi xảy ra khi tìm kiếm: ' . $e->getMessage(),
        'suggestions' => []
    ]);
}
?>