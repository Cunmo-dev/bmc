<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON và thoát
function jsonResponse($data) {
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

// Debug thông tin ban đầu
logDebug("Save Staff Started", [
    'method' => $_SERVER['REQUEST_METHOD'],
    'session_id' => session_id(),
    'user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'NOT SET',
    'post_data' => $_POST
]);

define('BASE_PATH', '/vay/');

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    logDebug("Login check failed", $_SESSION);
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Chỉ xử lý POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        logDebug("PDO connection not found");
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy user_id từ session
    $currentUserId = $_SESSION['user_id'];
    
    // Lấy dữ liệu từ POST với validation an toàn hơn
    $staffId = isset($_POST['staffId']) ? intval($_POST['staffId']) : 0;
    $shopId = isset($_POST['shopId']) ? intval($_POST['shopId']) : 0;
    $userName = isset($_POST['userName']) ? trim($_POST['userName']) : '';
    $fullName = isset($_POST['fullName']) ? trim($_POST['fullName']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $confirmPassword = isset($_POST['confirmPassword']) ? trim($_POST['confirmPassword']) : '';
    $status = isset($_POST['status']) ? intval($_POST['status']) : 1;

    logDebug("Save Staff Request", [
        'staffId' => $staffId,
        'shopId' => $shopId,
        'userName' => $userName,
        'fullName' => $fullName,
        'status' => $status,
        'userId' => $currentUserId
    ]);

    // Validate dữ liệu
    $errors = [];

    if (empty($shopId)) {
        $errors[] = 'Vui lòng chọn cửa hàng';
    }

    if (empty($userName)) {
        $errors[] = 'Vui lòng nhập tên đăng nhập';
    } elseif (mb_strlen($userName) < 3) {
        $errors[] = 'Tên đăng nhập phải có ít nhất 3 ký tự';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $userName)) {
        $errors[] = 'Tên đăng nhập chỉ được chứa chữ cái, số và dấu gạch dưới';
    }

    if (empty($fullName)) {
        $errors[] = 'Vui lòng nhập họ tên';
    } elseif (mb_strlen($fullName) < 2) {
        $errors[] = 'Họ tên phải có ít nhất 2 ký tự';
    }

    // Kiểm tra password cho trường hợp tạo mới hoặc đổi password
    if ($staffId == 0 || !empty($password)) {
        if (empty($password)) {
            $errors[] = 'Vui lòng nhập mật khẩu';
        } elseif (strlen($password) < 6) {
            $errors[] = 'Mật khẩu phải có ít nhất 6 ký tự';
        } elseif ($password !== $confirmPassword) {
            $errors[] = 'Mật khẩu xác nhận không khớp';
        }
    }

    // Validate status
    if (!in_array($status, [0, 1])) {
        $status = 1; // Default active
    }

    if (!empty($errors)) {
        jsonResponse([
            'success' => false,
            'message' => implode('<br>', $errors)
        ]);
    }

    // Kiểm tra shop có thuộc về user hiện tại không
    $checkShopQuery = "SELECT * FROM shops WHERE id = ? AND user_id = ?";
    $checkShopStmt = $pdo->prepare($checkShopQuery);
    
    if (!$checkShopStmt) {
        logDebug("Prepare check shop query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare statement cho check shop");
    }
    
    $checkShopStmt->execute([$shopId, $currentUserId]);
    $ownerShopData = $checkShopStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$ownerShopData) {
        jsonResponse([
            'success' => false,
            'message' => 'Cửa hàng không hợp lệ hoặc bạn không có quyền!'
        ]);
    }

    if ($staffId == 0) {
        // TẠO MỚI NHÂN VIÊN
        
        // Kiểm tra tên đăng nhập đã tồn tại chưa (trong cả 2 bảng staff và users)
        $checkUserQuery = "SELECT COUNT(*) FROM staff WHERE username = ? 
                          UNION ALL 
                          SELECT COUNT(*) FROM users WHERE username = ?";
        $checkUserStmt = $pdo->prepare($checkUserQuery);
        
        if (!$checkUserStmt) {
            logDebug("Prepare check user query failed", $pdo->errorInfo());
            throw new Exception("Lỗi prepare statement cho check user");
        }
        
        $checkUserStmt->execute([$userName, $userName]);
        $results = $checkUserStmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (array_sum($results) > 0) {
            jsonResponse([
                'success' => false,
                'message' => 'Tên đăng nhập đã tồn tại trong hệ thống!'
            ]);
        }

        // Bắt đầu transaction để đảm bảo data consistency
        $pdo->beginTransaction();

        try {
            // Mã hóa mật khẩu
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // BƯỚC 1: Insert vào bảng staff
            $insertStaffQuery = "INSERT INTO staff (shop_id, user_id, username, password, full_name, email, phone, status, created_at) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            $insertStaffStmt = $pdo->prepare($insertStaffQuery);
            
            if (!$insertStaffStmt) {
                throw new Exception("Lỗi prepare statement cho insert staff");
            }
            
            // Email tạm thời (có thể để NULL nếu cột cho phép)
            $tempEmail = $userName . '@staff.local';
            $tempPhone = '';
            
            $insertStaffResult = $insertStaffStmt->execute([
                $ownerShopData['shop_id'],  // shop_id từ shop của owner (CÙNG SHOP_ID)
                $currentUserId,             // user_id (chủ shop)
                $userName,                  // username
                $hashedPassword,            // password
                $fullName,                  // full_name
                $tempEmail,                 // email
                $tempPhone,                 // phone
                $status                     // status
            ]);

            if (!$insertStaffResult) {
                throw new Exception("Không thể tạo nhân viên!");
            }

            $newStaffDbId = $pdo->lastInsertId();
            
            // Lấy staff_id được tự động tạo bởi trigger
            $getStaffIdQuery = "SELECT staff_id FROM staff WHERE id = ?";
            $getStaffIdStmt = $pdo->prepare($getStaffIdQuery);
            $getStaffIdStmt->execute([$newStaffDbId]);
            $staffIdGenerated = $getStaffIdStmt->fetchColumn();
            
            if (!$staffIdGenerated) {
                throw new Exception("Không thể lấy staff_id được tạo!");
            }

            // BƯỚC 2: Insert vào bảng users để nhân viên có thể đăng nhập
            // *** KEY FIX: Sử dụng CÙNG store_id với owner để truy cập cùng dữ liệu ***
            $staffUserID = $staffIdGenerated;
            $storeID = $ownerShopData['shop_id']; // CÙNG SHOP_ID với owner

            $insertUserQuery = "INSERT INTO users (user_id, store_id, username, email, password, store_name, status, created_at) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
            $insertUserStmt = $pdo->prepare($insertUserQuery);
            
            if (!$insertUserStmt) {
                throw new Exception("Lỗi prepare statement cho insert user");
            }
            
            $staffStoreName = $ownerShopData['shop_name']; // CÙNG tên shop
            
            $insertUserResult = $insertUserStmt->execute([
                $staffUserID,           // user_id sẽ là staff_id 
                $storeID,              // store_id = shop_id của owner (CÙNG SHOP)
                $userName,             // username
                $tempEmail,            // email
                $hashedPassword,       // password (cùng password với staff)
                $staffStoreName,       // store_name (CÙNG tên shop)
                $status                // status
            ]);

            if (!$insertUserResult) {
                throw new Exception("Không thể tạo user login cho nhân viên!");
            }

            $newUserId = $pdo->lastInsertId();

            // BƯỚC 3: Tạo bản ghi trong bảng shops cho nhân viên
            // *** KEY FIX: Sử dụng CÙNG shop_id để truy cập cùng dữ liệu ***
            $insertShopQuery = "INSERT INTO shops (user_id, shop_id, shop_name, shop_description, shop_address, shop_phone, shop_email, total_money_in_safe, status, created_at) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            $insertShopStmt = $pdo->prepare($insertShopQuery);
            
            if (!$insertShopStmt) {
                throw new Exception("Lỗi prepare statement cho insert shop");
            }
            
            // *** QUAN TRỌNG: Sử dụng CÙNG shop_id, CÙNG dữ liệu với owner ***
            $insertShopResult = $insertShopStmt->execute([
                $staffUserID,                                   // user_id (staff_id)
                $ownerShopData['shop_id'],                      // shop_id (CÙNG với owner)
                $ownerShopData['shop_name'],                    // shop_name (CÙNG với owner)
                $ownerShopData['shop_description'] ?? '',       // shop_description
                $ownerShopData['shop_address'] ?? '',           // shop_address  
                $ownerShopData['shop_phone'] ?? '',             // shop_phone
                $ownerShopData['shop_email'] ?? '',             // shop_email
                $ownerShopData['total_money_in_safe'] ?? 0.00,  // total_money_in_safe (CÙNG với owner)
                $status                                         // status
            ]);

            if (!$insertShopResult) {
                throw new Exception("Không thể tạo shop cho nhân viên!");
            }

            $newShopDbId = $pdo->lastInsertId();
            
            // Commit transaction
            $pdo->commit();
            
            logDebug("Staff, User and Shop created successfully", [
                'staff_db_id' => $newStaffDbId,
                'staff_id' => $staffIdGenerated,
                'user_db_id' => $newUserId,
                'shop_db_id' => $newShopDbId,
                'shared_shop_id' => $ownerShopData['shop_id'], // CÙNG shop_id
                'shop_name' => $ownerShopData['shop_name']
            ]);
            
            jsonResponse([
                'success' => true,
                'message' => 'Tạo nhân viên thành công! Tài khoản đăng nhập: ' . $userName,
                'data' => [
                    'staff_id' => $staffIdGenerated,
                    'username' => $userName,
                    'full_name' => $fullName,
                    'shop_name' => $ownerShopData['shop_name'],
                    'shared_shop_id' => $ownerShopData['shop_id'],
                    'can_login' => true,
                    'same_data_as_owner' => true
                ],
                'redirect' => './Index'
            ]);

        } catch (Exception $e) {
            // Rollback nếu có lỗi
            $pdo->rollBack();
            throw $e;
        }

    } else {
        // CẬP NHẬT NHÂN VIÊN
        
        // Kiểm tra nhân viên có tồn tại và có quyền chỉnh sửa không
        $checkStaffQuery = "SELECT s.id, s.staff_id, s.username FROM staff s 
                           WHERE s.id = ? AND s.user_id = ?";
        $checkStaffStmt = $pdo->prepare($checkStaffQuery);
        
        if (!$checkStaffStmt) {
            throw new Exception("Lỗi prepare statement cho check staff");
        }
        
        $checkStaffStmt->execute([$staffId, $currentUserId]);
        $staffData = $checkStaffStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$staffData) {
            jsonResponse([
                'success' => false,
                'message' => 'Nhân viên không tồn tại hoặc bạn không có quyền chỉnh sửa!'
            ]);
        }

        // Kiểm tra tên đăng nhập đã tồn tại chưa (trừ chính nó - kiểm tra cả 2 bảng)
        $checkUserQuery = "SELECT COUNT(*) FROM staff WHERE username = ? AND id != ? 
                          UNION ALL 
                          SELECT COUNT(*) FROM users WHERE username = ? AND user_id NOT IN (SELECT staff_id FROM staff WHERE id = ?)";
        $checkUserStmt = $pdo->prepare($checkUserQuery);
        $checkUserStmt->execute([$userName, $staffId, $userName, $staffId]);
        $results = $checkUserStmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (array_sum($results) > 0) {
            jsonResponse([
                'success' => false,
                'message' => 'Tên đăng nhập đã tồn tại!'
            ]);
        }

        // Cập nhật thông tin nhân viên
        if (!empty($password)) {
            // Cập nhật cả mật khẩu
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Cập nhật bảng staff
            $updateQuery = "UPDATE staff SET shop_id = ?, username = ?, password = ?, 
                           full_name = ?, status = ?, updated_at = NOW() WHERE id = ?";
            $updateStmt = $pdo->prepare($updateQuery);
            $updateResult = $updateStmt->execute([
                $ownerShopData['shop_id'], // CÙNG shop_id
                $userName,
                $hashedPassword,
                $fullName,
                $status,
                $staffId
            ]);
            
            // Cập nhật bảng users tương ứng
            $updateUserQuery = "UPDATE users SET store_id = ?, username = ?, password = ?, status = ?, updated_at = NOW() 
                               WHERE user_id = (SELECT staff_id FROM staff WHERE id = ?)";
            $updateUserStmt = $pdo->prepare($updateUserQuery);
            $updateUserStmt->execute([
                $ownerShopData['shop_id'], // CÙNG store_id (shop_id)
                $userName,
                $hashedPassword,
                $status,
                $staffId
            ]);

            // Cập nhật bảng shops của nhân viên (đảm bảo cùng shop_id)
            $updateShopQuery = "UPDATE shops SET shop_id = ?, status = ?, updated_at = NOW() 
                               WHERE user_id = (SELECT staff_id FROM staff WHERE id = ?)";
            $updateShopStmt = $pdo->prepare($updateShopQuery);
            $updateShopStmt->execute([
                $ownerShopData['shop_id'], // CÙNG shop_id
                $status,
                $staffId
            ]);
            
        } else {
            // Không cập nhật mật khẩu
            
            // Cập nhật bảng staff
            $updateQuery = "UPDATE staff SET shop_id = ?, username = ?, 
                           full_name = ?, status = ?, updated_at = NOW() WHERE id = ?";
            $updateStmt = $pdo->prepare($updateQuery);
            $updateResult = $updateStmt->execute([
                $ownerShopData['shop_id'], // CÙNG shop_id
                $userName,
                $fullName,
                $status,
                $staffId
            ]);
            
            // Cập nhật bảng users tương ứng (không update password)
            $updateUserQuery = "UPDATE users SET store_id = ?, username = ?, status = ?, updated_at = NOW() 
                               WHERE user_id = (SELECT staff_id FROM staff WHERE id = ?)";
            $updateUserStmt = $pdo->prepare($updateUserQuery);
            $updateUserStmt->execute([
                $ownerShopData['shop_id'], // CÙNG store_id (shop_id)
                $userName,
                $status,
                $staffId
            ]);

            // Cập nhật bảng shops của nhân viên (đảm bảo cùng shop_id)
            $updateShopQuery = "UPDATE shops SET shop_id = ?, status = ?, updated_at = NOW() 
                               WHERE user_id = (SELECT staff_id FROM staff WHERE id = ?)";
            $updateShopStmt = $pdo->prepare($updateShopQuery);
            $updateShopStmt->execute([
                $ownerShopData['shop_id'], // CÙNG shop_id
                $status,
                $staffId
            ]);
        }

        if ($updateResult && $updateStmt->rowCount() > 0) {
            logDebug("Staff updated successfully", $staffId);
            
            jsonResponse([
                'success' => true,
                'message' => 'Cập nhật nhân viên thành công!',
                'redirect' => './Index'
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => 'Không có thay đổi nào được thực hiện!'
            ]);
        }
    }

} catch (PDOException $e) {
    // Rollback nếu đang trong transaction
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    // Log error chi tiết để debug
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    // Rollback nếu đang trong transaction
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>