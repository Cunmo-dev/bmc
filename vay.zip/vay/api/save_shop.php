<?php
require_once 'database.php';

// Bật error reporting để debug (tạm thời)
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');

// Function trả về JSON và thoát
function jsonResponse($data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

// Debug thông tin ban đầu
logDebug("Save Shop Started", [
    'method' => $_SERVER['REQUEST_METHOD'],
    'session_id' => session_id(),
    'user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'NOT SET',
    'post_data' => $_POST
]);
// đây là code để chuyển về trang chủ
define('BASE_PATH', '/vay/');
// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    logDebug("Login check failed", $_SESSION);
    
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Chỉ xử lý POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

// Lấy dữ liệu từ POST với validation an toàn hơn
$shopId = isset($_POST['shopId']) ? trim($_POST['shopId']) : '0';
$shopName = isset($_POST['shopName']) ? trim($_POST['shopName']) : '';
$totalMoney = 0;

// Xử lý totalMoney an toàn hơn
if (isset($_POST['totalMoney'])) {
    if (is_numeric($_POST['totalMoney'])) {
        $totalMoney = floatval($_POST['totalMoney']);
    } else {
        // Nếu có dấu phẩy, loại bỏ và convert
        $cleanMoney = str_replace(',', '', $_POST['totalMoney']);
        if (is_numeric($cleanMoney)) {
            $totalMoney = floatval($cleanMoney);
        }
    }
}

$status = isset($_POST['status']) ? intval($_POST['status']) : 1;
$action = isset($_POST['action']) ? trim($_POST['action']) : 'create';

logDebug("Processed input data", [
    'shopId' => $shopId,
    'shopName' => $shopName,
    'totalMoney' => $totalMoney,
    'status' => $status,
    'action' => $action
]);

// Validation
$errors = [];

// Validate tên cửa hàng
if (empty($shopName)) {
    $errors['ShopName'] = 'Vui lòng nhập tên cửa hàng';
} elseif (mb_strlen($shopName) < 2) {
    $errors['ShopName'] = 'Tên cửa hàng phải có ít nhất 2 ký tự';
} elseif (mb_strlen($shopName) > 255) {
    $errors['ShopName'] = 'Tên cửa hàng không được vượt quá 255 ký tự';
}

// Validate số vốn
if ($totalMoney <= 0) {
    $errors['TotalMoneyInSafe'] = 'Số vốn đầu tư phải lớn hơn 0';
} elseif ($totalMoney > 999999999999) {
    $errors['TotalMoneyInSafe'] = 'Số vốn đầu tư không được vượt quá 999,999,999,999';
}

// Validate status
if (!in_array($status, [0, 1])) {
    $status = 1; // Default active
}

// Nếu có lỗi validation
if (!empty($errors)) {
    logDebug("Validation errors", $errors);
    jsonResponse([
        'success' => false,
        'message' => 'Dữ liệu không hợp lệ!',
        'errors' => $errors
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        logDebug("PDO connection not found");
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy user_id từ session
    $currentUserId = $_SESSION['user_id'];
    logDebug("Processing with user_id", $currentUserId);
    
    if ($action === 'create') {
        // Kiểm tra tên cửa hàng có bị trùng không (của cùng user)
        $checkQuery = "SELECT COUNT(*) FROM shops WHERE user_id = ? AND shop_name = ?";
        $checkStmt = $pdo->prepare($checkQuery);
        
        if (!$checkStmt) {
            logDebug("Prepare check query failed", $pdo->errorInfo());
            throw new Exception("Lỗi prepare statement cho check query");
        }
        
        $checkStmt->execute([$currentUserId, $shopName]);
        $duplicateCount = $checkStmt->fetchColumn();
        
        logDebug("Duplicate check result", $duplicateCount);
        
        if ($duplicateCount > 0) {
            jsonResponse([
                'success' => false,
                'message' => 'Tên cửa hàng này đã tồn tại. Vui lòng chọn tên khác!'
            ]);
        }
        
        // Tạo cửa hàng mới
        $insertQuery = "INSERT INTO shops (user_id, shop_name, total_money_in_safe, status, created_at) VALUES (?, ?, ?, ?, NOW())";
        $insertStmt = $pdo->prepare($insertQuery);
        
        if (!$insertStmt) {
            logDebug("Prepare insert query failed", $pdo->errorInfo());
            throw new Exception("Lỗi prepare statement cho insert query");
        }
        
        $insertResult = $insertStmt->execute([$currentUserId, $shopName, $totalMoney, $status]);
        
        if (!$insertResult) {
            logDebug("Insert execution failed", $insertStmt->errorInfo());
            throw new Exception("Lỗi thực thi insert query");
        }
        
        $newShopId = $pdo->lastInsertId();
        logDebug("New shop created with ID", $newShopId);
        
        // Lấy thông tin shop vừa tạo để trả về
        $getShopQuery = "SELECT shop_id FROM shops WHERE id = ?";
        $getShopStmt = $pdo->prepare($getShopQuery);
        
        if (!$getShopStmt) {
            logDebug("Prepare get shop query failed", $pdo->errorInfo());
            // Không throw exception ở đây vì shop đã được tạo thành công
        }
        
        $getShopStmt->execute([$newShopId]);
        $shopData = $getShopStmt->fetch(PDO::FETCH_ASSOC);
        
        logDebug("Retrieved shop data", $shopData);
        
        jsonResponse([
            'success' => true,
            'message' => 'Tạo cửa hàng thành công!',
            'data' => [
                'id' => $newShopId,
                'shop_id' => $shopData ? $shopData['shop_id'] : null,
                'shop_name' => $shopName,
                'total_money' => $totalMoney,
                'status' => $status
            ],
            'redirect' => './Index'
        ]);
        
    } elseif ($action === 'update') {
        // Kiểm tra shop có thuộc về user hiện tại không
        $checkOwnerQuery = "SELECT COUNT(*) FROM shops WHERE id = ? AND user_id = ?";
        $checkOwnerStmt = $pdo->prepare($checkOwnerQuery);
        
        if (!$checkOwnerStmt) {
            throw new Exception("Lỗi prepare statement cho check owner");
        }
        
        $checkOwnerStmt->execute([$shopId, $currentUserId]);
        
        if ($checkOwnerStmt->fetchColumn() == 0) {
            jsonResponse([
                'success' => false,
                'message' => 'Bạn không có quyền chỉnh sửa cửa hàng này!'
            ]);
        }
        
        // Kiểm tra tên trùng (trừ chính nó)
        $checkDuplicateQuery = "SELECT COUNT(*) FROM shops WHERE user_id = ? AND shop_name = ? AND id != ?";
        $checkDuplicateStmt = $pdo->prepare($checkDuplicateQuery);
        
        if (!$checkDuplicateStmt) {
            throw new Exception("Lỗi prepare statement cho check duplicate");
        }
        
        $checkDuplicateStmt->execute([$currentUserId, $shopName, $shopId]);
        
        if ($checkDuplicateStmt->fetchColumn() > 0) {
            jsonResponse([
                'success' => false,
                'message' => 'Tên cửa hàng này đã tồn tại. Vui lòng chọn tên khác!'
            ]);
        }
        
        // Cập nhật thông tin
        $updateQuery = "UPDATE shops SET shop_name = ?, total_money_in_safe = ?, status = ?, updated_at = NOW() WHERE id = ? AND user_id = ?";
        $updateStmt = $pdo->prepare($updateQuery);
        
        if (!$updateStmt) {
            throw new Exception("Lỗi prepare statement cho update");
        }
        
        $updateResult = $updateStmt->execute([$shopName, $totalMoney, $status, $shopId, $currentUserId]);
        
        if (!$updateResult) {
            logDebug("Update execution failed", $updateStmt->errorInfo());
            throw new Exception("Lỗi thực thi update query");
        }
        
        if ($updateStmt->rowCount() > 0) {
            jsonResponse([
                'success' => true,
                'message' => 'Cập nhật cửa hàng thành công!',
                'redirect' => './Index'
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => 'Không có thay đổi nào được thực hiện!'
            ]);
        }
    } else {
        jsonResponse([
            'success' => false,
            'message' => 'Hành động không hợp lệ!'
        ]);
    }

} catch (PDOException $e) {
    // Log error chi tiết để debug
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage() // Tạm thời show lỗi để debug
    ]);
} catch (Exception $e) {
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage() // Tạm thời show lỗi để debug
    ]);
}
?>