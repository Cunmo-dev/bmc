<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON và thoát
function jsonResponse($data) {
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

define('BASE_PATH', '/vay/');

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    logDebug("Login check failed", $_SESSION);
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Chỉ xử lý GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        logDebug("PDO connection not found");
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy user_id từ session
    $currentUserId = $_SESSION['user_id'];
    
    // Lấy parameters từ URL
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $limit = isset($_GET['limit']) ? max(1, min(100, intval($_GET['limit']))) : 50;
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    
    // Calculate offset
    $offset = ($page - 1) * $limit;
    
    logDebug("Get Staff List All Started", [
        'user_id' => $currentUserId,
        'page' => $page,
        'limit' => $limit,
        'search' => $search,
        'offset' => $offset
    ]);

    // Base query để lấy thông tin nhân viên từ bảng staff và shops
    $baseQuery = "SELECT DISTINCT
                    s.id as staff_table_id,
                    s.staff_id,
                    s.username,
                    s.full_name,
                    s.email,
                    s.phone,
                    s.status,
                    s.created_at,
                    COUNT(DISTINCT sh.shop_id) as shop_count,
                    GROUP_CONCAT(DISTINCT sh.shop_name ORDER BY sh.shop_name SEPARATOR ', ') as shop_names,
                    GROUP_CONCAT(DISTINCT sh.shop_id ORDER BY sh.shop_name SEPARATOR ',') as shop_ids_list
                  FROM staff s
                  LEFT JOIN shops sh ON s.staff_id = sh.user_id AND sh.status = 1
                  WHERE s.user_id = ?";
    
    // Debug: Thêm query để kiểm tra dữ liệu thô
    $debugQuery = "SELECT s.staff_id, s.username, sh.user_id as shop_user_id, sh.shop_name, sh.status as shop_status 
                   FROM staff s 
                   LEFT JOIN shops sh ON s.staff_id = sh.user_id 
                   WHERE s.user_id = ? 
                   LIMIT 5";
    $debugStmt = $pdo->prepare($debugQuery);
    $debugStmt->execute([$currentUserId]);
    $debugData = $debugStmt->fetchAll(PDO::FETCH_ASSOC);
    logDebug("Debug data raw", $debugData);
    
    // Thêm điều kiện tìm kiếm nếu có
    $searchCondition = '';
    $searchParams = [$currentUserId];
    
    if (!empty($search)) {
        $searchCondition = " AND (
            s.username LIKE ? OR 
            s.full_name LIKE ? OR 
            s.email LIKE ? OR 
            s.phone LIKE ? OR
            sh.shop_name LIKE ?
        )";
        $searchTerm = '%' . $search . '%';
        $searchParams = array_merge($searchParams, [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    }
    
    $groupByClause = " GROUP BY s.id, s.staff_id, s.username, s.full_name, s.email, s.phone, s.status, s.created_at";
    $orderByClause = " ORDER BY s.full_name ASC, s.created_at DESC";
    
    // Query đếm tổng số bản ghi
    $countQuery = "SELECT COUNT(DISTINCT s.id) as total 
                   FROM staff s
                   LEFT JOIN shops sh ON s.staff_id = sh.user_id AND sh.status = 1
                   WHERE s.user_id = ?" . $searchCondition;
    $countStmt = $pdo->prepare($countQuery);
    
    if (!$countStmt) {
        logDebug("Prepare count query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare count statement");
    }
    
    $countStmt->execute($searchParams);
    $totalRecords = $countStmt->fetchColumn();
    
    // Query lấy dữ liệu với phân trang
    $dataQuery = $baseQuery . $searchCondition . $groupByClause . $orderByClause . " LIMIT ? OFFSET ?";
    $dataParams = array_merge($searchParams, [$limit, $offset]);
    
    $dataStmt = $pdo->prepare($dataQuery);
    
    if (!$dataStmt) {
        logDebug("Prepare data query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare data statement");
    }
    
    $dataStmt->execute($dataParams);
    $staffList = $dataStmt->fetchAll(PDO::FETCH_ASSOC);
    
    logDebug("Found staff with shops", [
        'total_records' => $totalRecords,
        'current_page_count' => count($staffList),
        'sample_data' => isset($staffList[0]) ? $staffList[0] : null
    ]);
    
    // Format dữ liệu cho frontend
    $formattedStaff = [];
    
    foreach ($staffList as $staff) {
        // Xử lý shop names
        $shopNames = !empty($staff['shop_names']) ? $staff['shop_names'] : '';
        $shopDisplayName = empty($shopNames) ? 'Chưa phân quyền' : $shopNames;
        
        // Giới hạn độ dài hiển thị shop name
        if (strlen($shopDisplayName) > 80) {
            $shopDisplayName = substr($shopDisplayName, 0, 77) . '...';
        }
        
        // Lấy danh sách shop chi tiết nếu có
        $shopDetails = [];
        if (!empty($staff['shop_ids_list'])) {
            $shopIdsArray = explode(',', $staff['shop_ids_list']);
            
            // Lấy thông tin chi tiết các shop
            $shopDetailQuery = "SELECT shop_id, shop_name, shop_address, shop_phone, status
                               FROM shops 
                               WHERE user_id = ? AND shop_id IN (" . str_repeat('?,', count($shopIdsArray) - 1) . "?)
                               ORDER BY shop_name ASC";
            
            $shopDetailStmt = $pdo->prepare($shopDetailQuery);
            $shopDetailParams = array_merge([$staff['staff_id']], $shopIdsArray);
            $shopDetailStmt->execute($shopDetailParams);
            $shopDetails = $shopDetailStmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        // Debug log cho từng staff
        logDebug("Processing staff", [
            'staff_id' => $staff['staff_id'],
            'username' => $staff['username'],
            'shop_count' => $staff['shop_count'],
            'shop_names' => $staff['shop_names'],
            'shop_display_name' => $shopDisplayName
        ]);
        
        $formattedStaff[] = [
            'id' => $staff['staff_table_id'],
            'staff_id' => $staff['staff_id'],
            'username' => $staff['username'],
            'full_name' => $staff['full_name'],
            'email' => $staff['email'] ?? '',
            'phone' => $staff['phone'] ?? '',
            'status' => $staff['status'],
            'status_text' => $staff['status'] == 1 ? 'Hoạt động' : 'Tạm dừng',
            'created_date' => date('d/m/Y', strtotime($staff['created_at'])),
            'shop_name' => $shopDisplayName,
            'shop_count' => (int)$staff['shop_count'],
            'shops' => $shopDetails
        ];
    }
    
    // Tính toán thông tin pagination
    $totalPages = ceil($totalRecords / $limit);
    $pagination = [
        'current_page' => $page,
        'total_pages' => $totalPages,
        'total_records' => $totalRecords,
        'per_page' => $limit,
        'has_prev_page' => $page > 1,
        'has_next_page' => $page < $totalPages,
        'from' => $totalRecords > 0 ? $offset + 1 : 0,
        'to' => min($offset + $limit, $totalRecords)
    ];
    
    jsonResponse([
        'success' => true,
        'message' => 'Lấy danh sách nhân viên thành công!',
        'data' => [
            'staff_list' => $formattedStaff,
            'pagination' => $pagination
        ]
    ]);

} catch (PDOException $e) {
    // Log error chi tiết để debug
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'sql_state' => $e->errorInfo[0] ?? 'Unknown',
        'error_code' => $e->errorInfo[1] ?? 'Unknown'
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>