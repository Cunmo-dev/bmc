<?php
session_start();

try {
    // Lấy dữ liệu từ POST request
    $contractsJson = $_POST['contracts'] ?? '';
    $shopId = $_POST['shopId'] ?? '';
    $userId = $_POST['userId'] ?? '';
    $searchInfo = $_POST['searchInfo'] ?? '';
    
    // Validate dữ liệu
    if (empty($contractsJson)) {
        throw new Exception("Không có dữ liệu hợp đồng để xuất");
    }
    
    if (empty($shopId) || empty($userId)) {
        throw new Exception("Thiếu thông tin shopId hoặc userId");
    }
    
    // Decode JSON data
    $contracts = json_decode($contractsJson, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("Dữ liệu hợp đồng không hợp lệ");
    }
    
    if (empty($contracts)) {
        throw new Exception("Danh sách hợp đồng trống");
    }
    
    // Lọc chỉ các hợp đồng ngày mai đóng họ
    $tomorrowContracts = filterTomorrowContracts($contracts);
    
    if (empty($tomorrowContracts)) {
        throw new Exception("Không có hợp đồng nào đến kỳ thanh toán vào ngày mai");
    }
    
    // Kiểm tra format xuất (mặc định là xlsx)
    $format = $_POST['format'] ?? 'xlsx';
    
    if ($format === 'csv') {
        generateCSVFromData($tomorrowContracts, $searchInfo);
    } else {
        generateExcelFromData($tomorrowContracts, $searchInfo);
    }
    
} catch (Exception $e) {
    // Trả về JSON error nếu có lỗi
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'message' => 'Có lỗi xảy ra: ' . $e->getMessage()
    ]);
}

function filterTomorrowContracts($contracts) {
    $tomorrow = new DateTime('tomorrow');
    $tomorrowStr = $tomorrow->format('Y-m-d');
    $tomorrowFormatted = $tomorrow->format('d/m/Y');
    
    $tomorrowContracts = [];
    
    foreach ($contracts as $contract) {
        $isTomorrowContract = false;
        
        // Kiểm tra next_payment_date
        if (!empty($contract['next_payment_date'])) {
            $nextPaymentDate = convertToSQLDate($contract['next_payment_date']);
            if ($nextPaymentDate === $tomorrowStr) {
                $isTomorrowContract = true;
            }
        } else {
            // Tính toán dựa trên from_date và frequency
            $isTomorrowContract = calculateIsPaymentDueTomorrow($contract, $tomorrow);
        }
        
        if ($isTomorrowContract) {
            // Thêm thông tin ngày mai vào contract
            $contract['is_tomorrow_payment'] = true;
            $contract['tomorrow_date'] = $tomorrowFormatted;
            $contract['tomorrow_amount'] = $contract['money_per_period'] ?? 0;
            $contract['current_status'] = 'Ngày mai đóng họ'; // Override status
            $tomorrowContracts[] = $contract;
        }
    }
    
    return $tomorrowContracts;
}

function calculateIsPaymentDueTomorrow($contract, $tomorrowDate) {
    try {
        if (empty($contract['from_date']) || empty($contract['frequency'])) {
            return false;
        }
        
        $fromDate = new DateTime($contract['from_date']);
        $fromDate->setTime(0, 0, 0);
        
        $tomorrow = clone $tomorrowDate;
        $tomorrow->setTime(0, 0, 0);
        
        // Tính số ngày từ ngày bắt đầu đến ngày mai
        $diffDays = $tomorrow->diff($fromDate)->days;
        
        // Kiểm tra xem ngày mai có phải là ngày đóng tiền không
        if ($diffDays >= 0 && $diffDays % $contract['frequency'] === 0) {
            // Kiểm tra xem kỳ này đã được thanh toán chưa
            $periodNumber = floor($diffDays / $contract['frequency']) + 1;
            $totalPeriods = ceil($contract['loan_time'] / $contract['frequency']);
            $paidPeriods = $contract['paid_periods'] ?? 0;
            
            return $periodNumber <= $totalPeriods && $periodNumber > $paidPeriods;
        }
        
        return false;
        
    } catch (Exception $e) {
        error_log('Error calculating payment due tomorrow: ' . $e->getMessage());
        return false;
    }
}

function convertToSQLDate($dateStr) {
    if (empty($dateStr)) return null;
    
    // Nếu đã đúng format YYYY-MM-DD
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateStr)) {
        return $dateStr;
    }
    
    // Chuyển từ DD/MM/YYYY
    if (preg_match('/^\d{1,2}\/\d{1,2}\/\d{4}$/', $dateStr)) {
        $parts = explode('/', $dateStr);
        $day = str_pad($parts[0], 2, '0', STR_PAD_LEFT);
        $month = str_pad($parts[1], 2, '0', STR_PAD_LEFT);
        $year = $parts[2];
        return $year . '-' . $month . '-' . $day;
    }
    
    return null;
}

function generateExcelFromData($contracts, $searchInfo = '') {
    try {
        // Set headers for Excel download
        $tomorrow = new DateTime('tomorrow');
        $filename = 'hop_dong_dao_han_ngay_mai_' . $tomorrow->format('d-m-Y') . '_' . date('H-i-s') . '.xlsx';
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        header('Pragma: public');
        
        // Tạo file XLSX sử dụng ZipArchive
        $zip = new ZipArchive();
        $tempFile = tempnam(sys_get_temp_dir(), 'excel');
        
        if ($zip->open($tempFile, ZipArchive::CREATE) !== TRUE) {
            throw new Exception("Không thể tạo file Excel");
        }
        
        // Add files to zip
        $zip->addFromString('[Content_Types].xml', getContentTypes());
        $zip->addFromString('_rels/.rels', getRels());
        $zip->addFromString('xl/_rels/workbook.xml.rels', getWorkbookRels());
        $zip->addFromString('xl/workbook.xml', getWorkbook());
        $zip->addFromString('xl/styles.xml', getStyles());
        $zip->addFromString('xl/worksheets/sheet1.xml', getWorksheetFromData($contracts, $searchInfo));
        
        $zip->close();
        
        // Output file
        readfile($tempFile);
        unlink($tempFile);
        
    } catch (Exception $e) {
        throw $e;
    }
}

function generateCSVFromData($contracts, $searchInfo = '') {
    try {
        // Set headers for CSV download
        $tomorrow = new DateTime('tomorrow');
        $filename = 'hop_dong_dao_han_ngay_mai_' . $tomorrow->format('d-m-Y') . '_' . date('H-i-s') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        header('Pragma: public');
        
        // Xuất BOM cho UTF-8
        echo "\xEF\xBB\xBF";
        
        // Tạo CSV output
        $output = fopen('php://output', 'w');
        
        // Tiêu đề đặc biệt cho ngày mai
        $tomorrow = new DateTime('tomorrow');
        fputcsv($output, ['HỢP ĐỒNG ĐẾN KỲ THANH TOÁN NGÀY MAI - ' . $tomorrow->format('d/m/Y')]);
        fputcsv($output, []); // Dòng trống
        
        // Thêm thông tin tìm kiếm nếu có
        if (!empty($searchInfo)) {
            fputcsv($output, ['Điều kiện tìm kiếm: ' . $searchInfo]);
            fputcsv($output, []); // Dòng trống
        }
        
        // Header đặc biệt cho ngày mai
        $headers = [
            'STT', 'Mã HĐ', 'Tên khách hàng', 
            'Tiền giao khách', 'Số tiền đóng ngày mai',
            'Số ngày vay', 'Tổng số kỳ', 'Số kỳ đã đóng',
            'Tiền đã đóng', 'Tiền còn lại', 'Trạng thái',
            'Ngày vay', 'Ngày đóng tiếp theo (Ngày mai)', 
            'Ghi chú', 'Ngày tạo'
        ];
        
        fputcsv($output, $headers);
        
        // Data rows và tính tổng
        $stt = 1;
        $totals = calculateTotals($contracts);
        
        foreach ($contracts as $contract) {
            $row = buildContractRow($contract, $stt++);
            fputcsv($output, $row);
        }
        
        // Dòng tổng cộng
        if (!empty($contracts)) {
            $totalRow = buildTotalRow($totals, count($contracts));
            fputcsv($output, $totalRow);
        }
        
        fclose($output);
        
    } catch (Exception $e) {
        throw $e;
    }
}

function getWorksheetFromData($contracts, $searchInfo = '') {
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <cols>';
    
    // Định nghĩa chiều rộng cột cho view ngày mai
    $columnWidths = [
        ['min' => '1', 'max' => '1', 'width' => '5'],      // STT
        ['min' => '2', 'max' => '2', 'width' => '12'],     // Mã HĐ
        ['min' => '3', 'max' => '3', 'width' => '20'],     // Tên khách hàng
        ['min' => '4', 'max' => '4', 'width' => '15'],     // Tiền giao khách
        ['min' => '5', 'max' => '5', 'width' => '15'],     // Số tiền đóng ngày mai
        ['min' => '6', 'max' => '6', 'width' => '10'],     // Số ngày vay
        ['min' => '7', 'max' => '7', 'width' => '10'],     // Tổng số kỳ
        ['min' => '8', 'max' => '8', 'width' => '12'],     // Số kỳ đã đóng
        ['min' => '9', 'max' => '9', 'width' => '15'],     // Tiền đã đóng
        ['min' => '10', 'max' => '10', 'width' => '15'],   // Tiền còn lại
        ['min' => '11', 'max' => '11', 'width' => '12'],   // Trạng thái
        ['min' => '12', 'max' => '12', 'width' => '12'],   // Ngày vay
        ['min' => '13', 'max' => '13', 'width' => '15'],   // Ngày đóng tiếp theo
        ['min' => '14', 'max' => '14', 'width' => '20'],   // Ghi chú
        ['min' => '15', 'max' => '15', 'width' => '15']    // Ngày tạo
    ];
    
    foreach ($columnWidths as $col) {
        $xml .= '<col min="' . $col['min'] . '" max="' . $col['max'] . '" width="' . $col['width'] . '" customWidth="1"/>';
    }
    
    $xml .= '</cols>
    <sheetData>';
    
    $rowNum = 1;
    
    // Tiêu đề đặc biệt cho ngày mai
    $tomorrow = new DateTime('tomorrow');
    $xml .= '<row r="' . $rowNum . '">';
    $xml .= '<c r="A' . $rowNum . '" s="1" t="inlineStr"><is><t>HỢP ĐỒNG ĐẾN KỲ THANH TOÁN NGÀY MAI - ' . $tomorrow->format('d/m/Y') . '</t></is></c>';
    $xml .= '</row>';
    $rowNum += 2; // Bỏ qua 1 dòng
    
    // Thêm dòng thông tin tìm kiếm nếu có
    if (!empty($searchInfo)) {
        $xml .= '<row r="' . $rowNum . '">';
        $xml .= '<c r="A' . $rowNum . '" s="1" t="inlineStr"><is><t>Điều kiện tìm kiếm: ' . htmlspecialchars($searchInfo) . '</t></is></c>';
        $xml .= '</row>';
        $rowNum += 2; // Bỏ qua 1 dòng
    }
    
    // Header row đặc biệt cho ngày mai
    $xml .= '<row r="' . $rowNum . '">';
    $headers = [
        'STT', 'Mã HĐ', 'Tên khách hàng',
        'Tiền giao khách', 'Số tiền đóng ngày mai',
        'Số ngày vay', 'Tổng số kỳ', 'Số kỳ đã đóng',
        'Tiền đã đóng', 'Tiền còn lại', 'Trạng thái',
        'Ngày vay', 'Ngày đóng tiếp theo (Ngày mai)', 
        'Ghi chú', 'Ngày tạo'
    ];
    $cols = [
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 
        'J', 'K', 'L', 'M', 'N', 'O'
    ];
    
    for ($i = 0; $i < count($headers); $i++) {
        $xml .= '<c r="' . $cols[$i] . $rowNum . '" s="1" t="inlineStr">';
        $xml .= '<is><t>' . htmlspecialchars($headers[$i]) . '</t></is>';
        $xml .= '</c>';
    }
    $xml .= '</row>';
    $rowNum++;
    
    // Tính tổng
    $totals = calculateTotals($contracts);
    
    // Data rows
    foreach ($contracts as $index => $contract) {
        $xml .= buildExcelRow($contract, $index + 1, $rowNum, $cols);
        $rowNum++;
    }
    
    // Thêm dòng tổng cộng
    if (!empty($contracts)) {
        $xml .= buildExcelTotalRow($totals, count($contracts), $rowNum, $cols);
    }
    
    $xml .= '</sheetData></worksheet>';
    return $xml;
}

function calculateTotals($contracts) {
    $totals = [
        'money_given' => 0,
        'money_to_pay_tomorrow' => 0, // Thay đổi key này
        'paid' => 0,
        'remaining' => 0
    ];
    
    foreach ($contracts as $contract) {
        $totals['money_given'] += floatval($contract['total_money_received'] ?? 0);
        $totals['money_to_pay_tomorrow'] += floatval($contract['money_per_period'] ?? 0); // Tiền cần đóng ngày mai
        $totals['paid'] += floatval($contract['paid_amount'] ?? 0);
        $totals['remaining'] += floatval($contract['remaining_amount'] ?? 0);
    }
    
    return $totals;
}

function buildContractRow($contract, $stt) {
    $tomorrow = new DateTime('tomorrow');
    
    return [
        $stt,
        $contract['code_id'] ?? '',
        $contract['customer_name'] ?? '',
        number_format($contract['total_money_received'] ?? 0, 0, ',', '.'),
        number_format($contract['money_per_period'] ?? 0, 0, ',', '.'), // Tiền cần đóng ngày mai
        ($contract['loan_time'] ?? 0) . ' ngày',
        $contract['total_periods'] ?? 0,
        $contract['paid_periods'] ?? 0,
        number_format($contract['paid_amount'] ?? 0, 0, ',', '.'),
        number_format($contract['remaining_amount'] ?? 0, 0, ',', '.'),
        'Ngày mai đóng họ',
        $contract['formatted_from_date'] ?? '',
        $tomorrow->format('d/m/Y'),
        $contract['note'] ?? '',
        $contract['formatted_created_at'] ?? ''
    ];
}

function buildTotalRow($totals, $contractCount) {
    return [
        '',
        '',
        'TỔNG CỘNG (' . $contractCount . ' hợp đồng)',
        number_format($totals['money_given'], 0, ',', '.'),
        number_format($totals['money_to_pay_tomorrow'], 0, ',', '.'),
        '',
        '',
        '',
        number_format($totals['paid'], 0, ',', '.'),
        number_format($totals['remaining'], 0, ',', '.'),
        '',
        '',
        '',
        '',
        ''
    ];
}

function buildExcelRow($contract, $stt, $rowNum, $cols) {
    $xml = '<row r="' . $rowNum . '">';
    $tomorrow = new DateTime('tomorrow');
    
    // STT
    $xml .= '<c r="A' . $rowNum . '" t="n"><v>' . $stt . '</v></c>';
    
    // Mã HĐ
    $xml .= '<c r="B' . $rowNum . '" t="inlineStr"><is><t>' . htmlspecialchars($contract['code_id'] ?? '') . '</t></is></c>';
    
    // Tên khách hàng
    $xml .= '<c r="C' . $rowNum . '" t="inlineStr"><is><t>' . htmlspecialchars($contract['customer_name'] ?? '') . '</t></is></c>';
    
    // Tiền giao khách
    $xml .= '<c r="D' . $rowNum . '" s="2" t="n"><v>' . ($contract['total_money_received'] ?? 0) . '</v></c>';
    
    // Số tiền đóng ngày mai
    $xml .= '<c r="E' . $rowNum . '" s="2" t="n"><v>' . ($contract['money_per_period'] ?? 0) . '</v></c>';
    
    // Số ngày vay
    $xml .= '<c r="F' . $rowNum . '" t="inlineStr"><is><t>' . ($contract['loan_time'] ?? 0) . ' ngày</t></is></c>';
    
    // Tổng số kỳ
    $xml .= '<c r="G' . $rowNum . '" t="n"><v>' . ($contract['total_periods'] ?? 0) . '</v></c>';
    
    // Số kỳ đã đóng
    $xml .= '<c r="H' . $rowNum . '" t="n"><v>' . ($contract['paid_periods'] ?? 0) . '</v></c>';
    
    // Tiền đã đóng
    $xml .= '<c r="I' . $rowNum . '" s="2" t="n"><v>' . ($contract['paid_amount'] ?? 0) . '</v></c>';
    
    // Tiền còn lại
    $xml .= '<c r="J' . $rowNum . '" s="2" t="n"><v>' . ($contract['remaining_amount'] ?? 0) . '</v></c>';
    
    // Trạng thái
    $xml .= '<c r="K' . $rowNum . '" t="inlineStr"><is><t>Ngày mai đóng họ</t></is></c>';
    
    // Ngày vay
    $xml .= '<c r="L' . $rowNum . '" t="inlineStr"><is><t>' . htmlspecialchars($contract['formatted_from_date'] ?? '') . '</t></is></c>';
    
    // Ngày đóng tiếp theo (Ngày mai)
    $xml .= '<c r="M' . $rowNum . '" t="inlineStr"><is><t>' . $tomorrow->format('d/m/Y') . '</t></is></c>';
    
    // Ghi chú
    $xml .= '<c r="N' . $rowNum . '" t="inlineStr"><is><t>' . htmlspecialchars($contract['note'] ?? '') . '</t></is></c>';
    
    // Ngày tạo
    $xml .= '<c r="O' . $rowNum . '" t="inlineStr"><is><t>' . htmlspecialchars($contract['formatted_created_at'] ?? '') . '</t></is></c>';
    
    $xml .= '</row>';
    return $xml;
}

function buildExcelTotalRow($totals, $contractCount, $rowNum, $cols) {
    $xml = '<row r="' . $rowNum . '">';
    
    // Cột A-C: Tổng cộng
    $xml .= '<c r="A' . $rowNum . '" s="1" t="inlineStr"><is><t></t></is></c>';
    $xml .= '<c r="B' . $rowNum . '" s="1" t="inlineStr"><is><t></t></is></c>';
    $xml .= '<c r="C' . $rowNum . '" s="1" t="inlineStr"><is><t>TỔNG CỘNG (' . $contractCount . ' hợp đồng)</t></is></c>';
    
    // Tiền giao khách
    $xml .= '<c r="D' . $rowNum . '" s="1" t="n"><v>' . $totals['money_given'] . '</v></c>';
    
    // Tổng tiền cần đóng ngày mai
    $xml .= '<c r="E' . $rowNum . '" s="1" t="n"><v>' . $totals['money_to_pay_tomorrow'] . '</v></c>';
    
    // Empty cells F-H
    for ($i = 5; $i < 8; $i++) {
        $xml .= '<c r="' . $cols[$i] . $rowNum . '" s="1" t="inlineStr"><is><t></t></is></c>';
    }
    
    // Tiền đã đóng
    $xml .= '<c r="I' . $rowNum . '" s="1" t="n"><v>' . $totals['paid'] . '</v></c>';
    
    // Tiền còn lại
    $xml .= '<c r="J' . $rowNum . '" s="1" t="n"><v>' . $totals['remaining'] . '</v></c>';
    
    // Empty cells K-O
    for ($i = 10; $i < 15; $i++) {
        $xml .= '<c r="' . $cols[$i] . $rowNum . '" s="1" t="inlineStr"><is><t></t></is></c>';
    }
    
    $xml .= '</row>';
    return $xml;
}

// Các hàm helper từ file gốc
function getContentTypes() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Default Extension="xml" ContentType="application/xml"/>
    <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
    <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
    <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>';
}

function getRels() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';
}

function getWorkbookRels() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>';
}

function getWorkbook() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <sheets>
        <sheet name="Hợp đồng ngày mai đóng họ" sheetId="1" r:id="rId1"/>
    </sheets>
</workbook>';
}

function getStyles() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <fonts count="2">
        <font>
            <sz val="11"/>
            <name val="Calibri"/>
        </font>
        <font>
            <b/>
            <sz val="11"/>
            <name val="Calibri"/>
            <color rgb="FFFFFFFF"/>
        </font>
    </fonts>
    <fills count="3">
        <fill>
            <patternFill patternType="none"/>
        </fill>
        <fill>
            <patternFill patternType="gray125"/>
        </fill>
        <fill>
            <patternFill patternType="solid">
                <fgColor rgb="FF4472C4"/>
            </patternFill>
        </fill>
    </fills>
    <borders count="2">
        <border>
            <left/>
            <right/>
            <top/>
            <bottom/>
            <diagonal/>
        </border>
        <border>
            <left/>
            <right/>
            <top/>
            <bottom/>
            <diagonal/>
        </border>
    </borders>
    <cellXfs count="3">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="0" applyFont="1" applyFill="1" applyAlignment="1">
            <alignment horizontal="center"/>
        </xf>
        <xf numFmtId="3" fontId="0" fillId="0" borderId="0" applyNumberFormat="1" applyAlignment="1">
            <alignment horizontal="right"/>
        </xf>
    </cellXfs>
</styleSheet>';
}
?>