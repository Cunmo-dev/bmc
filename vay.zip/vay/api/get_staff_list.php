<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON và thoát
function jsonResponse($data) {
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

define('BASE_PATH', '/vay/');

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    logDebug("Login check failed", $_SESSION);
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Chỉ xử lý GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        logDebug("PDO connection not found");
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy user_id từ session
    $currentUserId = $_SESSION['user_id'];
    
    logDebug("Get Staff List Started", [
        'user_id' => $currentUserId
    ]);

    // Lấy danh sách nhân viên của user hiện tại
    $query = "SELECT 
                id,
                staff_id,
                username,
                full_name,
                email,
                phone,
                status,
                created_at
              FROM staff 
              WHERE user_id = ? 
              ORDER BY full_name ASC, created_at DESC";
    
    $stmt = $pdo->prepare($query);
    
    if (!$stmt) {
        logDebug("Prepare query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare statement");
    }
    
    $stmt->execute([$currentUserId]);
    $staffList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    logDebug("Found staff", count($staffList));
    
    // Format dữ liệu cho frontend
    $formattedStaff = [];
    
    foreach ($staffList as $staff) {
        $formattedStaff[] = [
            'id' => $staff['id'],
            'staff_id' => $staff['staff_id'],
            'username' => $staff['username'],
            'full_name' => $staff['full_name'],
            'email' => $staff['email'] ?? '',
            'phone' => $staff['phone'] ?? '',
            'status' => $staff['status'],
            'status_text' => $staff['status'] == 1 ? 'Hoạt động' : 'Tạm dừng',
            'created_date' => date('d/m/Y', strtotime($staff['created_at']))
        ];
    }
    
    jsonResponse([
        'success' => true,
        'message' => 'Lấy danh sách nhân viên thành công!',
        'data' => $formattedStaff,
        'total' => count($formattedStaff)
    ]);

} catch (PDOException $e) {
    // Log error chi tiết để debug
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>