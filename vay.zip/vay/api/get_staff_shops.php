<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON và thoát
function jsonResponse($data) {
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

define('BASE_PATH', '/vay/');

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    logDebug("Login check failed", $_SESSION);
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Chỉ xử lý GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        logDebug("PDO connection not found");
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy user_id từ session và staff_id từ GET
    $currentUserId = $_SESSION['user_id'];
    $staffDbId = isset($_GET['staff_id']) ? intval($_GET['staff_id']) : 0;
    
    if ($staffDbId <= 0) {
        jsonResponse([
            'success' => false,
            'message' => 'ID nhân viên không hợp lệ!'
        ]);
    }
    
    logDebug("Get Staff Shops Started", [
        'user_id' => $currentUserId,
        'staff_db_id' => $staffDbId
    ]);

    // Kiểm tra nhân viên có thuộc về user hiện tại không
    $checkStaffQuery = "SELECT staff_id FROM staff WHERE id = ? AND user_id = ?";
    $checkStaffStmt = $pdo->prepare($checkStaffQuery);
    
    if (!$checkStaffStmt) {
        logDebug("Prepare check staff query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare statement cho check staff");
    }
    
    $checkStaffStmt->execute([$staffDbId, $currentUserId]);
    $staffData = $checkStaffStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$staffData) {
        jsonResponse([
            'success' => false,
            'message' => 'Nhân viên không tồn tại hoặc bạn không có quyền!'
        ]);
    }
    
    $staffId = $staffData['staff_id'];

    // Lấy danh sách shop_id mà nhân viên hiện tại đang quản lý
    // Nhân viên sẽ có các bản ghi trong bảng shops với user_id = staff_id
    $query = "SELECT shop_id FROM shops WHERE user_id = ? ORDER BY shop_id";
    
    $stmt = $pdo->prepare($query);
    
    if (!$stmt) {
        logDebug("Prepare query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare statement");
    }
    
    $stmt->execute([$staffId]);
    $shopIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    logDebug("Found staff shops", [
        'staff_id' => $staffId,
        'shop_ids' => $shopIds
    ]);
    
    jsonResponse([
        'success' => true,
        'message' => 'Lấy danh sách cửa hàng của nhân viên thành công!',
        'data' => $shopIds,
        'total' => count($shopIds)
    ]);

} catch (PDOException $e) {
    // Log error chi tiết để debug
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>