<?php
// Include database connection
require_once 'database.php';
session_start();

try {
    // Kiểm tra method
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Lấy dữ liệu từ POST
        $contractsJson = $_POST['contracts'] ?? '';
        $shopId = $_POST['shopId'] ?? '';
        $userId = $_POST['userId'] ?? '';
        $searchInfo = $_POST['searchInfo'] ?? '';
        $format = $_POST['format'] ?? 'xlsx';
        
        // Validate required parameters
        if (empty($contractsJson) || empty($shopId) || empty($userId)) {
            throw new Exception("Thiếu thông tin cần thiết");
        }
        
        // Parse JSON data
        $deletedContracts = json_decode($contractsJson, true);
        if (!$deletedContracts || !is_array($deletedContracts)) {
            throw new Exception("Dữ liệu không hợp lệ");
        }
        
        // Tạo Excel content
        generateSimpleExcel($deletedContracts, $searchInfo);
    } else {
        // Backward compatibility - GET method (old way)
        $search = $_GET['search'] ?? '';
        $fromDate = $_GET['from_date'] ?? '';
        $toDate = $_GET['to_date'] ?? '';
        $shopId = $_GET['shopId'] ?? '';
        $userId = $_GET['userId'] ?? '';
        
        if (empty($shopId) || empty($userId)) {
            throw new Exception("Thiếu thông tin cần thiết");
        }
        
        $deletedContracts = getDeletedContracts($pdo, $search, $fromDate, $toDate, $shopId, $userId);
        generateSimpleExcel($deletedContracts);
    }
    
} catch (Exception $e) {
    // Nếu có lỗi, trả về JSON error
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Có lỗi xảy ra: ' . $e->getMessage()
    ]);
}

function generateSimpleExcel($deletedContracts, $searchInfo = null) {
    try {
        // Set headers for Excel download
        $filename = 'danh_sach_hop_dong_da_xoa_' . date('Y-m-d_H-i-s') . '.xlsx';
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        header('Pragma: public');
        
        // Tạo file XLSX đơn giản sử dụng ZipArchive
        $zip = new ZipArchive();
        $tempFile = tempnam(sys_get_temp_dir(), 'excel');
        
        if ($zip->open($tempFile, ZipArchive::CREATE) !== TRUE) {
            throw new Exception("Không thể tạo file Excel");
        }
        
        // Add files to zip
        $zip->addFromString('[Content_Types].xml', getContentTypes());
        $zip->addFromString('_rels/.rels', getRels());
        $zip->addFromString('xl/_rels/workbook.xml.rels', getWorkbookRels());
        $zip->addFromString('xl/workbook.xml', getWorkbook());
        $zip->addFromString('xl/styles.xml', getStyles());
        $zip->addFromString('xl/worksheets/sheet1.xml', getWorksheet($deletedContracts));
        
        $zip->close();
        
        // Output file
        readfile($tempFile);
        unlink($tempFile);
        
    } catch (Exception $e) {
        throw $e;
    }
}

function getContentTypes() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Default Extension="xml" ContentType="application/xml"/>
    <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
    <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
    <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>';
}

function getRels() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';
}

function getWorkbookRels() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>';
}

function getWorkbook() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <sheets>
        <sheet name="Hợp đồng đã xóa" sheetId="1" r:id="rId1"/>
    </sheets>
</workbook>';
}

function getStyles() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <fonts count="2">
        <font>
            <sz val="11"/>
            <name val="Calibri"/>
        </font>
        <font>
            <b/>
            <sz val="11"/>
            <name val="Calibri"/>
            <color rgb="FFFFFFFF"/>
        </font>
    </fonts>
    <fills count="3">
        <fill>
            <patternFill patternType="none"/>
        </fill>
        <fill>
            <patternFill patternType="gray125"/>
        </fill>
        <fill>
            <patternFill patternType="solid">
                <fgColor rgb="FF4472C4"/>
            </patternFill>
        </fill>
    </fills>
    <borders count="2">
        <border>
            <left/>
            <right/>
            <top/>
            <bottom/>
            <diagonal/>
        </border>
        <border>
            <left style="thin"/>
            <right style="thin"/>
            <top style="thin"/>
            <bottom style="thin"/>
            <diagonal/>
        </border>
    </borders>
    <cellXfs count="3">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
            <alignment horizontal="center"/>
        </xf>
        <xf numFmtId="3" fontId="0" fillId="0" borderId="1" applyNumberFormat="1" applyBorder="1" applyAlignment="1">
            <alignment horizontal="right"/>
        </xf>
    </cellXfs>
</styleSheet>';
}

function getWorksheet($deletedContracts) {
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <cols>
        <col min="1" max="1" width="8"/>
        <col min="2" max="2" width="15"/>
        <col min="3" max="3" width="25"/>
        <col min="4" max="4" width="18"/>
        <col min="5" max="5" width="18"/>
        <col min="6" max="6" width="18"/>
        <col min="7" max="7" width="18"/>
        <col min="8" max="8" width="20"/>
        <col min="9" max="9" width="18"/>
        <col min="10" max="10" width="15"/>
    </cols>
    <sheetData>';
    
    // Header row
    $xml .= '<row r="1">';
    $headers = ['STT', 'Mã hợp đồng', 'Tên khách hàng', 'Số tiền nhận', 'Tổng tiền', 'Đã trả', 'Còn lại', 'Ngày xóa', 'Người xóa', 'Trạng thái'];
    $cols = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
    
    for ($i = 0; $i < count($headers); $i++) {
        $xml .= '<c r="' . $cols[$i] . '1" s="1" t="inlineStr">';
        $xml .= '<is><t>' . htmlspecialchars($headers[$i]) . '</t></is>';
        $xml .= '</c>';
    }
    $xml .= '</row>';
    
    // Data rows
    $rowNum = 2;
    foreach ($deletedContracts as $index => $contract) {
        $xml .= '<row r="' . $rowNum . '">';
        
        // STT
        $xml .= '<c r="A' . $rowNum . '" t="n"><v>' . ($index + 1) . '</v></c>';
        
        // Mã hợp đồng
        $xml .= '<c r="B' . $rowNum . '" t="inlineStr"><is><t>' . htmlspecialchars($contract['code_id']) . '</t></is></c>';
        
        // Tên khách hàng
        $xml .= '<c r="C' . $rowNum . '" t="inlineStr"><is><t>' . htmlspecialchars($contract['customer_name']) . '</t></is></c>';
        
        // Số tiền nhận
        $xml .= '<c r="D' . $rowNum . '" s="2" t="n"><v>' . ($contract['total_money_received'] ?? 0) . '</v></c>';
        
        // Tổng tiền
        $xml .= '<c r="E' . $rowNum . '" s="2" t="n"><v>' . ($contract['total_money'] ?? 0) . '</v></c>';
        
        // Đã trả
        $xml .= '<c r="F' . $rowNum . '" s="2" t="n"><v>' . ($contract['total_paid'] ?? 0) . '</v></c>';
        
        // Còn lại
        $remaining = ($contract['total_money'] ?? 0) - ($contract['total_paid'] ?? 0);
        $xml .= '<c r="G' . $rowNum . '" s="2" t="n"><v>' . $remaining . '</v></c>';
        
        // Ngày xóa
        $deletedDate = '';
        if (!empty($contract['deleted_at'])) {
            $deletedDate = date('d/m/Y H:i', strtotime($contract['deleted_at']));
        } elseif (!empty($contract['formatted_deleted_at'])) {
            $deletedDate = $contract['formatted_deleted_at'];
        }
        $xml .= '<c r="H' . $rowNum . '" t="inlineStr"><is><t>' . $deletedDate . '</t></is></c>';
        
        // Người xóa
        $xml .= '<c r="I' . $rowNum . '" t="inlineStr"><is><t>' . htmlspecialchars($contract['deleted_by'] ?? '') . '</t></is></c>';
        
        // Trạng thái
        $status = 'Đã xóa';
        if (isset($contract['deletion_status']) && $contract['deletion_status'] === 'closed') {
            $status = 'Đã hoàn thành';
        }
        $xml .= '<c r="J' . $rowNum . '" t="inlineStr"><is><t>' . $status . '</t></is></c>';
        
        $xml .= '</row>';
        $rowNum++;
    }
    
    $xml .= '</sheetData></worksheet>';
    return $xml;
}

// Hàm backward compatibility (giữ lại để tương thích)
function getDeletedContracts($pdo, $search, $fromDate, $toDate, $shopId, $userId) {
    try {
        $sql = "SELECT dc.* FROM deleted_contracts dc WHERE dc.shop_id = :shopId AND dc.user_id = :userId";
        $params = [':shopId' => $shopId, ':userId' => $userId];
        
        // Thêm điều kiện tìm kiếm
        if (!empty($search)) {
            $sql .= " AND (dc.code_id LIKE :search OR dc.customer_name LIKE :search OR dc.customer_phone LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }
        
        // Thêm điều kiện từ ngày
        if (!empty($fromDate)) {
            $sql .= " AND DATE(dc.deleted_at) >= :fromDate";
            $params[':fromDate'] = $fromDate;
        }
        
        // Thêm điều kiện đến ngày
        if (!empty($toDate)) {
            $sql .= " AND DATE(dc.deleted_at) <= :toDate";
            $params[':toDate'] = $toDate;
        }
        
        $sql .= " ORDER BY dc.deleted_at DESC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        throw new Exception("Lỗi khi lấy dữ liệu: " . $e->getMessage());
    }
}
?>