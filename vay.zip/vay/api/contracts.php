<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// DEBUG: Log để kiểm tra
error_log("=== CONTRACT API DEBUG ===");
error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Request URI: " . $_SERVER['REQUEST_URI']);

// Lấy raw input để debug
$raw_input = file_get_contents('php://input');
error_log("Raw Input: " . $raw_input);

// Lấy dữ liệu POST
$input = json_decode($raw_input, true);

// DEBUG: Kiểm tra JSON decode
if (json_last_error() !== JSON_ERROR_NONE) {
    error_log("JSON Error: " . json_last_error_msg());
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Lỗi JSON: ' . json_last_error_msg()]);
    exit();
}

error_log("Decoded Input: " . print_r($input, true));

if (!$input) {
    error_log("Input is empty or null");
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ - input rỗng']);
    exit();
}

// Xử lý dựa trên có ID hay không
// if (isset($input['id']) && $input['id'] > 0) {
//     error_log("Calling handleUpdateContract with ID: " . $input['id']);
//     handleUpdateContract($pdo, $input);
// } else {
//     error_log("Calling handleCreateContract");
//     handleCreateContract($pdo, $input);
// }
// Xử lý dựa trên action
if (isset($input['action'])) {
    switch ($input['action']) {
        case 'update_status':
            handleUpdateStatus($pdo, $input);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Action không hợp lệ']);
    }
} elseif (isset($input['id']) && $input['id'] > 0) {
    error_log("Calling handleUpdateContract with ID: " . $input['id']);
    handleUpdateContract($pdo, $input);
} else {
    error_log("Calling handleCreateContract");
    handleCreateContract($pdo, $input);
}

function handleCreateContract($pdo, $input) {
    error_log("=== CREATE CONTRACT ===");
    
    // Validate required fields với xử lý đặc biệt cho staffId
    $required_fields = ['userId', 'shopId', 'codeId', 'typeId', 'customerName', 'totalMoney', 'rateType', 'loanTime', 'frequency', 'fromDate'];
    
    $missing_fields = [];
    foreach ($required_fields as $field) {
        if (!isset($input[$field]) || $input[$field] === '') {
            $missing_fields[] = $field;
            error_log("Missing field: $field - Value: " . (isset($input[$field]) ? $input[$field] : 'NOT SET'));
        }
    }
    

    if (!empty($missing_fields)) {
        $error_msg = "Các trường bắt buộc bị thiếu: " . implode(', ', $missing_fields);
        error_log("Validation Error: " . $error_msg);
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $error_msg]);
        return;
    }
    
    try {
        $pdo->beginTransaction(); // Bắt đầu transaction
        
        $sql = "INSERT INTO contracts (
            user_id, shop_id, code_id, type_id, customer_id, customer_name, 
            customer_phone, customer_number_card, customer_address, customer_card_date, 
            customer_place, total_money, total_money_received, rate_type, loan_time, 
            frequency, from_date, is_before, note, staff_id, edit_loan
        ) VALUES (
            :user_id, :shop_id, :code_id, :type_id, :customer_id, :customer_name,
            :customer_phone, :customer_number_card, :customer_address, :customer_card_date,
            :customer_place, :total_money, :total_money_received, :rate_type, :loan_time,
            :frequency, :from_date, :is_before, :note, :staff_id, :edit_loan
        )";
        
        $stmt = $pdo->prepare($sql);
        
        // Convert date format if needed (from DD/MM/YYYY to YYYY-MM-DD)
        $fromDate = convertDateFormat($input['fromDate']);
        $customerCardDate = !empty($input['customerCardDate']) ? convertDateFormat($input['customerCardDate']) : null;
        
        error_log("Converted fromDate: $fromDate");
        error_log("Converted customerCardDate: $customerCardDate");
        
        // FIXED: Đã sửa việc ép kiểu dữ liệu - chỉ ép kiểu cho các trường số
        $executeData = [
            ':user_id' => trim($input['userId']),
            ':shop_id' => trim($input['shopId']),
            ':code_id' => trim($input['codeId']), // Giữ nguyên chuỗi
            ':type_id' => (int)$input['typeId'],
            ':customer_id' => (int)($input['customerId'] ?? 0),
            ':customer_name' => trim($input['customerName']), // Giữ nguyên chuỗi
            ':customer_phone' => trim($input['customerPhone'] ?? ''), // Giữ nguyên chuỗi
            ':customer_number_card' => trim($input['customerNumberCard'] ?? ''), // Giữ nguyên chuỗi
            ':customer_address' => trim($input['customerAddress'] ?? ''), // Giữ nguyên chuỗi
            ':customer_card_date' => $customerCardDate, // Đã được convert thành date
            ':customer_place' => trim($input['customerPlace'] ?? ''), // Giữ nguyên chuỗi
            ':total_money' => (float)$input['totalMoney'],
            ':total_money_received' => (float)($input['totalMoneyReceived'] ?? 0),
            ':rate_type' => (int)$input['rateType'],
            ':loan_time' => (int)$input['loanTime'],
            ':frequency' => (int)$input['frequency'],
            ':from_date' => $fromDate, // Đã được convert thành date
            ':is_before' => isset($input['isBefore']) && $input['isBefore'] ? 1 : 0,
            ':note' => trim($input['note'] ?? ''), // Giữ nguyên chuỗi
            ':staff_id' => $input['staffId'],
            ':edit_loan' => (int)($input['editLoan'] ?? 0)
        ];
        
        error_log("Execute Data: " . print_r($executeData, true));
        
        $stmt->execute($executeData);
        
        $contractId = $pdo->lastInsertId();
        error_log("Created contract with ID: $contractId");
        
        // TỰ ĐỘNG TẠO LỊCH TRẢ NỢ
        $paymentScheduleResult = createPaymentScheduleForContract($pdo, $contractId);
        
        $pdo->commit(); // Commit transaction
        
        echo json_encode([
            'success' => true, 
            'message' => 'Tạo hợp đồng thành công',
            'contract_id' => $contractId,
            'payment_schedule' => $paymentScheduleResult
        ]);
        
    } catch(PDOException $e) {
        $pdo->rollBack(); // Rollback nếu có lỗi
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    } catch(Exception $e) {
        $pdo->rollBack(); // Rollback nếu có lỗi
        error_log("General Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
    }
}

function handleUpdateContract($pdo, $input) {
    error_log("=== UPDATE CONTRACT ===");
    
    if (!isset($input['id']) || $input['id'] <= 0) {
        error_log("Invalid ID: " . ($input['id'] ?? 'NOT SET'));
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'ID hợp đồng không hợp lệ']);
        return;
    }
    
    // Validate required fields với xử lý đặc biệt cho staffId
    $required_fields = ['userId', 'shopId', 'codeId', 'typeId', 'customerName', 'totalMoney', 'rateType', 'loanTime', 'frequency', 'fromDate'];
    
    $missing_fields = [];
    foreach ($required_fields as $field) {
        if (!isset($input[$field]) || $input[$field] === '') {
            $missing_fields[] = $field;
            error_log("Missing field: $field - Value: " . (isset($input[$field]) ? $input[$field] : 'NOT SET'));
        }
    }
    
    if (!empty($missing_fields)) {
        $error_msg = "Các trường bắt buộc bị thiếu: " . implode(', ', $missing_fields);
        error_log("Validation Error: " . $error_msg);
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $error_msg]);
        return;
    }
    
    try {
        $pdo->beginTransaction(); // Bắt đầu transaction
        
        // Lấy thông tin hợp đồng cũ để so sánh
        $oldContractStmt = $pdo->prepare("SELECT total_money, rate_type, loan_time, frequency, from_date FROM contracts WHERE id = :id");
        $oldContractStmt->execute([':id' => (int)$input['id']]);
        $oldContract = $oldContractStmt->fetch();
        
        if (!$oldContract) {
            error_log("Contract not found with ID: " . $input['id']);
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Hợp đồng không tồn tại']);
            return;
        }
        
        // Kiểm tra xem có thay đổi gì ảnh hưởng đến lịch trả nợ không
        $needUpdateSchedule = false;
        $oldFromDate = convertDateFormat($oldContract['from_date']);
        $newFromDate = convertDateFormat($input['fromDate']);
        
        if ($oldContract['total_money'] != $input['totalMoney'] ||
            $oldContract['rate_type'] != $input['rateType'] ||
            $oldContract['loan_time'] != $input['loanTime'] ||
            $oldContract['frequency'] != $input['frequency'] ||
            $oldFromDate != $newFromDate) {
            
            $needUpdateSchedule = true;
            error_log("Schedule update needed due to changes in key fields");
        }
        
        $sql = "UPDATE contracts SET 
            user_id = :user_id,
            shop_id = :shop_id,
            code_id = :code_id,
            type_id = :type_id,
            customer_id = :customer_id,
            customer_name = :customer_name,
            customer_phone = :customer_phone,
            customer_number_card = :customer_number_card,
            customer_address = :customer_address,
            customer_card_date = :customer_card_date,
            customer_place = :customer_place,
            total_money = :total_money,
            total_money_received = :total_money_received,
            rate_type = :rate_type,
            loan_time = :loan_time,
            frequency = :frequency,
            from_date = :from_date,
            is_before = :is_before,
            note = :note,
            staff_id = :staff_id,
            edit_loan = :edit_loan,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = :id";
        
        $stmt = $pdo->prepare($sql);
        
        // Convert date format if needed
        $fromDate = convertDateFormat($input['fromDate']);
        $customerCardDate = !empty($input['customerCardDate']) ? convertDateFormat($input['customerCardDate']) : null;
        
        // FIXED: Đã sửa việc ép kiểu dữ liệu - chỉ ép kiểu cho các trường số
        $executeData = [
            ':id' => (int)$input['id'],
            ':user_id' => trim($input['userId']),
            ':shop_id' => trim($input['shopId']),
            ':code_id' => trim($input['codeId']), // Giữ nguyên chuỗi
            ':type_id' => (int)$input['typeId'],
            ':customer_id' => (int)($input['customerId'] ?? 0),
            ':customer_name' => trim($input['customerName']), // Giữ nguyên chuỗi
            ':customer_phone' => trim($input['customerPhone'] ?? ''), // Giữ nguyên chuỗi
            ':customer_number_card' => trim($input['customerNumberCard'] ?? ''), // Giữ nguyên chuỗi
            ':customer_address' => trim($input['customerAddress'] ?? ''), // Giữ nguyên chuỗi
            ':customer_card_date' => $customerCardDate, // Đã được convert thành date
            ':customer_place' => trim($input['customerPlace'] ?? ''), // Giữ nguyên chuỗi
            ':total_money' => (float)$input['totalMoney'],
            ':total_money_received' => (float)($input['totalMoneyReceived'] ?? 0),
            ':rate_type' => (int)$input['rateType'],
            ':loan_time' => (int)$input['loanTime'],
            ':frequency' => (int)$input['frequency'],
            ':from_date' => $fromDate, // Đã được convert thành date
            ':is_before' => isset($input['isBefore']) && $input['isBefore'] ? 1 : 0,
            ':note' => trim($input['note'] ?? ''), // Giữ nguyên chuỗi
            ':staff_id' => trim($input['staffId']),
            ':edit_loan' => (int)($input['editLoan'] ?? 0)
        ];
        
        error_log("Update Execute Data: " . print_r($executeData, true));
        
        $stmt->execute($executeData);
        
        error_log("Updated contract with ID: " . $input['id']);
        
        // TỰ ĐỘNG CẬP NHẬT LỊCH TRẢ NỢ nếu có thay đổi quan trọng
        $paymentScheduleResult = null;
        if ($needUpdateSchedule) {
            error_log("Updating payment schedule for contract ID: " . $input['id']);
            
            // Xóa tất cả lịch cũ chưa thanh toán (status = 'pending')
            $deleteOldSchedule = $pdo->prepare("DELETE FROM payment_schedules WHERE contract_id = ? AND status = 'pending'");
            $deleteOldSchedule->execute([$input['id']]);
            
            // Tạo lịch mới
            $paymentScheduleResult = createPaymentScheduleForContract($pdo, $input['id']);
            error_log("Payment schedule recreated: " . print_r($paymentScheduleResult, true));
        }
        
        $pdo->commit(); // Commit transaction
        
        $response = [
            'success' => true, 
            'message' => 'Cập nhật hợp đồng thành công',
            'contract_id' => (int)$input['id'],
            'schedule_updated' => $needUpdateSchedule
        ];
        
        if ($paymentScheduleResult) {
            $response['payment_schedule'] = $paymentScheduleResult;
        }
        
        echo json_encode($response);
        
    } catch(PDOException $e) {
        $pdo->rollBack(); // Rollback nếu có lỗi
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    } catch(Exception $e) {
        $pdo->rollBack(); // Rollback nếu có lỗi
        error_log("General Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
    }
}
/**
 * Function để tự động tạo lịch trả nợ cho hợp đồng
 */

function createPaymentScheduleForContract($pdo, $contractId) {
    error_log("=== CREATE PAYMENT SCHEDULE FOR CONTRACT $contractId ===");
    
    try {
        // Lấy thông tin từ bảng contracts
        $contractStmt = $pdo->prepare("SELECT * FROM contracts WHERE id = ?");
        $contractStmt->execute([$contractId]);
        $contract = $contractStmt->fetch();
        
        if (!$contract) {
            throw new Exception("Không tìm thấy hợp đồng với ID: $contractId");
        }
        
        // Lấy thông tin lãi suất từ contract_types (nếu có)
        $interestRate = 0.0;
        $penaltyRate = 0.0;
        
        if ($contract['rate_type'] > 0) {
            $typeStmt = $pdo->prepare("SELECT interest_rate, penalty_rate FROM contract_types WHERE id = ?");
            $typeStmt->execute([$contract['rate_type']]);
            $typeInfo = $typeStmt->fetch();
            
            if ($typeInfo) {
                $interestRate = (float)$typeInfo['interest_rate'];
                $penaltyRate = (float)$typeInfo['penalty_rate'];
            }
        }
        
        // Tính toán các thông số
        $totalMoney = (float)$contract['total_money'];
        $loanTime = (int)$contract['loan_time'];
        $frequency = (int)$contract['frequency'];
        $fromDate = $contract['from_date'];
        
        // Bước 1: Tính số kỳ trả nợ
        $totalPeriods = ceil($loanTime / $frequency);
        
        // Bước 2: Tính số tiền mỗi kỳ đầu
        $theoreticalAmount = $totalMoney * $frequency / $loanTime;
        $amountPerPeriod = floor($theoreticalAmount / $frequency) * $frequency;
        $numEqualPeriods = $totalPeriods - 1; // Số kỳ đầu bằng nhau
        $totalEqualAmount = $numEqualPeriods * $amountPerPeriod;
        
        // Bước 3: Tính số tiền kỳ cuối
        $lastPayment = $totalMoney - $totalEqualAmount;
        
        error_log("Contract ID: $contractId, Total Periods: $totalPeriods, Amount per period: $amountPerPeriod, Last payment: $lastPayment, Interest Rate: $interestRate");
        
        // Tạo lịch trả cho từng kỳ
        $insertStmt = $pdo->prepare("
            INSERT INTO payment_schedules (
                contract_id, user_id, shop_id, code_id, customer_id,
                period_number, from_date, to_date, due_date,
                amount_due, amount_remaining, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        
        $schedulesCreated = 0;
        
        for ($i = 1; $i <= $totalPeriods; $i++) {
            // Tính ngày bắt đầu và kết thúc của kỳ
            $periodFromDate = date('Y-m-d', strtotime($fromDate . " + " . (($i - 1) * $frequency) . " days"));
            $periodToDate = date('Y-m-d', strtotime($periodFromDate . " + " . ($frequency - 1) . " days"));
            $dueDate = $periodToDate; // Ngày đáo hạn là ngày cuối của kỳ
            
            // Gán số tiền cho kỳ hiện tại
            $currentAmount = ($i == $totalPeriods) ? $lastPayment : $amountPerPeriod;
            $currentAmount = round($currentAmount, 2); // Làm tròn để tránh lỗi số thập phân
            
            $insertStmt->execute([
                $contract['id'],
                $contract['user_id'],
                $contract['shop_id'],
                $contract['code_id'],
                $contract['customer_id'],
                $i,
                $periodFromDate,
                $periodToDate,
                $dueDate,
                $currentAmount,
                $currentAmount
            ]);
            
            $schedulesCreated++;
            error_log("Created schedule period $i: $periodFromDate to $periodToDate, due: $dueDate, amount: $currentAmount");
        }
        
        return [
            'success' => true,
            'message' => "Đã tạo $schedulesCreated kỳ trả nợ",
            'total_periods' => $totalPeriods,
            'amount_per_period' => $amountPerPeriod,
            'last_payment' => $lastPayment,
            'interest_rate' => $interestRate,
            'penalty_rate' => $penaltyRate
        ];
        
    } catch (Exception $e) {
        error_log("Payment Schedule Creation Error: " . $e->getMessage());
        throw $e;
    }
}

// Hàm helper để validate và sanitize dữ liệu đầu vào
function validateAndSanitizeInput($input) {
    $sanitized = [];
    
    // Validate và sanitize các trường số nguyên
    $integer_fields = ['userId', 'shopId', 'typeId', 'customerId', 'rateType', 'loanTime', 'frequency', 'staffId', 'editLoan'];
    foreach ($integer_fields as $field) {
        if (isset($input[$field])) {
            $sanitized[$field] = (int)$input[$field];
        }
    }
    
    // Validate và sanitize các trường số thực
    $float_fields = ['totalMoney', 'totalMoneyReceived'];
    foreach ($float_fields as $field) {
        if (isset($input[$field])) {
            // Remove formatting characters for money fields
            $value = str_replace([',', ' '], '', $input[$field]);
            $sanitized[$field] = (float)$value;
        }
    }
    
    // Validate và sanitize các trường chuỗi
    $string_fields = ['codeId', 'customerName', 'customerPhone', 'customerNumberCard', 'customerAddress', 'customerPlace', 'note'];
    foreach ($string_fields as $field) {
        if (isset($input[$field])) {
            $sanitized[$field] = trim($input[$field]);
        }
    }
    
    // Validate và sanitize các trường ngày tháng
    $date_fields = ['fromDate', 'customerCardDate'];
    foreach ($date_fields as $field) {
        if (isset($input[$field]) && !empty($input[$field])) {
            $sanitized[$field] = convertDateFormat($input[$field]);
        }
    }
    
    // Validate boolean field
    if (isset($input['isBefore'])) {
        $sanitized['isBefore'] = $input['isBefore'] ? 1 : 0;
    }
    
    return $sanitized;
}

function convertDateFormat($dateString) {
    if (empty($dateString)) {
        return null;
    }
    
    // Nếu đã đúng format YYYY-MM-DD thì giữ nguyên
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateString)) {
        return $dateString;
    }
    
    // Chuyển từ DD/MM/YYYY sang YYYY-MM-DD
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $dateString, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        // Validate date
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        } else {
            error_log("Invalid date: $dateString");
            return null;
        }
    }
    
    // Chuyển từ DD-MM-YYYY sang YYYY-MM-DD
    if (preg_match('/^(\d{1,2})-(\d{1,2})-(\d{4})$/', $dateString, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        // Validate date
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        } else {
            error_log("Invalid date: $dateString");
            return null;
        }
    }
    
    error_log("Cannot convert date format: $dateString");
    return null;
}

// Hàm helper để validate business logic
function validateBusinessLogic($data) {
    $errors = [];
    
    // Validate tiền
    if ($data['totalMoney'] <= 0) {
        $errors[] = "Tổng tiền trả góp phải lớn hơn 0";
    }
    
    if ($data['totalMoneyReceived'] <= 0) {
        $errors[] = "Tiền đưa khách phải lớn hơn 0";
    }
    
    if ($data['totalMoneyReceived'] >= $data['totalMoney']) {
        $errors[] = "Tiền đưa khách phải nhỏ hơn tổng tiền trả góp";
    }
    
    // Validate thời gian
    if ($data['loanTime'] <= 0) {
        $errors[] = "Thời gian bốc phải lớn hơn 0";
    }
    
    if ($data['frequency'] <= 0) {
        $errors[] = "Tần suất đóng tiền phải lớn hơn 0";
    }
    
    // Validate ngày
    if (empty($data['fromDate'])) {
        $errors[] = "Ngày bốc không được để trống";
    }
    
    // Validate mã hợp đồng
    if (empty($data['codeId'])) {
        $errors[] = "Mã hợp đồng không được để trống";
    }
    
    // Validate tên khách hàng
    if (empty($data['customerName'])) {
        $errors[] = "Tên khách hàng không được để trống";
    }
    
    return $errors;
}
function handleUpdateStatus($pdo, $input) {
    error_log("=== UPDATE CONTRACT STATUS ===");
    
    if (!isset($input['contract_id']) || $input['contract_id'] <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'ID hợp đồng không hợp lệ']);
        return;
    }
    
    if (!isset($input['current_status']) || empty($input['current_status'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Trạng thái không hợp lệ']);
        return;
    }
    
    try {
        $sql = "UPDATE contracts SET current_status = :status WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        
        $result = $stmt->execute([
            ':status' => trim($input['current_status']),
            ':id' => (int)$input['contract_id']
        ]);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => 'Cập nhật trạng thái thành công'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Không thể cập nhật trạng thái'
            ]);
        }
        
    } catch(PDOException $e) {
        error_log("Status Update Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}
?>