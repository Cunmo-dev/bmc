<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON và thoát
function jsonResponse($data) {
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

define('BASE_PATH', '/vay/');

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Chỉ xử lý POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    $currentUserId = $_SESSION['user_id'];
    
    // Lấy staffId từ POST
    $staffId = isset($_POST['staffId']) ? intval($_POST['staffId']) : 0;
    
    if (empty($staffId)) {
        jsonResponse([
            'success' => false,
            'message' => 'ID nhân viên không hợp lệ!'
        ]);
    }

    logDebug("Delete Staff Request", [
        'staff_id' => $staffId,
        'user_id' => $currentUserId
    ]);

    // Kiểm tra nhân viên có tồn tại và thuộc về user hiện tại không
    $checkStaffQuery = "SELECT s.id, s.staff_id, s.username, s.full_name, s.user_id 
                       FROM staff s 
                       WHERE s.id = ? AND s.user_id = ?";
    $checkStaffStmt = $pdo->prepare($checkStaffQuery);
    
    if (!$checkStaffStmt) {
        throw new Exception("Lỗi prepare statement cho check staff");
    }
    
    $checkStaffStmt->execute([$staffId, $currentUserId]);
    $staffData = $checkStaffStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$staffData) {
        jsonResponse([
            'success' => false,
            'message' => 'Nhân viên không tồn tại hoặc bạn không có quyền xóa!'
        ]);
    }

    $staffIdGenerated = $staffData['staff_id'];
    $username = $staffData['username'];

    // Bắt đầu transaction
    $pdo->beginTransaction();

    try {
        // BƯỚC 1: Xóa từ bảng shops (nếu có)
        $deleteShopQuery = "DELETE FROM shops WHERE user_id = ?";
        $deleteShopStmt = $pdo->prepare($deleteShopQuery);
        if ($deleteShopStmt) {
            $deleteShopStmt->execute([$staffIdGenerated]);
            logDebug("Deleted shop for staff", $staffIdGenerated);
        }

        // BƯỚC 2: Xóa từ bảng users (nếu có)
        $deleteUserQuery = "DELETE FROM users WHERE user_id = ?";
        $deleteUserStmt = $pdo->prepare($deleteUserQuery);
        if ($deleteUserStmt) {
            $deleteUserStmt->execute([$staffIdGenerated]);
            logDebug("Deleted user for staff", $staffIdGenerated);
        }

        // BƯỚC 3: Xóa từ bảng staff
        $deleteStaffQuery = "DELETE FROM staff WHERE id = ? AND user_id = ?";
        $deleteStaffStmt = $pdo->prepare($deleteStaffQuery);
        
        if (!$deleteStaffStmt) {
            throw new Exception("Lỗi prepare statement cho delete staff");
        }
        
        $deleteStaffResult = $deleteStaffStmt->execute([$staffId, $currentUserId]);
        
        if (!$deleteStaffResult || $deleteStaffStmt->rowCount() === 0) {
            throw new Exception("Không thể xóa nhân viên!");
        }

        // Commit transaction
        $pdo->commit();
        
        logDebug("Staff deleted successfully", [
            'staff_id' => $staffId,
            'staff_id_generated' => $staffIdGenerated,
            'username' => $username
        ]);
        
        jsonResponse([
            'success' => true,
            'message' => "Xóa nhân viên '$username' thành công!",
            'data' => [
                'deleted_staff_id' => $staffId,
                'username' => $username
            ]
        ]);

    } catch (Exception $e) {
        // Rollback nếu có lỗi
        $pdo->rollBack();
        throw $e;
    }

} catch (PDOException $e) {
    // Rollback nếu đang trong transaction
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    logDebug("PDO Error in Delete Staff", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    // Rollback nếu đang trong transaction
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    logDebug("General Error in Delete Staff", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>