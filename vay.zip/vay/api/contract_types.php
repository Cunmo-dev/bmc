<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

$raw_input = file_get_contents('php://input');
$input = json_decode($raw_input, true);
$action = $input['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'create':
        createContractType($pdo, $input);
        break;
    case 'list':
        getContractTypes($pdo, $input);
        break;
    case 'update':
        updateContractType($pdo, $input);
        break;
    case 'delete':
        deleteContractType($pdo, $input);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Action không hợp lệ']);
        break;
}

/**
 * Tạo loại hợp đồng mới
 */
function createContractType($pdo, $input) {
    $required = ['name', 'code', 'interest_rate'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || $input[$field] === '') {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => "Trường $field không được để trống"]);
            return;
        }
    }
    
    try {
        // Kiểm tra code đã tồn tại chưa
        $checkStmt = $pdo->prepare("SELECT id FROM contract_types WHERE code = ?");
        $checkStmt->execute([$input['code']]);
        if ($checkStmt->fetch()) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Mã loại hợp đồng đã tồn tại']);
            return;
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO contract_types (
                name, code, interest_rate, penalty_rate, 
                min_amount, max_amount, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            trim($input['name']),
            trim($input['code']),
            (float)$input['interest_rate'],
            (float)($input['penalty_rate'] ?? 0),
            (float)($input['min_amount'] ?? 0),
            (float)($input['max_amount'] ?? 0),
            isset($input['is_active']) ? ($input['is_active'] ? 1 : 0) : 1
        ]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Tạo loại hợp đồng thành công',
            'id' => $pdo->lastInsertId()
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}

/**
 * Lấy danh sách loại hợp đồng
 */
function getContractTypes($pdo, $input) {
    try {
        $whereClause = "1=1";
        $params = [];
        
        // Filter theo trạng thái active
        if (isset($input['is_active'])) {
            $whereClause .= " AND is_active = ?";
            $params[] = $input['is_active'] ? 1 : 0;
        }
        
        $stmt = $pdo->prepare("
            SELECT * FROM contract_types 
            WHERE $whereClause 
            ORDER BY created_at DESC
        ");
        
        $stmt->execute($params);
        $contractTypes = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'data' => $contractTypes,
            'total' => count($contractTypes)
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}

/**
 * Cập nhật loại hợp đồng
 */
function updateContractType($pdo, $input) {
    if (!isset($input['id']) || $input['id'] <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'ID không hợp lệ']);
        return;
    }
    
    try {
        // Kiểm tra tồn tại
        $checkStmt = $pdo->prepare("SELECT id FROM contract_types WHERE id = ?");
        $checkStmt->execute([$input['id']]);
        if (!$checkStmt->fetch()) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Loại hợp đồng không tồn tại']);
            return;
        }
        
        // Kiểm tra code trùng (ngoại trừ chính nó)
        if (!empty($input['code'])) {
            $codeCheckStmt = $pdo->prepare("SELECT id FROM contract_types WHERE code = ? AND id != ?");
            $codeCheckStmt->execute([$input['code'], $input['id']]);
            if ($codeCheckStmt->fetch()) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Mã loại hợp đồng đã tồn tại']);
                return;
            }
        }
        
        $updateFields = [];
        $params = [];
        
        if (isset($input['name'])) {
            $updateFields[] = "name = ?";
            $params[] = trim($input['name']);
        }
        if (isset($input['code'])) {
            $updateFields[] = "code = ?";
            $params[] = trim($input['code']);
        }
        if (isset($input['interest_rate'])) {
            $updateFields[] = "interest_rate = ?";
            $params[] = (float)$input['interest_rate'];
        }
        if (isset($input['penalty_rate'])) {
            $updateFields[] = "penalty_rate = ?";
            $params[] = (float)$input['penalty_rate'];
        }
        if (isset($input['min_amount'])) {
            $updateFields[] = "min_amount = ?";
            $params[] = (float)$input['min_amount'];
        }
        if (isset($input['max_amount'])) {
            $updateFields[] = "max_amount = ?";
            $params[] = (float)$input['max_amount'];
        }
        if (isset($input['is_active'])) {
            $updateFields[] = "is_active = ?";
            $params[] = $input['is_active'] ? 1 : 0;
        }
        
        if (empty($updateFields)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Không có dữ liệu để cập nhật']);
            return;
        }
        
        $updateFields[] = "updated_at = CURRENT_TIMESTAMP";
        $params[] = $input['id'];
        
        $sql = "UPDATE contract_types SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode([
            'success' => true,
            'message' => 'Cập nhật loại hợp đồng thành công'
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}

/**
 * Xóa loại hợp đồng (soft delete)
 */
function deleteContractType($pdo, $input) {
    if (!isset($input['id']) || $input['id'] <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'ID không hợp lệ']);
        return;
    }
    
    try {
        // Kiểm tra có hợp đồng nào đang sử dụng không
        $usageStmt = $pdo->prepare("SELECT COUNT(*) FROM contracts WHERE rate_type = ?");
        $usageStmt->execute([$input['id']]);
        $usageCount = $usageStmt->fetchColumn();
        
        if ($usageCount > 0) {
            http_response_code(400);
            echo json_encode([
                'success' => false, 
                'message' => "Không thể xóa. Có $usageCount hợp đồng đang sử dụng loại này"
            ]);
            return;
        }
        
        // Chỉ vô hiệu hóa thay vì xóa hoàn toàn
        $stmt = $pdo->prepare("UPDATE contract_types SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$input['id']]);
        
        if ($stmt->rowCount() > 0) {
            echo json_encode([
                'success' => true,
                'message' => 'Đã vô hiệu hóa loại hợp đồng'
            ]);
        } else {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Loại hợp đồng không tồn tại']);
        }
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}
?>