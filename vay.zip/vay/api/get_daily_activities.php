<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// // Cấu hình database
// $host = 'localhost';
// $dbname = 'login_system';
// $username = 'root'; // Thay đổi theo cấu hình của bạn
// $password = '';     // Thay đổi theo cấu hình của bạn

// try {
//     $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
//         PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
//         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
//         PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
//     ]);
// } catch (PDOException $e) {
//     echo json_encode(['success' => false, 'message' => 'Kết nối database thất bại: ' . $e->getMessage()]);
//     exit();
// }
require_once 'database.php';

// Lấy action từ request
$action = $_POST['action'] ?? '';

switch ($action) {
    case 'get_shops':
        getShops($pdo);
        break;
    case 'get_activities':
        getActivities($pdo);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Action không hợp lệ']);
        break;
}

/**
 * Lấy danh sách cửa hàng (đã sửa lấy shop_id đầu tiên thay vì cuối cùng)
 */
function getShops($pdo) {
    try {
        // Sử dụng MIN thay vì MAX để lấy shop gốc đầu tiên
        $sql = "SELECT MIN(shop_id) as shop_id, shop_name 
                FROM shops 
                WHERE deleted_at IS NULL AND status = 1 
                GROUP BY shop_name 
                ORDER BY shop_name ASC";
        
        $stmt = $pdo->query($sql);
        $shops = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'data' => $shops
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Lỗi khi lấy danh sách cửa hàng: ' . $e->getMessage()
        ]);
    }
}

/**
 * Lấy hoạt động và thống kê
 */
function getActivities($pdo) {
    try {
        $from_date = $_POST['from_date'] ?? date('Y-m-d');
        $to_date = $_POST['to_date'] ?? date('Y-m-d');
        $shop_id = $_POST['shop_id'] ?? '';
        
        // Validate dates
        if (!validateDate($from_date) || !validateDate($to_date)) {
            throw new Exception('Định dạng ngày không hợp lệ');
        }
        
        // Lấy thống kê
        $stats = getStatistics($pdo, $from_date, $to_date, $shop_id);
        
        // Lấy chi tiết hoạt động
        $activities = getDetailedActivities($pdo, $from_date, $to_date, $shop_id);
        
        echo json_encode([
            'success' => true,
            'stats' => $stats,
            'data' => $activities
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Lỗi khi lấy dữ liệu: ' . $e->getMessage()
        ]);
    }
}

/**
 * Lấy thống kê tổng quan (ĐÃ SỬA LỖI AMBIGUOUS COLUMN)
 */
function getStatistics($pdo, $from_date, $to_date, $shop_id) {
    // Xây dựng điều kiện shop với alias rõ ràng
    $shop_condition_contracts = $shop_id ? "AND c.shop_id = :shop_id" : "";
    $shop_condition_transactions = $shop_id ? "AND t.shop_id = :shop_id" : "";
    
    $params = [':from_date' => $from_date, ':to_date' => $to_date];
    if ($shop_id) {
        $params[':shop_id'] = $shop_id;
    }
    
    try {
        // 1. Tổng hợp đồng tạo mới
        $sql_contracts = "SELECT COUNT(*) as total_contracts 
                         FROM contracts c
                         WHERE DATE(c.created_at) BETWEEN :from_date AND :to_date 
                         $shop_condition_contracts";
        $stmt = $pdo->prepare($sql_contracts);
        $stmt->execute($params);
        $total_contracts = $stmt->fetch()['total_contracts'] ?? 0;
        
        // 2. Tổng tiền thu (từ payment_schedules)
        $sql_income = "SELECT COALESCE(SUM(ps.amount_paid), 0) as total_income 
                      FROM payment_schedules ps
                      INNER JOIN contracts c ON ps.contract_id = c.id
                      WHERE ps.status IN ('paid', 'partial_paid') 
                      AND DATE(ps.updated_at) BETWEEN :from_date AND :to_date 
                      $shop_condition_contracts";
        $stmt = $pdo->prepare($sql_income);
        $stmt->execute($params);
        $total_income = $stmt->fetch()['total_income'] ?? 0;
        
        // 3. Tổng chi (từ total_money_received trong contracts)
        $sql_expense = "SELECT COALESCE(SUM(c.total_money_received), 0) as total_expense 
                       FROM contracts c
                       WHERE DATE(c.created_at) BETWEEN :from_date AND :to_date 
                       $shop_condition_contracts";
        $stmt = $pdo->prepare($sql_expense);
        $stmt->execute($params);
        $total_expense = $stmt->fetch()['total_expense'] ?? 0;
        
        // 4. Thêm thu chi từ transactions
        $sql_transactions = "SELECT 
                               COALESCE(SUM(CASE WHEN t.transaction_type = 'income' THEN t.amount ELSE 0 END), 0) as trans_income,
                               COALESCE(SUM(CASE WHEN t.transaction_type = 'expense' THEN t.amount ELSE 0 END), 0) as trans_expense
                            FROM transactions t
                            WHERE DATE(t.created_at) BETWEEN :from_date AND :to_date 
                            $shop_condition_transactions";
        $stmt = $pdo->prepare($sql_transactions);
        $stmt->execute($params);
        $trans_result = $stmt->fetch();
        
        // Cộng thêm thu chi từ transactions
        $total_income += $trans_result['trans_income'] ?? 0;
        $total_expense += $trans_result['trans_expense'] ?? 0;
        
        // 5. Tổng số hoạt động (sẽ đếm từ kết quả activities)
        $activities = getDetailedActivities($pdo, $from_date, $to_date, $shop_id);
        $total_activities = count($activities);
        
        return [
            'total_contracts' => $total_contracts,
            'total_income' => $total_income,
            'total_expense' => $total_expense,
            'total_activities' => $total_activities
        ];
        
    } catch (Exception $e) {
        throw new Exception('Lỗi khi tính thống kê: ' . $e->getMessage());
    }
}

/**
 * Lấy chi tiết các hoạt động (ĐÃ SỬA LỖI AMBIGUOUS COLUMN)
 */
function getDetailedActivities($pdo, $from_date, $to_date, $shop_id) {
    $activities = [];
    
    // Xây dựng điều kiện shop với alias cụ thể cho từng bảng
    $params = [':from_date' => $from_date, ':to_date' => $to_date];
    if ($shop_id) {
        $params[':shop_id'] = $shop_id;
    }
    
    try {
        // 1. Hoạt động tạo hợp đồng
        $shop_condition = $shop_id ? "AND c.shop_id = :shop_id" : "";
        $sql = "SELECT 'contract_create' as activity_type,
                       CONCAT('Tạo hợp đồng: ', c.customer_name) as title,
                       CONCAT('Mã hợp đồng: ', c.code_id, ' - Số tiền: ', FORMAT(c.total_money, 0), 'đ') as description,
                       c.total_money as amount,
                       c.created_at,
                       c.shop_id
                FROM contracts c
                WHERE DATE(c.created_at) BETWEEN :from_date AND :to_date 
                $shop_condition";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $activities = array_merge($activities, $stmt->fetchAll());
        
        // 2. Hoạt động thanh toán
        $shop_condition = $shop_id ? "AND c.shop_id = :shop_id" : "";
        $sql = "SELECT 'payment_receive' as activity_type,
                       CONCAT('Thu tiền trả góp: ', c.customer_name) as title,
                       CONCAT('Kỳ ', ps.period_number, ' - Mã HĐ: ', c.code_id, ' - Số tiền: ', FORMAT(ps.amount_paid, 0), 'đ') as description,
                       ps.amount_paid as amount,
                       ps.updated_at as created_at,
                       c.shop_id
                FROM payment_schedules ps
                INNER JOIN contracts c ON ps.contract_id = c.id
                WHERE ps.status IN ('paid', 'partial_paid') 
                AND ps.amount_paid > 0
                AND DATE(ps.updated_at) BETWEEN :from_date AND :to_date 
                $shop_condition";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $activities = array_merge($activities, $stmt->fetchAll());
        
        // 3. Hoạt động tạo cửa hàng
        $shop_condition = $shop_id ? "AND s.shop_id = :shop_id" : "";
        $sql = "SELECT 'shop_create' as activity_type,
                       CONCAT('Tạo cửa hàng mới: ', s.shop_name) as title,
                       CONCAT('Địa chỉ: ', COALESCE(s.shop_address, 'Chưa cập nhật'), ' - SĐT: ', COALESCE(s.shop_phone, 'Chưa cập nhật')) as description,
                       s.total_money_in_safe as amount,
                       s.created_at,
                       s.shop_id
                FROM shops s
                WHERE DATE(s.created_at) BETWEEN :from_date AND :to_date 
                AND s.deleted_at IS NULL
                $shop_condition";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $activities = array_merge($activities, $stmt->fetchAll());
        
        // 4. Hoạt động nhân viên
        $shop_condition = $shop_id ? "AND st.shop_id = :shop_id" : "";
        $sql = "SELECT 'staff_create' as activity_type,
                       CONCAT('Thêm nhân viên: ', st.full_name) as title,
                       CONCAT('Username: ', st.username, ' - Chức vụ: ', st.position) as description,
                       0 as amount,
                       st.created_at,
                       st.shop_id
                FROM staff st
                WHERE DATE(st.created_at) BETWEEN :from_date AND :to_date 
                $shop_condition";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $activities = array_merge($activities, $stmt->fetchAll());
        
        // 5. Hoạt động cập nhật nhân viên
        $shop_condition = $shop_id ? "AND st.shop_id = :shop_id" : "";
        $sql = "SELECT 'staff_update' as activity_type,
                       CONCAT('Cập nhật nhân viên: ', st.full_name) as title,
                       CONCAT('Username: ', st.username, ' - Chức vụ: ', st.position) as description,
                       0 as amount,
                       st.updated_at as created_at,
                       st.shop_id
                FROM staff st
                WHERE DATE(st.updated_at) BETWEEN :from_date AND :to_date 
                AND DATE(st.updated_at) != DATE(st.created_at)
                $shop_condition";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $activities = array_merge($activities, $stmt->fetchAll());
        
        // 6. Hoạt động từ transactions (thu chi khác)
        $shop_condition = $shop_id ? "AND t.shop_id = :shop_id" : "";
        $sql = "SELECT CASE 
                        WHEN t.transaction_type = 'income' THEN 'payment_receive'
                        WHEN t.transaction_type = 'expense' THEN 'expense_create'
                        ELSE 'expense_create'
                       END as activity_type,
                       CONCAT(
                        CASE 
                            WHEN t.transaction_type = 'income' THEN 'Thu tiền: '
                            WHEN t.transaction_type = 'expense' THEN 'Chi tiền: '
                            ELSE 'Giao dịch: '
                        END,
                        COALESCE(t.category, 'Khác')
                       ) as title,
                       CONCAT(COALESCE(t.description, 'Không có mô tả'), ' - Mã GD: ', t.transaction_code) as description,
                       t.amount,
                       t.created_at,
                       t.shop_id
                FROM transactions t
                WHERE DATE(t.created_at) BETWEEN :from_date AND :to_date 
                $shop_condition";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $activities = array_merge($activities, $stmt->fetchAll());
        
        // 7. Hoạt động hợp đồng bị xóa
        $shop_condition = $shop_id ? "AND dc.shop_id = :shop_id" : "";
        $sql = "SELECT 'contract_delete' as activity_type,
                       CONCAT('Xóa hợp đồng: ', dc.customer_name) as title,
                       CONCAT('Mã HĐ: ', dc.code_id, ' - Lý do: ', COALESCE(dc.deletion_reason, 'Không có lý do')) as description,
                       dc.total_money as amount,
                       dc.deleted_at as created_at,
                       dc.shop_id
                FROM deleted_contracts dc
                WHERE DATE(dc.deleted_at) BETWEEN :from_date AND :to_date 
                $shop_condition";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $activities = array_merge($activities, $stmt->fetchAll());
        
        // 8. Hoạt động hủy thanh toán
        $shop_condition = $shop_id ? "AND pcl.shop_id = :shop_id" : "";
        $sql = "SELECT 'payment_cancel' as activity_type,
                       CONCAT('Hủy thanh toán: ', c.customer_name) as title,
                       CONCAT('Mã HĐ: ', c.code_id, ' - Số tiền hủy: ', FORMAT(pcl.cancelled_amount, 0), 'đ - Lý do: ', COALESCE(pcl.cancellation_reason, 'Không có lý do')) as description,
                       pcl.cancelled_amount as amount,
                       pcl.created_at,
                       pcl.shop_id
                FROM payment_cancellation_log pcl
                INNER JOIN contracts c ON pcl.contract_id = c.id
                WHERE DATE(pcl.created_at) BETWEEN :from_date AND :to_date 
                $shop_condition";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $activities = array_merge($activities, $stmt->fetchAll());
        
        // Sắp xếp theo thời gian giảm dần
        usort($activities, function($a, $b) {
            return strtotime($b['created_at']) - strtotime($a['created_at']);
        });
        
        return $activities;
        
    } catch (Exception $e) {
        throw new Exception('Lỗi khi lấy chi tiết hoạt động: ' . $e->getMessage());
    }
}

/**
 * Validate định dạng ngày
 */
function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

/**
 * Log hoạt động vào system_logs
 */
function logActivity($pdo, $user_id, $shop_id, $action, $table_name, $record_id, $old_values = null, $new_values = null) {
    try {
        $sql = "INSERT INTO system_logs (user_id, shop_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent) 
                VALUES (:user_id, :shop_id, :action, :table_name, :record_id, :old_values, :new_values, :ip_address, :user_agent)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':user_id' => $user_id,
            ':shop_id' => $shop_id,
            ':action' => $action,
            ':table_name' => $table_name,
            ':record_id' => $record_id,
            ':old_values' => $old_values ? json_encode($old_values, JSON_UNESCAPED_UNICODE) : null,
            ':new_values' => $new_values ? json_encode($new_values, JSON_UNESCAPED_UNICODE) : null,
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
        
        return true;
    } catch (Exception $e) {
        // Log error nhưng không throw exception để không làm gián đoạn luồng chính
        error_log('Lỗi khi ghi log: ' . $e->getMessage());
        return false;
    }
}

/**
 * Lấy thông tin cửa hàng theo ID
 */
function getShopInfo($pdo, $shop_id) {
    try {
        $sql = "SELECT shop_name FROM shops WHERE shop_id = :shop_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':shop_id' => $shop_id]);
        return $stmt->fetch();
    } catch (Exception $e) {
        return null;
    }
}
?>