<?php
// api/upload_contracts.php

// Prevent any output before headers
ob_start();

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to prevent HTML output

// Set headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Custom error handler to capture errors as JSON
set_error_handler(function($severity, $message, $file, $line) {
    throw new ErrorException($message, 0, $severity, $file, $line);
});

// Include database connection
try {
    require_once 'database.php';
} catch (Exception $e) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Lỗi kết nối database: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
}

// Response array
$response = array(
    'success' => false,
    'message' => '',
    'total_rows' => 0,
    'success_count' => 0,
    'error_count' => 0,
    'errors' => array(),
    'warnings' => array()
);

try {
    // Check request method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Chỉ chấp nhận phương thức POST');
    }

    // Check if file uploaded
    if (!isset($_FILES['excel_file']) || $_FILES['excel_file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Không có file được upload hoặc có lỗi upload');
    }

    // Get form data
    $user_id = trim($_POST['user_id'] ?? '');
    $shop_id = trim($_POST['shop_id'] ?? '');

    // Validate input
    if (empty($user_id) || empty($shop_id)) {
        throw new Exception('User ID và Shop ID không được để trống');
    }

    // Validate format
    if (!preg_match('/^USR\d{8}$/', $user_id)) {
        throw new Exception('User ID phải có định dạng: USR + 8 số');
    }

    if (!preg_match('/^SHP\d{8}$/', $shop_id)) {
        throw new Exception('Shop ID phải có định dạng: SHP + 8 số');
    }

    // Check if user exists
    $checkUserStmt = $pdo->prepare("SELECT id FROM users WHERE user_id = ? AND deleted_at IS NULL");
    $checkUserStmt->execute([$user_id]);
    if (!$checkUserStmt->fetch()) {
        throw new Exception('User ID không tồn tại trong hệ thống');
    }

    // Check if shop exists
    $checkShopStmt = $pdo->prepare("SELECT id FROM shops WHERE shop_id = ? AND user_id = ? AND deleted_at IS NULL");
    $checkShopStmt->execute([$shop_id, $user_id]);
    if (!$checkShopStmt->fetch()) {
        throw new Exception('Shop ID không tồn tại hoặc không thuộc về user này');
    }

    // File validation
    $file = $_FILES['excel_file'];
    $allowed_extensions = ['txt', 'csv'];
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_extension, $allowed_extensions)) {
        throw new Exception('Chỉ chấp nhận file TXT hoặc CSV');
    }

    if ($file['size'] > 10 * 1024 * 1024) { // 10MB
        throw new Exception('File quá lớn (tối đa 10MB)');
    }

    // Read file content
    $file_content = file_get_contents($file['tmp_name']);
    if ($file_content === false) {
        throw new Exception('Không thể đọc nội dung file');
    }

    // Convert encoding if needed
    $encoding = mb_detect_encoding($file_content, ['UTF-8', 'Windows-1252', 'ISO-8859-1'], true);
    if ($encoding !== 'UTF-8') {
        $file_content = mb_convert_encoding($file_content, 'UTF-8', $encoding);
    }

    // Split into lines
    $lines = explode("\n", $file_content);
    $lines = array_map('trim', $lines);
    $lines = array_filter($lines); // Remove empty lines

    if (empty($lines)) {
        throw new Exception('File trống hoặc không có dữ liệu hợp lệ');
    }

    // Remove header line
    array_shift($lines);
    $response['total_rows'] = count($lines);

    if ($response['total_rows'] === 0) {
        throw new Exception('File chỉ có header, không có dữ liệu');
    }

    // Prepare insert statement for contracts
    $insertStmt = $pdo->prepare("
        INSERT INTO contracts (
            user_id, shop_id, code_id, type_id, customer_id, customer_name, 
            customer_phone, customer_number_card, total_money, total_money_received, 
            rate_type, loan_time, frequency, from_date, is_before, note, staff_id, 
            edit_loan, total_paid, current_status
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )
    ");

    // Begin transaction
    $pdo->beginTransaction();

    // Process each line
    foreach ($lines as $line_number => $line) {
        $actual_line = $line_number + 2; // +2 because we removed header and array is 0-based
        
        try {
            if (empty(trim($line))) {
                continue;
            }

            // Split by pipe (|) separator
            $columns = explode('|', $line);
            $columns = array_map('trim', $columns);

            // Ensure we have at least the required columns
            if (count($columns) < 15) {
                $response['errors'][] = array(
                    'row' => $actual_line,
                    'message' => 'Không đủ số cột yêu cầu (cần 15 cột)'
                );
                $response['error_count']++;
                continue;
            }

            // Parse data from columns
            $contract_data = parseContractData($columns, $actual_line);
            
            if ($contract_data === false) {
                $response['error_count']++;
                continue;
            }

            // Add user_id and shop_id
            $contract_data['user_id'] = $user_id;
            $contract_data['shop_id'] = $shop_id;

            // Check if contract already exists
            $checkStmt = $pdo->prepare("SELECT id FROM contracts WHERE code_id = ? AND user_id = ? AND shop_id = ?");
            $checkStmt->execute([$contract_data['code_id'], $user_id, $shop_id]);
            
            if ($checkStmt->fetch()) {
                $response['warnings'][] = array(
                    'row' => $actual_line,
                    'message' => "Hợp đồng {$contract_data['code_id']} đã tồn tại, bỏ qua"
                );
                continue;
            }

            // Insert contract
            $insertStmt->execute([
                $contract_data['user_id'],
                $contract_data['shop_id'],
                $contract_data['code_id'],
                $contract_data['type_id'],
                $contract_data['customer_id'],
                $contract_data['customer_name'],
                $contract_data['customer_phone'],
                $contract_data['customer_number_card'],
                $contract_data['total_money'],
                $contract_data['total_money_received'],
                $contract_data['rate_type'],
                $contract_data['loan_time'],
                $contract_data['frequency'],
                $contract_data['from_date'],
                $contract_data['is_before'],
                $contract_data['note'],
                $contract_data['staff_id'],
                $contract_data['edit_loan'],
                $contract_data['amount_paid'],
                $contract_data['amount_paid'] >= $contract_data['total_money'] ? 'completed' : 'active'
            ]);

            $contractId = $pdo->lastInsertId();

            // Create payment schedule and update based on paid amount - SỬA ĐỔI CHÍNH
            $paymentScheduleResult = createPaymentScheduleForContractImport($pdo, $contractId, $contract_data);

            $response['success_count']++;

        } catch (Exception $e) {
            $response['errors'][] = array(
                'row' => $actual_line,
                'message' => $e->getMessage()
            );
            $response['error_count']++;
        }
    }

    // Commit transaction
    $pdo->commit();

    $response['success'] = true;
    $response['message'] = "Xử lý hoàn tất. Thành công: {$response['success_count']}, Lỗi: {$response['error_count']}";

} catch (Exception $e) {
    // Rollback transaction if it was started
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollback();
    }
    
    $response['success'] = false;
    $response['message'] = $e->getMessage();
} catch (Error $e) {
    // Catch fatal errors
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollback();
    }
    
    $response['success'] = false;
    $response['message'] = 'Lỗi hệ thống: ' . $e->getMessage();
}

// Clean any output buffer
ob_clean();

// Return JSON response
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;

/**
 * Parse contract data from CSV columns
 */
function parseContractData($columns, $line_number) {
    global $response;
    
    try {
        // Map columns according to the format
        // 0: Mã HĐ, 1: Tên KH, 2: SĐT, 3: Trả Góp, 4: Tiền giao khách, 
        // 5: Tỷ lệ, 6: Ngày bốc, 7: Ngày hết hạn, 8: Đã đóng đến ngày, 
        // 9: Đã đóng được, 10: Tiền còn phải đóng, 11: Ngày đóng họ tiếp theo,
        // 12: Tiền thu theo kỳ, 13: Tiền nợ, 14: CMND/CCCD

        $contract_code = trim($columns[0]);
        $customer_name = trim($columns[1]);
        $customer_phone = trim($columns[2] ?? '');
        $installment_amount = parseNumber($columns[3] ?? '0');
        $money_given = parseNumber($columns[4] ?? '0');
        $interest_rate = trim($columns[5] ?? '');
        $start_date = parseDate($columns[6] ?? '');
        $end_date = parseDate($columns[7] ?? '');
        $paid_until_date = parseDate($columns[8] ?? '');
        $amount_paid = parseNumber($columns[9] ?? '0');
        $amount_remaining = parseNumber($columns[10] ?? '0');
        $next_payment_date = parseDate($columns[11] ?? '');
        $payment_per_period = parseNumber($columns[12] ?? '0');
        $debt_amount = parseNumber($columns[13] ?? '0');
        $customer_id_card = trim($columns[14] ?? '');

        // Validate required fields
        if (empty($contract_code)) {
            throw new Exception('Mã hợp đồng không được để trống');
        }

        if (empty($customer_name)) {
            throw new Exception('Tên khách hàng không được để trống');
        }

        if (!$start_date) {
            throw new Exception('Ngày bốc không hợp lệ');
        }

        if (!$end_date) {
            throw new Exception('Ngày hết hạn không hợp lệ');
        }

        // Validate debt_amount
        if ($debt_amount > 0) {
            throw new Exception('Tiền nợ > 0, không hỗ trợ xử lý partial/overdue trong import này');
        }

        // Parse interest rate (format: "10 ăn 7.69")
        $rate_info = parseInterestRate($interest_rate);
        
        // Calculate loan time and frequency
        $loan_days = calculateLoanDays($start_date, $end_date);
        $frequency = $rate_info['periods']; // Use periods from interest rate (e.g., 10 from "10 ăn 7.69")

        // Validate amount consistency
        if ($amount_paid + $amount_remaining != $installment_amount) {
            $response['warnings'][] = array(
                'row' => $line_number,
                'message' => "Tổng tiền đã đóng ($amount_paid) và còn phải đóng ($amount_remaining) không khớp với tổng tiền trả góp ($installment_amount)"
            );
        }

        return array(
            'code_id' => $contract_code,
            'type_id' => 1, // Default contract type (e.g., Vay thường)
            'customer_id' => 0, // Default customer ID
            'customer_name' => $customer_name,
            'customer_phone' => $customer_phone,
            'customer_number_card' => $customer_id_card,
            'customer_address' => '', // Not provided in file
            'customer_card_date' => null, // Not provided in file
            'customer_place' => '', // Not provided in file
            'total_money' => $installment_amount,
            'total_money_received' => $money_given,
            'rate_type' => 1, // Default rate type
            'loan_time' => $loan_days,
            'frequency' => $frequency,
            'from_date' => $start_date,
            'is_before' => 0,
            'note' => "Imported from file. Interest: {$interest_rate}. Paid: {$amount_paid}. Remaining: {$amount_remaining}. Paid until: {$paid_until_date}",
            'staff_id' => 'STF00000001', // Default staff
            'edit_loan' => 0,
            'amount_paid' => $amount_paid,
            'paid_until_date' => $paid_until_date,
            'payment_per_period' => $payment_per_period,
            'amount_remaining' => $amount_remaining,
            'next_payment_date' => $next_payment_date
        );

    } catch (Exception $e) {
        $response['errors'][] = array(
            'row' => $line_number,
            'message' => $e->getMessage()
        );
        return false;
    }
}

/**
 * Parse number from string (remove commas, handle Vietnamese format)
 */
function parseNumber($str) {
    if (empty($str)) return 0;
    
    // Remove commas and spaces
    $str = str_replace([',', ' '], '', $str);
    
    // Convert to float
    return (float) $str;
}

/**
 * Parse date from dd-mm-yyyy format
 */
function parseDate($dateStr) {
    if (empty($dateStr)) return null;
    
    $dateStr = trim($dateStr);
    
    // Try to parse dd-mm-yyyy format
    if (preg_match('/^(\d{1,2})-(\d{1,2})-(\d{4})$/', $dateStr, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        // Validate date
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        }
    }
    
    return null;
}

/**
 * Parse interest rate from format "10 ăn 7.69"
 */
function parseInterestRate($rateStr) {
    $periods = 10; // Default
    $rate = 0.0; // Default
    
    if (preg_match('/(\d+)\s*ăn\s*([0-9.]+)/', $rateStr, $matches)) {
        $periods = (int) $matches[1];
        $rate = (float) $matches[2];
    }
    
    return array(
        'periods' => $periods,
        'rate' => $rate
    );
}

/**
 * Calculate loan days between start and end date
 */
function calculateLoanDays($startDate, $endDate) {
    if (!$startDate || !$endDate) return 30; // Default
    
    $start = new DateTime($startDate);
    $end = new DateTime($endDate);
    $interval = $start->diff($end);
    
    return $interval->days + 1; // Inclusive
}

/**
 * HÀM MỚI: Create payment schedule for contract và update dựa trên paid amount
 * SỬA ĐỔI CHÍNH: Sử dụng logic từ createPaymentScheduleForContract trong contracts.php
 */
function createPaymentScheduleForContractImport($pdo, $contractId, $contract_data) {
    error_log("=== CREATE PAYMENT SCHEDULE FOR CONTRACT IMPORT $contractId ===");
    
    try {
        // Lấy thông tin từ bảng contracts
        $contractStmt = $pdo->prepare("SELECT * FROM contracts WHERE id = ?");
        $contractStmt->execute([$contractId]);
        $contract = $contractStmt->fetch();
        
        if (!$contract) {
            throw new Exception("Không tìm thấy hợp đồng với ID: $contractId");
        }
        
        // Lấy thông tin lãi suất từ contract_types (nếu có)
        $interestRate = 0.0;
        $penaltyRate = 0.0;
        
        if ($contract['rate_type'] > 0) {
            $typeStmt = $pdo->prepare("SELECT interest_rate, penalty_rate FROM contract_types WHERE id = ?");
            $typeStmt->execute([$contract['rate_type']]);
            $typeInfo = $typeStmt->fetch();
            
            if ($typeInfo) {
                $interestRate = (float)$typeInfo['interest_rate'];
                $penaltyRate = (float)$typeInfo['penalty_rate'];
            }
        }
        
        // Tính toán các thông số - GIỐNG LOGIC TRONG CONTRACTS.PHP
        $totalMoney = (float)$contract['total_money'];
        $loanTime = (int)$contract['loan_time'];
        $frequency = (int)$contract['frequency'];
        $fromDate = $contract['from_date'];
        $amountPaid = (float)$contract_data['amount_paid'];
        $paidUntilDate = $contract_data['paid_until_date'];
        
        // Bước 1: Tính số kỳ trả nợ
        $totalPeriods = ceil($loanTime / $frequency);
        
        // Bước 2: Tính số tiền mỗi kỳ - SỬA ĐỔI THEO LOGIC CONTRACTS.PHP
        $theoreticalAmount = $totalMoney * $frequency / $loanTime;
        $amountPerPeriod = floor($theoreticalAmount / $frequency) * $frequency;
        $numEqualPeriods = $totalPeriods - 1;
        $totalEqualAmount = $numEqualPeriods * $amountPerPeriod;
        $lastPayment = $totalMoney - $totalEqualAmount;
        
        error_log("Contract ID: $contractId, Total Periods: $totalPeriods, Amount per period: $amountPerPeriod, Last payment: $lastPayment, Interest Rate: $interestRate");
        
        // Tạo lịch trả cho từng kỳ
        $insertStmt = $pdo->prepare("
            INSERT INTO payment_schedules (
                contract_id, user_id, shop_id, code_id, customer_id,
                period_number, from_date, to_date, due_date,
                amount_due, amount_paid, amount_remaining, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $transStmt = $pdo->prepare("
            INSERT INTO payment_transactions (
                contract_id, schedule_id, user_id, shop_id, code_id, customer_id,
                transaction_code, payment_date, amount_paid, payment_method, status, note, staff_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'cash', 'completed', 'Imported from TXT file', ?)
        ");
        
        $schedulesCreated = 0;
        $remainingPaidAmount = $amountPaid;
        
        for ($i = 1; $i <= $totalPeriods; $i++) {
            // Tính ngày bắt đầu và kết thúc của kỳ
            $periodFromDate = date('Y-m-d', strtotime($fromDate . " + " . (($i - 1) * $frequency) . " days"));
            $periodToDate = date('Y-m-d', strtotime($periodFromDate . " + " . ($frequency - 1) . " days"));
            $dueDate = $periodToDate; // Ngày đáo hạn là ngày cuối của kỳ
            
            // Gán số tiền cho kỳ hiện tại
            $currentAmount = ($i == $totalPeriods) ? $lastPayment : $amountPerPeriod;
            $currentAmount = round($currentAmount, 2);
            
            // Xác định trạng thái và số tiền đã trả dựa trên số tiền đã thanh toán - LOGIC MỚI
            $status = 'pending';
            $amountPaidThisPeriod = 0;
            $amountRemainingThisPeriod = $currentAmount;
            
            if ($remainingPaidAmount >= $currentAmount) {
                // Kỳ này được thanh toán đầy đủ
                $status = 'paid';
                $amountPaidThisPeriod = $currentAmount;
                $amountRemainingThisPeriod = 0;
                $remainingPaidAmount -= $currentAmount;
            } elseif ($remainingPaidAmount > 0) {
                // Thanh toán một phần
                $status = 'partial_paid';
                $amountPaidThisPeriod = $remainingPaidAmount;
                $amountRemainingThisPeriod = $currentAmount - $remainingPaidAmount;
                $remainingPaidAmount = 0;
            }
            
            // Insert payment schedule
            $insertStmt->execute([
                $contract['id'],
                $contract['user_id'],
                $contract['shop_id'],
                $contract['code_id'],
                $contract['customer_id'],
                $i,
                $periodFromDate,
                $periodToDate,
                $dueDate,
                $currentAmount,
                $amountPaidThisPeriod,
                $amountRemainingThisPeriod,
                $status
            ]);
            
            $scheduleId = $pdo->lastInsertId();
            $schedulesCreated++;
            
            // TỰ ĐỘNG TẠO PAYMENT TRANSACTION cho các kỳ đã thanh toán
            if ($amountPaidThisPeriod > 0) {
                $transactionCode = 'IMP' . date('YmdHis') . $contractId . str_pad($i, 3, '0', STR_PAD_LEFT);
                
                $transStmt->execute([
                    $contract['id'],
                    $scheduleId,
                    $contract['user_id'],
                    $contract['shop_id'], 
                    $contract['code_id'],
                    $contract['customer_id'],
                    $transactionCode,
                    $paidUntilDate ?: $dueDate, // Sử dụng ngày đã đóng hoặc due date
                    $amountPaidThisPeriod,
                    $contract['staff_id'] ?: 'STF00000001'
                ]);
                
                error_log("Created payment transaction for period $i: Amount $amountPaidThisPeriod, Transaction Code: $transactionCode");
            }
            
            error_log("Created schedule period $i: $periodFromDate to $periodToDate, due: $dueDate, amount: $currentAmount, paid: $amountPaidThisPeriod, status: $status");
        }
        
        // Update contract total_paid - TÍNH LẠI TỪ PAYMENT TRANSACTIONS
        $updateStmt = $pdo->prepare("
            UPDATE contracts 
            SET total_paid = (SELECT COALESCE(SUM(amount_paid), 0) 
                            FROM payment_transactions 
                            WHERE contract_id = ? AND status = 'completed')
            WHERE id = ?
        ");
        $updateStmt->execute([$contractId, $contractId]);
        
        return [
            'success' => true,
            'message' => "Đã tạo $schedulesCreated kỳ trả nợ và " . ($amountPaid > 0 ? "cập nhật thanh toán" : "chưa có thanh toán"),
            'total_periods' => $totalPeriods,
            'amount_per_period' => $amountPerPeriod,
            'last_payment' => $lastPayment,
            'total_paid_amount' => $amountPaid,
            'interest_rate' => $interestRate,
            'penalty_rate' => $penaltyRate
        ];
        
    } catch (Exception $e) {
        error_log("Payment Schedule Creation Error: " . $e->getMessage());
        throw $e;
    }
}
?>