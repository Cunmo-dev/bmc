<?php
/**
 * API để cập nhật trạng thái của một hợp đồng cụ thể
 * File: update_single_contract_status.php
 */

require_once 'database.php';
header('Content-Type: application/json');

// Thiết lập timezone
date_default_timezone_set('Asia/Ho_Chi_Minh');

// function calculateDetailedStatus($contract) {
//     $today = new DateTime();
//     $today->setTime(0, 0, 0); // Đặt về đầu ngày

//     // Tính toán ngày bắt đầu và các thông số cơ bản
//     $fromDate = new DateTime($contract['from_date']);
//     $loanDays = (int)($contract['loan_time'] ?? 0);
//     $frequency = (int)($contract['frequency'] ?? 1);
//     $totalPeriods = (int)($contract['total_periods'] ?? 0);
//     $paidPeriods = (int)($contract['paid_periods'] ?? 0);

//     // Tính ngày kết thúc hợp đồng (ngày trả gốc)
//     $endDate = clone $fromDate;
//     $endDate->add(new DateInterval("P{$loanDays}D"));
//     $endDate->sub(new DateInterval('P1D')); // Trừ 1 ngày

//     // Tìm kỳ thanh toán tiếp theo chưa được thanh toán
//     $nextUnpaidPeriod = findNextUnpaidPeriod($contract, $fromDate, $frequency, $paidPeriods, $totalPeriods);

//     // KIỂM TRA THỰC SỰ ĐÃ HOÀN THÀNH dựa trên dữ liệu
//     if ($paidPeriods >= $totalPeriods && $totalPeriods > 0) {
//         return [
//             'status' => 'Đã hoàn thành'
//         ];
//     }

//     // Nếu không có kỳ nào chưa thanh toán và đã qua ngày kết thúc
//     if (!$nextUnpaidPeriod && $today > $endDate) {
//         return [
//             'status' => 'Quá hạn trả gốc'
//         ];
//     }

//     // Nếu hôm nay là ngày kết thúc hợp đồng
//     if ($today->format('Y-m-d') === $endDate->format('Y-m-d')) {
//         return [
//             'status' => 'Trả gốc hôm nay'
//         ];
//     }

//     // Nếu không có kỳ thanh toán nào chưa thanh toán
//     if (!$nextUnpaidPeriod) {
//         return [
//             'status' => 'Đã hoàn thành'
//         ];
//     }

//     $nextPaymentDate = $nextUnpaidPeriod['date'];
//     $daysDiff = $today->diff($nextPaymentDate)->format('%r%a');

//     // Logic trạng thái dựa trên ngày thanh toán tiếp theo
//     if ($daysDiff < 0) {
//         // Đã qua ngày thanh toán - Chậm họ
//         return [
//             'status' => 'Chậm họ'
//         ];
//     } else if ($daysDiff == 0) {
//         // Hôm nay phải đóng - Đến ngày đóng họ
//         return [
//             'status' => 'Đến ngày đóng họ'
//         ];
//     } else if ($daysDiff == 1) {
//         // Ngày mai phải đóng - Ngày mai đóng họ
//         return [
//             'status' => 'Ngày mai đóng họ'
//         ];
//     } else {
//         // Còn thời gian - Đang vay
//         return [
//             'status' => 'Đang vay'
//         ];
//     }
// }
function calculateDetailedStatus($contract) {
    $today = new DateTime();
    $today->setTime(0, 0, 0); // Đặt về đầu ngày

    // Tính toán ngày bắt đầu và các thông số cơ bản
    $fromDate = new DateTime($contract['from_date']);
    $loanDays = (int)($contract['loan_time'] ?? 0);
    $frequency = (int)($contract['frequency'] ?? 1);
    $totalPeriods = (int)($contract['total_periods'] ?? 0);
    $paidPeriods = (int)($contract['paid_periods'] ?? 0);

    // Tính ngày kết thúc hợp đồng (ngày trả gốc)
    $endDate = clone $fromDate;
    $endDate->add(new DateInterval("P{$loanDays}D"));
    $endDate->sub(new DateInterval('P1D')); // Trừ 1 ngày vì ngày đầu đã được tính

    // KIỂM TRA CÁC TRƯỜNG HỢP ƯU TIÊN CAO NHẤT

    // 1. Kiểm tra nếu đã thanh toán đủ số kỳ (hoàn thành)
    if ($totalPeriods > 0 && $paidPeriods >= $totalPeriods) {
        return [
            'status' => 'Đã hoàn thành'
        ];
    }

    // 2. Kiểm tra nếu hôm nay là ngày kết thúc hợp đồng
    if ($today->format('Y-m-d') === $endDate->format('Y-m-d')) {
        return [
            'status' => 'Trả gốc hôm nay'
        ];
    }

    // 3. Kiểm tra nếu hợp đồng đã quá ngày kết thúc - PHẢI KIỂM TRA TRƯỚC KHI XỬ LÝ LOGIC KỲ THANH TOÁN
    if ($today > $endDate) {
        return [
            'status' => 'Quá hạn'
        ];
    }

    // XỬ LÝ CÁC TRẠNG THÁI TRONG QUÁ TRÌNH VAY (CHỈ KHI CHƯA QUÁ NGÀY KẾT THÚC)

    // 4. Tìm kỳ thanh toán tiếp theo chưa được thanh toán
    $nextUnpaidPeriod = findNextUnpaidPeriod($contract, $fromDate, $frequency, $paidPeriods, $totalPeriods);

    // 5. Nếu không có kỳ thanh toán nào chưa thanh toán (đã hoàn thành tất cả)
    if (!$nextUnpaidPeriod) {
        return [
            'status' => 'Đã hoàn thành'
        ];
    }

    // 6. Xử lý logic dựa trên kỳ thanh toán tiếp theo
    $nextPaymentDate = $nextUnpaidPeriod['date'];
    $daysDiff = $today->diff($nextPaymentDate);
    $daysDiffValue = (int)$daysDiff->format('%r%a'); // Lấy số ngày có dấu

    // Logic trạng thái dựa trên ngày thanh toán tiếp theo (chỉ khi trong thời hạn hợp đồng)
    if ($daysDiffValue < 0) {
        // Đã qua ngày thanh toán - Chậm họ (nhưng vẫn trong thời hạn hợp đồng)
        return [
            'status' => 'Chậm họ'
        ];
    } else if ($daysDiffValue == 0) {
        // Hôm nay phải đóng - Đến ngày đóng họ
        return [
            'status' => 'Đến ngày đóng họ'
        ];
    } else if ($daysDiffValue == 1) {
        // Ngày mai phải đóng - Ngày mai đóng họ
        return [
            'status' => 'Ngày mai đóng họ'
        ];
    } else {
        // Còn thời gian - Đang vay
        return [
            'status' => 'Đang vay'
        ];
    }
}
function findNextUnpaidPeriod($contract, $fromDate, $frequency, $paidPeriods, $totalPeriods) {
    // Nếu đã thanh toán đủ số kỳ
    if ($paidPeriods >= $totalPeriods) {
        return null;
    }

    // Tính ngày thanh toán của kỳ tiếp theo (kỳ đầu tiên chưa thanh toán)
    $nextPeriodIndex = $paidPeriods; // Index của kỳ tiếp theo (0-based)
    $nextPaymentDate = clone $fromDate;
    $nextPaymentDate->add(new DateInterval("P" . ($nextPeriodIndex * $frequency) . "D"));

    return [
        'period' => $nextPeriodIndex + 1,
        'date' => $nextPaymentDate
    ];
}

function getContractData($pdo, $contractId) {
    try {
        // Query để lấy thông tin hợp đồng kèm theo thông tin thanh toán
        $sql = "
            SELECT 
                c.*,
                -- Tính tổng số kỳ dựa trên loan_time và frequency
                CEIL(c.loan_time / c.frequency) as total_periods,
                -- Tính số kỳ đã thanh toán từ payment_schedules
                COALESCE(
                    (SELECT COUNT(*) 
                     FROM payment_schedules ps 
                     WHERE ps.contract_id = c.id 
                     AND ps.status = 'paid'), 0
                ) as paid_periods,
                -- Tính tổng số tiền đã thu từ payment_schedules
                COALESCE(
                    (SELECT SUM(amount_paid) 
                     FROM payment_schedules ps 
                     WHERE ps.contract_id = c.id 
                     AND ps.status = 'paid'), 0
                ) as paid_amount,
                -- Tính số tiền còn lại
                (c.total_money - COALESCE(
                    (SELECT SUM(amount_paid) 
                     FROM payment_schedules ps 
                     WHERE ps.contract_id = c.id 
                     AND ps.status = 'paid'), 0
                )) as remaining_amount,
                -- Tính số tiền mỗi kỳ
                ROUND(c.total_money / CEIL(c.loan_time / c.frequency), 2) as money_per_period
            FROM contracts c
            WHERE c.id = ?
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$contractId]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return null;
    }
}

function updateContractStatus($pdo, $contractId, $newStatus) {
    try {
        $sql = "UPDATE contracts SET 
                current_status = :status,
                updated_at = CURRENT_TIMESTAMP 
                WHERE id = :id";
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':status' => $newStatus,
            ':id' => $contractId
        ]);
        
        return $result;
    } catch (Exception $e) {
        return false;
    }
}

// Xử lý request
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Chỉ chấp nhận method POST');
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['contract_id'])) {
        throw new Exception('Thiếu contract_id');
    }

    $contractId = (int)$input['contract_id'];
    
    // Kiểm tra kết nối database
    if (!$pdo) {
        throw new Exception('Không thể kết nối database');
    }

    // Lấy dữ liệu hợp đồng
    $contract = getContractData($pdo, $contractId);
    
    if (!$contract) {
        throw new Exception('Không tìm thấy hợp đồng');
    }

    // Tính toán trạng thái mới
    $statusResult = calculateDetailedStatus($contract);
    $newStatus = $statusResult['status'];
    $oldStatus = $contract['current_status'];

    // Cập nhật trạng thái
    $success = updateContractStatus($pdo, $contractId, $newStatus);
    
    if ($success) {
        echo json_encode([
            'success' => true,
            'message' => 'Cập nhật trạng thái hợp đồng thành công',
            'data' => [
                'contract_id' => $contractId,
                'old_status' => $oldStatus,
                'new_status' => $newStatus,
                'updated_at' => date('Y-m-d H:i:s')
            ]
        ]);
    } else {
        throw new Exception('Lỗi khi cập nhật trạng thái hợp đồng');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>