<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
session_start();
// Include database connection
require_once 'database.php'; // Thay đổi đường dẫn phù hợp

try {
    $deletedContractId = $_GET['id'] ?? null;
    
    if (!$deletedContractId) {
        throw new Exception("ID hợp đồng đã xóa không được cung cấp");
    }
    
    handleGetDeletedContractDetails($pdo, $deletedContractId);
    
} catch (Exception $e) {
    error_log("Get deleted contract details error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Có lỗi xảy ra: ' . $e->getMessage()
    ]);
}

function handleGetDeletedContractDetails($pdo, $deletedContractId) {
    try {
        // Lấy thông tin hợp đồng đã xóa (không JOIN với bảng users)
        $stmt = $pdo->prepare("
            SELECT dc.*
            FROM deleted_contracts dc
            WHERE dc.id = :id
        ");
        $stmt->execute([':id' => $deletedContractId]);
        $deletedContract = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$deletedContract) {
            throw new Exception("Không tìm thấy hợp đồng đã xóa");
        }
        
        // Parse payment schedules data
        $paymentSchedules = [];
        if (!empty($deletedContract['payment_schedules_data'])) {
            $paymentSchedules = json_decode($deletedContract['payment_schedules_data'], true) ?: [];
        }
        
        // Parse payment transactions data
        $paymentTransactions = [];
        if (!empty($deletedContract['payment_transactions_data'])) {
            $paymentTransactions = json_decode($deletedContract['payment_transactions_data'], true) ?: [];
        }
        
        // Parse contract metadata
        $contractMetadata = [];
        if (!empty($deletedContract['contract_metadata'])) {
            $contractMetadata = json_decode($deletedContract['contract_metadata'], true) ?: [];
        }
        
        // Format dates
        $deletedContract['formatted_from_date'] = date('d/m/Y', strtotime($deletedContract['from_date']));
        $deletedContract['formatted_created_at'] = date('d/m/Y H:i', strtotime($deletedContract['original_created_at']));
        $deletedContract['formatted_deleted_at'] = date('d/m/Y H:i', strtotime($deletedContract['deleted_at']));
        
        // Thêm thông tin vào response
        $deletedContract['payment_schedules'] = $paymentSchedules;
        $deletedContract['payment_transactions'] = $paymentTransactions;
        $deletedContract['metadata'] = $contractMetadata;
        
        // Tính toán thống kê
        $deletedContract['total_schedules'] = count($paymentSchedules);
        $deletedContract['paid_schedules'] = count(array_filter($paymentSchedules, function($s) { 
            return isset($s['status']) && $s['status'] == 'paid'; 
        }));
        $deletedContract['total_transactions'] = count($paymentTransactions);
        $deletedContract['remaining_amount'] = $deletedContract['total_money'] - $deletedContract['total_paid'];
        
        // Sử dụng deleted_by làm deleted_by_name nếu không có bảng users
        $deletedContract['deleted_by_name'] = $deletedContract['deleted_by'];
        
        echo json_encode([
            'success' => true,
            'data' => $deletedContract
        ]);
        
    } catch(Exception $e) {
        error_log("Error getting deleted contract details: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
?>