<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
session_start();
// Include database connection
require_once 'database.php'; // Thay đổi đường dẫn phù hợp

try {
    // Lấy parameters từ GET request
    $shopId = $_GET['shopId'] ?? null;
    $userId = $_GET['userId'] ?? null;

    // Gọi hàm từ code bạn đã có
    $params = [
        'shopId' => $shopId,
        'userId' => $userId
    ];
    
    handleGetDeletedContracts($pdo, $params);
    
} catch (Exception $e) {
    error_log("Get deleted contracts error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Có lỗi xảy ra: ' . $e->getMessage()
    ]);
}

// Hàm đã có từ code của bạn
function handleGetDeletedContracts($pdo, $params) {
    try {
        $shopId = $params['shopId'] ?? null;
        $userId = $params['userId'] ?? null;
        
        // Add these missing variables
        $page = $params['page'] ?? 1;
        $limit = $params['limit'] ?? 50;
        $offset = ($page - 1) * $limit;
        
        $whereConditions = [];
        $queryParams = [];
        
        if ($shopId) {
            $whereConditions[] = "shop_id = :shop_id";
            $queryParams[':shop_id'] = $shopId;
        }
        
        if ($userId) {
            $whereConditions[] = "user_id = :user_id";
            $queryParams[':user_id'] = $userId;
        }

        $whereClause = empty($whereConditions) ? '' : 'WHERE ' . implode(' AND ', $whereConditions);
        
        // Đếm tổng số record
        $countSql = "SELECT COUNT(*) as total FROM deleted_contracts $whereClause";
        $countStmt = $pdo->prepare($countSql);
        $countStmt->execute($queryParams);
        $totalRecords = $countStmt->fetch()['total'];
        
        // Lấy dữ liệu với thông tin bổ sung
        $sql = "SELECT 
            dc.id, dc.original_contract_id, dc.code_id, dc.customer_name, dc.customer_phone,
            dc.total_money, dc.total_money_received, dc.total_paid,
            DATE_FORMAT(dc.from_date, '%d/%m/%Y') as formatted_from_date,
            DATE_FORMAT(dc.original_created_at, '%d/%m/%Y %H:%i') as formatted_created_at,
            DATE_FORMAT(dc.deleted_at, '%d/%m/%Y %H:%i') as formatted_deleted_at,
            dc.deleted_by, dc.deletion_reason, dc.deletion_status,
            (dc.total_money - dc.total_paid) as remaining_amount,
            dc.deleted_by as deleted_by_name  -- Use deleted_by field directly
        FROM deleted_contracts dc
        $whereClause
        ORDER BY dc.deleted_at DESC
        LIMIT :limit OFFSET :offset";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_merge($queryParams, [':limit' => $limit, ':offset' => $offset]));
        $deletedContracts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Lấy thống kê tổng quan
        $statsParams = array_diff_key($queryParams, [':limit' => '', ':offset' => '']);
        $statsSql = "SELECT 
                        COUNT(*) as total_contracts,
                        COALESCE(SUM(total_money_received), 0) as total_money_lent,
                        COALESCE(SUM(total_paid), 0) as total_money_collected
                     FROM deleted_contracts $whereClause";
        
        $statsStmt = $pdo->prepare($statsSql);
        $statsStmt->execute($statsParams);
        $statistics = $statsStmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $deletedContracts,
            'pagination' => [
                'currentPage' => $page,
                'totalPages' => ceil($totalRecords / $limit),
                'totalRecords' => $totalRecords,
                'limit' => $limit
            ],
            'statistics' => $statistics
        ]);
        
    } catch(Exception $e) {
        error_log("Error getting deleted contracts: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
?>