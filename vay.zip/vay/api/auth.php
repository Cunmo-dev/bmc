<?php
    require_once 'database.php';
    session_start();

    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        exit(0);
    }

    $action = $_GET['action'] ?? '';

    switch ($action) {
        case 'login':
            handleLogin();
            break;
        case 'register':
            handleRegister();
            break;
        case 'logout':
            handleLogout();
            break;
        case 'check_session':
            checkSession();
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }

    // Helper function để tạo User ID ngẫu nhiên
    function generateUserID($pdo) {
        do {
            $userID = 'USR' . str_pad(mt_rand(1, 99999999), 8, '0', STR_PAD_LEFT);
            $stmt = $pdo->prepare("SELECT id FROM users WHERE user_id = ?");
            $stmt->execute([$userID]);
        } while ($stmt->fetch());
        
        return $userID;
    }

    function handleLogin() {
        global $pdo;
        
        $input = json_decode(file_get_contents('php://input'), true);
        $username = $input['username'] ?? '';
        $password = $input['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'Tên đăng nhập và mật khẩu không được để trống']);
            return;
        }
        
        try {
            // Get user - thêm user_id và store_id vào SELECT
            $stmt = $pdo->prepare("SELECT id, user_id, store_id, username, email, password, store_name FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || !password_verify($password, $user['password'])) {
                echo json_encode(['success' => false, 'message' => 'Tên đăng nhập hoặc mật khẩu không chính xác']);
                return;
            }
            
            // Invalidate existing sessions for this user
            $stmt = $pdo->prepare("UPDATE user_sessions SET is_active = FALSE WHERE user_id = ?");
            $stmt->execute([$user['id']]);
            
            // Create new session
            $sessionToken = bin2hex(random_bytes(32));
            $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            
            $stmt = $pdo->prepare("INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user['id'], $sessionToken, $ipAddress, $userAgent]);
            $_SESSION['user_id'] = $user['user_id'];
$_SESSION['store_id'] = $user['store_id'];
$_SESSION['username'] = $user['username'];
            echo json_encode([
                'success' => true,
                'message' => 'Đăng nhập thành công',
                'session_token' => $sessionToken,
                'user' => [
                    'id' => $user['id'],
                    'user_id' => $user['user_id'],      // Thêm user_id
                    'store_id' => $user['store_id'],    // Thêm store_id
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'store_name' => $user['store_name'] ?? ''
                ]
            ]);
            
        } catch (Exception $e) {
            error_log('Login error: ' . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống, vui lòng thử lại sau']);
        }
    }
    function handleRegister() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $storeName = trim($input['store_name'] ?? '');
    $username = trim($input['username'] ?? '');
    $email = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';
    $initialCapital = $input['initial_capital'] ?? 0;
if (!is_numeric($initialCapital) || $initialCapital < 0) {
    echo json_encode(['success' => false, 'message' => 'Vốn khởi tạo phải là số dương', 'field' => 'initial-capital']);
    return;
}
if ($initialCapital < 100000) {
    echo json_encode(['success' => false, 'message' => 'Vốn khởi tạo không được thấp hơn 100,000 VND', 'field' => 'initial-capital']);
    return;
}
    // Detailed validation (giữ nguyên validation cũ)
    if (empty($storeName)) {
        echo json_encode(['success' => false, 'message' => 'Tên cửa hàng không được để trống', 'field' => 'store-name']);
        return;
    }
    
    if (strlen($storeName) < 2) {
        echo json_encode(['success' => false, 'message' => 'Tên cửa hàng phải có ít nhất 2 ký tự', 'field' => 'store-name']);
        return;
    }
    
    if (empty($username)) {
        echo json_encode(['success' => false, 'message' => 'Tên đăng nhập không được để trống', 'field' => 'username']);
        return;
    }
    
    if (strlen($username) < 3) {
        echo json_encode(['success' => false, 'message' => 'Tên đăng nhập phải có ít nhất 3 ký tự', 'field' => 'username']);
        return;
    }
    
    if (empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Email không được để trống', 'field' => 'email']);
        return;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Định dạng email không hợp lệ', 'field' => 'email']);
        return;
    }
    
    if (empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Mật khẩu không được để trống', 'field' => 'password']);
        return;
    }
    
    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'Mật khẩu phải có ít nhất 6 ký tự', 'field' => 'password']);
        return;
    }
    
    // Kiểm tra ký tự đặc biệt trong username
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        echo json_encode(['success' => false, 'message' => 'Tên đăng nhập chỉ được chứa chữ cái, số và dấu gạch dưới', 'field' => 'username']);
        return;
    }
    
    try {
        // Bắt đầu transaction để đảm bảo data consistency
        $pdo->beginTransaction();
        
        // Check if username exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => 'Tên đăng nhập đã tồn tại', 'field' => 'username']);
            return;
        }
        
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => 'Email đã được sử dụng', 'field' => 'email']);
            return;
        }
        
        // Check if store name exists trong bảng users
        $stmt = $pdo->prepare("SELECT id FROM users WHERE store_name = ?");
        $stmt->execute([$storeName]);
        if ($stmt->fetch()) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => 'Tên cửa hàng đã được sử dụng', 'field' => 'store-name']);
            return;
        }
        
        // Check if store name exists trong bảng shops (quan trọng!)
        $stmt = $pdo->prepare("SELECT id FROM shops WHERE shop_name = ?");
        $stmt->execute([$storeName]);
        if ($stmt->fetch()) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => 'Tên cửa hàng đã được sử dụng', 'field' => 'store-name']);
            return;
        }
        
        // Tạo random IDs
        $userID = generateUserID($pdo);
        
        $shopId = generateShopID($pdo); // Bạn cần tạo function này
        // Create user
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (user_id, store_id, store_name, username, email, password, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$userID, $shopId, $storeName, $username, $email, $hashedPassword]);

        // **QUAN TRỌNG: Tạo shop mặc định cho user**
        $defaultMoney = $initialCapital; // Hoặc số tiền mặc định bạn muốn
        $defaultStatus = 1; // Active
        
        // Tạo shop_id unique cho shop (nếu bảng shops có trường shop_id riêng)
        
        
        $stmt = $pdo->prepare("INSERT INTO shops (user_id, shop_id, shop_name, total_money_in_safe, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$userID, $shopId, $storeName, $defaultMoney, $defaultStatus]);
        
        // Commit transaction
        $pdo->commit();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Đăng ký thành công! Shop đã được tạo tự động.',
            'user' => [
                'user_id' => $userID,
                'store_id' => $shopId,
                'username' => $username,
                'email' => $email,
                'store_name' => $storeName
            ]
        ]);
        
    } catch (Exception $e) {
        // Rollback nếu có lỗi
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log('Register error: ' . $e->getMessage());
        
        // Kiểm tra lỗi cụ thể
        if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            if (strpos($e->getMessage(), 'username') !== false) {
                echo json_encode(['success' => false, 'message' => 'Tên đăng nhập đã tồn tại', 'field' => 'username']);
            } elseif (strpos($e->getMessage(), 'email') !== false) {
                echo json_encode(['success' => false, 'message' => 'Email đã được sử dụng', 'field' => 'email']);
            } elseif (strpos($e->getMessage(), 'store_name') !== false || strpos($e->getMessage(), 'shop_name') !== false) {
                echo json_encode(['success' => false, 'message' => 'Tên cửa hàng đã được sử dụng', 'field' => 'store-name']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Thông tin đã tồn tại']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống, vui lòng thử lại sau']);
        }
    }
}

// Function tạo Shop ID (bạn cần thêm function này)
function generateShopID($pdo) {
    do {
        $shopID = 'SHP' . str_pad(mt_rand(1, 99999999), 8, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT id FROM shops WHERE shop_id = ?");
        $stmt->execute([$shopID]);
    } while ($stmt->fetch());
    
    return $shopID;
}

    function checkSession() {
        global $pdo;
        
        $sessionToken = $_GET['session_token'] ?? '';
        
        if (empty($sessionToken)) {
            echo json_encode(['success' => false, 'message' => 'Không có session token']);
            return;
        }
        
        try {
            // Check if session exists and is active - thêm user_id và store_id
            $stmt = $pdo->prepare("
                SELECT s.*, u.user_id, u.store_id, u.username, u.email, u.store_name 
                FROM user_sessions s 
                JOIN users u ON s.user_id = u.id 
                WHERE s.session_token = ? AND s.is_active = TRUE
            ");
            $stmt->execute([$sessionToken]);
            $session = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$session) {
                echo json_encode(['success' => false, 'message' => 'Session không hợp lệ']);
                return;
            }
            
            // Kiểm tra session timeout (24 giờ)
            $lastActivity = new DateTime($session['last_activity']);
            $now = new DateTime();
            $diff = $now->diff($lastActivity);
            $hoursDiff = $diff->h + ($diff->days * 24);
            
            if ($hoursDiff > 24) {
                // Vô hiệu hóa session hết hạn
                $stmt = $pdo->prepare("UPDATE user_sessions SET is_active = FALSE WHERE session_token = ?");
                $stmt->execute([$sessionToken]);
                
                echo json_encode(['success' => false, 'message' => 'Session đã hết hạn']);
                return;
            }
            
            // Update last activity
            $stmt = $pdo->prepare("UPDATE user_sessions SET last_activity = CURRENT_TIMESTAMP WHERE session_token = ?");
            $stmt->execute([$sessionToken]);
            
            echo json_encode([
                'success' => true,
                'user' => [
                    'user_id' => $session['user_id'],       // Thêm user_id
                    'store_id' => $session['store_id'],     // Thêm store_id
                    'username' => $session['username'],
                    'email' => $session['email'],
                    'store_name' => $session['store_name'] ?? ''
                ]
            ]);
            
        } catch (Exception $e) {
            error_log('Check session error: ' . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống']);
        }
    }

    function handleLogout() {
        global $pdo;
        
        $sessionToken = $_GET['session_token'] ?? '';
        
        if (!empty($sessionToken)) {
            try {
                $stmt = $pdo->prepare("UPDATE user_sessions SET is_active = FALSE, logged_out_at = CURRENT_TIMESTAMP WHERE session_token = ?");
                $stmt->execute([$sessionToken]);
            } catch (Exception $e) {
                error_log('Logout error: ' . $e->getMessage());
                // Silent fail
            }
        }
        
        echo json_encode(['success' => true, 'message' => 'Đăng xuất thành công']);
    }

    // Hàm helper để làm sạch session cũ (có thể gọi định kỳ)
    function cleanupOldSessions() {
        global $pdo;
        
        try {
            // Xóa session không hoạt động quá 7 ngày
            $stmt = $pdo->prepare("
                UPDATE user_sessions 
                SET is_active = FALSE 
                WHERE is_active = TRUE 
                AND last_activity < DATE_SUB(NOW(), INTERVAL 7 DAY)
            ");
            $stmt->execute();
            
            // Xóa session record cũ hơn 30 ngày
            $stmt = $pdo->prepare("
                DELETE FROM user_sessions 
                WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
            ");
            $stmt->execute();
            
        } catch (Exception $e) {
            error_log('Cleanup sessions error: ' . $e->getMessage());
        }
    }

    // Hàm kiểm tra và tạo lại ID nếu trùng lặp (backup function)
    function ensureUniqueIDs($pdo, $userID, $shopId) {
        $attempts = 0;
        $maxAttempts = 10;
        
        while ($attempts < $maxAttempts) {
            // Kiểm tra User ID
            $stmt = $pdo->prepare("SELECT id FROM users WHERE user_id = ?");
            $stmt->execute([$userID]);
            if ($stmt->fetch()) {
                $userID = generateUserID($pdo);
                $attempts++;
                continue;
            }
            
            // Kiểm tra Store ID
            $stmt = $pdo->prepare("SELECT id FROM users WHERE store_id = ?");
            $stmt->execute([$shopId]);
            if ($stmt->fetch()) {
                $shopId = generateShopID($pdo);
                $attempts++;
                continue;
            }
            
            // Nếu cả hai ID đều unique, break
            break;
        }
        
        if ($attempts >= $maxAttempts) {
            throw new Exception('Không thể tạo ID unique sau ' . $maxAttempts . ' lần thử');
        }
        
        return ['user_id' => $userID, 'store_id' => $shopId];
    }
?>