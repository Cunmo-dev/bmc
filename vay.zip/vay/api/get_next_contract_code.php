<?php
require_once 'database.php';
session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

try {
    $userId = $_GET['userId'] ?? null;
    $shopId = $_GET['shopId'] ?? null;
    
    if (!$userId || !$shopId) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Thiếu userId hoặc shopId']);
        exit();
    }
    
    // Lấy mã hợp đồng lớn nhất từ cả 2 bảng contracts và deleted_contracts
    $stmt = $pdo->prepare("
        SELECT MAX(max_code) as highest_code FROM (
            -- Lấy max từ bảng contracts
            SELECT MAX(CAST(code_id AS UNSIGNED)) as max_code 
            FROM contracts 
            WHERE user_id = ? AND shop_id = ? 
            AND code_id REGEXP '^[0-9]+$'
            
            UNION ALL
            
            -- Lấy max từ bảng deleted_contracts
            SELECT MAX(CAST(code_id AS UNSIGNED)) as max_code 
            FROM deleted_contracts 
            WHERE user_id = ? AND shop_id = ? 
            AND code_id REGEXP '^[0-9]+$'
        ) as combined_codes
    ");
    
    $stmt->execute([$userId, $shopId, $userId, $shopId]);
    $result = $stmt->fetch();
    
    $maxCode = $result['highest_code'] ?? 0;
    $nextCode = (int)$maxCode + 1;
    
    // Thêm thông tin chi tiết để debug (tùy chọn)
    $debugInfo = [];
    
    // Lấy max từ contracts
    $stmtContracts = $pdo->prepare("
        SELECT MAX(CAST(code_id AS UNSIGNED)) as max_code 
        FROM contracts 
        WHERE user_id = ? AND shop_id = ? 
        AND code_id REGEXP '^[0-9]+$'
    ");
    $stmtContracts->execute([$userId, $shopId]);
    $contractsMax = $stmtContracts->fetch()['max_code'] ?? 0;
    
    // Lấy max từ deleted_contracts
    $stmtDeleted = $pdo->prepare("
        SELECT MAX(CAST(code_id AS UNSIGNED)) as max_code 
        FROM deleted_contracts 
        WHERE user_id = ? AND shop_id = ? 
        AND code_id REGEXP '^[0-9]+$'
    ");
    $stmtDeleted->execute([$userId, $shopId]);
    $deletedMax = $stmtDeleted->fetch()['max_code'] ?? 0;
    
    $debugInfo = [
        'contracts_max' => $contractsMax,
        'deleted_contracts_max' => $deletedMax,
        'combined_max' => $maxCode
    ];
    
    echo json_encode([
        'success' => true,
        'next_code' => (string)$nextCode,
        'current_max' => $maxCode,
        'debug_info' => $debugInfo
    ]);
    
} catch(PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
} catch(Exception $e) {
    error_log("General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
}
?>