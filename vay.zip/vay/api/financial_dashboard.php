<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

try {
    // Lấy shopId từ nhiều nguồn có thể
    $shopId = $_GET['shopId'] ?? $_POST['shopId'] ?? $_GET['shop_id'] ?? $_SESSION['shop_id'] ?? '';
    
    if (empty($shopId)) {
        // Thử lấy từ input JSON
        $raw_input = file_get_contents('php://input');
        $input = json_decode($raw_input, true);
        $shopId = $input['shopId'] ?? $input['shop_id'] ?? '';
        
        if (empty($shopId)) {
            throw new Exception('Shop ID không được để trống. Vui lòng truyền shopId trong request.');
        }
    }

    // 1. Lấy vốn đầu tư từ bảng shops
    $capitalStmt = $pdo->prepare("
        SELECT total_money_in_safe 
        FROM shops 
        WHERE shop_id = ? AND deleted_at IS NULL
    ");
    $capitalStmt->execute([$shopId]);
    $capital = $capitalStmt->fetchColumn() ?: 0;

    // 2. Tính tổng số tiền giao cho khách
    // Từ contracts đang hoạt động
    $activeContractsStmt = $pdo->prepare("
        SELECT COALESCE(SUM(total_money_received), 0) as total_disbursed
        FROM contracts 
        WHERE shop_id = ?
    ");
    $activeContractsStmt->execute([$shopId]);
    $activeDisbursed = $activeContractsStmt->fetchColumn() ?: 0;

    // Từ deleted_contracts với status = 'closed'
    $closedContractsStmt = $pdo->prepare("
        SELECT COALESCE(SUM(total_money_received), 0) as total_disbursed
        FROM deleted_contracts 
        WHERE shop_id = ? AND deletion_status = 'closed'
    ");
    $closedContractsStmt->execute([$shopId]);
    $closedDisbursed = $closedContractsStmt->fetchColumn() ?: 0;

    $totalDisbursed = $activeDisbursed + $closedDisbursed;

    // 3. Tính tổng số tiền khách đã trả
    // Từ payment_schedules của contracts đang hoạt động
    $activePaidStmt = $pdo->prepare("
        SELECT COALESCE(SUM(ps.amount_paid), 0) as total_paid
        FROM payment_schedules ps
        INNER JOIN contracts c ON ps.contract_id = c.id
        WHERE c.shop_id = ?
    ");
    $activePaidStmt->execute([$shopId]);
    $activePaid = $activePaidStmt->fetchColumn() ?: 0;

    // Từ deleted_contracts với status = 'closed' (lấy từ trường total_paid)
    $closedPaidStmt = $pdo->prepare("
        SELECT COALESCE(SUM(total_paid), 0) as total_paid
        FROM deleted_contracts 
        WHERE shop_id = ? AND deletion_status = 'closed'
    ");
    $closedPaidStmt->execute([$shopId]);
    $closedPaid = $closedPaidStmt->fetchColumn() ?: 0;

    $totalPaid = $activePaid + $closedPaid;

    // 4. Tính tổng số tiền mà khách phải trả
    // Từ contracts đang hoạt động
    $activeOwedStmt = $pdo->prepare("
        SELECT COALESCE(SUM(total_money), 0) as total_owed
        FROM contracts 
        WHERE shop_id = ?
    ");
    $activeOwedStmt->execute([$shopId]);
    $activeOwed = $activeOwedStmt->fetchColumn() ?: 0;

    // Từ deleted_contracts với status = 'closed'
    $closedOwedStmt = $pdo->prepare("
        SELECT COALESCE(SUM(total_money), 0) as total_owed
        FROM deleted_contracts 
        WHERE shop_id = ? AND deletion_status = 'closed'
    ");
    $closedOwedStmt->execute([$shopId]);
    $closedOwed = $closedOwedStmt->fetchColumn() ?: 0;

    $totalOwed = $activeOwed + $closedOwed;

    // 5. Tính toán các chỉ số chính
    $cashFund = $capital - $totalDisbursed + $totalPaid; // Quỹ tiền mặt
    $loanAmount = $totalOwed - $totalPaid; // Tiền cho vay (còn lại)

    // 6. Tính lãi dự kiến và lãi đã thu
    // Lãi dự kiến = Tổng tiền phải trả - Tổng tiền gốc giao cho khách
    $expectedInterest = $totalOwed - $totalDisbursed;
    
    // Lãi đã thu = Tổng tiền đã thu - Tổng tiền gốc giao cho khách (nhưng không được âm)
    $earnedInterest = max(0, $totalPaid - $totalDisbursed);

    // 7. Lấy thêm thông tin chi tiết cho debugging
    $detailsStmt = $pdo->prepare("
        SELECT 
            COUNT(CASE WHEN c.current_status != 'Đã hoàn thành' THEN 1 END) as active_contracts,
            COUNT(CASE WHEN c.current_status = 'Đã hoàn thành' THEN 1 END) as completed_contracts,
            COUNT(CASE WHEN ps.status = 'overdue' THEN 1 END) as overdue_schedules,
            COALESCE(SUM(CASE WHEN ps.status = 'overdue' THEN ps.amount_remaining END), 0) as overdue_amount
        FROM contracts c
        LEFT JOIN payment_schedules ps ON c.id = ps.contract_id
        WHERE c.shop_id = ?
    ");
    $detailsStmt->execute([$shopId]);
    $details = $detailsStmt->fetch(PDO::FETCH_ASSOC);

    // 8. Lấy số hợp đồng đã đóng
    $closedCountStmt = $pdo->prepare("
        SELECT COUNT(*) as closed_contracts
        FROM deleted_contracts 
        WHERE shop_id = ? AND deletion_status = 'closed'
    ");
    $closedCountStmt->execute([$shopId]);
    $closedCount = $closedCountStmt->fetchColumn() ?: 0;

    // Trả về kết quả
    echo json_encode([
        'success' => true,
        'data' => [
            // Các chỉ số chính
            'cash_fund' => round($cashFund, 2),
            'loan_amount' => round($loanAmount, 2),
            'expected_interest' => round($expectedInterest, 2),
            'earned_interest' => round($earnedInterest, 2),
            
            // Dữ liệu gốc để tham khảo
            'raw_data' => [
                'capital' => round($capital, 2),
                'total_disbursed' => round($totalDisbursed, 2),
                'total_paid' => round($totalPaid, 2),
                'total_owed' => round($totalOwed, 2),
                'active_disbursed' => round($activeDisbursed, 2),
                'closed_disbursed' => round($closedDisbursed, 2),
                'active_paid' => round($activePaid, 2),
                'closed_paid' => round($closedPaid, 2),
                'active_owed' => round($activeOwed, 2),
                'closed_owed' => round($closedOwed, 2)
            ],
            
            // Thông tin bổ sung
            'additional_info' => [
                'active_contracts' => (int)$details['active_contracts'],
                'completed_contracts' => (int)$details['completed_contracts'],
                'closed_contracts' => (int)$closedCount,
                'overdue_schedules' => (int)$details['overdue_schedules'],
                'overdue_amount' => round($details['overdue_amount'], 2),
                'total_contracts' => (int)$details['active_contracts'] + (int)$details['completed_contracts'] + (int)$closedCount
            ]
        ],
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    error_log("Financial Dashboard Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Lỗi: ' . $e->getMessage(),
        'error_details' => [
            'shop_id' => $shopId ?? 'not_set',
            'timestamp' => date('Y-m-d H:i:s')
        ]
    ]);
}
?>