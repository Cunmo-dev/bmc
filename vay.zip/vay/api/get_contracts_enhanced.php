<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'database.php';

try {
    // Build WHERE clause dynamically
    $whereConditions = [];
    $params = [];
    
    // Base conditions
    if (!empty($_GET['userId'])) {
        $whereConditions[] = "c.user_id = :userId";
        $params[':userId'] = $_GET['userId'];
    }
    
    if (!empty($_GET['shopId'])) {
        $whereConditions[] = "c.shop_id = :shopId"; 
        $params[':shopId'] = $_GET['shopId'];
    }
    
    // Enhanced search conditions
    if (!empty($_GET['search'])) {
        $whereConditions[] = "(c.customer_name LIKE :search OR c.code_id LIKE :search2)";
        $params[':search'] = '%' . $_GET['search'] . '%';
        $params[':search2'] = '%' . $_GET['search'] . '%';
    }
    
    // Date range conditions
    if (!empty($_GET['fromDate'])) {
        $whereConditions[] = "c.from_date >= :fromDate";
        $params[':fromDate'] = convertDateFormat($_GET['fromDate']);
        
        if (!empty($_GET['toDate'])) {
            $whereConditions[] = "c.from_date <= :toDate";
            $params[':toDate'] = convertDateFormat($_GET['toDate']);
        }
    }
    
    if (!empty($_GET['loanTime']) && $_GET['loanTime'] != '0') {
        $whereConditions[] = "c.loan_time = :loanTime";
        $params[':loanTime'] = (int)$_GET['loanTime'];
    }
    
    if (!empty($_GET['searchStatus']) && $_GET['searchStatus'] != '0') {
        // Add status condition based on business logic
        switch ($_GET['searchStatus']) {
            case '1': // Hợp đồng đúng hẹn
                $whereConditions[] = "c.current_status = 'Đang vay'";
                break;
            case '2': // Quá hạn
                $whereConditions[] = "c.current_status = 'Quá hạn'";
                break;
            case '3': // Chậm họ
                $whereConditions[] = "c.current_status = 'Chậm họ'";
                break;
            case '4': // Trả gốc hôm nay
                $whereConditions[] = "c.current_status = 'Trả gốc hôm nay'";
                break;
            case '5': // Đã hoàn thành
                $whereConditions[] = "c.current_status = 'Đã hoàn thành'";
                break;
            case '6': // Quá hạn trả gốc
                $whereConditions[] = "c.current_status = 'Quá hạn trả gốc'";
                break;
            case '7': // Đến ngày đóng họ
                $whereConditions[] = "c.current_status = 'Đến ngày đóng họ'";
                break;
            case '8': // Ngày mai đóng họ
                $whereConditions[] = "c.current_status = 'Ngày mai đóng họ'";
                break;
            default: // Tất cả hợp đồng đang vay (bao gồm tất cả trạng thái trừ Đã hoàn thành)
                $whereConditions[] = "c.current_status != 'Đã hoàn thành'";
                break;
        }
    }
    
    // Build final WHERE clause
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get pagination params
    $page = (int)($_GET['page'] ?? 1);
    $limit = (int)($_GET['limit'] ?? 2000);
    $offset = ($page - 1) * $limit;
    
    // Count total records
    $countSQL = "SELECT COUNT(*) as total FROM contracts c $whereClause";
    $countStmt = $pdo->prepare($countSQL);
    $countStmt->execute($params);
    $totalRecords = $countStmt->fetch()['total'];
    
    // Get contracts data with all required fields including money_should_pay
    $sql = "SELECT 
                c.id, 
                c.code_id, 
                c.customer_name, 
                c.customer_phone, 
                c.customer_number_card, 
                c.customer_address, 
                c.total_money, 
                c.total_money_received, 
                c.loan_time, 
                c.frequency, 
                c.from_date, 
                c.staff_id, 
                c.note, 
                c.current_status,
                DATE_FORMAT(c.from_date, '%d/%m/%Y') as formatted_from_date,
                
                -- Contract type information
                ct.name as contract_type_name,
                ct.interest_rate,
                ct.penalty_rate,
                
                -- Time and period calculations
                CASE 
                    WHEN c.loan_time >= 365 THEN CONCAT(FLOOR(c.loan_time/365), ' năm')
                    WHEN c.loan_time >= 30 THEN CONCAT(FLOOR(c.loan_time/30), ' tháng') 
                    ELSE CONCAT(c.loan_time, ' ngày')
                END as time_range,
                
                CASE 
                    WHEN c.frequency = 1 THEN 'ngày'
                    WHEN c.frequency = 7 THEN 'tuần'
                    WHEN c.frequency = 30 THEN 'tháng'
                    ELSE 'kỳ'
                END as period_text,
                
                -- Period calculations
                CEILING(c.loan_time / c.frequency) as total_periods,
                COALESCE(paid_info.paid_periods, 0) as paid_periods,
                (CEILING(c.loan_time / c.frequency) - COALESCE(paid_info.paid_periods, 0)) as remaining_periods,
                
                -- Money calculations
                COALESCE(paid_info.total_paid, 0) as paid_amount,
                (c.total_money - COALESCE(paid_info.total_paid, 0)) as remaining_amount,
                ROUND(c.total_money / CEILING(c.loan_time / c.frequency), 2) as money_per_period,
                
                -- Interest calculation
                ROUND((c.total_money - c.total_money_received) * COALESCE(ct.interest_rate, 0) / 100, 2) as total_interest,
                
                -- Next payment info
                next_payment.next_payment_date,
                next_payment.next_amount,
                
                -- Overdue info
                COALESCE(overdue_info.overdue_amount, 0) as overdue_amount,
                COALESCE(overdue_info.overdue_periods, 0) as overdue_periods,
                
                -- ✅ ADDED: Money should pay (từ các kỳ đã đến hạn)
                COALESCE(should_pay_info.total_should_pay_amount, 0) as money_should_pay,
                COALESCE(should_pay_info.should_pay_periods_count, 0) as should_pay_periods_count,
                
                -- Status with fallback
                COALESCE(c.current_status, 'Đang vay') as current_status
                
            FROM contracts c
            LEFT JOIN contract_types ct ON c.rate_type = ct.id
            LEFT JOIN (
                SELECT 
                    contract_id,
                    COUNT(*) as paid_periods,
                    SUM(amount_paid) as total_paid
                FROM payment_schedules 
                WHERE status = 'paid'
                GROUP BY contract_id
            ) paid_info ON c.id = paid_info.contract_id
            LEFT JOIN (
                SELECT 
                    contract_id,
                    MIN(due_date) as next_payment_date,
                    MIN(amount_due) as next_amount
                FROM payment_schedules 
                WHERE status != 'paid'
                GROUP BY contract_id
            ) next_payment ON c.id = next_payment.contract_id
            LEFT JOIN (
                SELECT 
                    contract_id,
                    COUNT(*) as overdue_periods,
                    SUM(amount_due) as overdue_amount
                FROM payment_schedules 
                WHERE status = 'overdue' AND due_date < CURDATE()
                GROUP BY contract_id
            ) overdue_info ON c.id = overdue_info.contract_id
            LEFT JOIN (
                SELECT 
                    ps.contract_id,
                    COUNT(*) as should_pay_periods_count,
                    SUM(ps.amount_due) as total_should_pay_amount
                FROM payment_schedules ps
                INNER JOIN contracts c ON ps.contract_id = c.id
                WHERE ps.status IN ('pending', 'overdue') 
                AND DATE_SUB(ps.due_date, INTERVAL (c.frequency - 1) DAY) <= CURDATE()
                GROUP BY ps.contract_id
            ) should_pay_info ON c.id = should_pay_info.contract_id
            $whereClause 
            ORDER BY c.from_date DESC 
            LIMIT :limit OFFSET :offset";
    
    $stmt = $pdo->prepare($sql);
    
    // Bind all parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    // Bind pagination params
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $contracts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Process data to ensure all fields are properly formatted
    foreach ($contracts as &$contract) {
        // Ensure numeric fields are properly typed
        $contract['total_money'] = (float)($contract['total_money'] ?? 0);
        $contract['total_money_received'] = (float)($contract['total_money_received'] ?? 0);
        $contract['paid_amount'] = (float)($contract['paid_amount'] ?? 0);
        $contract['remaining_amount'] = (float)($contract['remaining_amount'] ?? 0);
        $contract['money_per_period'] = (float)($contract['money_per_period'] ?? 0);
        $contract['total_interest'] = (float)($contract['total_interest'] ?? 0);
        $contract['overdue_amount'] = (float)($contract['overdue_amount'] ?? 0);
        $contract['money_should_pay'] = (float)($contract['money_should_pay'] ?? 0); // ✅ ADDED
        
        // Ensure integer fields
        $contract['total_periods'] = (int)($contract['total_periods'] ?? 0);
        $contract['paid_periods'] = (int)($contract['paid_periods'] ?? 0);
        $contract['remaining_periods'] = (int)($contract['remaining_periods'] ?? 0);
        $contract['overdue_periods'] = (int)($contract['overdue_periods'] ?? 0);
        $contract['should_pay_periods_count'] = (int)($contract['should_pay_periods_count'] ?? 0); // ✅ ADDED
        
        // Ensure status is not null
        $contract['current_status'] = $contract['current_status'] ?? 'Đang vay';
        
        // Add debit money field (you might want to calculate this based on your business logic)
        $contract['debit_money'] = 0; // Default to 0, modify as needed
        
        // Format next payment date if exists
        if (!empty($contract['next_payment_date'])) {
            $date = new DateTime($contract['next_payment_date']);
            $contract['formatted_next_payment_date'] = $date->format('d/m/Y');
        }
    }
    
    // Calculate pagination
    $totalPages = ceil($totalRecords / $limit);
    
    echo json_encode([
        'success' => true,
        'data' => $contracts,
        'pagination' => [
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalRecords' => $totalRecords,
            'limit' => $limit
        ],
        'summary' => calculateSummary($contracts)
    ]);
    
} catch (PDOException $e) {
    error_log("Database Error in enhanced search: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("General Error in enhanced search: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}

function convertDateFormat($dateStr) {
    if (empty($dateStr)) {
        return null;
    }
    
    // If already in YYYY-MM-DD format, return as is
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateStr)) {
        return $dateStr;
    }
    
    // Convert DD/MM/YYYY to YYYY-MM-DD
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $dateStr, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        }
    }
    
    // Convert DD-MM-YYYY to YYYY-MM-DD
    if (preg_match('/^(\d{1,2})-(\d{1,2})-(\d{4})$/', $dateStr, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        }
    }
    
    error_log("Cannot convert date format: $dateStr");
    return null;
}

function calculateSummary($contracts) {
    $summary = [
        'totalContracts' => count($contracts),
        'totalMoneyGiven' => 0,
        'totalCollected' => 0,
        'totalRemaining' => 0,
        'totalOverdue' => 0,
        'totalShouldPay' => 0 // ✅ ADDED: Tổng tiền phải đóng
    ];
    
    foreach ($contracts as $contract) {
        $summary['totalMoneyGiven'] += (float)($contract['total_money_received'] ?? 0);
        $summary['totalCollected'] += (float)($contract['paid_amount'] ?? 0);
        $summary['totalRemaining'] += (float)($contract['remaining_amount'] ?? 0);
        $summary['totalOverdue'] += (float)($contract['overdue_amount'] ?? 0);
        $summary['totalShouldPay'] += (float)($contract['money_should_pay'] ?? 0); // ✅ ADDED
    }
    
    return $summary;
}
?>