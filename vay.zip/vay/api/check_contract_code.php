<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// DEBUG: Log để kiểm tra
error_log("=== CHECK CONTRACT CODE API DEBUG ===");
error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);

// Kiểm tra method phải là POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Chỉ chấp nhận POST request']);
    exit();
}

// Lấy raw input để debug
$raw_input = file_get_contents('php://input');
error_log("Raw Input: " . $raw_input);

// Kiểm tra raw input không rỗng
if (empty($raw_input)) {
    error_log("Raw input is empty");
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Không có dữ liệu gửi lên']);
    exit();
}

// Lấy dữ liệu POST
$input = json_decode($raw_input, true);

// DEBUG: Kiểm tra JSON decode
if (json_last_error() !== JSON_ERROR_NONE) {
    error_log("JSON Error: " . json_last_error_msg());
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Lỗi JSON: ' . json_last_error_msg()]);
    exit();
}

error_log("Decoded Input: " . print_r($input, true));

if (!$input || !is_array($input)) {
    error_log("Input is not a valid array");
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ']);
    exit();
}

try {
    // Validate và sanitize input
    $codeId = isset($input['codeId']) ? trim($input['codeId']) : '';
    $userId = isset($input['userId']) ? trim($input['userId']) : '';
    $shopId = isset($input['shopId']) ? trim($input['shopId']) : '';
    $excludeId = isset($input['excludeId']) ? (int)$input['excludeId'] : 0;
    
    error_log("Parameters - codeId: '$codeId', userId: '$userId', shopId: '$shopId', excludeId: $excludeId");
    
    // Kiểm tra các tham số bắt buộc
    if (empty($codeId)) {
        error_log("Missing codeId parameter");
        http_response_code(400);
        echo json_encode([
            'success' => false, 
            'message' => 'Mã hợp đồng không được để trống'
        ]);
        exit();
    }
    
    if (empty($userId)) {
        error_log("Missing userId parameter");
        http_response_code(400);
        echo json_encode([
            'success' => false, 
            'message' => 'Thiếu thông tin userId'
        ]);
        exit();
    }
    
    if (empty($shopId)) {
        error_log("Missing shopId parameter");
        http_response_code(400);
        echo json_encode([
            'success' => false, 
            'message' => 'Thiếu thông tin shopId'
        ]);
        exit();
    }
    
    // Kiểm tra kết nối database
    if (!isset($pdo) || !$pdo) {
        error_log("Database connection not available");
        http_response_code(500);
        echo json_encode([
            'success' => false, 
            'message' => 'Lỗi kết nối database'
        ]);
        exit();
    }
    
    // Kiểm tra trùng lặp (loại trừ chính hợp đồng đang edit)
    $sql = "SELECT COUNT(*) as count FROM contracts WHERE code_id = :code_id AND user_id = :user_id AND shop_id = :shop_id";
    $params = [
        ':code_id' => $codeId,
        ':user_id' => $userId,
        ':shop_id' => $shopId
    ];
    
    if ($excludeId > 0) {
        $sql .= " AND id != :exclude_id";
        $params[':exclude_id'] = $excludeId;
    }
    
    error_log("SQL Query: $sql");
    error_log("SQL Params: " . print_r($params, true));
    
    $stmt = $pdo->prepare($sql);
    
    if (!$stmt) {
        error_log("Failed to prepare SQL statement");
        http_response_code(500);
        echo json_encode([
            'success' => false, 
            'message' => 'Lỗi chuẩn bị câu lệnh SQL'
        ]);
        exit();
    }
    
    $executed = $stmt->execute($params);
    
    if (!$executed) {
        $errorInfo = $stmt->errorInfo();
        error_log("SQL execution failed: " . print_r($errorInfo, true));
        http_response_code(500);
        echo json_encode([
            'success' => false, 
            'message' => 'Lỗi thực thi SQL: ' . $errorInfo[2]
        ]);
        exit();
    }
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$result) {
        error_log("No result returned from query");
        http_response_code(500);
        echo json_encode([
            'success' => false, 
            'message' => 'Không lấy được kết quả từ database'
        ]);
        exit();
    }
    
    $exists = (int)$result['count'] > 0;
    
    error_log("Query result - count: " . $result['count'] . ", exists: " . ($exists ? 'true' : 'false'));
    
    // Trả về kết quả thành công
    echo json_encode([
        'success' => true,
        'exists' => $exists,
        'message' => $exists ? 'Mã hợp đồng đã tồn tại' : 'Mã hợp đồng có thể sử dụng',
        'data' => [
            'count' => (int)$result['count'],
            'code_id' => $codeId,
            'user_id' => $userId,
            'shop_id' => $shopId,
            'exclude_id' => $excludeId
        ]
    ]);
    
} catch(PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    error_log("Error Code: " . $e->getCode());
    error_log("Error Info: " . print_r($e->errorInfo ?? [], true));
    
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Lỗi database: ' . $e->getMessage(),
        'error_code' => $e->getCode()
    ]);
} catch(Exception $e) {
    error_log("General Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>