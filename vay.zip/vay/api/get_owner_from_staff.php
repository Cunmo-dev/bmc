<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON
function jsonResponse($data) {
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Log function
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

// Chỉ xử lý POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy staff_id từ POST
    $staffId = isset($_POST['staff_id']) ? trim($_POST['staff_id']) : '';

    logDebug("Get Owner User ID from Staff Request", ['staff_id' => $staffId]);

    // Validate staff_id
    if (empty($staffId)) {
        jsonResponse([
            'success' => false,
            'message' => 'Vui lòng cung cấp staff_id!'
        ]);
    }

    // Kiểm tra format staff_id (phải bắt đầu bằng STF)
    if (!preg_match('/^STF/i', $staffId)) {
        jsonResponse([
            'success' => false,
            'message' => 'Staff ID không hợp lệ!'
        ]);
    }

    // Truy vấn lấy user_id của owner từ bảng staff
    // staff.user_id chính là owner_user_id (người tạo ra nhân viên này)
    $query = "SELECT user_id, username, full_name, status, shop_id FROM staff WHERE staff_id = ? AND status = 1";
    $stmt = $pdo->prepare($query);
    
    if (!$stmt) {
        logDebug("Prepare statement failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare statement");
    }
    
    $stmt->execute([$staffId]);
    $staffData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$staffData) {
        jsonResponse([
            'success' => false,
            'message' => 'Không tìm thấy nhân viên hoặc tài khoản đã bị khóa!'
        ]);
    }

    $ownerUserId = $staffData['user_id']; // Đây chính là owner_user_id

    // Kiểm tra thêm owner có tồn tại trong bảng users không
    $checkOwnerQuery = "SELECT username, status FROM users WHERE user_id = ? AND status = 1";
    $checkOwnerStmt = $pdo->prepare($checkOwnerQuery);
    $checkOwnerStmt->execute([$ownerUserId]);
    $ownerData = $checkOwnerStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$ownerData) {
        jsonResponse([
            'success' => false,
            'message' => 'Không tìm thấy thông tin chủ cửa hàng hoặc tài khoản đã bị khóa!'
        ]);
    }

    // Lấy thêm thông tin shop để verify
    $shopQuery = "SELECT shop_name FROM shops WHERE user_id = ? AND shop_id = ? AND status = 1";
    $shopStmt = $pdo->prepare($shopQuery);
    $shopStmt->execute([$ownerUserId, $staffData['shop_id']]);
    $shopData = $shopStmt->fetch(PDO::FETCH_ASSOC);

    logDebug("Owner User ID found from Staff", [
        'staff_id' => $staffId,
        'staff_username' => $staffData['username'],
        'owner_user_id' => $ownerUserId,
        'owner_username' => $ownerData['username'],
        'shop_id' => $staffData['shop_id'],
        'shop_name' => $shopData ? $shopData['shop_name'] : 'N/A'
    ]);

    // Trả về owner_user_id
    jsonResponse([
        'success' => true,
        'owner_user_id' => $ownerUserId,
        'staff_info' => [
            'staff_id' => $staffId,
            'staff_username' => $staffData['username'],
            'staff_full_name' => $staffData['full_name'],
            'shop_id' => $staffData['shop_id'],
            'role' => 'staff'
        ],
        'owner_info' => [
            'owner_user_id' => $ownerUserId,
            'owner_username' => $ownerData['username'],
            'shop_name' => $shopData ? $shopData['shop_name'] : null
        ],
        'message' => 'Lấy owner user_id thành công!'
    ]);

} catch (PDOException $e) {
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>