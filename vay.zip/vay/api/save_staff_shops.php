<?php
require_once 'database.php';

// Bật error reporting để debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Đặt header JSON ngay từ đầu
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function trả về JSON và thoát
function jsonResponse($data) {
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Log function để debug
function logDebug($message, $data = null) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if ($data !== null) {
        $logMessage .= " - Data: " . print_r($data, true);
    }
    error_log($logMessage);
}

define('BASE_PATH', '/vay/');

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    logDebug("Login check failed", $_SESSION);
    jsonResponse([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để tiếp tục!',
        'redirect' => BASE_PATH
    ]);
}

// Chỉ xử lý POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ!'
    ]);
}

try {
    // Kiểm tra kết nối database
    if (!isset($pdo)) {
        logDebug("PDO connection not found");
        jsonResponse([
            'success' => false,
            'message' => 'Lỗi kết nối database!'
        ]);
    }

    // Lấy user_id từ session
    $currentUserId = $_SESSION['user_id'];
    
    // Lấy dữ liệu từ POST
    $staffDbId = isset($_POST['staff_id']) ? intval($_POST['staff_id']) : 0;
    $shopIds = isset($_POST['shop_ids']) ? $_POST['shop_ids'] : [];
    
    // Debug log để kiểm tra dữ liệu nhận được
    logDebug("Received POST data", [
        'staff_id' => $staffDbId,
        'shop_ids_raw' => $_POST,
        'shop_ids_content' => $shopIds
    ]);
    
    // Xử lý trường hợp shop_ids có thể được gửi dạng shop_ids[]
    if (empty($shopIds) && isset($_POST['shop_ids'])) {
        $shopIds = $_POST['shop_ids'];
    }
    
    // Đảm bảo $shopIds là array
    if (!is_array($shopIds)) {
        $shopIds = [];
    }
    
    // Validate dữ liệu
    if ($staffDbId <= 0) {
        jsonResponse([
            'success' => false,
            'message' => 'Vui lòng chọn nhân viên!'
        ]);
    }
    
    if (!is_array($shopIds) || empty($shopIds)) {
        jsonResponse([
            'success' => false,
            'message' => 'Vui lòng chọn ít nhất một cửa hàng!'
        ]);
    }
    
    // Sanitize shop_ids - có thể là string (SHP...) hoặc số
    $shopIds = array_filter($shopIds, function($id) {
        // Loại bỏ các giá trị empty, null, false
        return !empty(trim($id));
    });
    
    if (empty($shopIds)) {
        jsonResponse([
            'success' => false,
            'message' => 'Danh sách cửa hàng không hợp lệ!'
        ]);
    }
    
    logDebug("Save Staff Shops Request", [
        'user_id' => $currentUserId,
        'staff_db_id' => $staffDbId,
        'shop_ids' => $shopIds
    ]);

    // Kiểm tra nhân viên có thuộc về user hiện tại không
    $checkStaffQuery = "SELECT staff_id, username, full_name FROM staff WHERE id = ? AND user_id = ?";
    $checkStaffStmt = $pdo->prepare($checkStaffQuery);
    
    if (!$checkStaffStmt) {
        logDebug("Prepare check staff query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare statement cho check staff");
    }
    
    $checkStaffStmt->execute([$staffDbId, $currentUserId]);
    $staffData = $checkStaffStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$staffData) {
        jsonResponse([
            'success' => false,
            'message' => 'Nhân viên không tồn tại hoặc bạn không có quyền!'
        ]);
    }
    
    $staffId = $staffData['staff_id'];

    // Kiểm tra các shop_id có thuộc về user hiện tại không
    $placeholders = str_repeat('?,', count($shopIds) - 1) . '?';
    $checkShopsQuery = "SELECT DISTINCT shop_id FROM shops WHERE user_id = ? AND shop_id IN ($placeholders)";
    $checkShopsStmt = $pdo->prepare($checkShopsQuery);
    
    if (!$checkShopsStmt) {
        logDebug("Prepare check shops query failed", $pdo->errorInfo());
        throw new Exception("Lỗi prepare statement cho check shops");
    }
    
    $params = array_merge([$currentUserId], $shopIds);
    $checkShopsStmt->execute($params);
    $validShopIds = $checkShopsStmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Convert sang string để so sánh chính xác (vì shop_id trong DB là string)
    $validShopIdsStr = array_map('strval', $validShopIds);
    $shopIdsStr = array_map('strval', $shopIds);
    
    // Debug log để kiểm tra
    logDebug("Shop validation check", [
        'current_user_id' => $currentUserId,
        'requested_shop_ids' => $shopIds,
        'requested_shop_ids_str' => $shopIdsStr,
        'valid_shop_ids' => $validShopIds,
        'valid_shop_ids_str' => $validShopIdsStr,
        'requested_count' => count($shopIds),
        'valid_count' => count($validShopIds)
    ]);
    
    // So sánh số lượng shop hợp lệ
    if (count($validShopIds) !== count($shopIds)) {
        $invalidShops = array_diff($shopIdsStr, $validShopIdsStr);
        logDebug("Invalid shops detected", $invalidShops);
        
        jsonResponse([
            'success' => false,
            'message' => 'Một số cửa hàng không hợp lệ hoặc bạn không có quyền! Invalid: ' . implode(', ', $invalidShops)
        ]);
    }
    
    // Sử dụng validShopIds từ database để đảm bảo định dạng chính xác
    $shopIds = $validShopIds;
    
    if (count($validShopIds) !== count($shopIds)) {
        jsonResponse([
            'success' => false,
            'message' => 'Một số cửa hàng không hợp lệ hoặc bạn không có quyền!'
        ]);
    }

    // Bắt đầu transaction để đảm bảo tính toàn vẹn dữ liệu
    $pdo->beginTransaction();

    try {
        // BƯỚC 1: Xóa tất cả shop hiện tại của nhân viên
        // Xóa trong bảng shops (nhân viên sẽ không còn truy cập vào các shop cũ)
        $deleteShopsQuery = "DELETE FROM shops WHERE user_id = ?";
        $deleteShopsStmt = $pdo->prepare($deleteShopsQuery);
        
        if (!$deleteShopsStmt) {
            throw new Exception("Lỗi prepare statement cho delete shops");
        }
        
        $deleteResult = $deleteShopsStmt->execute([$staffId]);
        
        if (!$deleteResult) {
            throw new Exception("Không thể xóa dữ liệu shop cũ của nhân viên!");
        }
        
        logDebug("Deleted old staff shops", [
            'staff_id' => $staffId,
            'deleted_count' => $deleteShopsStmt->rowCount()
        ]);

        // BƯỚC 2: Lấy thông tin các shop mới từ owner để sao chép
        $placeholders = str_repeat('?,', count($validShopIds) - 1) . '?';
        $getOwnerShopsQuery = "SELECT shop_id, shop_name, shop_description, shop_address, 
                                     shop_phone, shop_email, total_money_in_safe 
                              FROM shops 
                              WHERE user_id = ? AND shop_id IN ($placeholders)
                              ORDER BY shop_id";
        
        $getOwnerShopsStmt = $pdo->prepare($getOwnerShopsQuery);
        
        if (!$getOwnerShopsStmt) {
            throw new Exception("Lỗi prepare statement cho get owner shops");
        }
        
        $params = array_merge([$currentUserId], $validShopIds);
        $getOwnerShopsStmt->execute($params);
        $ownerShops = $getOwnerShopsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($ownerShops)) {
            throw new Exception("Không tìm thấy thông tin các cửa hàng!");
        }

        // BƯỚC 3: Tạo bản ghi shop mới cho nhân viên với CÙNG shop_id
        $insertShopQuery = "INSERT INTO shops (user_id, shop_id, shop_name, shop_description, 
                                             shop_address, shop_phone, shop_email, 
                                             total_money_in_safe, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())";
        $insertShopStmt = $pdo->prepare($insertShopQuery);
        
        if (!$insertShopStmt) {
            throw new Exception("Lỗi prepare statement cho insert shops");
        }
        
        $insertedCount = 0;
        foreach ($ownerShops as $ownerShop) {
            $insertResult = $insertShopStmt->execute([
                $staffId,                                    // user_id (staff_id)
                $ownerShop['shop_id'],                      // shop_id (CÙNG với owner)
                $ownerShop['shop_name'],                    // shop_name
                $ownerShop['shop_description'] ?? '',       // shop_description
                $ownerShop['shop_address'] ?? '',           // shop_address
                $ownerShop['shop_phone'] ?? '',             // shop_phone
                $ownerShop['shop_email'] ?? '',             // shop_email
                $ownerShop['total_money_in_safe'] ?? 0.00   // total_money_in_safe (CÙNG dữ liệu)
            ]);
            
            if ($insertResult) {
                $insertedCount++;
            }
        }
        
        if ($insertedCount !== count($ownerShops)) {
            throw new Exception("Không thể tạo đầy đủ các shop cho nhân viên!");
        }

        // BƯỚC 4: Cập nhật store_id trong bảng users để nhân viên có thể đăng nhập
        // Cập nhật để nhân viên có thể truy cập tất cả các shop được gán
        // Chọn shop_id đầu tiên làm store_id chính
        $primaryShopId = $validShopIds[0];
        
        $updateUserQuery = "UPDATE users SET store_id = ?, updated_at = NOW() 
                           WHERE user_id = ?";
        $updateUserStmt = $pdo->prepare($updateUserQuery);
        
        if (!$updateUserStmt) {
            throw new Exception("Lỗi prepare statement cho update user");
        }
        
        $updateUserResult = $updateUserStmt->execute([$primaryShopId, $staffId]);
        
        if (!$updateUserResult) {
            throw new Exception("Không thể cập nhật thông tin đăng nhập cho nhân viên!");
        }

        // Commit transaction
        $pdo->commit();
        
        logDebug("Staff shops updated successfully", [
            'staff_id' => $staffId,
            'staff_name' => $staffData['full_name'],
            'new_shop_ids' => $validShopIds,
            'inserted_count' => $insertedCount,
            'primary_shop_id' => $primaryShopId
        ]);
        
        jsonResponse([
            'success' => true,
            'message' => "Cập nhật cửa hàng cho nhân viên '{$staffData['full_name']}' thành công! Đã gán {$insertedCount} cửa hàng.",
            'data' => [
                'staff_id' => $staffId,
                'staff_name' => $staffData['full_name'],
                'shop_count' => $insertedCount,
                'shop_ids' => $validShopIds,
                'can_access_same_data' => true
            ],
            'redirect' => './Index'
        ]);

    } catch (Exception $e) {
        // Rollback nếu có lỗi
        $pdo->rollBack();
        throw $e;
    }

} catch (PDOException $e) {
    // Rollback nếu đang trong transaction
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    // Log error chi tiết để debug
    logDebug("PDO Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi database: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    // Rollback nếu đang trong transaction
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    logDebug("General Error", [
        'message' => $e->getMessage(),
        'code' => $e->getCode(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    jsonResponse([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ]);
}
?>