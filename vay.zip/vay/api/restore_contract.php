<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
session_start();
// Handle OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database connection
require_once 'database.php'; // Thay đổi đường dẫn phù hợp

try {
    // Chỉ cho phép POST method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Method không được hỗ trợ");
    }
    
    // Lấy dữ liệu từ request body
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception("Dữ liệu request không hợp lệ");
    }
    
    $deletedContractId = $input['deleted_contract_id'] ?? null;
    $restoredBy = $input['restored_by'] ?? null;
    
    if (!$deletedContractId) {
        throw new Exception("ID hợp đồng đã xóa không được cung cấp");
    }
    
    if (!$restoredBy) {
        throw new Exception("Thông tin người khôi phục không được cung cấp");
    }
    
    // Gọi hàm khôi phục từ code bạn đã có
    handleRestoreDeletedContract($pdo, $deletedContractId, $restoredBy);
    
} catch (Exception $e) {
    error_log("Restore contract error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Có lỗi xảy ra: ' . $e->getMessage()
    ]);
}

// Cập nhật hàm handleRestoreDeletedContract để nhận thêm parameter restored_by
function handleRestoreDeletedContract($pdo, $deletedContractId, $restoredBy = null) {
    try {
        $pdo->beginTransaction();
        
        // Lấy thông tin hợp đồng đã xóa
        $stmt = $pdo->prepare("SELECT * FROM deleted_contracts WHERE id = :id");
        $stmt->execute([':id' => $deletedContractId]);
        $deletedContract = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$deletedContract) {
            throw new Exception("Không tìm thấy hợp đồng đã xóa");
        }
        
        // Kiểm tra xem mã hợp đồng có bị trùng không
        $checkCodeStmt = $pdo->prepare("SELECT id FROM contracts WHERE code_id = :code_id AND shop_id = :shop_id");
        $checkCodeStmt->execute([
            ':code_id' => $deletedContract['code_id'],
            ':shop_id' => $deletedContract['shop_id']
        ]);
        
        if ($checkCodeStmt->fetch()) {
            throw new Exception("Mã hợp đồng đã tồn tại, không thể khôi phục");
        }
        
        // Tính toán to_date và amount_remaining cho thông tin trả về (không lưu vào DB)
        $fromDate = new DateTime($deletedContract['from_date']);
        $toDate = clone $fromDate;
        $toDate->add(new DateInterval('P' . $deletedContract['loan_time'] . 'D'));
        
        // Tính amount_remaining từ payment transactions
        $totalPaidFromTransactions = 0;
        if (!empty($deletedContract['payment_transactions_data'])) {
            $transactions = json_decode($deletedContract['payment_transactions_data'], true);
            if ($transactions) {
                $totalPaidFromTransactions = array_sum(array_column($transactions, 'amount_paid'));
            }
        }
        $amountRemaining = $deletedContract['total_money_received'] - $totalPaidFromTransactions;
        
        // Khôi phục hợp đồng (chỉ với các cột tồn tại trong bảng contracts)
        $restoreStmt = $pdo->prepare("
            INSERT INTO contracts (
                user_id, shop_id, code_id, type_id, customer_id, customer_name,
                customer_phone, customer_number_card, customer_address, customer_card_date,
                customer_place, total_money, total_money_received, total_paid, rate_type,
                loan_time, frequency, from_date, is_before, note, staff_id, edit_loan,
                created_at, updated_at
            ) VALUES (
                :user_id, :shop_id, :code_id, :type_id, :customer_id, :customer_name,
                :customer_phone, :customer_number_card, :customer_address, :customer_card_date,
                :customer_place, :total_money, :total_money_received, :total_paid, :rate_type,
                :loan_time, :frequency, :from_date, :is_before, :note, :staff_id, :edit_loan,
                :original_created_at, NOW()
            )
        ");
        
        $restoreStmt->execute([
            ':user_id' => $deletedContract['user_id'],
            ':shop_id' => $deletedContract['shop_id'],
            ':code_id' => $deletedContract['code_id'],
            ':type_id' => $deletedContract['type_id'],
            ':customer_id' => $deletedContract['customer_id'],
            ':customer_name' => $deletedContract['customer_name'],
            ':customer_phone' => $deletedContract['customer_phone'],
            ':customer_number_card' => $deletedContract['customer_number_card'],
            ':customer_address' => $deletedContract['customer_address'],
            ':customer_card_date' => $deletedContract['customer_card_date'],
            ':customer_place' => $deletedContract['customer_place'],
            ':total_money' => $deletedContract['total_money'],
            ':total_money_received' => $deletedContract['total_money_received'],
            ':total_paid' => $deletedContract['total_paid'],
            ':rate_type' => $deletedContract['rate_type'],
            ':loan_time' => $deletedContract['loan_time'],
            ':frequency' => $deletedContract['frequency'],
            ':from_date' => $deletedContract['from_date'],
            ':is_before' => $deletedContract['is_before'],
            ':note' => $deletedContract['note'],
            ':staff_id' => $deletedContract['staff_id'],
            ':edit_loan' => $deletedContract['edit_loan'],
            ':original_created_at' => $deletedContract['original_created_at']
        ]);
        
        $restoredContractId = $pdo->lastInsertId();
        
        // Khôi phục payment schedules nếu có
        $schedules = [];
        if (!empty($deletedContract['payment_schedules_data'])) {
            $schedules = json_decode($deletedContract['payment_schedules_data'], true);
            if ($schedules) {
                $scheduleIdMap = []; // Map old schedule ID to new schedule ID
                
                foreach ($schedules as $schedule) {
                    $insertScheduleStmt = $pdo->prepare("
                        INSERT INTO payment_schedules (
                            contract_id, period_number, due_date, amount_due, amount_paid, 
                            status, from_date, to_date, amount_remaining, created_at
                        ) VALUES (
                            :contract_id, :period_number, :due_date, :amount_due, :amount_paid, 
                            :status, :from_date, :to_date, :amount_remaining, :created_at
                        )
                    ");
                    
                    $insertScheduleStmt->execute([
                        ':contract_id' => $restoredContractId,
                        ':period_number' => $schedule['period_number'],
                        ':due_date' => $schedule['due_date'],
                        ':amount_due' => $schedule['amount_due'],
                        ':amount_paid' => $schedule['amount_paid'],
                        ':status' => $schedule['status'],
                        ':from_date' => $schedule['from_date'] ?? null,
                        ':to_date' => $schedule['to_date'] ?? null,
                        ':amount_remaining' => $schedule['amount_remaining'] ?? null,
                        ':created_at' => $schedule['created_at']
                    ]);
                    
                    $newScheduleId = $pdo->lastInsertId();
                    $scheduleIdMap[$schedule['id']] = $newScheduleId;
                }
            }
        }
        
        // Khôi phục payment transactions nếu có
        $transactions = [];
        if (!empty($deletedContract['payment_transactions_data'])) {
            $transactions = json_decode($deletedContract['payment_transactions_data'], true);
            if ($transactions) {
                foreach ($transactions as $transaction) {
                    // Map schedule_id cũ sang schedule_id mới
                    $newScheduleId = isset($scheduleIdMap[$transaction['schedule_id']]) ? 
                        $scheduleIdMap[$transaction['schedule_id']] : null;
                    
                    // $insertTransStmt = $pdo->prepare("
                    //     INSERT INTO payment_transactions (
                    //         contract_id, schedule_id, amount_paid, payment_date, payment_method,
                    //         note, created_at
                    //     ) VALUES (
                    //         :contract_id, :schedule_id, :amount_paid, :payment_date, :payment_method,
                    //         :note,  :created_at
                    //     )
                    // ");
                    $insertTransStmt = $pdo->prepare("
    INSERT INTO payment_transactions (
        contract_id, schedule_id, amount_paid, payment_date, payment_method,
        note, transaction_code, status, created_at
    ) VALUES (
        :contract_id, :schedule_id, :amount_paid, :payment_date, :payment_method,
        :note, :transaction_code, :status, :created_at
    )
");
                    
                    // $insertTransStmt->execute([
                    //     ':contract_id' => $restoredContractId,
                    //     ':schedule_id' => $newScheduleId,
                    //     ':amount_paid' => $transaction['amount_paid'],
                    //     ':payment_date' => $transaction['payment_date'],
                    //     ':payment_method' => $transaction['payment_method'],
                    //     ':note' => $transaction['note'],
                    //     ':created_at' => $transaction['created_at']
                    // ]);

                    $insertTransStmt->execute([
    ':contract_id' => $restoredContractId,
    ':schedule_id' => $newScheduleId,
    ':amount_paid' => $transaction['amount_paid'],
    ':payment_date' => $transaction['payment_date'],
    ':payment_method' => $transaction['payment_method'],
    ':note' => $transaction['note'],
    ':transaction_code' => $transaction['transaction_code'] ?? 'RESTORED_' . uniqid() . '_' . time(),
    ':status' => $transaction['status'] ?? 'completed',
    ':created_at' => $transaction['created_at']
]);
                }
            }
        }
        
        // Xóa khỏi bảng deleted_contracts
        $removeDeletedStmt = $pdo->prepare("DELETE FROM deleted_contracts WHERE id = :id");
        $removeDeletedStmt->execute([':id' => $deletedContractId]);
        
        // Log khôi phục
        $logRestoreStmt = $pdo->prepare("
            INSERT INTO deletion_logs (
                table_name, record_id, user_id, shop_id, deletion_reason, ip_address, user_agent
            ) VALUES (
                'contracts_restored', :record_id, :user_id, :shop_id, :deletion_reason, :ip_address, :user_agent
            )
        ");
        
        $logRestoreStmt->execute([
            ':record_id' => $restoredContractId,
            ':user_id' => $deletedContract['user_id'],
            ':shop_id' => $deletedContract['shop_id'],
            ':deletion_reason' => "Restored from deleted_contracts ID: $deletedContractId by user: $restoredBy",
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
        
        // Log hệ thống (nếu có hàm logSystemAction)
        if (function_exists('logSystemAction')) {
            logSystemAction($pdo, $deletedContract['user_id'], $deletedContract['shop_id'], 'RESTORE_CONTRACT', 'contracts', $restoredContractId, null, $deletedContract);
        }
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Khôi phục hợp đồng thành công',
            'restored_contract_id' => $restoredContractId,
            'restored_data' => [
                'schedules_count' => count($schedules),
                'transactions_count' => count($transactions),
                'original_contract_id' => $deletedContract['original_contract_id'],
                'to_date' => $toDate->format('Y-m-d'),
                'amount_remaining' => $amountRemaining
            ]
        ]);
        
    } catch(Exception $e) {
        $pdo->rollback();
        error_log("Restore contract error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
?>