<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

error_log("=== PAYMENT SCHEDULE API DEBUG ===");
error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Request URI: " . $_SERVER['REQUEST_URI']);

$raw_input = file_get_contents('php://input');
error_log("Raw Input: " . $raw_input);

$input = json_decode($raw_input, true);
$action = $input['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'create_schedule':
        createPaymentSchedule($pdo, $input);
        break;
    case 'get_schedule':
        getPaymentSchedule($pdo, $input);
        break;
    case 'update_payment':
        updatePayment($pdo, $input);
        break;
    case 'get_overdue':
        getOverdueContracts($pdo, $input);
        break;
    case 'get_due_today':
        getDueTodayContracts($pdo, $input);
        break;
    case 'get_contract_status':
        getContractStatus($pdo, $input);
        break;
    case 'cancel_payment':
        cancelPaymentSchedule($pdo, $input);
        break;
    case 'cancel_transaction':
        cancelTransaction($pdo, $input);
        break;
    case 'get_cancellation_history':
        getPaymentCancellationHistory($pdo, $input);
        break;
    case 'get_payment_history':
        handleGetPaymentHistory($pdo, $input);
        break;  
    case 'delete_contracts':
        handleDeleteContract($pdo,$input['contract_id']);
        break;
    case 'close_contract':
        closeContract($pdo, $input);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Action không hợp lệ']);
        break;
}

function closeContract($pdo, $input) {
    error_log("=== CLOSE CONTRACT ===");
    
    if (!isset($input['contract_id']) || $input['contract_id'] <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Contract ID không hợp lệ']);
        return;
    }
    
    try {
        $currentUserId = $_SESSION['username'] ?? 'SYSTEM';
        $pdo->beginTransaction();
        
        // 1. Lấy thông tin hợp đồng và kiểm tra trạng thái thanh toán
        $contractStmt = $pdo->prepare("
            SELECT c.*, ct.name as contract_type_name, ct.interest_rate, ct.penalty_rate,
                   COALESCE(SUM(ps.amount_remaining), 0) as total_remaining,
                   COUNT(ps.id) as total_periods,
                   COUNT(CASE WHEN ps.status = 'paid' THEN 1 END) as paid_periods
            FROM contracts c
            LEFT JOIN contract_types ct ON c.rate_type = ct.id
            LEFT JOIN payment_schedules ps ON c.id = ps.contract_id
            WHERE c.id = :id
            GROUP BY c.id
        ");
        $contractStmt->execute([':id' => $input['contract_id']]);
        $contract = $contractStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$contract) {
            throw new Exception("Hợp đồng không tồn tại");
        }
        
        // 2. Kiểm tra điều kiện đóng hợp đồng - số tiền còn lại phải = 0
        if ($contract['total_remaining'] > 0.01) { // Sử dụng 0.01 để tránh lỗi floating point
            throw new Exception("Không thể đóng hợp đồng. Còn phải thanh toán: " . number_format($contract['total_remaining'], 0, ',', '.') . " VNĐ");
        }
        
        // 3. Kiểm tra tất cả các kỳ đã được thanh toán
        $unpaidPeriodsStmt = $pdo->prepare("
            SELECT COUNT(*) as unpaid_count,
                   GROUP_CONCAT(period_number ORDER BY period_number) as unpaid_periods
            FROM payment_schedules 
            WHERE contract_id = ? AND status NOT IN ('paid')
        ");
        $unpaidPeriodsStmt->execute([$input['contract_id']]);
        $unpaidInfo = $unpaidPeriodsStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($unpaidInfo['unpaid_count'] > 0) {
            throw new Exception("Còn {$unpaidInfo['unpaid_count']} kỳ chưa thanh toán (kỳ: {$unpaidInfo['unpaid_periods']}). Vui lòng hoàn thành tất cả trước khi đóng hợp đồng.");
        }
        
        // 4. Lấy dữ liệu payment schedules và transactions để lưu trữ
        $schedulesStmt = $pdo->prepare("SELECT * FROM payment_schedules WHERE contract_id = :contract_id ORDER BY due_date");
        $schedulesStmt->execute([':contract_id' => $input['contract_id']]);
        $paymentSchedules = $schedulesStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Lấy tất cả fields của payment_transactions
        $transactionsStmt = $pdo->prepare("SELECT * FROM payment_transactions WHERE contract_id = :contract_id ORDER BY created_at");
        $transactionsStmt->execute([':contract_id' => $input['contract_id']]);
        $paymentTransactions = $transactionsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // **THỰC SỰ THỰC HIỆN**: Loại bỏ id và transaction_code khỏi dữ liệu để tránh conflict khi restore
        foreach ($paymentTransactions as &$transaction) {
            unset($transaction['id']);
            if (isset($transaction['transaction_code'])) {
                unset($transaction['transaction_code']); 
            }
        }
        unset($transaction); // Unset reference để tránh side effects
        $totalPaid = array_sum(array_column(
    array_filter($paymentTransactions, function($transaction) {
        return $transaction['status'] === 'completed';
    }), 
    'amount_paid'
));
        // 5. Tính toán số liệu hoàn thành
        //$totalPaid = array_sum(array_column($paymentTransactions, 'amount_paid'));
        $amountRemaining = 0; // Đã thanh toán hết
        
        // 6. Lưu vào bảng deleted_contracts với trạng thái 'closed'
        $insertClosedStmt = $pdo->prepare("
            INSERT INTO deleted_contracts (
                original_contract_id, user_id, shop_id, code_id, type_id, customer_id,
                customer_name, customer_phone, customer_number_card, customer_address,
                customer_card_date, customer_place, total_money, total_money_received,
                total_paid, rate_type, loan_time, frequency, from_date, to_date, 
                amount_remaining, is_before, note, staff_id, edit_loan, 
                original_created_at, original_updated_at, deleted_by, 
                payment_schedules_data, payment_transactions_data, contract_metadata,
                deletion_status, completion_date
            ) VALUES (
                :original_contract_id, :user_id, :shop_id, :code_id, :type_id, :customer_id,
                :customer_name, :customer_phone, :customer_number_card, :customer_address,
                :customer_card_date, :customer_place, :total_money, :total_money_received,
                :total_paid, :rate_type, :loan_time, :frequency, :from_date, :to_date,
                :amount_remaining, :is_before, :note, :staff_id, :edit_loan,
                :original_created_at, :original_updated_at, :deleted_by,
                :payment_schedules_data, :payment_transactions_data, :contract_metadata,
                :deletion_status, :completion_date
            )
        ");
        
        // Tạo metadata cho việc đóng hợp đồng
        $metadata = [
            'contract_type_name' => $contract['contract_type_name'],
            'interest_rate' => $contract['interest_rate'],
            'penalty_rate' => $contract['penalty_rate'],
            'total_periods' => $contract['total_periods'],
            'paid_periods' => $contract['paid_periods'],
            'completion_timestamp' => date('Y-m-d H:i:s'),
            'completion_ip' => $_SERVER['REMOTE_ADDR'] ?? null,
            'completion_user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
            'completion_type' => 'normal_completion',
            'final_remaining_amount' => $amountRemaining,
            'total_paid_verified' => $totalPaid,
            'note' => 'Transaction codes removed to avoid duplicates on restore - will be regenerated if needed'
        ];
        
        $insertClosedStmt->execute([
            ':original_contract_id' => $contract['id'],
            ':user_id' => $contract['user_id'],
            ':shop_id' => $contract['shop_id'],
            ':code_id' => $contract['code_id'],
            ':type_id' => $contract['type_id'],
            ':customer_id' => $contract['customer_id'],
            ':customer_name' => $contract['customer_name'],
            ':customer_phone' => $contract['customer_phone'],
            ':customer_number_card' => $contract['customer_number_card'],
            ':customer_address' => $contract['customer_address'],
            ':customer_card_date' => $contract['customer_card_date'],
            ':customer_place' => $contract['customer_place'],
            ':total_money' => $contract['total_money'],
            ':total_money_received' => $contract['total_money_received'],
            ':total_paid' => $totalPaid,
            ':rate_type' => $contract['rate_type'],
            ':loan_time' => $contract['loan_time'],
            ':frequency' => $contract['frequency'],
            ':from_date' => $contract['from_date'],
            ':to_date' => $contract['to_date'] ?? null,
            ':amount_remaining' => $amountRemaining,
            ':is_before' => $contract['is_before'],
            ':note' => $contract['note'],
            ':staff_id' => $contract['staff_id'],
            ':edit_loan' => $contract['edit_loan'],
            ':original_created_at' => $contract['created_at'],
            ':original_updated_at' => $contract['updated_at'],
            ':deleted_by' => $currentUserId,
            ':payment_schedules_data' => json_encode($paymentSchedules, JSON_UNESCAPED_UNICODE),
            ':payment_transactions_data' => json_encode($paymentTransactions, JSON_UNESCAPED_UNICODE),
            ':contract_metadata' => json_encode($metadata, JSON_UNESCAPED_UNICODE),
            ':deletion_status' => 'closed', // KHÁC VỚI 'deleted'
            ':completion_date' => date('Y-m-d H:i:s')
        ]);
        
        $closedContractId = $pdo->lastInsertId();
        
        // Xóa payment transactions trước
        $deleteTransactionsStmt = $pdo->prepare("DELETE FROM payment_transactions WHERE contract_id = :contract_id");
        $deleteTransactionsStmt->execute([':contract_id' => $input['contract_id']]);
        
        // Xóa payment schedules
        $deleteScheduleStmt = $pdo->prepare("DELETE FROM payment_schedules WHERE contract_id = :contract_id");
        $deleteScheduleStmt->execute([':contract_id' => $input['contract_id']]);
        
        // Xóa các transactions liên quan khác
        $deleteRelatedTransStmt = $pdo->prepare("DELETE FROM transactions WHERE reference_id = :contract_id AND category IN ('loan_disbursement', 'contract_related')");
        $deleteRelatedTransStmt->execute([':contract_id' => $input['contract_id']]);
        
        // Xóa hợp đồng chính
        $deleteContractStmt = $pdo->prepare("DELETE FROM contracts WHERE id = :id");
        $deleteContractStmt->execute([':id' => $input['contract_id']]);
        
        // 8. Ghi log vào deletion_logs với lý do khác
        $logStmt = $pdo->prepare("
            INSERT INTO deletion_logs (
                table_name, record_id, deleted_contract_id, user_id, shop_id,
                deletion_reason, ip_address, user_agent
            ) VALUES (
                'contracts', :record_id, :deleted_contract_id, :user_id, :shop_id,
                :deletion_reason, :ip_address, :user_agent
            )
        ");
        
        $logStmt->execute([
            ':record_id' => $input['contract_id'],
            ':deleted_contract_id' => $closedContractId,
            ':user_id' => $contract['user_id'],
            ':shop_id' => $contract['shop_id'],
            ':deletion_reason' => 'Contract completion - all payments finished successfully',
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
        
        // 9. Log hệ thống nếu có
        if (function_exists('logSystemAction')) {
            logSystemAction($pdo, $contract['user_id'], $contract['shop_id'], 'CLOSE_CONTRACT', 'contracts', $input['contract_id'], $contract, null);
        }
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Đóng hợp đồng thành công. Hợp đồng đã hoàn thành và được lưu trữ.',
            'closed_contract_id' => $closedContractId,
            'completion_data' => [
                'total_periods' => $contract['total_periods'],
                'paid_periods' => $contract['paid_periods'],
                'total_transactions' => count($paymentTransactions),
                'total_paid_amount' => $totalPaid,
                'completion_date' => date('Y-m-d H:i:s'),
                'final_status' => 'completed'
            ]
        ]);
        
    } catch(Exception $e) {
        $pdo->rollback();
        error_log("Close contract error: " . $e->getMessage());
        
        // Xác định HTTP status code phù hợp
        $statusCode = 500;
        if (strpos($e->getMessage(), 'Còn phải thanh toán') !== false || 
            strpos($e->getMessage(), 'kỳ chưa thanh toán') !== false) {
            $statusCode = 400; // Bad Request cho điều kiện chưa đủ
        } elseif (strpos($e->getMessage(), 'không tồn tại') !== false) {
            $statusCode = 404; // Not Found
        }
        
        http_response_code($statusCode);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

function handleDeleteContract($pdo, $contractId) {
    try {
        $currentUserId = $_SESSION['username'];
        $pdo->beginTransaction();
        // 1. Lấy thông tin hợp đồng đầy đủ
        $contractStmt = $pdo->prepare("
            SELECT c.*, ct.name as contract_type_name, ct.interest_rate, ct.penalty_rate
            FROM contracts c
            LEFT JOIN contract_types ct ON c.rate_type = ct.id
            WHERE c.id = :id
        ");
        $contractStmt->execute([':id' => $contractId]);
        $contract = $contractStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$contract) {
            throw new Exception("Hợp đồng không tồn tại");
        }
        
        // 2. Lấy dữ liệu payment schedules
        $schedulesStmt = $pdo->prepare("SELECT * FROM payment_schedules WHERE contract_id = :contract_id ORDER BY due_date");
        $schedulesStmt->execute([':contract_id' => $contractId]);
        $paymentSchedules = $schedulesStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 3. Lấy dữ liệu payment transactions
        $transactionsStmt = $pdo->prepare("SELECT * FROM payment_transactions WHERE contract_id = :contract_id ORDER BY created_at");
        $transactionsStmt->execute([':contract_id' => $contractId]);
        $paymentTransactions = $transactionsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 4. Kiểm tra có thanh toán hay không (tùy chọn - có thể bỏ qua nếu muốn cho phép xóa)
        if (!empty($paymentTransactions)) {
            // Ghi log cảnh báo nhưng vẫn cho phép xóa
            error_log("Warning: Deleting contract with existing payments. Contract ID: $contractId");
        }
        
        // 5. Lưu vào bảng deleted_contracts với đầy đủ các trường
        $insertDeletedStmt = $pdo->prepare("
            INSERT INTO deleted_contracts (
                original_contract_id, user_id, shop_id, code_id, type_id, customer_id,
                customer_name, customer_phone, customer_number_card, customer_address,
                customer_card_date, customer_place, total_money, total_money_received,
                total_paid, rate_type, loan_time, frequency, from_date, to_date, 
                amount_remaining, is_before, note, staff_id, edit_loan, 
                original_created_at, original_updated_at, deleted_by, 
                payment_schedules_data, payment_transactions_data, contract_metadata
            ) VALUES (
                :original_contract_id, :user_id, :shop_id, :code_id, :type_id, :customer_id,
                :customer_name, :customer_phone, :customer_number_card, :customer_address,
                :customer_card_date, :customer_place, :total_money, :total_money_received,
                :total_paid, :rate_type, :loan_time, :frequency, :from_date, :to_date,
                :amount_remaining, :is_before, :note, :staff_id, :edit_loan,
                :original_created_at, :original_updated_at, :deleted_by,
                :payment_schedules_data, :payment_transactions_data, :contract_metadata
            )
        ");
        
        // Tính tổng số tiền đã trả
        
        $totalPaid = array_sum(array_column(
    array_filter($paymentTransactions, function($transaction) {
        return $transaction['status'] === 'completed';
    }), 
    'amount_paid'
));
        
        // Tính amount_remaining
        $amountRemaining = $contract['total_money_received'] - $totalPaid;
        
        // Tạo metadata bổ sung
        $metadata = [
            'contract_type_name' => $contract['contract_type_name'],
            'interest_rate' => $contract['interest_rate'],
            'penalty_rate' => $contract['penalty_rate'],
            'total_periods' => ceil($contract['loan_time'] / $contract['frequency']),
            'paid_periods' => count(array_filter($paymentSchedules, function($s) { return $s['status'] == 'paid'; })),
            'deletion_timestamp' => date('Y-m-d H:i:s'),
            'deletion_ip' => $_SERVER['REMOTE_ADDR'] ?? null,
            'deletion_user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ];
        
        $insertDeletedStmt->execute([
            ':original_contract_id' => $contract['id'],
            ':user_id' => $contract['user_id'],
            ':shop_id' => $contract['shop_id'],
            ':code_id' => $contract['code_id'],
            ':type_id' => $contract['type_id'],
            ':customer_id' => $contract['customer_id'],
            ':customer_name' => $contract['customer_name'],
            ':customer_phone' => $contract['customer_phone'],
            ':customer_number_card' => $contract['customer_number_card'],
            ':customer_address' => $contract['customer_address'],
            ':customer_card_date' => $contract['customer_card_date'],
            ':customer_place' => $contract['customer_place'],
            ':total_money' => $contract['total_money'],
            ':total_money_received' => $contract['total_money_received'],
            ':total_paid' => $totalPaid,
            ':rate_type' => $contract['rate_type'],
            ':loan_time' => $contract['loan_time'],
            ':frequency' => $contract['frequency'],
            ':from_date' => $contract['from_date'],
            ':to_date' => $contract['to_date'] ?? null, // Lưu to_date nếu có
            ':amount_remaining' => $amountRemaining,
            ':is_before' => $contract['is_before'],
            ':note' => $contract['note'],
            ':staff_id' => $contract['staff_id'],
            ':edit_loan' => $contract['edit_loan'],
            ':original_created_at' => $contract['created_at'],
            ':original_updated_at' => $contract['updated_at'],
            ':deleted_by' => $currentUserId, // Hoặc lấy từ session
            ':payment_schedules_data' => json_encode($paymentSchedules, JSON_UNESCAPED_UNICODE),
            ':payment_transactions_data' => json_encode($paymentTransactions, JSON_UNESCAPED_UNICODE),
            ':contract_metadata' => json_encode($metadata, JSON_UNESCAPED_UNICODE)
        ]);
        
        $deletedContractId = $pdo->lastInsertId();
        
        // 6. Xóa dữ liệu từ bảng gốc (theo thứ tự để tránh foreign key constraint)
        
        // Xóa payment transactions trước
        $deleteTransactionsStmt = $pdo->prepare("DELETE FROM payment_transactions WHERE contract_id = :contract_id");
        $deleteTransactionsStmt->execute([':contract_id' => $contractId]);
        
        // Xóa payment schedules
        $deleteScheduleStmt = $pdo->prepare("DELETE FROM payment_schedules WHERE contract_id = :contract_id");
        $deleteScheduleStmt->execute([':contract_id' => $contractId]);
        
        // Xóa các transactions liên quan khác
        $deleteRelatedTransStmt = $pdo->prepare("DELETE FROM transactions WHERE reference_id = :contract_id AND category IN ('loan_disbursement', 'contract_related')");
        $deleteRelatedTransStmt->execute([':contract_id' => $contractId]);
        
        // Xóa hợp đồng chính
        $deleteContractStmt = $pdo->prepare("DELETE FROM contracts WHERE id = :id");
        $deleteContractStmt->execute([':id' => $contractId]);
        
        // 7. Ghi log vào deletion_logs
        $logStmt = $pdo->prepare("
            INSERT INTO deletion_logs (
                table_name, record_id, deleted_contract_id, user_id, shop_id,
                deletion_reason, ip_address, user_agent
            ) VALUES (
                'contracts', :record_id, :deleted_contract_id, :user_id, :shop_id,
                :deletion_reason, :ip_address, :user_agent
            )
        ");
        
        $logStmt->execute([
            ':record_id' => $contractId,
            ':deleted_contract_id' => $deletedContractId,
            ':user_id' => $contract['user_id'],
            ':shop_id' => $contract['shop_id'],
            ':deletion_reason' => 'Manual deletion via admin interface',
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
        
        // 8. Log hệ thống (nếu có hàm logSystemAction)
        if (function_exists('logSystemAction')) {
            logSystemAction($pdo, $contract['user_id'], $contract['shop_id'], 'DELETE_CONTRACT', 'contracts', $contractId, $contract, null);
        }
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Xóa hợp đồng thành công và đã lưu vào kho lưu trữ',
            'deleted_contract_id' => $deletedContractId,
            'archived_data' => [
                'payment_schedules_count' => count($paymentSchedules),
                'payment_transactions_count' => count($paymentTransactions),
                'total_paid_amount' => $totalPaid,
                'amount_remaining' => $amountRemaining
            ]
        ]);
        
    } catch(Exception $e) {
        $pdo->rollback();
        error_log("Delete contract error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
function handleGetPaymentHistory($pdo, $params) {
    if (!isset($params['contract_id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Thiếu thông tin bắt buộc']);
        return;
    }
    
    try {
        // Kiểm tra quyền truy cập contract
        $checkSql = "SELECT id FROM contracts WHERE id = :contract_id";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->execute([
            ':contract_id' => (int)$params['contract_id']
        ]);
        
        if (!$checkStmt->fetch()) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Không có quyền truy cập hợp đồng này']);
            return;
        }
        
        // Query lấy lịch sử thanh toán - SỬA TÊN BẢNG
        $sql = "SELECT 
                    pt.id,
                    pt.contract_id,
                    pt.schedule_id,
                    pt.user_id,
                    pt.shop_id,
                    pt.code_id,
                    pt.customer_id,
                    pt.transaction_code,
                    DATE_FORMAT(pt.payment_date, '%d/%m/%Y') as formatted_payment_date,
                    pt.payment_date, -- Raw date for sorting
                    pt.amount_paid,
                    pt.payment_method,
                    pt.note,
                    pt.staff_id,
                    DATE_FORMAT(pt.created_at, '%d/%m/%Y %H:%i') as formatted_created_at,
                    pt.status,
                    DATE_FORMAT(pt.cancelled_at, '%d/%m/%Y %H:%i') as formatted_cancelled_at,
                    pt.cancelled_by,
                    pt.cancellation_reason,
                    -- Lấy thông tin kỳ từ payment_schedules (có chữ s) hoặc tính toán
                    COALESCE(ps.period_number, 
                        ROW_NUMBER() OVER (ORDER BY pt.payment_date ASC)
                    ) as period_number
                FROM payment_transactions pt
                LEFT JOIN payment_schedules ps ON pt.schedule_id = ps.id  -- SỬA TÊN BẢNG
                WHERE pt.contract_id = :contract_id 
                ORDER BY pt.payment_date DESC, pt.created_at DESC";
                
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':contract_id' => (int)$params['contract_id'],
        ]);
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $history
        ]);
        
    } catch(Exception $e) {
        error_log("Error getting payment history: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()]);
    }
}
/**
 * Hủy thanh toán của một kỳ (đặt lại trạng thái chưa thanh toán)
 */
function cancelPaymentSchedule($pdo, $input) {
    error_log("=== CANCEL PAYMENT SCHEDULE ===");
    
    if (!isset($input['schedule_id']) || $input['schedule_id'] <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Schedule ID không hợp lệ']);
        return;
    }
    
    try {
        $pdo->beginTransaction();
        
        // Lấy thông tin payment schedule hiện tại
        $scheduleStmt = $pdo->prepare("
            SELECT ps.*, c.user_id, c.shop_id, c.code_id, c.customer_id 
            FROM payment_schedules ps
            JOIN contracts c ON ps.contract_id = c.id
            WHERE ps.id = ?
        ");
        $scheduleStmt->execute([$input['schedule_id']]);
       $schedule = $scheduleStmt->fetch();
        
        if (!$schedule) {
            throw new Exception('Không tìm thấy kỳ thanh toán');
        }
        
        if ($schedule['status'] === 'pending') {
            throw new Exception('Kỳ này chưa được thanh toán, không thể hủy');
        }
        
        // Lấy tổng số tiền đã thanh toán cho kỳ này
        $totalPaidStmt = $pdo->prepare("
            SELECT SUM(amount_paid) as total_paid, COUNT(*) as transaction_count
            FROM payment_transactions 
            WHERE schedule_id = ? AND status = 'completed'
        ");
        $totalPaidStmt->execute([$input['schedule_id']]);
        $paidInfo = $totalPaidStmt->fetch();
        
        if (!$paidInfo || $paidInfo['transaction_count'] == 0) {
            throw new Exception('Không tìm thấy giao dịch thanh toán nào cho kỳ này');
        }
        
        // Đánh dấu tất cả transactions của kỳ này là đã hủy
        $cancelTransStmt = $pdo->prepare("
            UPDATE payment_transactions 
            SET status = 'cancelled', 
                cancelled_at = NOW(),
                cancelled_by = ?,
                cancellation_reason = ?
            WHERE schedule_id = ? AND status = 'completed'
        ");
        
        $cancelTransStmt->execute([
            $input['cancelled_by'] ?? 'USER',
            $input['reason'] ?? 'Payment cancellation',
            $input['schedule_id']
        ]);
        
        // Reset payment schedule về trạng thái chưa thanh toán
        $resetScheduleStmt = $pdo->prepare("
            UPDATE payment_schedules 
            SET amount_paid = 0,
                amount_remaining = amount_due,
                status = 'pending',
                updated_at = NOW()
            WHERE id = ?
        ");
        $resetScheduleStmt->execute([$input['schedule_id']]);
        
        // Log hành động hủy thanh toán
        $logStmt = $pdo->prepare("
            INSERT INTO payment_cancellation_log (
                contract_id, schedule_id, user_id, shop_id,
                cancelled_amount, cancellation_reason, cancelled_by,
                original_status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $logStmt->execute([
            $schedule['contract_id'],
            $input['schedule_id'],
            $schedule['user_id'],
            $schedule['shop_id'],
            $paidInfo['total_paid'],
            $input['reason'] ?? 'User cancellation',
            $input['cancelled_by'] ?? 'USER',
            $schedule['status']
        ]);
        
        // Cập nhật tổng tiền đã trả của hợp đồng
        updateContractTotals($pdo, $schedule['contract_id']);
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Hủy thanh toán thành công',
            'data' => [
                'cancelled_amount' => $paidInfo['total_paid'],
                'cancelled_transactions' => $paidInfo['transaction_count'],
                'new_status' => 'pending'
            ]
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Cancel Payment Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
    }
}

/**
 * Hủy một giao dịch thanh toán cụ thể
 */
function cancelTransaction($pdo, $input) {
    error_log("=== CANCEL TRANSACTION ===");
    
    if (!isset($input['transaction_id']) || $input['transaction_id'] <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Transaction ID không hợp lệ']);
        return;
    }
    
    try {
        $pdo->beginTransaction();
        
        // Lấy thông tin giao dịch
        $transStmt = $pdo->prepare("
            SELECT pt.*, ps.amount_due, ps.amount_paid, ps.status as schedule_status,
                   c.user_id, c.shop_id
            FROM payment_transactions pt
            JOIN payment_schedules ps ON pt.schedule_id = ps.id
            JOIN contracts c ON pt.contract_id = c.id
            WHERE pt.id = ? AND pt.status = 'completed'
        ");
        $transStmt->execute([$input['transaction_id']]);
        $transaction = $transStmt->fetch();
        
        if (!$transaction) {
            throw new Exception('Không tìm thấy giao dịch hoặc giao dịch đã được hủy');
        }
        
        // Kiểm tra xem có phải giao dịch cuối cùng không
        $remainingTransStmt = $pdo->prepare("
            SELECT COUNT(*) as remaining_count
            FROM payment_transactions 
            WHERE schedule_id = ? AND status = 'completed' AND id != ?
        ");
        $remainingTransStmt->execute([$transaction['schedule_id'], $input['transaction_id']]);
        $remainingCount = $remainingTransStmt->fetchColumn();
        
        // Hủy giao dịch
        $cancelStmt = $pdo->prepare("
            UPDATE payment_transactions 
            SET status = 'cancelled',
                cancelled_at = NOW(),
                cancelled_by = ?,
                cancellation_reason = ?
            WHERE id = ?
        ");
        
        $cancelStmt->execute([
            $input['cancelled_by'] ?? 'USER',
            $input['reason'] ?? 'Transaction cancellation',
            $input['transaction_id']
        ]);
        
        // Cập nhật payment schedule
        $newAmountPaid = $transaction['amount_paid'] - $transaction['amount_paid'];
        $newAmountRemaining = $transaction['amount_due'] - $newAmountPaid;
        
        // Xác định trạng thái mới của schedule
        $newStatus = 'pending';
        if ($remainingCount > 0) {
            // Còn giao dịch khác, tính lại tổng
            $remainingAmountStmt = $pdo->prepare("
                SELECT SUM(amount_paid) as total_remaining
                FROM payment_transactions 
                WHERE schedule_id = ? AND status = 'completed'
            ");
            $remainingAmountStmt->execute([$transaction['schedule_id']]);
            $totalRemaining = $remainingAmountStmt->fetchColumn() ?: 0;
            
            $newAmountPaid = $totalRemaining;
            $newAmountRemaining = $transaction['amount_due'] - $totalRemaining;
            
            if ($totalRemaining >= $transaction['amount_due']) {
                $newStatus = 'paid';
                $newAmountRemaining = 0;
            } elseif ($totalRemaining > 0) {
                $newStatus = 'partial_paid';
            }
        }
        
        // Cập nhật schedule
        $updateScheduleStmt = $pdo->prepare("
            UPDATE payment_schedules 
            SET amount_paid = ?,
                amount_remaining = ?,
                status = ?,
                updated_at = NOW()
            WHERE id = ?
        ");
        
        $updateScheduleStmt->execute([
            $newAmountPaid,
            $newAmountRemaining,
            $newStatus,
            $transaction['schedule_id']
        ]);
        
        // Log hành động
        $logStmt = $pdo->prepare("
            INSERT INTO payment_cancellation_log (
                contract_id, schedule_id, transaction_id, user_id, shop_id,
                cancelled_amount, cancellation_reason, cancelled_by,
                original_status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $logStmt->execute([
            $transaction['contract_id'],
            $transaction['schedule_id'],
            $input['transaction_id'],
            $transaction['user_id'],
            $transaction['shop_id'],
            $transaction['amount_paid'],
            $input['reason'] ?? 'Individual transaction cancellation',
            $input['cancelled_by'] ?? 'USER',
            'completed'
        ]);
        
        // Cập nhật tổng tiền của hợp đồng
        updateContractTotals($pdo, $transaction['contract_id']);
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Hủy giao dịch thành công',
            'data' => [
                'cancelled_amount' => $transaction['amount_paid'],
                'transaction_code' => $transaction['transaction_code'],
                'schedule_new_status' => $newStatus,
                'schedule_amount_paid' => $newAmountPaid,
                'schedule_amount_remaining' => $newAmountRemaining
            ]
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Cancel Transaction Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
    }
}

/**
 * Cập nhật lại tổng tiền của hợp đồng sau khi hủy thanh toán
 */
function updateContractTotals($pdo, $contractId) {
    // Tính lại tổng tiền đã trả từ các giao dịch còn hiệu lực
    $totalStmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount_paid), 0) as total_paid
        FROM payment_transactions 
        WHERE contract_id = ? AND status = 'completed'
    ");
    $totalStmt->execute([$contractId]);
    $totalPaid = $totalStmt->fetchColumn();
    
    // Cập nhật contracts table nếu có trường lưu tổng tiền đã trả
    $updateContractStmt = $pdo->prepare("
        UPDATE contracts 
        SET total_paid = ?,
            remaining_amount = total_money - ?,
            updated_at = NOW()
        WHERE id = ?
    ");
    $updateContractStmt->execute([$totalPaid, $totalPaid, $contractId]);
    
    return $totalPaid;
}

/**
 * Lấy lịch sử hủy thanh toán
 */
function getPaymentCancellationHistory($pdo, $input) {
    $contractId = $input['contract_id'] ?? null;
    $limit = $input['limit'] ?? 50;
    $offset = $input['offset'] ?? 0;
    
    try {
        $whereClause = "";
        $params = [];
        
        if ($contractId) {
            $whereClause = "WHERE contract_id = ?";
            $params[] = $contractId;
        }
        
        $stmt = $pdo->prepare("
            SELECT pcl.*, 
                   c.customer_name, c.code_id as contract_code,
                   ps.period_number,
                   pt.transaction_code
            FROM payment_cancellation_log pcl
            JOIN contracts c ON pcl.contract_id = c.id
            LEFT JOIN payment_schedules ps ON pcl.schedule_id = ps.id
            LEFT JOIN payment_transactions pt ON pcl.transaction_id = pt.id
            $whereClause
            ORDER BY pcl.created_at DESC
            LIMIT ? OFFSET ?
        ");
        
        $params[] = $limit;
        $params[] = $offset;
        $stmt->execute($params);
        $history = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'data' => $history,
            'total' => count($history)
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}

/**
 * Tạo lịch trả nợ tự động cho hợp đồng
 */
function createPaymentSchedule($pdo, $input) {
    error_log("=== CREATE PAYMENT SCHEDULE ===");
    
    if (!isset($input['contract_id']) || $input['contract_id'] <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Contract ID không hợp lệ']);
        return;
    }
    
    try {
        // Kiểm tra hợp đồng có tồn tại không
        $checkStmt = $pdo->prepare("SELECT * FROM contracts WHERE id = ?");
        $checkStmt->execute([$input['contract_id']]);
        $contract = $checkStmt->fetch();
        
        if (!$contract) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Hợp đồng không tồn tại']);
            return;
        }
        
        // Kiểm tra đã có lịch trả nợ chưa
        $existingStmt = $pdo->prepare("SELECT COUNT(*) FROM payment_schedules WHERE contract_id = ?");
        $existingStmt->execute([$input['contract_id']]);
        $existing = $existingStmt->fetchColumn();
        
        if ($existing > 0) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Hợp đồng này đã có lịch trả nợ']);
            return;
        }
        
        // Lấy thông tin lãi suất từ contract_types (nếu có)
        $interestRate = 0.0;
        $penaltyRate = 0.0;
        
        if ($contract['rate_type'] > 0) {
            $typeStmt = $pdo->prepare("SELECT interest_rate, penalty_rate FROM contract_types WHERE id = ?");
            $typeStmt->execute([$contract['rate_type']]);
            $typeInfo = $typeStmt->fetch();
            
            if ($typeInfo) {
                $interestRate = $typeInfo['interest_rate'];
                $penaltyRate = $typeInfo['penalty_rate'];
            }
        }
        
        // Tính toán các thông số
        $totalMoney = (float)$contract['total_money'];
        $loanTime = (int)$contract['loan_time'];
        $frequency = (int)$contract['frequency'];
        $fromDate = $contract['from_date'];
        
        // Số kỳ trả = tổng thời gian / tần suất
        $totalPeriods = ceil($loanTime / $frequency);
        
        // Tính số tiền phải trả mỗi kỳ (bao gồm cả gốc và lãi)
        if ($interestRate > 0) {
            // Công thức lãi đơn: Tổng tiền = Gốc × (1 + lãi suất × số kỳ)
            $totalWithInterest = $totalMoney * (1 + ($interestRate * $totalPeriods));
            $amountPerPeriod = round($totalWithInterest / $totalPeriods, 2);
        } else {
            $amountPerPeriod = round($totalMoney / $totalPeriods, 2);
        }
        
        error_log("Total Periods: $totalPeriods, Amount per period: $amountPerPeriod");
        
        // Tạo lịch trả cho từng kỳ
        $insertStmt = $pdo->prepare("
            INSERT INTO payment_schedules (
                contract_id, user_id, shop_id, code_id, customer_id,
                period_number, from_date, to_date, due_date,
                amount_due, amount_remaining, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        
        for ($i = 1; $i <= $totalPeriods; $i++) {
            $periodFromDate = date('Y-m-d', strtotime($fromDate . " + " . (($i - 1) * $frequency) . " days"));
            $periodToDate = date('Y-m-d', strtotime($periodFromDate . " + " . ($frequency - 1) . " days"));
            $dueDate = $periodToDate; // Ngày đáo hạn là ngày cuối của kỳ
            
            // Kỳ cuối cùng có thể có số tiền khác để đảm bảo tổng đúng
            $currentAmount = $amountPerPeriod;
            if ($i == $totalPeriods) {
                // Tính lại để đảm bảo tổng chính xác
                $totalScheduled = $amountPerPeriod * ($totalPeriods - 1);
                if ($interestRate > 0) {
                    $totalWithInterest = $totalMoney * (1 + ($interestRate * $totalPeriods));
                    $currentAmount = $totalWithInterest - $totalScheduled;
                } else {
                    $currentAmount = $totalMoney - $totalScheduled;
                }
                $currentAmount = round($currentAmount, 2);
            }
            
            $insertStmt->execute([
                $contract['id'],
                $contract['user_id'],
                $contract['shop_id'],
                $contract['code_id'],
                $contract['customer_id'],
                $i,
                $periodFromDate,
                $periodToDate,
                $dueDate,
                $currentAmount,
                $currentAmount
            ]);
            
            error_log("Created period $i: $periodFromDate to $periodToDate, due: $dueDate, amount: $currentAmount");
        }
        
        echo json_encode([
            'success' => true,
            'message' => "Đã tạo lịch trả nợ với $totalPeriods kỳ",
            'data' => [
                'total_periods' => $totalPeriods,
                'amount_per_period' => $amountPerPeriod,
                'interest_rate' => $interestRate,
                'penalty_rate' => $penaltyRate
            ]
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}

/**
 * Lấy lịch trả nợ của hợp đồng
 */
function getPaymentSchedule($pdo, $input) {
    if (!isset($input['contract_id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Contract ID không được để trống']);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT ps.*, 
                   c.customer_name,
                   c.code_id as contract_code,
                   CASE 
                       WHEN ps.due_date = CURDATE() THEN 'due_today'
                       WHEN ps.due_date = DATE_ADD(CURDATE(), INTERVAL 1 DAY) THEN 'due_tomorrow'
                       WHEN ps.due_date < CURDATE() AND ps.status != 'paid' THEN 'overdue'
                       WHEN ps.due_date > CURDATE() THEN 'active'
                       ELSE 'unknown'
                   END as schedule_status,
                   CASE 
                       WHEN ps.due_date < CURDATE() AND ps.status != 'paid' THEN DATEDIFF(CURDATE(), ps.due_date)
                       ELSE 0
                   END as days_overdue
            FROM payment_schedules ps
            JOIN contracts c ON ps.contract_id = c.id
            WHERE ps.contract_id = ?
            ORDER BY ps.period_number ASC
        ");
        
        $stmt->execute([$input['contract_id']]);
        $schedules = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'data' => $schedules,
            'total_periods' => count($schedules)
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}

/**
 * Cập nhật thanh toán cho một kỳ
 */
function updatePayment($pdo, $input) {
    $required = ['schedule_id', 'amount_paid', 'payment_date', 'payment_method'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || $input[$field] === '') {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => "Trường $field không được để trống"]);
            return;
        }
    }
    
    try {
        $pdo->beginTransaction();
        
        // Lấy thông tin schedule hiện tại
        $scheduleStmt = $pdo->prepare("SELECT * FROM payment_schedules WHERE id = ?");
        $scheduleStmt->execute([$input['schedule_id']]);
        $schedule = $scheduleStmt->fetch();
        
        if (!$schedule) {
            throw new Exception('Không tìm thấy kỳ thanh toán');
        }
        
        $amountPaid = round((float)$input['amount_paid'], 2);
        $newTotalPaid = $schedule['amount_paid'] + $amountPaid;
        $newRemaining = $schedule['amount_due'] - $newTotalPaid;
        
        // Xác định trạng thái mới
        $newStatus = 'pending';
        // Sử dụng so sánh với độ chính xác
if (abs($newTotalPaid - $schedule['amount_due']) < 0.01) {
    $newStatus = 'paid';
    $newRemaining = 0;
} elseif ($newTotalPaid >= $schedule['amount_due']) {
    $newStatus = 'paid'; 
    $newRemaining = 0;
} elseif ($newTotalPaid > 0) {
    $newStatus = 'partial_paid';
}
        
        // Cập nhật payment_schedules
        $updateStmt = $pdo->prepare("
            UPDATE payment_schedules 
            SET amount_paid = ?, amount_remaining = ?, status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $updateStmt->execute([$newTotalPaid, $newRemaining, $newStatus, $input['schedule_id']]);
        
        // Tạo transaction code unique
        $transactionCode = 'PAY' . date('YmdHis') . rand(1000, 9999);
        
        // // Thêm vào payment_transactions
        
        $transactionStmt = $pdo->prepare("
    INSERT INTO payment_transactions (
        contract_id, schedule_id, user_id, shop_id, code_id, customer_id,
        transaction_code, payment_date, amount_paid, payment_method, note, staff_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

// Xác định user_id và staff_id đúng cách
$transaction_user_id = $_SESSION['user_id'] ?? null;
$transaction_staff_id = $_SESSION['staff_id'] ?? null;

$transactionStmt->execute([
    $schedule['contract_id'],
    $schedule['id'],
    $transaction_user_id, // Có thể null nếu là staff
    $schedule['shop_id'],
    $schedule['code_id'],
    $schedule['customer_id'],
    $transactionCode,
    $input['payment_date'],
    $amountPaid,
    $input['payment_method'],
    $input['note'] ?? '',
    $transaction_staff_id ?? $input['staff_id'] ?? 'SYSTEM'
]);
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Cập nhật thanh toán thành công',
            'data' => [
                'transaction_code' => $transactionCode,
                'new_status' => $newStatus,
                'amount_paid' => $newTotalPaid,
                'amount_remaining' => $newRemaining
            ]
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Payment Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
    }
}

/**
 * Lấy danh sách hợp đồng quá hạn
 */
function getOverdueContracts($pdo, $input) {
    $shopId = $input['shop_id'] ?? '';
    $limit = $input['limit'] ?? 50;
    $offset = $input['offset'] ?? 0;
    
    try {
        $whereClause = "ps.due_date < CURDATE() AND ps.status IN ('pending', 'partial_paid')";
        $params = [];
        
        if (!empty($shopId)) {
            $whereClause .= " AND ps.shop_id = ?";
            $params[] = $shopId;
        }
        
        $stmt = $pdo->prepare("
            SELECT ps.*, c.customer_name, c.customer_phone,
                   DATEDIFF(CURDATE(), ps.due_date) as days_overdue,
                   ct.penalty_rate
            FROM payment_schedules ps
            JOIN contracts c ON ps.contract_id = c.id
            LEFT JOIN contract_types ct ON c.rate_type = ct.id
            WHERE $whereClause
            ORDER BY ps.due_date ASC, ps.amount_remaining DESC
            LIMIT ? OFFSET ?
        ");
        
        $params[] = $limit;
        $params[] = $offset;
        $stmt->execute($params);
        $overdueContracts = $stmt->fetchAll();
        
        // Tính penalty cho mỗi hợp đồng quá hạn
        foreach ($overdueContracts as &$contract) {
            $penaltyRate = $contract['penalty_rate'] ?? 0;
            $daysOverdue = $contract['days_overdue'];
            $penalty = $contract['amount_remaining'] * $penaltyRate * $daysOverdue / 100;
            $contract['penalty_amount'] = round($penalty, 2);
            $contract['total_due'] = $contract['amount_remaining'] + $contract['penalty_amount'];
        }
        
        echo json_encode([
            'success' => true,
            'data' => $overdueContracts,
            'total' => count($overdueContracts)
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}

/**
 * Lấy danh sách hợp đồng đến hạn hôm nay
 */
function getDueTodayContracts($pdo, $input) {
    $shopId = $input['shop_id'] ?? '';
    
    try {
        $whereClause = "ps.due_date = CURDATE() AND ps.status IN ('pending', 'partial_paid')";
        $params = [];
        
        if (!empty($shopId)) {
            $whereClause .= " AND ps.shop_id = ?";
            $params[] = $shopId;
        }
        
        $stmt = $pdo->prepare("
            SELECT ps.*, c.customer_name, c.customer_phone, c.customer_address
            FROM payment_schedules ps
            JOIN contracts c ON ps.contract_id = c.id
            WHERE $whereClause
            ORDER BY ps.amount_remaining DESC
        ");
        
        $stmt->execute($params);
        $dueTodayContracts = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'data' => $dueTodayContracts,
            'total' => count($dueTodayContracts)
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}

/**
 * Lấy trạng thái tổng quan của hợp đồng
 */
function getContractStatus($pdo, $input) {
    $contractId = $input['contract_id'] ?? '';
    
    if (empty($contractId)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Contract ID không được để trống']);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM contract_status_view WHERE contract_id = ?
        ");
        
        $stmt->execute([$contractId]);
        $status = $stmt->fetch();
        
        if (!$status) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Không tìm thấy hợp đồng']);
            return;
        }
        
        echo json_encode([
            'success' => true,
            'data' => $status
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi database: ' . $e->getMessage()]);
    }
}
?>