<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Logging function để debug
function logDebug($message, $data = null) {
    error_log("[DASHBOARD DEBUG] " . $message . ($data ? " | Data: " . print_r($data, true) : ""));
}

try {
    // Lấy shopId từ nhiều nguồn có thể
    $shopId = $_GET['shopId'] ?? $_POST['shopId'] ?? $_GET['shop_id'] ?? $_SESSION['shop_id'] ?? '';
    $userId = $_GET['userId'] ?? $_POST['userId'] ?? $_SESSION['user_id'] ?? '';
    
    logDebug("Request received", ['shopId' => $shopId, 'userId' => $userId]);
    
    if (empty($shopId)) {
        // Thử lấy từ input JSON
        $raw_input = file_get_contents('php://input');
        $input = json_decode($raw_input, true);
        $shopId = $input['shopId'] ?? $input['shop_id'] ?? '';
        $userId = $userId ?: ($input['userId'] ?? $input['user_id'] ?? '');
        
        logDebug("JSON input parsed", ['shopId' => $shopId, 'userId' => $userId]);
        
        if (empty($shopId)) {
            throw new Exception('Shop ID không được để trống. Vui lòng truyền shopId trong request.');
        }
    }

    // 1. Lấy vốn đầu tư từ bảng shops - BỎ DELETED_AT
    $capitalStmt = $pdo->prepare("
        SELECT total_money_in_safe 
        FROM shops 
        WHERE shop_id = ?
    ");
    $capitalStmt->execute([$shopId]);
    $capital = (float)($capitalStmt->fetchColumn() ?: 0);
    logDebug("Capital fetched", $capital);

    // 2. Tính tổng số tiền đã giải ngân (từ contracts đang hoạt động) - KIỂM TRA CỘT
    // Trước tiên kiểm tra xem bảng contracts có cột deleted_at không
    $checkDeletedAtStmt = $pdo->prepare("SHOW COLUMNS FROM contracts LIKE 'deleted_at'");
    $checkDeletedAtStmt->execute();
    $hasDeletedAt = $checkDeletedAtStmt->rowCount() > 0;
    
    logDebug("Contracts table has deleted_at column", $hasDeletedAt);

    if ($hasDeletedAt) {
        $activeContractsQuery = "
            SELECT 
                COALESCE(SUM(total_money_received), 0) as total_disbursed,
                COUNT(*) as total_contracts
            FROM contracts 
            WHERE shop_id = ? AND deleted_at IS NULL
        ";
    } else {
        $activeContractsQuery = "
            SELECT 
                COALESCE(SUM(total_money_received), 0) as total_disbursed,
                COUNT(*) as total_contracts
            FROM contracts 
            WHERE shop_id = ?
        ";
    }

    $activeContractsStmt = $pdo->prepare($activeContractsQuery);
    $activeContractsStmt->execute([$shopId]);
    $activeData = $activeContractsStmt->fetch(PDO::FETCH_ASSOC);
    $activeDisbursed = (float)($activeData['total_disbursed'] ?: 0);
    $totalActiveContracts = (int)($activeData['total_contracts'] ?: 0);
    logDebug("Active contracts", $activeData);

    // 3. Kiểm tra bảng deleted_contracts có tồn tại không
    $checkDeletedTableStmt = $pdo->prepare("SHOW TABLES LIKE 'deleted_contracts'");
    $checkDeletedTableStmt->execute();
    $hasDeletedTable = $checkDeletedTableStmt->rowCount() > 0;
    
    logDebug("Has deleted_contracts table", $hasDeletedTable);

    $closedDisbursed = 0;
    if ($hasDeletedTable) {
        $closedContractsStmt = $pdo->prepare("
            SELECT COALESCE(SUM(total_money_received), 0) as total_disbursed
            FROM deleted_contracts 
            WHERE shop_id = ? AND deletion_status = 'closed'
        ");
        $closedContractsStmt->execute([$shopId]);
        $closedDisbursed = (float)($closedContractsStmt->fetchColumn() ?: 0);
    }
    logDebug("Closed disbursed", $closedDisbursed);

    $totalDisbursed = $activeDisbursed + $closedDisbursed;

    // 4. Tính tổng số tiền khách đã trả (từ payment_transactions ACTIVE)
    if ($hasDeletedAt) {
        $activePaidQuery = "
            SELECT COALESCE(SUM(pt.amount_paid), 0) as total_paid
            FROM payment_transactions pt
            INNER JOIN contracts c ON pt.contract_id = c.id
            WHERE c.shop_id = ? AND c.deleted_at IS NULL AND pt.status = 'completed'
        ";
    } else {
        $activePaidQuery = "
            SELECT COALESCE(SUM(pt.amount_paid), 0) as total_paid
            FROM payment_transactions pt
            INNER JOIN contracts c ON pt.contract_id = c.id
            WHERE c.shop_id = ? AND pt.status = 'completed'
        ";
    }

    $activePaidStmt = $pdo->prepare($activePaidQuery);
    $activePaidStmt->execute([$shopId]);
    $activePaid = (float)($activePaidStmt->fetchColumn() ?: 0);
    logDebug("Active paid", $activePaid);

    // 5. Tính tổng từ deleted_contracts với status = 'closed'
    $closedPaid = 0;
    if ($hasDeletedTable) {
        $closedPaidStmt = $pdo->prepare("
            SELECT COALESCE(SUM(total_paid), 0) as total_paid
            FROM deleted_contracts 
            WHERE shop_id = ? AND deletion_status = 'closed'
        ");
        $closedPaidStmt->execute([$shopId]);
        $closedPaid = (float)($closedPaidStmt->fetchColumn() ?: 0);
    }
    logDebug("Closed paid", $closedPaid);

    $totalPaid = $activePaid + $closedPaid;

    // 6. Tính tổng số tiền mà khách phải trả (từ contracts đang hoạt động)
    if ($hasDeletedAt) {
        $activeOwedQuery = "
            SELECT COALESCE(SUM(total_money), 0) as total_owed
            FROM contracts 
            WHERE shop_id = ? AND deleted_at IS NULL
        ";
    } else {
        $activeOwedQuery = "
            SELECT COALESCE(SUM(total_money), 0) as total_owed
            FROM contracts 
            WHERE shop_id = ?
        ";
    }

    $activeOwedStmt = $pdo->prepare($activeOwedQuery);
    $activeOwedStmt->execute([$shopId]);
    $activeOwed = (float)($activeOwedStmt->fetchColumn() ?: 0);

    // 7. Tính tổng từ deleted_contracts với status = 'closed'
    $closedOwed = 0;
    if ($hasDeletedTable) {
        $closedOwedStmt = $pdo->prepare("
            SELECT COALESCE(SUM(total_money), 0) as total_owed
            FROM deleted_contracts 
            WHERE shop_id = ? AND deletion_status = 'closed'
        ");
        $closedOwedStmt->execute([$shopId]);
        $closedOwed = (float)($closedOwedStmt->fetchColumn() ?: 0);
    }

    $totalOwed = $activeOwed + $closedOwed;

    // 8. TÍNH LÃI ĐÃ THU TRONG THÁNG - LOGIC ĐÚNG
    $currentMonth = date('Y-m');
    
    // Phần A: Lãi từ payment_transactions trong tháng hiện tại (chỉ tính phần lãi thực tế)
    if ($hasDeletedAt) {
        $monthlyPaymentQuery = "
            SELECT 
                COALESCE(SUM(pt.amount_paid), 0) as monthly_paid,
                COALESCE(SUM(c.total_money_received), 0) as monthly_principal_involved
            FROM payment_transactions pt
            INNER JOIN contracts c ON pt.contract_id = c.id
            WHERE c.shop_id = ? 
              AND c.deleted_at IS NULL
              AND pt.status = 'completed'
              AND DATE_FORMAT(pt.payment_date, '%Y-%m') = ?
        ";
    } else {
        $monthlyPaymentQuery = "
            SELECT 
                COALESCE(SUM(pt.amount_paid), 0) as monthly_paid,
                COALESCE(SUM(c.total_money_received), 0) as monthly_principal_involved
            FROM payment_transactions pt
            INNER JOIN contracts c ON pt.contract_id = c.id
            WHERE c.shop_id = ? 
              AND pt.status = 'completed'
              AND DATE_FORMAT(pt.payment_date, '%Y-%m') = ?
        ";
    }

    $monthlyPaymentStmt = $pdo->prepare($monthlyPaymentQuery);
    $monthlyPaymentStmt->execute([$shopId, $currentMonth]);
    $monthlyPaymentData = $monthlyPaymentStmt->fetch(PDO::FETCH_ASSOC);
    $monthlyPaidFromActive = (float)($monthlyPaymentData['monthly_paid'] ?: 0);

    // Phần B: Lãi từ contracts được đóng trong tháng (chỉ tính lãi, không tính gốc)
    $monthlyClosedInterest = 0;
    if ($hasDeletedTable) {
        // LOGIC ĐÚNG: Chỉ tính phần lãi = total_paid - total_money_received
        $monthlyClosedInterestStmt = $pdo->prepare("
            SELECT 
                COALESCE(SUM(
                    CASE 
                        WHEN total_paid > total_money_received 
                        THEN total_paid - total_money_received
                        ELSE 0 
                    END
                ), 0) as monthly_interest_from_closed
            FROM deleted_contracts 
            WHERE shop_id = ? 
              AND deletion_status = 'closed'
              AND deleted_at IS NOT NULL
              AND DATE_FORMAT(deleted_at, '%Y-%m') = ?
        ");
        $monthlyClosedInterestStmt->execute([$shopId, $currentMonth]);
        $monthlyClosedInterest = (float)($monthlyClosedInterestStmt->fetchColumn() ?: 0);
    }

    // Phần C: Tính lãi từ contracts mới tạo trong tháng (trừ đi gốc)
    if ($hasDeletedAt) {
        $monthlyNewContractsQuery = "
            SELECT COALESCE(SUM(c.total_money_received), 0) as monthly_new_principal
            FROM contracts c
            WHERE c.shop_id = ? 
              AND c.deleted_at IS NULL
              AND DATE_FORMAT(c.from_date, '%Y-%m') = ?
        ";
    } else {
        $monthlyNewContractsQuery = "
            SELECT COALESCE(SUM(c.total_money_received), 0) as monthly_new_principal
            FROM contracts c
            WHERE c.shop_id = ? 
              AND DATE_FORMAT(c.from_date, '%Y-%m') = ?
        ";
    }

    $monthlyNewContractsStmt = $pdo->prepare($monthlyNewContractsQuery);
    $monthlyNewContractsStmt->execute([$shopId, $currentMonth]);
    $monthlyNewPrincipal = (float)($monthlyNewContractsStmt->fetchColumn() ?: 0);

    // TÍNH LÃI THỰC TẾ TRONG THÁNG
    // Lãi = (Tiền thu từ thanh toán - Tiền gốc cho vay mới) + Lãi từ contracts đóng
    $totalInterestEarnedMonth = max(0, ($monthlyPaidFromActive - $monthlyNewPrincipal) + $monthlyClosedInterest);

    logDebug("Monthly interest calculation", [
        'monthlyPaidFromActive' => $monthlyPaidFromActive,
        'monthlyNewPrincipal' => $monthlyNewPrincipal,
        'monthlyClosedInterest' => $monthlyClosedInterest,
        'totalInterestEarnedMonth' => $totalInterestEarnedMonth
    ]);

    // 9. Tính toán tiền đang cho vay (remaining amount)
    if ($hasDeletedAt) {
        $currentInvestmentQuery = "
            SELECT COALESCE(SUM(
                CASE 
                    WHEN c.total_money > COALESCE(paid_summary.total_paid_per_contract, 0) 
                    THEN c.total_money - COALESCE(paid_summary.total_paid_per_contract, 0)
                    ELSE 0 
                END
            ), 0) as current_investment
            FROM contracts c
            LEFT JOIN (
                SELECT contract_id, SUM(amount_paid) as total_paid_per_contract
                FROM payment_transactions 
                WHERE status = 'completed'
                GROUP BY contract_id
            ) paid_summary ON c.id = paid_summary.contract_id
            WHERE c.shop_id = ? AND c.deleted_at IS NULL
        ";
    } else {
        $currentInvestmentQuery = "
            SELECT COALESCE(SUM(
                CASE 
                    WHEN c.total_money > COALESCE(paid_summary.total_paid_per_contract, 0) 
                    THEN c.total_money - COALESCE(paid_summary.total_paid_per_contract, 0)
                    ELSE 0 
                END
            ), 0) as current_investment
            FROM contracts c
            LEFT JOIN (
                SELECT contract_id, SUM(amount_paid) as total_paid_per_contract
                FROM payment_transactions 
                WHERE status = 'completed'
                GROUP BY contract_id
            ) paid_summary ON c.id = paid_summary.contract_id
            WHERE c.shop_id = ?
        ";
    }
    
    $currentInvestmentStmt = $pdo->prepare($currentInvestmentQuery);
    $currentInvestmentStmt->execute([$shopId]);
    $totalMoneyInvestment = (float)($currentInvestmentStmt->fetchColumn() ?: 0);
    
    logDebug("Current investment calculated", $totalMoneyInvestment);

    // 10. Tính tổng quỹ tiền mặt
    $totalCashFund = $capital - $totalDisbursed + $totalPaid;

    // 11. Lấy số hợp đồng đã đóng
    $closedCount = 0;
    if ($hasDeletedTable) {
        $closedCountStmt = $pdo->prepare("
            SELECT COUNT(*) as closed_contracts
            FROM deleted_contracts 
            WHERE shop_id = ? AND deletion_status = 'closed'
        ");
        $closedCountStmt->execute([$shopId]);
        $closedCount = (int)($closedCountStmt->fetchColumn() ?: 0);
    }

    // Final logging
    logDebug("Final calculations", [
        'capital' => $capital,
        'totalDisbursed' => $totalDisbursed,
        'totalPaid' => $totalPaid,
        'totalCashFund' => $totalCashFund,
        'totalMoneyInvestment' => $totalMoneyInvestment,
        'totalInterestEarnedMonth' => $totalInterestEarnedMonth
    ]);

    // Trả về kết quả
    echo json_encode([
        'success' => true,
        'data' => [
            // Dữ liệu chính cho dashboard
            'total_cash_fund' => round($totalCashFund, 2),
            'total_active_contracts' => (int)$totalActiveContracts,
            'total_money_investment' => round($totalMoneyInvestment, 2),
            'total_interest_earned_month' => round($totalInterestEarnedMonth, 2),
            
            // Dữ liệu gốc để tham khảo
            'raw_data' => [
                'capital' => round($capital, 2),
                'total_disbursed' => round($totalDisbursed, 2),
                'total_paid' => round($totalPaid, 2),
                'total_owed' => round($totalOwed, 2),
                'active_disbursed' => round($activeDisbursed, 2),
                'closed_disbursed' => round($closedDisbursed, 2),
                'active_paid' => round($activePaid, 2),
                'closed_paid' => round($closedPaid, 2),
                'active_owed' => round($activeOwed, 2),
                'closed_owed' => round($closedOwed, 2),
                'monthly_paid_from_active' => round($monthlyPaidFromActive, 2),
                'monthly_closed_interest' => round($monthlyClosedInterest, 2),
                'monthly_new_principal' => round($monthlyNewPrincipal, 2)
            ],
            
            // Thông tin bổ sung
            'additional_info' => [
                'active_contracts' => (int)$totalActiveContracts,
                'completed_contracts' => 0, // Simplified
                'closed_contracts' => (int)$closedCount,
                'overdue_schedules' => 0, // Simplified
                'overdue_amount' => 0, // Simplified
                'total_all_contracts' => (int)$totalActiveContracts + (int)$closedCount,
                'current_month' => $currentMonth
            ]
        ],
        'timestamp' => date('Y-m-d H:i:s'),
        'shop_id' => $shopId,
        'database_info' => [
            'has_deleted_at_column' => $hasDeletedAt,
            'has_deleted_contracts_table' => $hasDeletedTable
        ]
    ]);

} catch (Exception $e) {
    error_log("Dashboard Data Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Lỗi: ' . $e->getMessage(),
        'error_details' => [
            'shop_id' => $shopId ?? 'not_set',
            'user_id' => $userId ?? 'not_set',
            'timestamp' => date('Y-m-d H:i:s'),
            'file' => __FILE__,
            'line' => $e->getLine()
        ]
    ]);
} catch (PDOException $e) {
    error_log("Dashboard Database Error: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Lỗi database: ' . $e->getMessage(),
        'error_details' => [
            'shop_id' => $shopId ?? 'not_set',
            'timestamp' => date('Y-m-d H:i:s'),
            'sql_error' => $e->getCode()
        ]
    ]);
}
?>