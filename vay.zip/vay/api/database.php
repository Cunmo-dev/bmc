<?php
// File: database.php
// Cấu hình kết nối database

$host = 'localhost';           // Thay đổi nếu cần
$dbname = 'banhmich_allin';       // Tên database
$username = 'root';            // Username database
$password = '';                // Password database (thay đổi nếu cần)
$charset = 'utf8mb4';

// DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

// Tùy chọn PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
];

try {
    // Tạo kết nối PDO
    $pdo = new PDO($dsn, $username, $password, $options);
    
    // Thiết lập timezone (tùy chọn)
    $pdo->exec("SET time_zone = '+07:00'");
    
} catch (PDOException $e) {
    // Log lỗi thay vì hiển thị trực tiếp
    error_log("Database connection error: " . $e->getMessage());
    
    // Trả về lỗi JSON nếu là API call
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false, 
            'message' => 'Lỗi kết nối database. Vui lòng thử lại sau.'
        ]);
        exit;
    }
    
    // Hoặc chuyển hướng đến trang lỗi
    die('Lỗi kết nối database. Vui lòng liên hệ quản trị viên.');
}

// Test connection function (optional)
function testDatabaseConnection() {
    global $pdo;
    try {
        $stmt = $pdo->query('SELECT 1');
        return true;
    } catch (PDOException $e) {
        error_log("Database test failed: " . $e->getMessage());
        return false;
    }
}

// Function để lấy thông tin database
function getDatabaseInfo() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT DATABASE() as db_name, VERSION() as db_version, NOW() as current_time");
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Get database info error: " . $e->getMessage());
        return false;
    }
}
?>