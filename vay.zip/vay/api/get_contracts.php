<?php
require_once 'database.php';
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}
// Thêm vào đầu file, sau phần xử lý OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !isset($_GET['action'])) {
    handleGetContractsList($pdo, $_GET);
    exit();
}

// DEBUG: Log để kiểm tra
error_log("=== CONTRACT API DEBUG ===");
error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Request URI: " . $_SERVER['REQUEST_URI']);

// Lấy raw input để debug
$raw_input = file_get_contents('php://input');
error_log("Raw Input: " . $raw_input);

// Lấy dữ liệu POST
$input = json_decode($raw_input, true);

// DEBUG: Kiểm tra JSON decode
if (json_last_error() !== JSON_ERROR_NONE) {
    error_log("JSON Error: " . json_last_error_msg());
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Lỗi JSON: ' . json_last_error_msg()]);
    exit();
}

error_log("Decoded Input: " . print_r($input, true));

if (!$input) {
    error_log("Input is empty or null");
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ - input rỗng']);
    exit();
}

// Route handling
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'get_contract_types':
            handleGetContractTypes($pdo);
            break;
        case 'get_payment_schedule':
            handleGetPaymentSchedule($pdo, $_GET);
            break;
        case 'update_payment_status':
            handleUpdatePaymentStatus($pdo);
            break;
        case 'add_payment':
            handleAddPayment($pdo);
            break;
        case 'get_contract_status':
            handleGetContractStatus($pdo, $_GET);
            break;
        case 'get_contract_details':
            handleGetContractDetails($pdo, $_GET);
            break;
        case 'get_contracts_list':
            handleGetContractsList($pdo, $_GET);
            break;
        case 'update_overdue_status':
            handleUpdateOverdueStatus($pdo);
            break;
        case 'get_deleted_contracts':
            handleGetDeletedContracts($pdo, $_GET);
            break;
        case 'restore_contract':
        if (isset($_GET['deleted_contract_id'])) {
            handleRestoreDeletedContract($pdo, (int)$_GET['deleted_contract_id']);
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Thiếu deleted_contract_id']);
        }
        break;
        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Action không tồn tại']);
    }
} else {
    // Xử lý dựa trên có ID hay không (tạo mới hoặc cập nhật)
    if (isset($input['id']) && $input['id'] > 0) {
        error_log("Calling handleUpdateContract with ID: " . $input['id']);
        handleUpdateContract($pdo, $input);
    } else {
        error_log("Calling handleCreateContract");
        handleCreateContract($pdo, $input);
    }
}


function handleGetContractDetails($pdo, $params) {
    if (!isset($params['contract_id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Thiếu contract_id']);
        return;
    }
    
    try {
        $contractId = (int)$params['contract_id'];
        
        $sql = "SELECT 
                    c.*,
                    ct.name as contract_type_name,
                    ct.interest_rate,
                    ct.penalty_rate,
                    DATE_FORMAT(c.from_date, '%d/%m/%Y') as formatted_from_date,
                    DATE_FORMAT(c.created_at, '%d/%m/%Y %H:%i') as formatted_created_at,
                    CASE 
                        WHEN c.loan_time >= 365 THEN CONCAT(FLOOR(c.loan_time/365), ' năm')
                        WHEN c.loan_time >= 30 THEN CONCAT(FLOOR(c.loan_time/30), ' tháng') 
                        ELSE CONCAT(c.loan_time, ' ngày')
                    END as time_range,
                    CASE 
                        WHEN c.frequency = 1 THEN 'ngày'
                        WHEN c.frequency = 7 THEN 'tuần'
                        WHEN c.frequency = 30 THEN 'tháng'
                        ELSE CONCAT(c.frequency, ' ngày')
                    END as period_text,
                    CEILING(c.loan_time / c.frequency) as total_periods,
                    COALESCE(paid_info.paid_periods, 0) as paid_periods,
                    COALESCE(paid_info.total_paid, 0) as paid_amount,
                    (c.total_money - COALESCE(paid_info.total_paid, 0)) as remaining_amount,
                    (CEILING(c.loan_time / c.frequency) - COALESCE(paid_info.paid_periods, 0)) as remaining_periods,
                    ROUND(c.total_money / CEILING(c.loan_time / c.frequency), 2) as money_per_period,
                    next_payment.next_payment_date,
                    next_payment.next_amount,
                    overdue_info.overdue_amount,
                    overdue_info.overdue_periods,
                    -- ✅ FIX: Lấy current_status trực tiếp từ bảng contracts
                    COALESCE(c.current_status, 'Đang vay') as current_status,
                    -- Tính lãi suất và tiền lãi
                    ROUND((c.total_money - c.total_money_received) * ct.interest_rate / 100, 2) as total_interest,
                    -- Tính số nợ (nếu có)
                    COALESCE(overdue_info.overdue_amount, 0) as debit_money,
                    0 as loan_debit
                FROM contracts c
                LEFT JOIN contract_types ct ON c.rate_type = ct.id
                LEFT JOIN (
                    SELECT 
                        contract_id,
                        COUNT(*) as paid_periods,
                        SUM(amount_paid) as total_paid
                    FROM payment_schedules 
                    WHERE status = 'paid'
                    GROUP BY contract_id
                ) paid_info ON c.id = paid_info.contract_id
                LEFT JOIN (
                    SELECT 
                        contract_id,
                        MIN(due_date) as next_payment_date,
                        MIN(amount_due) as next_amount
                    FROM payment_schedules 
                    WHERE status != 'paid'
                    GROUP BY contract_id
                ) next_payment ON c.id = next_payment.contract_id
                LEFT JOIN (
                    SELECT 
                        contract_id,
                        COUNT(*) as overdue_periods,
                        SUM(amount_due) as overdue_amount
                    FROM payment_schedules 
                    WHERE status = 'overdue' AND due_date < CURDATE()
                    GROUP BY contract_id
                ) overdue_info ON c.id = overdue_info.contract_id
                WHERE c.id = :contract_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':contract_id' => $contractId]);
        $contract = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$contract) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Hợp đồng không tồn tại']);
            return;
        }
        
        // Format số tiền
        $contract['total_money'] = (float)$contract['total_money'];
        $contract['total_money_received'] = (float)$contract['total_money_received'];
        $contract['paid_amount'] = (float)$contract['paid_amount'];
        $contract['remaining_amount'] = (float)$contract['remaining_amount'];
        $contract['total_interest'] = (float)$contract['total_interest'];
        $contract['debit_money'] = (float)$contract['debit_money'];
        $contract['loan_debit'] = (float)$contract['loan_debit'];
        
        echo json_encode([
            'success' => true,
            'data' => $contract,
            'message' => 'Lấy thông tin hợp đồng thành công'
        ]);
        
    } catch(Exception $e) {
        error_log("Error getting contract details: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()]);
    }
}
function handleCreateContract($pdo, $input) {
    error_log("=== CREATE CONTRACT ===");
    
    // Validate required fields
    $required_fields = ['userId', 'shopId', 'codeId', 'typeId', 'customerName', 'totalMoney', 'rateType', 'loanTime', 'frequency', 'fromDate'];
    
    $missing_fields = [];
    foreach ($required_fields as $field) {
        if (!isset($input[$field]) || $input[$field] === '') {
            $missing_fields[] = $field;
            error_log("Missing field: $field - Value: " . (isset($input[$field]) ? $input[$field] : 'NOT SET'));
        }
    }
    
    if (!empty($missing_fields)) {
        $error_msg = "Các trường bắt buộc bị thiếu: " . implode(', ', $missing_fields);
        error_log("Validation Error: " . $error_msg);
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $error_msg]);
        return;
    }
    
    // Validate business logic
    $validation_errors = validateBusinessLogic($input);
    if (!empty($validation_errors)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => implode('; ', $validation_errors)]);
        return;
    }
    
    try {
        // Bắt đầu transaction
        $pdo->beginTransaction();
        
        // 1. Kiểm tra contract type có tồn tại không
        $checkTypeStmt = $pdo->prepare("SELECT id, interest_rate, penalty_rate FROM contract_types WHERE id = :type_id AND is_active = 1");
        $checkTypeStmt->execute([':type_id' => (int)$input['rateType']]);
        $contractType = $checkTypeStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$contractType) {
            throw new Exception("Loại hợp đồng không tồn tại hoặc đã bị vô hiệu hóa");
        }
        
        // 2. Kiểm tra trung lập mã hợp đồng trong cùng shop
        $checkCodeStmt = $pdo->prepare("SELECT id FROM contracts WHERE code_id = :code_id AND shop_id = :shop_id");
        $checkCodeStmt->execute([
            ':code_id' => trim($input['codeId']),
            ':shop_id' => trim($input['shopId'])
        ]);
        
        if ($checkCodeStmt->fetch()) {
            throw new Exception("Mã hợp đồng đã tồn tại trong cửa hàng này");
        }
        
        // 3. Tạo hợp đồng
        $sql = "INSERT INTO contracts (
            user_id, shop_id, code_id, type_id, customer_id, customer_name, 
            customer_phone, customer_number_card, customer_address, customer_card_date, 
            customer_place, total_money, total_money_received, rate_type, loan_time, 
            frequency, from_date, is_before, note, staff_id, edit_loan
        ) VALUES (
            :user_id, :shop_id, :code_id, :type_id, :customer_id, :customer_name,
            :customer_phone, :customer_number_card, :customer_address, :customer_card_date,
            :customer_place, :total_money, :total_money_received, :rate_type, :loan_time,
            :frequency, :from_date, :is_before, :note, :staff_id, :edit_loan
        )";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':user_id' => $userId,
            ':shop_id' => $shopId,
            ':action' => $action,
            ':table_name' => $tableName,
            ':record_id' => $recordId,
            ':old_values' => $oldValues ? json_encode($oldValues) : null,
            ':new_values' => $newValues ? json_encode($newValues) : null,
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
        
        error_log("Logged system action: $action for $tableName ID: $recordId");
        
    } catch(Exception $e) {
        error_log("Error logging system action: " . $e->getMessage());
        // Không throw exception để không ảnh hưởng đến flow chính
    }
}

function validateBusinessLogic($data) {
    $errors = [];
    
    // Validate tiền
    if ($data['totalMoney'] <= 0) {
        $errors[] = "Tổng tiền trả góp phải lớn hơn 0";
    }
    
    if (isset($data['totalMoneyReceived']) && $data['totalMoneyReceived'] <= 0) {
        $errors[] = "Tiền đưa khách phải lớn hơn 0";
    }
    
    if (isset($data['totalMoneyReceived']) && $data['totalMoneyReceived'] >= $data['totalMoney']) {
        $errors[] = "Tiền đưa khách phải nhỏ hơn tổng tiền trả góp";
    }
    
    // Validate thời gian
    if ($data['loanTime'] <= 0) {
        $errors[] = "Thời gian bốc phải lớn hơn 0";
    }
    
    if ($data['frequency'] <= 0) {
        $errors[] = "Tần suất đóng tiền phải lớn hơn 0";
    }
    
    if ($data['frequency'] > $data['loanTime']) {
        $errors[] = "Tần suất đóng tiền không được lớn hơn thời gian vay";
    }
    
    // Validate ngày
    if (empty($data['fromDate'])) {
        $errors[] = "Ngày bốc không được để trống";
    } else {
        $fromDate = convertDateFormat($data['fromDate']);
        if (!$fromDate) {
            $errors[] = "Ngày bốc không đúng định dạng";
        } else {
            // Kiểm tra ngày không được trong quá khứ quá xa (trừ trường hợp đặc biệt)
            $dateCheck = new DateTime($fromDate);
            $today = new DateTime();
            $diff = $today->diff($dateCheck);
            
            if ($dateCheck < $today && $diff->days > 30) {
                $errors[] = "Ngày bốc không thể quá xa trong quá khứ (hơn 30 ngày)";
            }
        }
    }
    
    // Validate mã hợp đồng
    if (empty($data['codeId'])) {
        $errors[] = "Mã hợp đồng không được để trống";
    } else if (strlen($data['codeId']) < 3) {
        $errors[] = "Mã hợp đồng phải có ít nhất 3 ký tự";
    }
    
    // Validate tên khách hàng
    if (empty($data['customerName'])) {
        $errors[] = "Tên khách hàng không được để trống";
    } else if (strlen(trim($data['customerName'])) < 2) {
        $errors[] = "Tên khách hàng phải có ít nhất 2 ký tự";
    }
    
    // Validate số điện thoại nếu có
    if (!empty($data['customerPhone'])) {
        $phone = preg_replace('/[^0-9]/', '', $data['customerPhone']);
        if (strlen($phone) < 10 || strlen($phone) > 11) {
            $errors[] = "Số điện thoại không hợp lệ";
        }
    }
    
    // Validate CMND/CCCD nếu có
    if (!empty($data['customerNumberCard'])) {
        $card = preg_replace('/[^0-9]/', '', $data['customerNumberCard']);
        if (strlen($card) != 9 && strlen($card) != 12) {
            $errors[] = "Số CMND/CCCD không hợp lệ";
        }
    }
    
    return $errors;
}

function convertDateFormat($dateString) {
    if (empty($dateString)) {
        return null;
    }
    
    // Nếu đã đúng format YYYY-MM-DD thì giữ nguyên
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateString)) {
        return $dateString;
    }
    
    // Chuyển từ DD/MM/YYYY sang YYYY-MM-DD
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $dateString, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        // Validate date
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        } else {
            error_log("Invalid date: $dateString");
            return null;
        }
    }
    
    // Chuyển từ DD-MM-YYYY sang YYYY-MM-DD
    if (preg_match('/^(\d{1,2})-(\d{1,2})-(\d{4})$/', $dateString, $matches)) {
        $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $year = $matches[3];
        
        // Validate date
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        } else {
            error_log("Invalid date: $dateString");
            return null;
        }
    }
    
    // Chuyển từ YYYY/MM/DD sang YYYY-MM-DD
    if (preg_match('/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/', $dateString, $matches)) {
        $year = $matches[1];
        $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
        $day = str_pad($matches[3], 2, '0', STR_PAD_LEFT);
        
        if (checkdate($month, $day, $year)) {
            return "$year-$month-$day";
        }
    }
    
    error_log("Cannot convert date format: $dateString");
    return null;
}

function camelToSnake($camelCase) {
    return strtolower(preg_replace('/([a-z])([A-Z])/', '$1_$2', $camelCase));
}


function handleGetContractsList($pdo, $params) {
    error_log("=== RECEIVED PARAMETERS ===");
    error_log(print_r($params, true));
    
    try {
        $shopId = $params['shopId'] ?? null;
        $userId = $params['userId'] ?? null;
        $status = $params['status'] ?? 'all';
        $page = (int)($params['page'] ?? 1);
        $limit = (int)($params['limit'] ?? 2000);
        $offset = ($page - 1) * $limit;
        
        // Có thể JavaScript gửi 'contractId' thay vì 'contract_id'
        $contractId = $params['contract_id'] ?? $params['contractId'] ?? null;
        
        error_log("Contract ID from params: " . ($contractId ?? 'NULL'));
        
        $whereConditions = [];
        $queryParams = [];
        
        // CONTRACT_ID FILTER - Ưu tiên cao nhất
        if ($contractId) {
            $contractId = (int)$contractId;
            $whereConditions[] = "c.id = :contract_id";
            $queryParams[':contract_id'] = $contractId;
            
            error_log("Adding contract_id filter: " . $contractId);
            
            // Khi filter theo contract_id, chỉ lấy 1 record
            $limit = 1;
            $offset = 0;
        }
        
        if ($shopId) {
            $whereConditions[] = "c.shop_id COLLATE utf8mb4_unicode_ci = :shop_id";
            $queryParams[':shop_id'] = $shopId;
        }
        
        if ($userId) {
            $whereConditions[] = "c.user_id COLLATE utf8mb4_unicode_ci = :user_id";
            $queryParams[':user_id'] = $userId;
        }
        
        
        $whereClause = empty($whereConditions) ? '' : 'WHERE ' . implode(' AND ', $whereConditions);
        
        error_log("WHERE CLAUSE: " . $whereClause);
        error_log("QUERY PARAMS: " . print_r($queryParams, true));
        
        // Đếm tổng số record
        $countSql = "SELECT COUNT(*) as total FROM contracts c $whereClause";
        $countStmt = $pdo->prepare($countSql);
        $countStmt->execute($queryParams);
        $totalRecords = $countStmt->fetch()['total'];
        
        error_log("Total records found: " . $totalRecords);
        
        // Kiểm tra nếu filter theo contract_id mà không tìm thấy
        if ($contractId && $totalRecords == 0) {
            error_log("Contract ID $contractId not found");
            echo json_encode([
                'success' => false,
                'message' => "Không tìm thấy hợp đồng với ID: $contractId"
            ]);
            return;
        }
        
        // Main query
        $sql = "SELECT 
                    c.*,
                    ct.name as contract_type_name,
                    ct.interest_rate,
                    DATE_FORMAT(c.from_date, '%d/%m/%Y') as formatted_from_date,
                    CASE 
                        WHEN c.loan_time >= 365 THEN CONCAT(FLOOR(c.loan_time/365), ' năm')
                        WHEN c.loan_time >= 30 THEN CONCAT(FLOOR(c.loan_time/30), ' tháng') 
                        ELSE CONCAT(c.loan_time, ' ngày')
                    END as time_range,
                    CASE 
                        WHEN c.frequency = 1 THEN 'ngày'
                        WHEN c.frequency = 7 THEN 'tuần'
                        WHEN c.frequency = 30 THEN 'tháng'
                        ELSE 'kỳ'
                    END as period_text,
                    CEILING(c.loan_time / c.frequency) as total_periods,
                    COALESCE(paid_info.paid_periods, 0) as paid_periods,
                    COALESCE(paid_info.total_paid, 0) as paid_amount,
                    (c.total_money - COALESCE(paid_info.total_paid, 0)) as remaining_amount,
                    ROUND(c.total_money / CEILING(c.loan_time / c.frequency), 2) as money_per_period,
                    next_payment.next_payment_date,
                    next_payment.next_due_date,
                    -- ✅ FIX: Lấy current_status từ database thay vì hardcode
                    COALESCE(c.current_status, 'Đang vay') as current_status,
                    ROUND((c.total_money - c.total_money_received) * COALESCE(ct.interest_rate, 0) / 100, 2) as total_interest
                FROM contracts c
                LEFT JOIN contract_types ct ON c.rate_type = ct.id
                LEFT JOIN (
                    SELECT 
                        contract_id,
                        COUNT(*) as paid_periods,
                        SUM(amount_paid) as total_paid
                    FROM payment_schedules 
                    WHERE status = 'paid'
                    GROUP BY contract_id
                ) paid_info ON c.id = paid_info.contract_id
                LEFT JOIN (
                    SELECT 
                        contract_id,
                        MIN(from_date) as next_payment_date,
                        MIN(due_date) as next_due_date
                    FROM payment_schedules 
                    WHERE status != 'paid'
                    GROUP BY contract_id
                ) next_payment ON c.id = next_payment.contract_id
                $whereClause
                ORDER BY c.created_at DESC
                LIMIT :limit OFFSET :offset";
        
        $stmt = $pdo->prepare($sql);
        $queryParamsWithLimit = array_merge($queryParams, [':limit' => $limit, ':offset' => $offset]);
        
        error_log("Final query params: " . print_r($queryParamsWithLimit, true));
        
        $stmt->execute($queryParamsWithLimit);
        $contracts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("Contracts found: " . count($contracts));
        if (count($contracts) > 0) {
            error_log("Returned contract ID: " . $contracts[0]['id']);
            error_log("Expected contract ID: " . $contractId);
        }
        
        echo json_encode([
            'success' => true,
            'data' => $contracts,
            'pagination' => [
                'currentPage' => $page,
                'totalPages' => ceil($totalRecords / $limit),
                'totalRecords' => $totalRecords,
                'limit' => $limit
            ],
            'summary' => [
                'totalContracts' => $totalRecords,
                'totalMoneyGiven' => array_sum(array_column($contracts, 'total_money_received')),
                'totalCollected' => array_sum(array_column($contracts, 'paid_amount')),
                'totalRemaining' => array_sum(array_column($contracts, 'remaining_amount'))
            ]
        ]);
        
    } catch(Exception $e) {
        error_log("Error getting contracts list: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

function handleUpdateOverdueStatus($pdo) {
    try {
        $stmt = $pdo->prepare("CALL UpdateOverdueStatus()");
        $stmt->execute();
        
        // Lấy số record đã update
        $countStmt = $pdo->prepare("SELECT ROW_COUNT() as updated_count");
        $countStmt->execute();
        $result = $countStmt->fetch();
        
        echo json_encode([
            'success' => true,
            'message' => 'Cập nhật trạng thái quá hạn thành công',
            'updated_count' => $result['updated_count']
        ]);
        
    } catch(Exception $e) {
        error_log("Error updating overdue status: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}



// Hàm phụ trợ: Khôi phục hợp đồng đã xóa
function handleRestoreDeletedContract($pdo, $deletedContractId) {
    try {
        $pdo->beginTransaction();
        
        // Lấy thông tin hợp đồng đã xóa
        $stmt = $pdo->prepare("SELECT * FROM deleted_contracts WHERE id = :id");
        $stmt->execute([':id' => $deletedContractId]);
        $deletedContract = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$deletedContract) {
            throw new Exception("Không tìm thấy hợp đồng đã xóa");
        }
        
        // Kiểm tra xem mã hợp đồng có bị trùng không
        $checkCodeStmt = $pdo->prepare("SELECT id FROM contracts WHERE code_id = :code_id AND shop_id = :shop_id");
        $checkCodeStmt->execute([
            ':code_id' => $deletedContract['code_id'],
            ':shop_id' => $deletedContract['shop_id']
        ]);
        
        if ($checkCodeStmt->fetch()) {
            throw new Exception("Mã hợp đồng đã tồn tại, không thể khôi phục");
        }
        
        // Khôi phục hợp đồng
        $restoreStmt = $pdo->prepare("
            INSERT INTO contracts (
                user_id, shop_id, code_id, type_id, customer_id, customer_name,
                customer_phone, customer_number_card, customer_address, customer_card_date,
                customer_place, total_money, total_money_received, total_paid, rate_type,
                loan_time, frequency, from_date, is_before, note, staff_id, edit_loan,
                created_at, updated_at
            ) VALUES (
                :user_id, :shop_id, :code_id, :type_id, :customer_id, :customer_name,
                :customer_phone, :customer_number_card, :customer_address, :customer_card_date,
                :customer_place, :total_money, :total_money_received, :total_paid, :rate_type,
                :loan_time, :frequency, :from_date, :is_before, :note, :staff_id, :edit_loan,
                :original_created_at, NOW()
            )
        ");
        
        $restoreStmt->execute([
            ':user_id' => $deletedContract['user_id'],
            ':shop_id' => $deletedContract['shop_id'],
            ':code_id' => $deletedContract['code_id'],
            ':type_id' => $deletedContract['type_id'],
            ':customer_id' => $deletedContract['customer_id'],
            ':customer_name' => $deletedContract['customer_name'],
            ':customer_phone' => $deletedContract['customer_phone'],
            ':customer_number_card' => $deletedContract['customer_number_card'],
            ':customer_address' => $deletedContract['customer_address'],
            ':customer_card_date' => $deletedContract['customer_card_date'],
            ':customer_place' => $deletedContract['customer_place'],
            ':total_money' => $deletedContract['total_money'],
            ':total_money_received' => $deletedContract['total_money_received'],
            ':total_paid' => $deletedContract['total_paid'],
            ':rate_type' => $deletedContract['rate_type'],
            ':loan_time' => $deletedContract['loan_time'],
            ':frequency' => $deletedContract['frequency'],
            ':from_date' => $deletedContract['from_date'],
            ':is_before' => $deletedContract['is_before'],
            ':note' => $deletedContract['note'],
            ':staff_id' => $deletedContract['staff_id'],
            ':edit_loan' => $deletedContract['edit_loan'],
            ':original_created_at' => $deletedContract['original_created_at']
        ]);
        
        $restoredContractId = $pdo->lastInsertId();
        
        // Khôi phục payment schedules nếu có
        if (!empty($deletedContract['payment_schedules_data'])) {
            $schedules = json_decode($deletedContract['payment_schedules_data'], true);
            if ($schedules) {
                foreach ($schedules as $schedule) {
                    $insertScheduleStmt = $pdo->prepare("
                        INSERT INTO payment_schedules (
                            contract_id, period_number, due_date, amount_due, amount_paid, status, created_at
                        ) VALUES (
                            :contract_id, :period_number, :due_date, :amount_due, :amount_paid, :status, :created_at
                        )
                    ");
                    
                    $insertScheduleStmt->execute([
                        ':contract_id' => $restoredContractId,
                        ':period_number' => $schedule['period_number'],
                        ':due_date' => $schedule['due_date'],
                        ':amount_due' => $schedule['amount_due'],
                        ':amount_paid' => $schedule['amount_paid'],
                        ':status' => $schedule['status'],
                        ':created_at' => $schedule['created_at']
                    ]);
                }
            }
        }
        
        // Khôi phục payment transactions nếu có
        if (!empty($deletedContract['payment_transactions_data'])) {
            $transactions = json_decode($deletedContract['payment_transactions_data'], true);
            if ($transactions) {
                foreach ($transactions as $transaction) {
                    $insertTransStmt = $pdo->prepare("
                        INSERT INTO payment_transactions (
                            contract_id, schedule_id, amount_paid, payment_date, payment_method,
                            note, created_by, created_at
                        ) VALUES (
                            :contract_id, :schedule_id, :amount_paid, :payment_date, :payment_method,
                            :note, :created_by, :created_at
                        )
                    ");
                    
                    $insertTransStmt->execute([
                        ':contract_id' => $restoredContractId,
                        ':schedule_id' => $transaction['schedule_id'], // Cần map lại với schedule_id mới
                        ':amount_paid' => $transaction['amount_paid'],
                        ':payment_date' => $transaction['payment_date'],
                        ':payment_method' => $transaction['payment_method'],
                        ':note' => $transaction['note'],
                        ':created_by' => $transaction['created_by'],
                        ':created_at' => $transaction['created_at']
                    ]);
                }
            }
        }
        
        // Xóa khỏi bảng deleted_contracts
        $removeDeletedStmt = $pdo->prepare("DELETE FROM deleted_contracts WHERE id = :id");
        $removeDeletedStmt->execute([':id' => $deletedContractId]);
        
        // Log khôi phục
        $logRestoreStmt = $pdo->prepare("
            INSERT INTO deletion_logs (
                table_name, record_id, user_id, shop_id, deletion_reason, ip_address, user_agent
            ) VALUES (
                'contracts_restored', :record_id, :user_id, :shop_id, :deletion_reason, :ip_address, :user_agent
            )
        ");
        
        $logRestoreStmt->execute([
            ':record_id' => $restoredContractId,
            ':user_id' => $deletedContract['user_id'],
            ':shop_id' => $deletedContract['shop_id'],
            ':deletion_reason' => "Restored from deleted_contracts ID: $deletedContractId",
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Khôi phục hợp đồng thành công',
            'restored_contract_id' => $restoredContractId
        ]);
        
    } catch(Exception $e) {
        $pdo->rollback();
        error_log("Restore contract error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

// Hàm lấy danh sách hợp đồng đã xóa
function handleGetDeletedContracts($pdo, $params) {
    try {
        $shopId = $params['shopId'] ?? null;
        $userId = $params['userId'] ?? null;
        $page = (int)($params['page'] ?? 1);
        $limit = (int)($params['limit'] ?? 20);
        $offset = ($page - 1) * $limit;
        
        $whereConditions = [];
        $queryParams = [];
        
        if ($shopId) {
            $whereConditions[] = "shop_id = :shop_id";
            $queryParams[':shop_id'] = $shopId;
        }
        
        if ($userId) {
            $whereConditions[] = "user_id = :user_id";
            $queryParams[':user_id'] = $userId;
        }
        
        
        $whereClause = empty($whereConditions) ? '' : 'WHERE ' . implode(' AND ', $whereConditions);
        
        // Đếm tổng số record
        $countSql = "SELECT COUNT(*) as total FROM deleted_contracts $whereClause";
        $countStmt = $pdo->prepare($countSql);
        $countStmt->execute($queryParams);
        $totalRecords = $countStmt->fetch()['total'];
        
        // Lấy dữ liệu
        $sql = "SELECT 
                    id, original_contract_id, code_id, customer_name, customer_phone,
                    total_money, total_money_received, total_paid,
                    DATE_FORMAT(from_date, '%d/%m/%Y') as formatted_from_date,
                    DATE_FORMAT(original_created_at, '%d/%m/%Y %H:%i') as formatted_created_at,
                    DATE_FORMAT(deleted_at, '%d/%m/%Y %H:%i') as formatted_deleted_at,
                    deleted_by, deletion_reason,
                    (total_money - total_paid) as remaining_amount
                FROM deleted_contracts 
                $whereClause
                ORDER BY deleted_at DESC
                LIMIT :limit OFFSET :offset";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_merge($queryParams, [':limit' => $limit, ':offset' => $offset]));
        $deletedContracts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $deletedContracts,
            'pagination' => [
                'currentPage' => $page,
                'totalPages' => ceil($totalRecords / $limit),
                'totalRecords' => $totalRecords,
                'limit' => $limit
            ]
        ]);
        
    } catch(Exception $e) {
        error_log("Error getting deleted contracts: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

// Route cho DELETE request
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    if (isset($_GET['contract_id'])) {
        handleDeleteContract($pdo, (int)$_GET['contract_id']);
    } else {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Thiếu contract_id']);
    }
    exit();
}

?>