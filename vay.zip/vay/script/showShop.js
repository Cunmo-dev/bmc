// Shops Management JavaScript

// Global variables
let shopsData = [];
let isLoading = false;

// Initialize shops page
document.addEventListener('DOMContentLoaded', function () {
    console.log('Shops page loaded');
    loadShopsList();
});

// Load shops list from backend
async function loadShopsList() {
    if (isLoading) return;

    isLoading = true;
    showLoading(true);

    try {
        console.log('Loading shops list...');

        const result = await apiCall('get_shops.php?action=list', 'GET');

        if (result.success) {
            shopsData = result.data || [];
            console.log('Loaded shops:', shopsData);

            renderShopsTable(shopsData);
            updateShopsCount(shopsData.length);

            if (shopsData.length === 0) {
                showEmptyState();
            }
        } else {
            console.error('Failed to load shops:', result.message);
            showErrorMessage('Lỗi tải danh sách cửa hàng: ' + result.message);

            // Redirect to login if session expired
            if (result.redirect) {
                setTimeout(() => {
                    window.location.href = result.redirect;
                }, 2000);
            }
        }
    } catch (error) {
        console.error('Error loading shops:', error);
        showErrorMessage('Lỗi kết nối khi tải danh sách cửa hàng!');
    } finally {
        isLoading = false;
        showLoading(false);
    }
}

// Render shops table
function renderShopsTable(shops) {
    const tableBody = document.querySelector('.m-datatable__body');

    if (!tableBody) {
        console.error('Table body not found');
        return;
    }

    if (!shops || shops.length === 0) {
        tableBody.innerHTML = `
            <tr class="m-datatable__row">
                <td colspan="6" style="text-align: center; padding: 20px;">
                    <div class="m-portlet__empty">
                        <i class="la la-store" style="font-size: 48px; color: #ccc;"></i>
                        <p style="color: #999; margin-top: 10px;">Chưa có cửa hàng nào</p>
                        <button class="btn btn-primary" onclick="openCreateShopModal()">
                            <i class="la la-plus"></i> Tạo cửa hàng đầu tiên
                        </button>
                    </div>
                </td>
            </tr>
        `;
        return;
    }

    let html = '';

    shops.forEach((shop, index) => {
        html += `
            <tr data-row="${index}" class="m-datatable__row" style="height: auto;">
                <td data-field="RowID" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                    <span style="width: 40px;">${shop.row_id}</span>
                </td>
                
                <td data-field="Name" style="text-align:left" class="m-datatable__cell">
                    <span style="width: 220px;">
                        <a href="javascript:void(0)" onclick="editShop(${shop.id})" 
                           class="m-card-user__email m-link font-cusName font-weight-bold" 
                           title="Chỉnh sửa ${shop.name}">
                            ${escapeHtml(shop.name)}
                        </a>
                        ${shop.shop_id ? `<br><small class="text-muted">ID: ${shop.shop_id}</small>` : ''}
                    </span>
                </td>

                <td data-field="TotalMoney" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                    <span style="width: 140px;">${shop.total_money_formatted}</span>
                </td>
                
                <td data-field="CreatedDate" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                    <span style="width: 100px;">${shop.created_date}</span>
                </td>
                
                <td data-field="Status" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                    <span style="width: 110px;">
                        <span class="m-badge m-badge--${shop.status_class} m-badge--wide">
                            ${shop.status_text}
                        </span>
                    </span>
                </td>
                
                <td data-field="Actions" style="text-align:left" class="m-datatable__cell">
                    <span style="overflow: visible; width: 140px;">
                        
                        <button onclick="confirmDelete(${shop.id}, '${escapeJs(shop.name)}')"
                               class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill"
                               title="Xóa">
                            <i class="la la-trash"></i>
                        </button>
                    </span>
                </td>
            </tr>
        `;
    });

    tableBody.innerHTML = html;
}

// Update shops count display
function updateShopsCount(count) {
    const countElements = document.querySelectorAll('.shops-count');
    countElements.forEach(element => {
        element.textContent = count;
    });
}

// Show loading state
function showLoading(show) {
    const loadingElement = document.getElementById('shops-loading');
    if (loadingElement) {
        loadingElement.style.display = show ? 'block' : 'none';
    }

    // Disable refresh button during loading
    const refreshBtn = document.getElementById('refresh-shops');
    if (refreshBtn) {
        refreshBtn.disabled = show;
        if (show) {
            refreshBtn.innerHTML = '<i class="la la-spinner la-spin"></i> Đang tải...';
        } else {
            refreshBtn.innerHTML = '<i class="la la-refresh"></i> Làm mới';
        }
    }
}

// Show error message
function showErrorMessage(message) {
    // You can customize this based on your notification system
    if (typeof showMessage === 'function') {
        showMessage(message, 'error');
    } else {
        alert(message);
    }
}

// Show success message
function showSuccessMessage(message) {
    if (typeof showMessage === 'function') {
        showMessage(message, 'success');
    } else {
        alert(message);
    }
}

// Show empty state
function showEmptyState() {
    const tableContainer = document.querySelector('.m-datatable__table');
    if (tableContainer) {
        tableContainer.style.display = 'none';
    }

    const emptyState = document.getElementById('empty-state');
    if (emptyState) {
        emptyState.style.display = 'block';
    }
}

// Edit shop function
async function editShop(shopId) {
    try {
        console.log('Loading shop details for edit:', shopId);

        const result = await apiCall(`get_shops.php?action=get_detail&shop_id=${shopId}`, 'GET');

        if (result.success && result.data) {
            // Fill edit form with shop data
            populateEditForm(result.data);

            // Open edit modal/form
            openEditShopModal();
        } else {
            showErrorMessage('Lỗi tải thông tin cửa hàng: ' + result.message);
        }
    } catch (error) {
        console.error('Error loading shop details:', error);
        showErrorMessage('Lỗi kết nối khi tải thông tin cửa hàng!');
    }
}

// Populate edit form
function populateEditForm(shopData) {
    // Fill form fields
    const shopIdField = document.getElementById('shopId');
    const shopNameField = document.getElementById('shopName');
    const totalMoneyField = document.getElementById('totalMoney');
    const statusField = document.getElementById('status');
    const actionField = document.getElementById('action');

    if (shopIdField) shopIdField.value = shopData.id;
    if (shopNameField) shopNameField.value = shopData.shop_name;
    if (totalMoneyField) totalMoneyField.value = shopData.total_money;
    if (statusField) statusField.value = shopData.status;
    if (actionField) actionField.value = 'update';
}

// Open edit shop modal
function openEditShopModal() {
    // Customize based on your modal system
    const modal = document.getElementById('edit-shop-modal');
    if (modal) {
        modal.style.display = 'block';
    }
}

// Open create shop modal
function openCreateShopModal() {
    // Reset form for create
    const form = document.getElementById('shop-form');
    if (form) {
        form.reset();
    }

    const actionField = document.getElementById('action');
    if (actionField) actionField.value = 'create';

    const modal = document.getElementById('create-shop-modal');
    if (modal) {
        modal.style.display = 'block';
    }
}

// Change shop function (switch to another shop)
function changeShop(shopId, shopName) {
    sessionStorage.setItem('selected_shop_id', shopId);
    sessionStorage.setItem('selected_shop_name', shopName);
    updateMenuShopName(shopName);
    if (typeof showMessage === 'function') {
        showMessage(`Đã chọn cửa hàng: ${shopName}`, 'success');
    } else {
        alert(`Đã chọn cửa hàng: ${shopName}`);
    }

    closeAllSubmenus();
    if (isMobileView()) {
        closeMobileMenu();
    }

    document.dispatchEvent(new CustomEvent('shopSelected', {
        detail: { shopId: shopId, shopName: shopName }
    }));
}
function closeAllSubmenus() {
    const submenuItems = document.querySelectorAll('.m-menu__item--submenu');
    submenuItems.forEach(function (item) {
        item.classList.remove('m-menu__item--open');
        const submenu = item.querySelector('.m-menu__submenu');
        if (submenu) {
            if (isMobileView()) {
                submenu.style.display = 'none';
            } else {
                submenu.style.display = ''; // Reset về CSS
            }
        }
    });
}
function isMobileView() {
    return window.innerWidth <= 1024;
}
// Confirm delete shop
function confirmDelete(shopId, shopName) {
    // Tạo HTML modal
    const modalHTML = `
        <div class="swal2-container swal2-center swal2-fade swal2-shown" style="overflow-y: auto;">
            <div role="dialog" aria-modal="true" aria-labelledby="swal2-title" aria-describedby="swal2-content" 
                 class="swal2-popup swal2-modal swal2-show" tabindex="-1" aria-live="assertive" 
                 style="width: 400px; padding: 2.5rem; background: rgb(255, 255, 255); display: flex;">
                
                <ul class="swal2-progresssteps" style="display: none;"></ul>
                
                <div class="swal2-icon swal2-error" style="display: none;">
                    <span class="swal2-x-mark">
                        <span class="swal2-x-mark-line-left"></span>
                        <span class="swal2-x-mark-line-right"></span>
                    </span>
                </div>
                
                <div class="swal2-icon swal2-question" style="display: none;">?</div>
                
                <div class="swal2-icon swal2-warning" style="display: block;">!</div>
                
                <div class="swal2-icon swal2-info" style="display: none;">i</div>
                
                <div class="swal2-icon swal2-success" style="display: none;">
                    <div class="swal2-success-circular-line-left" style="background: rgb(255, 255, 255);"></div>
                    <span class="swal2-success-line-tip"></span> 
                    <span class="swal2-success-line-long"></span>
                    <div class="swal2-success-ring"></div> 
                    <div class="swal2-success-fix" style="background: rgb(255, 255, 255);"></div>
                    <div class="swal2-success-circular-line-right" style="background: rgb(255, 255, 255);"></div>
                </div>
                
                <img class="swal2-image" style="display: none;">
                
                <div class="swal2-contentwrapper">
                    <h2 class="swal2-title" id="swal2-title">
                        Bạn có chắc chắn xóa cửa hàng<br> 
                        <b class="text-danger">${shopName}</b> không. cửa hàng xóa vĩnh viễn và không thể khôi phục lại?
                    </h2>
                    <div id="swal2-content" class="swal2-content" style="display: block;">
                        Bạn sẽ không thể khôi phục cửa hàng này nữa!
                    </div>
                </div>
                
                <input class="swal2-input" style="display: none;">
                <input type="file" class="swal2-file" style="display: none;">
                <div class="swal2-range" style="display: none;">
                    <output></output>
                    <input type="range">
                </div>
                <select class="swal2-select" style="display: none;"></select>
                <div class="swal2-radio" style="display: none;"></div>
                <label for="swal2-checkbox" class="swal2-checkbox" style="display: none;">
                    <input type="checkbox">
                </label>
                <textarea class="swal2-textarea" style="display: none;"></textarea>
                <div class="swal2-validationerror" id="swal2-validationerror" style="display: none;"></div>
                
                <div class="swal2-buttonswrapper" style="display: flex;">
                    <button type="button" class="swal2-confirm btn btn-danger m-btn m-btn--pill m-btn--air m-btn--icon" aria-label="">
                        <span>
                            <i class="la la-check-circle"></i>
                            <span>Đồng ý xóa!</span>
                        </span>
                    </button>
                    <button type="button" class="swal2-cancel btn btn-secondary m-btn m-btn--pill m-btn--icon" aria-label="" style="display: inline-block;">
                        <span>
                            <i class="la la-minus-circle"></i>
                            <span>Nghĩ lại</span>
                        </span>
                    </button>
                </div>
                
                <button type="button" class="swal2-close" style="display: none;">×</button>
            </div>
        </div>
    `;

    // Thêm modal vào body
    const modalContainer = document.createElement('div');
    modalContainer.innerHTML = modalHTML;
    document.body.appendChild(modalContainer);

    // Lấy các nút
    const confirmBtn = modalContainer.querySelector('.swal2-confirm');
    const cancelBtn = modalContainer.querySelector('.swal2-cancel');
    const modalElement = modalContainer.querySelector('.swal2-container');

    // Xử lý sự kiện cho nút "Đồng ý xóa"
    confirmBtn.addEventListener('click', function () {
        // Xóa modal
        document.body.removeChild(modalContainer);
        // Gọi hàm deleteShop
        deleteShop(shopId, shopName);
    });

    // Xử lý sự kiện cho nút "Nghĩ lại"
    cancelBtn.addEventListener('click', function () {
        // Chỉ xóa modal
        document.body.removeChild(modalContainer);
    });

    // Xử lý sự kiện click bên ngoài modal để đóng
    modalElement.addEventListener('click', function (e) {
        if (e.target === modalElement) {
            document.body.removeChild(modalContainer);
        }
    });
}

// Delete shop
async function deleteShop(shopId, shopName) {
    try {
        console.log('Deleting shop:', shopId, shopName);

        // Show loading on delete button
        const deleteBtn = document.getElementById(`btnDeleteShop_${shopId}`);
        if (deleteBtn) {
            deleteBtn.disabled = true;
            deleteBtn.innerHTML = '<i class="la la-spinner la-spin"></i>';
        }

        const result = await apiCall(`get_shops.php?action=delete&shop_id=${shopId}`, 'GET');

        if (result.success) {
            showSuccessMessage(`Đã xóa cửa hàng "${shopName}" thành công!`);

            // Reload shops list
            loadShopsList();
        } else {
            showErrorMessage('Lỗi xóa cửa hàng: ' + result.message);

            // Re-enable delete button
            if (deleteBtn) {
                deleteBtn.disabled = false;
                deleteBtn.innerHTML = '<i class="la la-trash"></i>';
            }
        }
    } catch (error) {
        console.error('Error deleting shop:', error);
        showErrorMessage('Lỗi kết nối khi xóa cửa hàng!');

        // Re-enable delete button
        const deleteBtn = document.getElementById(`btnDeleteShop_${shopId}`);
        if (deleteBtn) {
            deleteBtn.disabled = false;
            deleteBtn.innerHTML = '<i class="la la-trash"></i>';
        }
    }
}

// Refresh shops list
function refreshShopsList() {
    console.log('Refreshing shops list...');
    loadShopsList();
}

// Utility functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function escapeJs(text) {
    return text.replace(/'/g, "\\'").replace(/"/g, '\\"');
}

// Export functions for global access
window.loadShopsList = loadShopsList;
window.refreshShopsList = refreshShopsList;
window.editShop = editShop;
window.changeShop = changeShop;
window.confirmDelete = confirmDelete;
window.deleteShop = deleteShop;
window.openCreateShopModal = openCreateShopModal;

