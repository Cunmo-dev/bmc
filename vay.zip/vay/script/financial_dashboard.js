// financial_dashboard.js - Script hiển thị dữ liệu tài chính - FIXED VERSION

/**
 * Format số tiền theo định dạng Việt Nam
 * @param {number} amount - Số tiền
 * @returns {string} - Số tiền đã format
 */
function formatCurrency(amount) {
    if (amount === null || amount === undefined) return '0';
    return new Intl.NumberFormat('vi-VN').format(Math.round(amount));
}

/**
 * Hiển thị loading state
 */
function showLoadingState() {
    const elements = [
        'lbl_LoanPawn_MoneyEndDate',
        'lbl_LoanPawn_MoneyInvestment',
        'lbl_LoanPawn_InterestExpected',
        'lbl_LoanPawn_InterestEarned'
    ];

    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Đang tải...';
            element.style.color = '#999';
        }
    });
}

/**
 * Hiển thị dữ liệu lên giao diện
 * @param {Object} data - Dữ liệu từ API
 */
function displayFinancialData(data) {
    // Quỹ tiền mặt
    const cashFundElement = document.getElementById('lbl_LoanPawn_MoneyEndDate');
    if (cashFundElement) {
        cashFundElement.textContent = formatCurrency(data.cash_fund);
        cashFundElement.style.color = data.cash_fund >= 0 ? '#28a745' : '#dc3545';
    }

    // Tiền cho vay
    const loanAmountElement = document.getElementById('lbl_LoanPawn_MoneyInvestment');
    if (loanAmountElement) {
        loanAmountElement.textContent = formatCurrency(data.loan_amount);
        loanAmountElement.style.color = '#007bff';
    }

    // Lãi dự kiến
    const expectedInterestElement = document.getElementById('lbl_LoanPawn_InterestExpected');
    if (expectedInterestElement) {
        expectedInterestElement.textContent = formatCurrency(data.expected_interest);
        expectedInterestElement.style.color = '#ffc107';
    }

    // Lãi đã thu - Sửa ID từ lbl_LoanPawn*InterestEarned thành lbl_LoanPawn_InterestEarned
    const earnedInterestElement = document.getElementById('lbl_LoanPawn_InterestEarned');
    if (earnedInterestElement) {
        earnedInterestElement.textContent = formatCurrency(data.earned_interest);
        earnedInterestElement.style.color = '#28a745';
    }

    // Log dữ liệu để debug (có thể tắt trong production)
    if (typeof console !== 'undefined' && console.log) {
        // console.log('Financial Dashboard Data:', {
        //     'Quỹ tiền mặt': formatCurrency(data.cash_fund),
        //     'Tiền cho vay': formatCurrency(data.loan_amount),
        //     'Lãi dự kiến': formatCurrency(data.expected_interest),
        //     'Lãi đã thu': formatCurrency(data.earned_interest),
        //     'Raw data': data.raw_data,
        //     'Additional info': data.additional_info
        // });
    }
}

/**
 * Hiển thị lỗi lên giao diện
 * @param {string} message - Thông báo lỗi
 */
function displayError(message) {
    const elements = [
        'lbl_LoanPawn_MoneyEndDate',
        'lbl_LoanPawn_MoneyInvestment',
        'lbl_LoanPawn_InterestExpected',
        'lbl_LoanPawn_InterestEarned'
    ];

    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = '<i class="fa fa-exclamation-triangle"></i> Lỗi';
            element.style.color = '#dc3545';
        }
    });

    // Hiển thị thông báo lỗi nếu có hàm alert hoặc notification
    if (typeof toastr !== 'undefined') {
        toastr.error(message, 'Lỗi tải dữ liệu');
    } else if (typeof alert !== 'undefined') {
        alert('Lỗi tải dữ liệu: ' + message);
    }

    console.error('Financial Dashboard Error:', message);
}

/**
 * Lấy user ID theo cách thức giống display_contracts.js
 */
async function getUserId() {
    var userID = sessionStorage.getItem('user_id');

    if (!userID) return null;

    // Nếu là staff ID (bắt đầu bằng STF)
    if (String(userID).toUpperCase().startsWith('STF')) {
        sessionStorage.setItem('user_id_staff', userID);
        // Lấy owner_user_id thay vì staff user_id
        const ownerUserId = await getOwnerUserId(userID);
        return ownerUserId;
    }

    // Nếu là owner, trả về bình thường
    return userID;
}

/**
 * Hàm lấy user_id của owner từ staff_id thông qua API
 */
async function getOwnerUserId(staffId) {
    try {
        // Lấy API_BASE_URL từ global hoặc định nghĩa mặc định
        const apiBaseUrl = (typeof API_BASE_URL !== 'undefined') ? API_BASE_URL : './api/';

        const response = await fetch(apiBaseUrl + 'get_owner_from_staff.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'staff_id=' + encodeURIComponent(staffId)
        });

        const result = await response.json();

        if (result.success && result.owner_user_id) {
            return result.owner_user_id;
        } else {
            console.error('Lỗi lấy owner user_id từ staff_id:', result.message);
            return null;
        }
    } catch (error) {
        console.error('Lỗi kết nối API:', error);
        return null;
    }
}

/**
 * Lấy shop ID theo cách thức giống display_contracts.js
 */
function getShopId() {
    const selectedShopId = localStorage.getItem('selected_shop_id');
    const defaultShopId = localStorage.getItem('store_id');
    return selectedShopId || defaultShopId;
}

/**
 * Tải dữ liệu tài chính từ server - ĐÃ SỬA
 * @param {string} shopId - ID của shop (tùy chọn, lấy từ session nếu không có)
 */
async function loadFinancialData() {
    try {
        // Hiển thị loading state
        showLoadingState();

        // Lấy thông tin cần thiết
        const userId = await getUserId();
        const shopId = getShopId();

        if (!shopId) {
            throw new Error('Không tìm thấy thông tin shop. Vui lòng đăng nhập lại.');
        }

        // Tạo API URL
        const apiBaseUrl = (typeof API_BASE_URL !== 'undefined') ? API_BASE_URL : './api/';
        const url = `${apiBaseUrl}financial_dashboard.php`;

        // Tạo parameters
        const params = new URLSearchParams({
            shopId: shopId,
            userId: userId || '',
            timestamp: new Date().getTime() // Để tránh cache
        });

        // Gọi API bằng fetch
        const response = await fetch(`${url}?${params}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        // Kiểm tra response
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        // Xử lý kết quả
        if (data.success) {
            displayFinancialData(data.data);
            //console.log('Financial data loaded successfully:', data);
        } else {
            throw new Error(data.message || 'Không thể tải dữ liệu tài chính');
        }

    } catch (error) {
        //console.error('Error loading financial data:', error);
        displayError(error.message);
    }
}

/**
 * Hàm reload dữ liệu (được gọi từ nút Reload)
 */
function ReloadMoneyDataShop() {
    console.log('Reloading financial data...');
    loadFinancialData();
}

/**
 * Khởi tạo khi trang được tải
 */
function initFinancialDashboard() {
    //console.log('Initializing Financial Dashboard...');

    // Tải dữ liệu lần đầu
    loadFinancialData();

    // Thiết lập auto-refresh mỗi 5 phút (300000ms)
    // Có thể điều chỉnh hoặc tắt tùy theo nhu cầu
    setInterval(function () {
        console.log('Auto-refreshing financial data...');
        loadFinancialData();
    }, 300000); // 5 phút
}

// Tự động chạy khi DOM ready
document.addEventListener('DOMContentLoaded', function () {
    //console.log('DOM loaded, initializing financial dashboard...');
    initFinancialDashboard();
});

// Fallback cho jQuery nếu có
if (typeof $ !== 'undefined') {
    $(document).ready(function () {
        //console.log('jQuery ready, initializing financial dashboard...');
        initFinancialDashboard();
    });
}