/**
 * Daily Activities Dashboard JavaScript
 * Quản lý hiển thị lịch sử hoạt động hàng ngày
 */

class DailyActivitiesManager {
    constructor() {
        this.currentFilter = 'all';
        this.currentData = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setDefaultDates();
        this.loadShops();
        this.loadActivities();
    }

    setupEventListeners() {
        // Xử lý tab filter
        $('#activityTabs .nav-link').on('click', (e) => {
            e.preventDefault();
            const $tab = $(e.currentTarget);
            $('#activityTabs .nav-link').removeClass('active');
            $tab.addClass('active');
            this.currentFilter = $tab.data('filter');
            this.filterActivities();
        });

        // Xử lý nút lọc
        $('#btnFilter').on('click', () => {
            this.loadActivities();
        });

        // Xử lý nút reset
        $('#btnReset').on('click', () => {
            this.resetFilters();
        });

        // Auto refresh mỗi 30 giây
        setInterval(() => {
            this.loadActivities(false); // Silent refresh
        }, 30000);
    }

    setDefaultDates() {
        const today = new Date();
        const todayStr = today.toISOString().split('T')[0];
        $('#fromDate').val(todayStr);
        $('#toDate').val(todayStr);

        // Cập nhật hiển thị ngày hiện tại
        const options = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };
        $('#currentDate').html(
            `<i class="fa fa-calendar"></i> ${today.toLocaleDateString('vi-VN', options)}`
        );
    }

    async loadShops() {
        try {
            const response = await $.ajax({
                url: API_BASE_URL + 'get_daily_activities.php',
                method: 'POST',
                dataType: 'json',
                data: { action: 'get_shops' }
            });

            if (response.success) {
                const $shopFilter = $('#shopFilter');
                $shopFilter.empty().append('<option value="">Tất cả cửa hàng</option>');

                response.data.forEach(shop => {
                    $shopFilter.append(`<option value="${shop.shop_id}">${shop.shop_name}</option>`);
                });
            }
        } catch (error) {
            console.error('Lỗi khi tải danh sách cửa hàng:', error);
        }
    }

    async loadActivities(showLoading = true) {
        if (showLoading) {
            this.showLoading();
        }

        try {
            const data = {
                action: 'get_activities',
                from_date: $('#fromDate').val(),
                to_date: $('#toDate').val(),
                shop_id: $('#shopFilter').val()
            };

            const response = await $.ajax({
                url: API_BASE_URL + 'get_daily_activities.php',
                method: 'POST',
                dataType: 'json',
                data: data
            });

            if (response.success) {
                this.currentData = response.data;
                this.updateStats(response.stats);
                this.renderActivities(this.currentData);
            } else {
                this.showError(response.message || 'Có lỗi xảy ra khi tải dữ liệu');
            }
        } catch (error) {
            console.error('Lỗi khi tải hoạt động:', error);
            this.showError('Không thể kết nối đến server');
        }

        this.hideLoading();
    }

    updateStats(stats) {
        $('#totalContracts').text(this.formatNumber(stats.total_contracts || 0));
        $('#totalIncome').text(this.formatMoney(stats.total_income || 0));
        $('#totalExpense').text(this.formatMoney(stats.total_expense || 0));
        $('#totalActivities').text(this.formatNumber(stats.total_activities || 0));
    }

    renderActivities(activities) {
        const $timeline = $('#activityTimeline');

        if (!activities || activities.length === 0) {
            this.showNoData();
            return;
        }

        this.hideNoData();
        $timeline.empty();

        activities.forEach(activity => {
            const timelineItem = this.createTimelineItem(activity);
            $timeline.append(timelineItem);
        });
    }

    createTimelineItem(activity) {
        const typeClass = this.getActivityTypeClass(activity.activity_type);
        const icon = this.getActivityIcon(activity.activity_type);

        return $(`
            <div class="timeline-item" data-type="${activity.activity_type}">
                <div class="timeline-time">${this.formatTime(activity.created_at)}</div>
                <div class="timeline-title">
                    <span class="activity-type ${typeClass}">
                        <i class="fa ${icon}"></i> ${this.getActivityTypeName(activity.activity_type)}
                    </span>
                    ${activity.title}
                </div>
                <div class="timeline-desc">${activity.description}</div>
                ${activity.amount ? `<div class="timeline-amount"><strong>${this.formatMoney(activity.amount)}</strong></div>` : ''}
            </div>
        `);
    }

    getActivityTypeClass(type) {
        const typeMap = {
            'contract_create': 'type-contract',
            'contract_close': 'type-contract',
            'contract_delete': 'type-delete',
            'payment_receive': 'type-payment',
            'payment_cancel': 'type-delete',
            'expense_create': 'type-expense',
            'shop_create': 'type-shop',
            'staff_create': 'type-staff',
            'staff_update': 'type-staff'
        };
        return typeMap[type] || 'type-contract';
    }

    getActivityIcon(type) {
        const iconMap = {
            'contract_create': 'fa-file-text-o',
            'contract_close': 'fa-check-circle',
            'contract_delete': 'fa-trash',
            'payment_receive': 'fa-money',
            'payment_cancel': 'fa-ban',
            'expense_create': 'fa-minus-circle',
            'shop_create': 'fa-store',
            'staff_create': 'fa-user-plus',
            'staff_update': 'fa-user-edit'
        };
        return iconMap[type] || 'fa-circle';
    }

    getActivityTypeName(type) {
        const nameMap = {
            'contract_create': 'Hợp đồng',
            'contract_close': 'Hoàn thành',
            'contract_delete': 'Xóa HĐ',
            'payment_receive': 'Thu tiền',
            'payment_cancel': 'Hủy thanh toán',
            'expense_create': 'Chi tiêu',
            'shop_create': 'Cửa hàng',
            'staff_create': 'Nhân viên',
            'staff_update': 'Cập nhật NV'
        };
        return nameMap[type] || 'Hoạt động';
    }

    filterActivities() {
        let filteredData = this.currentData;

        if (this.currentFilter !== 'all') {
            filteredData = this.currentData.filter(activity => {
                return this.getFilterType(activity.activity_type) === this.currentFilter;
            });
        }

        this.renderActivities(filteredData);
    }

    getFilterType(activityType) {
        const filterMap = {
            'contract_create': 'contract',
            'contract_close': 'contract',
            'contract_delete': 'contract',
            'payment_receive': 'payment',
            'payment_cancel': 'payment',
            'expense_create': 'expense',
            'shop_create': 'shop',
            'staff_create': 'staff',
            'staff_update': 'staff'
        };
        return filterMap[activityType] || 'contract';
    }

    resetFilters() {
        this.setDefaultDates();
        $('#shopFilter').val('');
        $('#activityTabs .nav-link').removeClass('active');
        $('#activityTabs .nav-link[data-filter="all"]').addClass('active');
        this.currentFilter = 'all';
        this.loadActivities();
    }

    showLoading() {
        $('#loadingSpinner').show();
        $('#noDataMessage').hide();
        $('#activityTimeline').hide();
    }

    hideLoading() {
        $('#loadingSpinner').hide();
        $('#activityTimeline').show();
    }

    showNoData() {
        $('#noDataMessage').show();
        $('#activityTimeline').hide();
    }

    hideNoData() {
        $('#noDataMessage').hide();
    }

    showError(message) {
        Swal.fire({
            icon: 'error',
            title: 'Lỗi',
            text: message,
            timer: 3000,
            showConfirmButton: false
        });
    }

    formatTime(datetime) {
        const date = new Date(datetime);
        return date.toLocaleTimeString('vi-VN', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    formatMoney(amount) {
        if (!amount) return '0đ';
        return new Intl.NumberFormat('vi-VN').format(amount) + 'đ';
    }

    formatNumber(number) {
        if (!number) return '0';
        return new Intl.NumberFormat('vi-VN').format(number);
    }
}

// Khởi tạo khi DOM ready
$(document).ready(() => {
    new DailyActivitiesManager();
});

// Thêm SweetAlert2 nếu chưa có
if (typeof Swal === 'undefined') {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.7.32/sweetalert2.all.min.js';
    document.head.appendChild(script);
}