$(document).ready(function () {
    addValidationStyles();
    setTimeout(async function () {
        await initializeComponents();
        bindEvents();
    }, 500);
});

// Sửa hàm initializeComponents()
async function initializeComponents() {
    initializeCustomSelects();
    initializeDatePicker();
    initializeCustomerInput();
    formatMoneyInputs();
    setDefaultValues();
    loadStaffList();
    await loadNextContractCode(); // Thêm await
    // Kiểm tra lại sau khi load xong
    setTimeout(function () {
        if (!$('#txtCodeID').val().trim()) {
            console.warn('Contract code still empty, retrying...');
            loadNextContractCode();
        }
    }, 1000);
}
function initializeCustomerInput() {
    // Chỉ xử lý input thông thường, không có search
    $('#txtCustomer').on('input', function () {
        // Clear customer ID vì đây là khách hàng mới
        $('#hfCustomer').val('0');
        clearFieldError('#txtCustomer');
    });
}
// ================== CUSTOM SELECTS ==================
function initializeCustomSelects() {
    initializeRateTypeSelect();
    initializeStaffSelect();

    $(document).on('click', function (e) {
        if (!$(e.target).closest('.custom-select-wrapper').length) {
            $('.custom-select-dropdown').hide();
            $('.custom-select-display').removeClass('active');
        }
    });
}

function initializeRateTypeSelect() {
    $('#ratetype-display').on('click', function (e) {
        e.stopPropagation();
        $('.custom-select-dropdown').not('#ratetype-dropdown').hide();
        $('.custom-select-display').not(this).removeClass('active');

        $('#ratetype-dropdown').toggle();
        $(this).toggleClass('active');
    });

    $('#ratetype-dropdown').on('click', '.custom-select-option', function () {
        var value = $(this).data('value');
        var text = $(this).text();

        $('#ratetype-selected').text(text);
        $('#m-select-ratetype_create').val(value);
        $('#ratetype-dropdown').hide();
        $('#ratetype-display').removeClass('active');

        updateRateTypeUI(value);
        calculateInstallment();
        clearFieldError('#ratetype-display');
    });
}

function initializeStaffSelect() {
    $('#staff-display').on('click', function (e) {
        e.stopPropagation();
        $('.custom-select-dropdown').not('#staff-dropdown').hide();
        $('.custom-select-display').not(this).removeClass('active');

        $('#staff-dropdown').toggle();
        $(this).toggleClass('active');
    });

    $('#staff-dropdown').on('click', '.custom-select-option', function () {
        var value = $(this).data('value');
        var text = $(this).text();

        $('#staff-selected').text(text);
        $('#m-select-staff').val(value);
        $('#staff-dropdown').hide();
        $('#staff-display').removeClass('active');
        clearFieldError('#staff-display');
    });
}

function loadStaffList() {
    $.ajax({
        url: API_BASE_URL + 'get_staff_list.php',
        method: 'GET',
        dataType: 'json', // Đảm bảo jQuery parse JSON
        success: function (response) {
            var html = '';

            // Kiểm tra response format từ PHP
            if (response && response.success) {
                var data = response.data || [];

                if (data.length > 0) {
                    // Thêm search box nếu có nhiều hơn 5 nhân viên
                    if (data.length > 5) {
                        html += '<div class="custom-select-search"><input type="text" placeholder="Tìm nhân viên..." id="staff-search"></div>';
                    }

                    // Tạo options cho từng nhân viên
                    data.forEach(function (staff) {
                        html += '<div class="custom-select-option" data-value="' + staff.id + '" style="padding: 8px 12px; cursor: pointer; border-bottom: 1px solid #eee;">' +
                            staff.full_name + ' (<b>' + staff.username + '</b>)' +
                            '<span style="color: #666; font-size: 0.9em;"></span></div>';
                    });
                    $('#staff-dropdown').html(html);

                    // Thêm search functionality nếu có search box
                    $('#staff-search').on('input', function () {
                        var searchTerm = $(this).val().toLowerCase();
                        $('#staff-dropdown .custom-select-option').each(function () {
                            var text = $(this).text().toLowerCase();
                            $(this).toggle(text.includes(searchTerm));
                        });
                    });

                    // Tự động chọn user hiện tại từ danh sách (nếu có)
                    autoSelectCurrentUserFromList(data);
                } else {
                    $('#staff-dropdown').html('');
                    selectCurrentUser();
                }
            } else {
                // Xử lý trường hợp response không thành công
                var errorMessage = response && response.message ? response.message : 'Lỗi không xác định';
                html = '<div style="padding: 8px 12px; color: #dc3545;">' + errorMessage + '</div>';

                // Kiểm tra redirect (trường hợp chưa đăng nhập)
                if (response && response.redirect) {
                    window.location.href = response.redirect;
                    return;
                }
            }

            $('#staff-dropdown').html(html);

            // Thêm search functionality nếu có search box
            $('#staff-search').on('input', function () {
                var searchTerm = $(this).val().toLowerCase();
                $('#staff-dropdown .custom-select-option').each(function () {
                    var text = $(this).text().toLowerCase();
                    $(this).toggle(text.includes(searchTerm));
                });
            });

            // Auto select current user nếu có trong danh sách
            // Uncomment nếu cần
            // var currentUserId = getUserId();
            // if (response && response.success && response.data) {
            //     var currentStaff = response.data.find(function (staff) { 
            //         return staff.user_id == currentUserId; 
            //     });
            //     if (currentStaff) {
            //         $('#staff-selected').text(currentStaff.full_name);
            //         $('#m-select-staff').val(currentStaff.id);
            //     }
            // }
        },
        error: function (xhr, status, error) {
            console.error('AJAX Error:', error);
            console.error('Status:', status);
            console.error('Response:', xhr.responseText);

            $('#staff-dropdown').html('<div style="padding: 8px 12px; color: #dc3545;">Lỗi tải danh sách nhân viên</div>');
        }
    });
}
// Thêm vào phần JavaScript (sau function loadStaffList())
// Thay thế hàm loadNextContractCode() cũ bằng version này:
async function loadNextContractCode() {
    try {
        var userId = await getUserId1();
        var shopId = getShopId();

        console.log('Loading contract code with userId:', userId, 'shopId:', shopId);

        if (!userId || !shopId) {
            console.error('Missing userId or shopId:', { userId, shopId });
            $('#txtCodeID').val('1');
            return;
        }

        $.ajax({
            url: API_BASE_URL + 'get_next_contract_code.php',
            method: 'GET',
            data: {
                userId: userId,
                shopId: shopId
            },
            dataType: 'json',
            success: function (response) {
                //console.log('Contract code response:', response);
                if (response && response.success) {
                    $('#txtCodeID').val(response.next_code);
                    //console.log('Auto-generated contract code:', response.next_code);
                } else {
                    console.error('Error getting next contract code:', response.message);
                    $('#txtCodeID').val('1');
                }
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error getting contract code:', error);
                console.error('Response:', xhr.responseText);
                $('#txtCodeID').val('1');
            }
        });

    } catch (error) {
        console.error('Error in loadNextContractCode:', error);
        $('#txtCodeID').val('1');
    }
}
// Hàm mới để tự động chọn user hiện tại từ danh sách nhân viên
function autoSelectCurrentUserFromList(staffList) {
    var userId = localStorage.getItem('user_id');
    var username = localStorage.getItem('username');

    if (!userId || !username) {
        // Fallback sang selectCurrentUser nếu không có thông tin user
        selectCurrentUser();
        return;
    }

    // Tìm user hiện tại trong danh sách
    var currentStaff = staffList.find(function (staff) {
        return staff.user_id == userId || staff.username === username;
    });

    if (currentStaff) {
        // Tìm thấy user trong danh sách - chọn từ danh sách
        $('#staff-selected').text(currentStaff.full_name + ' (' + currentStaff.username + ')');
        $('#m-select-staff').val(currentStaff.id);

        console.log('Auto-selected from staff list:', currentStaff.full_name, 'ID:', currentStaff.id);
    } else {
        // Không tìm thấy trong danh sách - fallback sang selectCurrentUser
        selectCurrentUser();
    }
}
// Hàm mới để tự động chọn user hiện tại từ sessionStorage
function selectCurrentUser() {
    // Lấy thông tin user hiện tại từ sessionStorage
    var userId = localStorage.getItem('user_id');
    var username = localStorage.getItem('username');
    var userEmail = localStorage.getItem('user_email');

    if (userId && username) {
        // Cập nhật UI để hiển thị user hiện tại đã được chọn
        $('#staff-selected').text(username);
        $('#m-select-staff').val(userId);

        // Thêm thông báo cho user biết đã tự động chọn
        var notification = '<div style="padding: 8px 12px; color: #28a745; background-color: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-top: 5px;">' +
            'Đã tự động chọn: <b>' + username + '</b>' +
            (userEmail ? ' (' + userEmail + ')' : '') +
            '</div>';
        $('#staff-dropdown').append(notification);

        //console.log('Auto-selected current user:', username, 'ID:', userId);
    } else {
        console.warn('Không tìm thấy thông tin user trong sessionStorage');

        // Hiển thị thông báo lỗi
        var errorNotification = '<div style="padding: 8px 12px; color: #dc3545; background-color: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-top: 5px;">' +
            'Không thể tự động chọn user hiện tại</div>';
        $('#staff-dropdown').append(errorNotification);
    }
}
function updateRateTypeUI(value) {
    if (value == '0') {
        $('#lbl_loantime_icon').html('<i class="text-black">Ngày</i>');
        $('#lbl_frenquency_create').text('Số ngày đóng tiền');
        $('#lbl_introduce_installment').text('(VD : 3 ngày đóng 1 lần thì điền số 3 )');
        $('#lbl_money_perday').text('/ 1 Kỳ');
    } else if (value == '6') {
        $('#lbl_loantime_icon').html('<i class="text-black">Tháng</i>');
        $('#lbl_frenquency_create').text('Số tháng đóng tiền');
        $('#lbl_introduce_installment').text('(VD : 2 tháng đóng 1 lần thì điền số 2 )');
        $('#lbl_money_perday').text('/ 1 tháng');
    }
}

// ================== SIMPLE DATEPICKER ==================
function initializeDatePicker() {
    $('#txtStrFromDate').addClass('m_datepicker').prop('readonly', true);

    // Unbind trước khi bind để tránh trùng lặp
    $('#txtStrFromDate, #txtStrFromDate').parent().find('.input-group-addon').off('click.datepicker');

    $('#txtStrFromDate, #txtStrFromDate').parent().find('.input-group-addon').on('click.datepicker', function (e) {
        e.preventDefault();
        e.stopPropagation(); // Ngăn event bubbling
        showSimpleDatePicker($('#txtStrFromDate'));
    });
}

function showSimpleDatePicker($input) {
    $('.simple-datepicker').remove();

    var today = new Date();
    var currentMonth = today.getMonth();
    var currentYear = today.getFullYear();

    var datepickerHtml = `
        <div class="simple-datepicker" style="position: absolute; background: white; border: 1px solid #ddd; 
             border-radius: 4px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); z-index: 9999; padding: 10px; min-width: 280px;">
            <div class="datepicker-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <button type="button" class="btn-prev" style="border: none; background: #f8f9fa; padding: 5px 10px; border-radius: 3px; cursor: pointer;">‹</button>
                <span class="current-month-year" style="font-weight: bold;">Tháng ${currentMonth + 1} ${currentYear}</span>
                <button type="button" class="btn-next" style="border: none; background: #f8f9fa; padding: 5px 10px; border-radius: 3px; cursor: pointer;">›</button>
            </div>
            <div class="datepicker-calendar"></div>
            <div class="datepicker-footer" style="margin-top: 10px; text-align: center;">
                <button type="button" class="btn-today" style="border: none; background: #007bff; color: white; padding: 5px 15px; border-radius: 3px; cursor: pointer; margin-right: 5px;">Hôm nay</button>
                <button type="button" class="btn-clear" style="border: none; background: #6c757d; color: white; padding: 5px 15px; border-radius: 3px; cursor: pointer;">Xóa</button>
            </div>
        </div>
    `;

    $('body').append(datepickerHtml);
    var $datepicker = $('.simple-datepicker');

    var offset = $input.offset();
    $datepicker.css({
        'top': offset.top + $input.outerHeight() + 5,
        'left': offset.left
    });

    generateCalendar($datepicker, currentYear, currentMonth);
    bindDatePickerEvents($datepicker, $input);
}

function generateCalendar($datepicker, year, month) {
    var firstDay = new Date(year, month, 1);
    var lastDay = new Date(year, month + 1, 0);
    var daysInMonth = lastDay.getDate();
    var startDay = firstDay.getDay();

    var html = '<table style="width: 100%; border-collapse: collapse;">';
    html += '<tr>';
    ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'].forEach(function (day) {
        html += `<th style="padding: 8px 4px; text-align: center; font-size: 12px; color: #666;">${day}</th>`;
    });
    html += '</tr>';

    var day = 1;
    var today = new Date();

    for (var week = 0; week < 6; week++) {
        html += '<tr>';
        for (var dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
            if (week === 0 && dayOfWeek < startDay) {
                html += '<td style="padding: 8px 4px; text-align: center;"></td>';
            } else if (day <= daysInMonth) {
                var isToday = (day === today.getDate() && month === today.getMonth() && year === today.getFullYear());
                var todayClass = isToday ? 'background: #007bff; color: white;' : 'background: #f8f9fa;';
                html += `<td class="calendar-day" data-day="${day}" data-month="${month}" data-year="${year}" 
                         style="padding: 8px 4px; text-align: center; cursor: pointer; border-radius: 3px; ${todayClass}">${day}</td>`;
                day++;
            } else {
                html += '<td style="padding: 8px 4px; text-align: center;"></td>';
            }
        }
        html += '</tr>';
        if (day > daysInMonth) break;
    }
    html += '</table>';

    $datepicker.find('.datepicker-calendar').html(html);
    $datepicker.find('.current-month-year').text(`Tháng ${month + 1} ${year}`);
}

function bindDatePickerEvents($datepicker, $input) {
    $datepicker.on('click', '.calendar-day', function () {
        var day = $(this).data('day');
        var month = $(this).data('month');
        var year = $(this).data('year');

        var formattedDate = String(day).padStart(2, '0') + '/' +
            String(month + 1).padStart(2, '0') + '/' + year;

        $input.val(formattedDate);
        $('.simple-datepicker').remove();
        clearFieldError($input);
    });

    $datepicker.on('click', '.btn-today', function () {
        var today = new Date();
        var formattedDate = String(today.getDate()).padStart(2, '0') + '/' +
            String(today.getMonth() + 1).padStart(2, '0') + '/' + today.getFullYear();
        $input.val(formattedDate);
        $('.simple-datepicker').remove();
        clearFieldError($input);
    });

    $datepicker.on('click', '.btn-clear', function () {
        $input.val('');
        $('.simple-datepicker').remove();
        clearFieldError($input);
    });

    $datepicker.on('click', '.btn-prev', function () {
        var currentText = $datepicker.find('.current-month-year').text();
        var parts = currentText.split(' ');
        var month = parseInt(parts[1]) - 1;
        var year = parseInt(parts[2]);

        if (month < 1) {
            month = 12;
            year--;
        }

        generateCalendar($datepicker, year, month - 1);
    });

    $datepicker.on('click', '.btn-next', function () {
        var currentText = $datepicker.find('.current-month-year').text();
        var parts = currentText.split(' ');
        var month = parseInt(parts[1]) - 1;
        var year = parseInt(parts[2]);

        if (month > 10) {
            month = -1;
            year++;
        }

        generateCalendar($datepicker, year, month + 1);
    });

    $(document).on('click', function (e) {
        if (!$(e.target).closest('.simple-datepicker, .m_datepicker, .input-group-addon').length) {
            $('.simple-datepicker').remove();
        }
    });
}

// ================== CUSTOMER SEARCH ==================
function initializeCustomerTypeahead() {
    if (typeof $.fn.typeahead === 'undefined') {
        initializeFallbackAutocomplete();
        return;
    }

    $('#txtCustomer').typeahead({
        hint: true,
        highlight: true,
        minLength: 2
    }, {
        name: 'customers',
        source: function (query, syncResults, asyncResults) {
            $.ajax({
                url: '/api/customers/search',
                method: 'GET',
                data: {
                    q: query,
                    userId: getUserId(),
                    shopId: getShopId()
                },
                success: function (data) {
                    asyncResults(data);
                }
            });
        },
        display: 'name',
        templates: {
            suggestion: function (data) {
                return '<div><strong>' + data.name + '</strong><br><small>' + data.phone + '</small></div>';
            }
        }
    }).on('typeahead:select', function (e, customer) {
        selectCustomer(customer);
    });
}

function initializeFallbackAutocomplete() {
    var searchTimeout;
    var currentCustomers = [];

    if ($('#customer-dropdown').length === 0) {
        var dropdown = $('<div id="customer-dropdown" style="display: none; position: absolute; background: white; border: 1px solid #ccc; max-height: 200px; overflow-y: auto; z-index: 1000; width: 100%;"></div>');
        $('#txtCustomer').parent().css('position', 'relative').append(dropdown);
    }

    $('#txtCustomer').on('input', function () {
        var query = $(this).val();
        var $dropdown = $('#customer-dropdown');

        if (query.length < 2) {
            $dropdown.hide();
            return;
        }

        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(function () {
            $.ajax({
                url: '/api/customers/search',
                method: 'GET',
                data: {
                    q: query,
                    userId: getUserId(),
                    shopId: getShopId()
                },
                success: function (data) {
                    currentCustomers = data;
                    var html = '';

                    if (data && data.length > 0) {
                        data.forEach(function (customer) {
                            html += '<div class="customer-option" data-index="' + data.indexOf(customer) + '" style="padding: 8px 12px; cursor: pointer; border-bottom: 1px solid #eee;">' +
                                '<strong>' + customer.name + '</strong><br>' +
                                '<small>' + customer.phone + '</small>' +
                                '</div>';
                        });
                    } else {
                        html = '<div style="padding: 8px 12px; color: #999;">Không tìm thấy khách hàng</div>';
                    }

                    $dropdown.html(html).show();
                },
                error: function () {
                    $dropdown.html('<div style="padding: 8px 12px; color: #dc3545;">Lỗi tìm kiếm</div>').show();
                }
            });
        }, 300);
    });

    $(document).on('click', '#customer-dropdown .customer-option', function () {
        var index = $(this).data('index');
        var customer = currentCustomers[index];
        if (customer) {
            $('#txtCustomer').val(customer.name);
            selectCustomer(customer);
            $('#customer-dropdown').hide();
        }
    });

    $(document).on('click', function (e) {
        if (!$(e.target).closest('#txtCustomer, #customer-dropdown').length) {
            $('#customer-dropdown').hide();
        }
    });

    $('#txtCustomer').on('keydown', function (e) {
        if (e.keyCode === 27) {
            $('#customer-dropdown').hide();
        }
    });
}

function selectCustomer(customer) {
    $('#hfCustomer').val(customer.id);
    $('#hfCustomerName').val(customer.name);
    $('#hfCustomerPhone').val(customer.phone);
    $('#hfCustomerNumberCard').val(customer.numberCard);
    $('#hfCustomerAddress').val(customer.address);
    $('#hfCustomerCardDate').val(customer.cardDate);
    $('#hfCustomerPlace').val(customer.place);

    $('#customername-container').html(
        '<div class="customer-info">' +
        '<strong>' + customer.name + '</strong><br>' +
        '<small>SĐT: ' + customer.phone + '</small><br>' +
        '<small>CMND: ' + customer.numberCard + '</small>' +
        '</div>'
    );

    $('#btnCustomer').html(
        '<button type="button" class="btn btn-sm btn-secondary" onclick="clearCustomer()">' +
        '<i class="fa fa-times"></i> Thay đổi' +
        '</button>'
    );

    clearFieldError('#txtCustomer');
}

function clearCustomer() {
    $('#txtCustomer').val('');
    $('#hfCustomer').val('0');
    $('#hfCustomerName, #hfCustomerPhone, #hfCustomerNumberCard, #hfCustomerAddress, #hfCustomerCardDate, #hfCustomerPlace').val('');
    $('#customername-container, #btnCustomer').empty();
    $('#txtCustomer').focus();
}

// ================== EVENT BINDING ==================
function bindEvents() {
    $('#txtTotalMoney, #txtTotalMoneyReceived, #txtLoanTime, #txtFrequency').on('input', function () {
        calculateInstallment();
        clearFieldError(this);
    });

    $('#txtTotalMoney, #txtTotalMoneyReceived').on('input', function () {
        formatMoney(this);
    });

    $('#txtCodeID, #txtLoanTime, #txtFrequency').on('input', function () {
        this.value = this.value.replace(/[^0-9]/g, '');
        clearFieldError(this);
    });

    $('#txtCodeID').on('input', function () {
        clearFieldError(this);
    });

    $('#btnSaveInstallment').on('click', async function () {
        await saveContract();
    });

    $('#btnCloseModalPawn, [data-dismiss="modal"]').on('click', async function () {
        await resetForm();
    });
}

// ================== CALCULATIONS ==================
function calculateInstallment() {
    var totalMoney = parseFloat($('#txtTotalMoney').val().replace(/[^\d]/g, '')) || 0;
    var totalMoneyReceived = parseFloat($('#txtTotalMoneyReceived').val().replace(/[^\d]/g, '')) || 0;
    var loanTime = parseFloat($('#txtLoanTime').val()) || 0;
    var frequency = parseFloat($('#txtFrequency').val()) || 1;

    if (totalMoney > 0 && loanTime > 0) {
        var profit = totalMoney - totalMoneyReceived;
        var installmentCount = Math.ceil(loanTime / frequency);
        var moneyPerPeriod = installmentCount > 0 ? Math.round(totalMoney / installmentCount) : 0;
        console.log('số tiền 1 kỳ: ' + formatNumber(moneyPerPeriod));
        $('#strMoneyOfLoanTime').text(formatNumber(moneyPerPeriod));

        if (profit < 0) {
            showFieldError('#txtTotalMoneyReceived', 'Tiền đưa khách không được lớn hơn tổng tiền trả góp');
        } else {
            clearFieldError('#txtTotalMoneyReceived');
        }
    } else {
        $('#strMoneyOfLoanTime').text('0');
    }
}

// ================== VALIDATION SYSTEM ==================
function showFieldError(fieldSelector, message) {
    var $field = $(fieldSelector);

    clearFieldError(fieldSelector);
    $field.addClass('is-invalid');

    var $errorDiv = $('<div class="invalid-feedback" style="display: block; width: 100%; margin-top: 0.25rem; font-size: 0.875em; color: #dc3545;">' + message + '</div>');

    if ($field.parent().hasClass('input-group')) {
        $field.parent().after($errorDiv);
    } else if ($field.hasClass('custom-select-display')) {
        $field.closest('.custom-select-wrapper').after($errorDiv);
    } else {
        $field.after($errorDiv);
    }
}

function clearFieldError(fieldSelector) {
    var $field = $(fieldSelector);
    $field.removeClass('is-invalid');

    if ($field.parent().hasClass('input-group')) {
        $field.parent().next('.invalid-feedback').remove();
    } else if ($field.hasClass('custom-select-display')) {
        $field.closest('.custom-select-wrapper').next('.invalid-feedback').remove();
    } else {
        $field.next('.invalid-feedback').remove();
    }
}
// Hàm kiểm tra mã hợp đồng có trùng lặp không

// Hàm kiểm tra mã hợp đồng có trùng lặp không
function validateContractCodeUnique() {
    return new Promise((resolve) => {
        var codeId = $('#txtCodeID').val().trim();
        var currentContractId = $('#hfId').val() || 0;

        console.log('=== VALIDATE CONTRACT CODE ===');
        console.log('Code ID:', codeId);
        console.log('Current Contract ID:', currentContractId);

        if (!codeId) {
            console.log('Code ID is empty, skipping validation');
            resolve(true); // Mã trống - để các validation khác xử lý
            return;
        }

        if (typeof getUserId !== 'function') {
            console.error('getUserId function not found');
            showFieldError('#txtCodeID', 'Lỗi: không tìm thấy getUserId()');
            resolve(false);
            return;
        }

        if (typeof getShopId !== 'function') {
            console.error('getShopId function not found');
            showFieldError('#txtCodeID', 'Lỗi: không tìm thấy getShopId()');
            resolve(false);
            return;
        }

        Promise.resolve(getUserId1()).then(function (userId) {
            var shopId = getShopId();
            console.log('Resolved User ID:', userId);
            console.log('Shop ID:', shopId);

            if (!userId || !shopId) {
                console.error('Missing userId or shopId:', { userId, shopId });
                showFieldError('#txtCodeID', 'Thiếu thông tin userId hoặc shopId');
                resolve(false);
                return;
            }

            $('#txtCodeID').prop('disabled', true);
            clearFieldError('#txtCodeID');

            var requestData = {
                codeId: String(codeId),
                userId: String(userId),
                shopId: String(shopId),
                excludeId: parseInt(currentContractId) || 0
            };

            console.log('Request Data:', requestData);

            $.ajax({
                url: API_BASE_URL + 'check_contract_code.php',
                method: 'POST',
                data: JSON.stringify(requestData),
                contentType: 'application/json',
                dataType: 'json',
                timeout: 10000,
                success: function (response) {
                    console.log('AJAX Success Response:', response);

                    if (response && response.success) {
                        if (response.exists) {
                            console.log('Contract code exists, showing error');
                            showFieldError('#txtCodeID', 'Mã hợp đồng đã tồn tại');
                            resolve(false); // Mã đã tồn tại - validation failed
                        } else {
                            console.log('Contract code is unique, clearing error');
                            clearFieldError('#txtCodeID');
                            resolve(true); // Mã hợp lệ - validation passed
                        }
                    } else {
                        console.error('API returned error:', response);
                        showFieldError('#txtCodeID', response.message || 'Không thể kiểm tra mã hợp đồng');
                        resolve(false); // Lỗi API - validation failed
                    }
                },
                error: function (xhr, status, error) {
                    console.error('AJAX Error Details:', { status, error, response: xhr.responseText });

                    var errorMessage = 'Lỗi kiểm tra mã hợp đồng';
                    if (xhr.status === 0) {
                        errorMessage = 'Không thể kết nối tới server';
                    } else if (xhr.status === 404) {
                        errorMessage = 'API không tồn tại (404)';
                    } else if (xhr.status === 500) {
                        errorMessage = 'Lỗi server (500)';
                    } else if (status === 'timeout') {
                        errorMessage = 'Timeout khi kiểm tra mã hợp đồng';
                    }

                    showFieldError('#txtCodeID', errorMessage);
                    resolve(false); // Lỗi - validation failed
                },
                complete: function () {
                    $('#txtCodeID').prop('disabled', false);
                }
            });
        }).catch(function (error) {
            console.error('Error getting userId:', error);
            showFieldError('#txtCodeID', 'Lỗi lấy thông tin user');
            resolve(false);
        });
    });
}
async function validateForm() {
    var hasError = false;

    $('.is-invalid').removeClass('is-invalid');
    $('.invalid-feedback').remove();

    if (!$('#txtCustomer').val().trim()) {
        showFieldError('#txtCustomer', 'Vui lòng nhập tên khách hàng');
        hasError = true;
    }

    // Validate mã hợp đồng
    // if (!$('#txtCodeID').val().trim()) {
    //     showFieldError('#txtCodeID', 'Mã hợp đồng không được để trống');
    //     hasError = true;
    // }
    // Validate mã hợp đồng
    if (!$('#txtCodeID').val().trim()) {
        await loadNextContractCode();
        await new Promise(resolve => setTimeout(resolve, 500));

        if (!$('#txtCodeID').val().trim()) {
            showFieldError('#txtCodeID', 'Mã hợp đồng không được để trống');
            hasError = true;
        }
    }

    // QUAN TRỌNG: Kiểm tra mã trùng lặp và đợi kết quả
    if ($('#txtCodeID').val().trim() && !hasError) {
        const isCodeUnique = await validateContractCodeUnique();
        if (!isCodeUnique) {
            hasError = true; // Mã đã tồn tại - ngăn không cho lưu
        }
    }
    // Validate số tiền
    var totalMoney = parseFloat($('#txtTotalMoney').val().replace(/[^\d]/g, ''));
    var totalMoneyReceived = parseFloat($('#txtTotalMoneyReceived').val().replace(/[^\d]/g, ''));

    if (!totalMoney || totalMoney <= 0) {
        showFieldError('#txtTotalMoney', 'Số tiền trả góp phải lớn hơn 0');
        hasError = true;
    }

    if (!totalMoneyReceived || totalMoneyReceived <= 0) {
        showFieldError('#txtTotalMoneyReceived', 'Số tiền đưa khách phải lớn hơn 0');
        hasError = true;
    }

    if (totalMoneyReceived && totalMoney && totalMoneyReceived >= totalMoney) {
        showFieldError('#txtTotalMoneyReceived', 'Tiền đưa khách phải nhỏ hơn tổng tiền trả góp');
        hasError = true;
    }

    // Validate thời gian
    if (!$('#txtLoanTime').val() || parseFloat($('#txtLoanTime').val()) <= 0) {
        showFieldError('#txtLoanTime', 'Thời gian bốc phải lớn hơn 0');
        hasError = true;
    }

    if (!$('#txtFrequency').val() || parseFloat($('#txtFrequency').val()) <= 0) {
        showFieldError('#txtFrequency', 'Tần suất đóng tiền phải lớn hơn 0');
        hasError = true;
    }

    // Validate ngày bốc
    if (!$('#txtStrFromDate').val()) {
        showFieldError('#txtStrFromDate', 'Ngày bốc không được để trống');
        hasError = true;
    }
    var valueStaff = $('#staff-selected').text();
    console.log('giá trị :' + valueStaff);
    //Validate nhân viên
    if (valueStaff && valueStaff !== "Chọn nhân viên" && valueStaff !== "" && valueStaff !== null) {
        // Có nhân viên hợp lệ được chọn - không làm gì
    } else

        if (!$('#m-select-staff').val()) {
            showFieldError('#staff-display', 'Vui lòng chọn nhân viên thu tiền');
            hasError = true;
        }

    // Scroll đến field đầu tiên có lỗi
    if (hasError) {
        var $firstError = $('.is-invalid').first();
        if ($firstError.length) {
            $('html, body').animate({
                scrollTop: $firstError.offset().top - 100
            }, 300);
            setTimeout(() => $firstError.focus(), 350);
        }
    }

    return !hasError;
}

// ================== SAVE CONTRACT ==================
async function saveContract() {
    const isValid = await validateForm();

    if (!isValid) {
        console.log('Validation failed - không thể lưu hợp đồng');
        return; // Dừng lại nếu validation failed
    }
    //console.log('UserID:', getUserId(), typeof getUserId());
    //console.log('ShopID:', getShopId(), typeof getShopId());
    //var staffId = sessionStorage.getItem('username');
    var staffId = $('#staff-selected').text();
    console.log(staffId);
    var contractData = {
        userId: await getUserId1(),
        shopId: getShopId(),
        id: parseInt($('#hfId').val()) || 0,
        codeId: $('#txtCodeID').val(),
        typeId: parseInt($('#TypeId').val()),
        customerId: 0,
        customerName: $('#txtCustomer').val().trim(),
        customerPhone: $('#txtCustomerPhone').val() || '',
        customerNumberCard: $('#hfCustomerNumberCard').val(),
        customerAddress: $('#hfCustomerAddress').val(),
        customerCardDate: $('#hfCustomerCardDate').val(),
        customerPlace: $('#hfCustomerPlace').val(),
        totalMoney: parseFloat($('#txtTotalMoney').val().replace(/[^\d]/g, '')),
        totalMoneyReceived: parseFloat($('#txtTotalMoneyReceived').val().replace(/[^\d]/g, '')),
        rateType: parseInt($('#m-select-ratetype_create').val()),
        loanTime: parseInt($('#txtLoanTime').val()),
        frequency: parseInt($('#txtFrequency').val()),
        fromDate: $('#txtStrFromDate').val(),
        isBefore: $('#IsBefore').is(':checked'),
        note: $('#txtNote').val(),
        staffId: staffId,
        editLoan: parseInt($('#hdd_editLoan').val())
    };

    $('#btnSaveInstallment').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Đang lưu...');

    $.ajax({
        url: API_BASE_URL + 'contracts.php',
        method: 'POST',
        data: JSON.stringify(contractData),
        contentType: 'application/json',
        success: function (response) {
            if (response.success) {
                showSuccessMessage('Lưu hợp đồng thành công!');
                $('#modal_create_pawn').modal('hide');
                if (typeof refreshContractList === 'function') {
                    refreshContractList();
                    loadFinancialData();
                }
            } else {
                showErrorMessage('Lỗi: ' + (response.message || 'Không thể lưu hợp đồng'));
            }
        },
        error: function (xhr) {
            console.error('Error saving contract:', xhr);
            var errorMsg = 'Có lỗi xảy ra khi lưu hợp đồng';
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMsg += ': ' + xhr.responseJSON.message;
            }
            //showErrorMessage(errorMsg);
        },
        complete: function () {
            $('#btnSaveInstallment').prop('disabled', false).html('<i class="fa fa-save"></i> Lưu lại');
        }
    });
}

// ================== UTILITY FUNCTIONS ==================
function formatMoney(input) {
    var value = input.value.replace(/[^\d]/g, '');
    if (value) {
        input.value = formatNumber(value);
    }
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function formatMoneyInputs() {
    $('#txtTotalMoney, #txtTotalMoneyReceived').each(function () {
        if ($(this).val() && $(this).val() !== '0') {
            formatMoney(this);
        }
    });
}

function setDefaultValues() {
    // Luôn set ngày hiện tại cho txtStrFromDate
    var today = new Date();
    var formattedDate = String(today.getDate()).padStart(2, '0') + '/' +
        String(today.getMonth() + 1).padStart(2, '0') + '/' + today.getFullYear();

    $('#txtStrFromDate').val(formattedDate); // Luôn ghi đè bằng ngày hiện tại

    // Các giá trị mặc định khác
    if (!$('#txtLoanTime').val() || $('#txtLoanTime').val() === '0') {
        $('#txtLoanTime').val('50');
    }
    if (!$('#txtFrequency').val() || $('#txtFrequency').val() === '0') {
        $('#txtFrequency').val('1');
    }
    if (!$('#txtTotalMoney').val() || $('#txtTotalMoney').val() === '') {
        $('#txtTotalMoney').val('0');
    }
    if (!$('#txtTotalMoneyReceived').val() || $('#txtTotalMoneyReceived').val() === '') {
        $('#txtTotalMoneyReceived').val('0');
    }

    // Set nhân viên mặc định là username hiện tại
    // Set nhân viên mặc định là username hiện tại
    // if (window.username || sessionStorage.getItem('username')) {
    //     var currentUsername = window.username || sessionStorage.getItem('username');
    //     var currentUserId = getUserId();

    //     $('#staff-selected').text(currentUsername);
    //     $('#m-select-staff').val(currentUsername);

    //     // Đảm bảo giá trị được set đúng
    //     console.log('Set default staff ID:', currentUserId);
    // }
    // Đảm bảo luôn có staff được chọn (nếu chưa có)
    var currentStaffText = $('#staff-selected').text();
    if (!currentStaffText || currentStaffText === 'Chọn nhân viên' || !$('#m-select-staff').val()) {
        // Đợi một chút để loadStaffList hoàn thành trước khi set default
        setTimeout(function () {
            if (!$('#m-select-staff').val()) {
                selectCurrentUser();
            }
        }, 1000);
    }
}

async function resetForm() {
    $('#hfId').val('0');
    //$('#txtCodeID').val('');
    $('#txtTotalMoney').val('0');
    $('#txtTotalMoneyReceived').val('0');
    $('#txtLoanTime').val('50');
    $('#txtFrequency').val('1');
    $('#txtNote').val('');
    $('#IsBefore').prop('checked', false);

    clearCustomer();

    $('.is-invalid').removeClass('is-invalid');
    $('.invalid-feedback').remove();

    $('#ratetype-selected').text('Theo ngày');
    $('#m-select-ratetype_create').val('0');
    updateRateTypeUI('0');

    $('#staff-selected').text('Chọn nhân viên');
    $('#m-select-staff').val('');

    // Luôn set ngày hiện tại khi reset
    var today = new Date();
    var formattedDate = String(today.getDate()).padStart(2, '0') + '/' +
        String(today.getMonth() + 1).padStart(2, '0') + '/' + today.getFullYear();
    $('#txtStrFromDate').val(formattedDate);

    // Gọi setDefaultValues cho các field khác
    await loadNextContractCode(); // Thêm dòng này
    setDefaultValues();
    $('#strMoneyOfLoanTime').text('0');
    // Tự động load mã hợp đồng mới

}

// ================== NOTIFICATION SYSTEM ==================
function showSuccessMessage(message) {
    var toast = $(`
        <div class="toast-notification success" style="position: fixed; top: 20px; right: 20px; 
             background: #28a745; color: white; padding: 15px 20px; border-radius: 5px; 
             box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 10000; min-width: 300px;">
            <i class="fa fa-check-circle" style="margin-right: 10px;"></i>
            ${message}
        </div>
    `);

    $('body').append(toast);

    setTimeout(function () {
        toast.fadeOut(function () {
            toast.remove();
        });
    }, 3000);
}

function showErrorMessage(message) {
    var toast = $(`
        <div class="toast-notification error" style="position: fixed; top: 20px; right: 20px; 
             background: #dc3545; color: white; padding: 15px 20px; border-radius: 5px; 
             box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 10000; min-width: 300px;">
            <i class="fa fa-exclamation-circle" style="margin-right: 10px;"></i>
            ${message}
            <button type="button" style="float: right; background: none; border: none; color: white; font-size: 18px; cursor: pointer; margin-left: 10px;" onclick="$(this).closest('.toast-notification').remove()">×</button>
        </div>
    `);

    $('body').append(toast);

    setTimeout(function () {
        if (toast.is(':visible')) {
            toast.fadeOut(function () {
                toast.remove();
            });
        }
    }, 5000);
}

// ================== STYLES ==================
function addValidationStyles() {
    if ($('#validation-styles').length === 0) {
        $('<style id="validation-styles">')
            .text(`
                .is-invalid {
                    border-color: #dc3545 !important;
                    box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
                }
                
                .invalid-feedback {
                    display: block;
                    width: 100%;
                    margin-top: 0.25rem;
                    font-size: 0.875em;
                    color: #dc3545;
                    animation: fadeInError 0.3s ease-in;
                }
                
                @keyframes fadeInError {
                    from { opacity: 0; transform: translateY(-5px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                
                .custom-select-display.is-invalid {
                    border-color: #dc3545 !important;
                    box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
                }
                
                #customer-dropdown {
                    border-radius: 4px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                    margin-top: 2px;
                }
                
                #customer-dropdown .customer-option:hover {
                    background-color: #f8f9fa;
                }
                
                #customer-dropdown .customer-option:last-child {
                    border-bottom: none;
                }
                
                .toast-notification {
                    animation: slideInRight 0.3s ease-out;
                }
                
                @keyframes slideInRight {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                
                .simple-datepicker .calendar-day:hover {
                    background: #e9ecef !important;
                    color: #495057 !important;
                }
                
                .simple-datepicker button:hover {
                    opacity: 0.8;
                }
                
                .custom-select-search input {
                    width: 100%;
                    padding: 8px 12px;
                    border: none;
                    border-bottom: 1px solid #eee;
                    outline: none;
                    background: #f8f9fa;
                }
            `)
            .appendTo('head');
    }
}

// ================== HELPER FUNCTIONS ==================
async function getUserId1() {
    var userID = localStorage.getItem('user_id');
    if (!userID) return null;

    // Nếu là staff ID (bắt đầu bằng STF)
    if (String(userID).toUpperCase().startsWith('STF')) {
        // Lấy owner_user_id thay vì staff user_id
        const ownerUserId = await getOwnerUserId(userID);
        console.log(ownerUserId);
        return ownerUserId;
    }

    // Nếu là owner, trả về bình thường
    return userID;
}
// Hàm lấy user_id của owner từ staff_id thông qua API
async function getOwnerUserId(staffId) {
    try {
        const response = await fetch(API_BASE_URL + 'get_owner_from_staff.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'staff_id=' + encodeURIComponent(staffId)
        });

        const result = await response.json();

        if (result.success && result.owner_user_id) {
            return result.owner_user_id;
        } else {
            console.error('Lỗi lấy owner user_id từ staff_id:', result.message);
            return null;
        }
    } catch (error) {
        console.error('Lỗi kết nối API:', error);
        return null;
    }
}

function getShopId() {
    var selectedShopId = localStorage.getItem('selected_shop_id');
    var defaultShopId = localStorage.getItem('store_id');

    return selectedShopId;
}

// ================== CONTRACT LOADING ==================
function loadContractData(contractId) {
    $.ajax({
        url: '/api/contracts/' + contractId,
        method: 'GET',
        data: {
            userId: getUserId(),
            shopId: getShopId()
        },
        success: function (data) {
            fillFormData(data);
            $('#modal_create_pawn').modal('show');
        },
        error: function () {
            showErrorMessage('Không thể tải thông tin hợp đồng');
        }
    });
}

function fillFormData(data) {
    $('#hfId').val(data.id);
    $('#txtCodeID').val(data.codeId);
    $('#txtTotalMoney').val(formatNumber(data.totalMoney));
    $('#txtTotalMoneyReceived').val(formatNumber(data.totalMoneyReceived));
    $('#txtLoanTime').val(data.loanTime);
    $('#txtFrequency').val(data.frequency);
    $('#txtStrFromDate').val(data.fromDate);
    $('#txtNote').val(data.note);
    $('#IsBefore').prop('checked', data.isBefore);

    // Set Rate Type
    $('#m-select-ratetype_create').val(data.rateType);
    var rateText = data.rateType == '0' ? 'Theo ngày' : 'Định kì theo tháng';
    $('#ratetype-selected').text(rateText);
    updateRateTypeUI(data.rateType);

    // Set Staff
    $('#m-select-staff').val(data.staffId);
    if (data.staffName) {
        $('#staff-selected').text(data.staffName + ' (' + data.staffUsername + ')');
    }

    // Load thông tin khách hàng
    if (data.customer) {
        selectCustomer(data.customer);
    }

    // Hiển thị thông báo không thể sửa nếu đã có kỳ đóng
    if (data.hasInstallments) {
        $('#messageNotUpdate').show();
        $('#txtTotalMoney, #txtTotalMoneyReceived, #txtLoanTime, #txtStrFromDate').prop('readonly', true);
        $('#ratetype-display').css('pointer-events', 'none').addClass('disabled');
    }

    calculateInstallment();
}