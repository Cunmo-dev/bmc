// ================== CONTRACT DETAILS MODAL MANAGER ==================
let currentContractId = null;
let currentCodeId = null;
let currentContractData = null;
let currentPaymentSchedules = null;
let currentPaymentHistory = null;
let currentUserId = null;        // Thêm biến này
let currentShopId = null;        // Thêm biến này
async function getDetailsPawn(contractId, codeId, tab) {
    console.log('=== DEBUG getDetailsPawn ===');
    console.log('contractId:', contractId);
    console.log('codeId:', codeId);
    console.log('tab:', tab);
    currentContractId = contractId;
    currentCodeId = codeId;

    // Reset modal data
    resetModal();

    // Open modal and activate specified tab
    $('#modal_details_pawn').modal('show');
    $(`a[href="#${tab}"]`).tab('show');


    // Load payment schedules for lịch đóng tiền tab
    await loadPaymentSchedules();

    // Load payment history if needed for lịch sử tab
    await loadPaymentHistory();
    // Load contract details
    await loadContractDetails();

    // Bind events inside modal
    await bindModalEvents();
}

function resetModal() {
    // Clear labels
    $('#lblCodeId').text('');
    $('#lblCusName').text('');
    $('#lblCusPhone').text('');
    $('#lblCusAddress').text('');
    $('#lblTotalMoney').text('');
    $('#lblStrRate').text('');
    $('#lblFromDate').text('');
    $('#lblToDate').text('');
    $('#lblCustomerDebitMoney').text('');
    $('#lblLoanDebitMoney').text('');
    $('#lblTotalMoneyReceived').text('');
    $('#lblTotalMoneyPayment').text('');
    $('#lblPaymentMoney').text('');
    $('#lblTotalMoneyCurrent').text('');
    $('#lblTotalInterest').text('');
    $('#lblStatus').text('');

    // Clear tables
    $('#tbl_DongTien_list tbody').empty();
    $('#tbl_Lichsu_listHistoryTransaction').empty();
    $('#tbl_Lichsu_listCommentDebt').empty();
    $('#tbl_Hengio_HistoryAlarmDate').empty();

    // Reset hidden inputs
    $('#hddLoanID').val('');
    $('#hddCustomerID').val('');
    $('#hddTotalMoneyCurrent').val('');
    $('#hddNotePayment').val('0');

    // Hide/show sections
    $('.dvInfoPayNeed').hide();
    $('#dvDone').hide();
    $('#dvPending').hide();
}

// async function loadContractDetails() {
//     // Kiểm tra currentContractId có tồn tại không
//     if (!currentContractId) {
//         showErrorMessage('Không có ID hợp đồng để tải thông tin');
//         return;
//     }

//     showLoadingState();

//     // Sử dụng loadContracts với filter theo contract ID cụ thể
//     const params = {
//         userId: getUserId(),
//         shopId: getShopId(),
//         page: 1,
//         limit: 1,
//         search: '', // Có thể search theo code nếu cần
//         status: 'all',
//         contract_id: currentContractId // Thêm tham số này để filter theo ID cụ thể
//     };

//     $.ajax({
//         url: API_BASE_URL + 'get_contracts.php',
//         method: 'GET',
//         data: params,
//         dataType: 'json',
//         success: await function (response) {
//             console.log('Contract details response:', response);

//             if (response.success && response.data && response.data.length > 0) {
//                 // ← Thêm filter để đảm bảo đúng contract
//                 const contract = response.data.find(c => c.id == currentContractId);

//                 if (contract) {
//                     currentContractData = contract;
//                     populateContractDetails(contract, currentPaymentSchedules);
//                 } else {
//                     showErrorMessage('Không tìm thấy hợp đồng với ID: ' + currentContractId);
//                 }
//             } else if (response.success && response.data && response.data.length === 0) {
//                 showErrorMessage('Không tìm thấy hợp đồng với ID: ' + currentContractId);
//             } else {
//                 const errorMsg = response?.message || 'Không thể tải thông tin hợp đồng';
//                 showErrorMessage(errorMsg);
//                 console.error('Contract details error:', response);
//             }
//         },
//         error: function (xhr, status, error) {
//             console.error('AJAX Error Details:', {
//                 status: status,
//                 error: error,
//                 responseText: xhr.responseText,
//                 statusCode: xhr.status
//             });

//             let errorMessage = 'Lỗi khi tải thông tin hợp đồng';

//             switch (xhr.status) {
//                 case 404:
//                     errorMessage = 'Hợp đồng không tồn tại';
//                     break;
//                 case 400:
//                     errorMessage = 'Yêu cầu không hợp lệ';
//                     break;
//                 case 500:
//                     errorMessage = 'Lỗi máy chủ, vui lòng thử lại sau';
//                     break;
//                 case 0:
//                     errorMessage = 'Không thể kết nối đến máy chủ';
//                     break;
//                 default:
//                     if (status === 'timeout') {
//                         errorMessage = 'Yêu cầu quá thời gian chờ';
//                     }
//             }

//             showErrorMessage(errorMessage);
//         },
//         complete: function () {
//             hideLoadingState();
//         }
//     });
// }

async function loadContractDetails() {
    if (!currentContractId) {
        showErrorMessage('Không có ID hợp đồng để tải thông tin');
        return;
    }

    showLoadingState();

    // ✅ DEBUG: Log parameters trước khi gửi
    const params = {
        userId: getUserId(),
        shopId: getShopId(),
        page: 1,
        limit: 1,
        search: '',
        status: 'all',
        contract_id: currentContractId  // ← Đảm bảo đúng tên parameter
    };

    console.log('=== SENDING PARAMETERS ===');
    console.log('currentContractId:', currentContractId);
    console.log('params:', params);

    $.ajax({
        url: API_BASE_URL + 'get_contracts.php',
        method: 'GET',
        data: params,
        dataType: 'json',
        success: function (response) {
            console.log('=== API RESPONSE ===');
            console.log('Full response:', response);

            if (response.success && response.data && response.data.length > 0) {
                const contract = response.data[0];

                // ✅ KIỂM TRA: So sánh ID được trả về với ID yêu cầu
                console.log('Expected contract ID:', currentContractId);
                console.log('Actual contract ID:', contract.id);

                if (contract.id != currentContractId) {
                    console.error('❌ CONTRACT ID MISMATCH!');
                    console.error('Expected:', currentContractId, 'Got:', contract.id);
                    showErrorMessage(`Lỗi: Yêu cầu contract ${currentContractId} nhưng nhận được contract ${contract.id}`);
                    return;
                } else {
                    console.log('✅ Contract ID matches!');
                }

                currentContractData = contract;
                populateContractDetails(contract, currentPaymentSchedules);

            } else if (response.success && response.data && response.data.length === 0) {
                showErrorMessage('Không tìm thấy hợp đồng với ID: ' + currentContractId);
            } else {
                const errorMsg = response?.message || 'Không thể tải thông tin hợp đồng';
                showErrorMessage(errorMsg);
                console.error('Contract details error:', response);
            }
        },
        error: function (xhr, status, error) {
            console.error('AJAX Error Details:', {
                status: status,
                error: error,
                responseText: xhr.responseText,
                statusCode: xhr.status
            });

            let errorMessage = 'Lỗi khi tải thông tin hợp đồng';

            switch (xhr.status) {
                case 404:
                    errorMessage = 'Hợp đồng không tồn tại';
                    break;
                case 400:
                    errorMessage = 'Yêu cầu không hợp lệ';
                    break;
                case 500:
                    errorMessage = 'Lỗi máy chủ, vui lòng thử lại sau';
                    break;
                case 0:
                    errorMessage = 'Không thể kết nối đến máy chủ';
                    break;
                default:
                    if (status === 'timeout') {
                        errorMessage = 'Yêu cầu quá thời gian chờ';
                    }
            }

            showErrorMessage(errorMessage);
        },
        complete: function () {
            hideLoadingState();
        }
    });
}
function populateContractDetails(contract, schedules = null) {
    try {
        console.log('Populating contract details:', contract);
        // Tính tổng số tiền đã thanh toán từ payment schedules
        let total_amount_paid = 0;
        if (schedules && Array.isArray(schedules)) {
            total_amount_paid = schedules.reduce((total, schedule) => {
                // Chỉ tính các kỳ đã thanh toán hoặc thanh toán một phần
                if (schedule.status === 'paid' || schedule.status === 'partial_paid') {
                    return total + parseFloat(schedule.amount_paid || 0);
                }
                return total;
            }, 0);
        }
        // Populate hidden fields
        if ($('#hddLoanID').length) $('#hddLoanID').val(contract.id || '');
        if ($('#hddCustomerID').length) $('#hddCustomerID').val(contract.customer_id || '');
        if ($('#hddTotalMoneyCurrent').length) $('#hddTotalMoneyCurrent').val(contract.remaining_amount || 0);

        // Populate customer info
        $('#lblCusName').text(contract.customer_name || 'N/A');
        $('#lblCusPhone').text(contract.customer_phone ? ` - ${contract.customer_phone}` : '');
        $('#lblCusAddress').text(contract.customer_address ? ` - ${contract.customer_address}` : '');

        // Populate contract info - left table
        $('#lblTotalMoney').text(formatNumber(contract.total_money || 0));
        $('#lblStrRate').text(contract.staff_id || 'N/A');
        $('#lblFromDate').text(contract.formatted_from_date || 'N/A');

        // Calculate and display to_date
        if (contract.from_date && contract.loan_time) {
            const toDate = new Date(contract.from_date);
            toDate.setDate(toDate.getDate() + parseInt(contract.loan_time));
            $('#lblToDate').text(formatDate(toDate));
        } else {
            $('#lblToDate').text('N/A');
        }

        // Nợ cũ và nợ vay
        // $('#lblCustomerDebitMoney').text(formatNumber(contract.debit_money || 0) + ' VNĐ');
        // $('#lblLoanDebitMoney').text(formatNumber(contract.loan_debit || 0) + ' VNĐ');

        // Populate money info - right table
        $('#lblTotalMoneyReceived').text(formatNumber(contract.total_money_received || 0));
        $('#lblTotalMoneyPayment').text(formatNumber(contract.total_money || 0));
        $('#lblPaymentMoney').text(formatNumber(total_amount_paid));
        $('#lblTotalMoneyCurrent').text(formatNumber(contract.remaining_amount || 0));
        $('#lblTotalInterest').text(formatNumber(contract.total_interest || 0));
        $('#lblStatus').text(contract.current_status || 'Đang vay');

        // Update completion section if exists
        if ($('#lblDongHD_FinishDay').length) {
            $('#lblDongHD_FinishDay').text(contract.remaining_periods || 0);
        }
        if ($('#lblDongHD_TotalMoneyCurrent').length) {
            $('#lblDongHD_TotalMoneyCurrent').text(formatNumber(contract.remaining_amount || 0));
        }
        if ($('#lblDongHD_DebitMoney').length) {
            $('#lblDongHD_DebitMoney').text(formatNumber(contract.debit_money || 0));
        }

        // Show/hide sections based on status
        if (contract.current_status === 'Đã hoàn thành') {
            if ($('#dvDone').length) $('#dvDone').show();
            if ($('#dvPending').length) $('#dvPending').hide();
        } else {
            if ($('#dvDone').length) $('#dvDone').hide();
            if ($('#dvPending').length) $('#dvPending').show();
        }

        // Update additional info if available
        if (contract.contract_type_name && $('#lblContractType').length) {
            $('#lblContractType').text(contract.contract_type_name);
        }
        if (contract.interest_rate && $('#lblInterestRate').length) {
            $('#lblInterestRate').text(contract.interest_rate + '%');
        }
        // Cập nhật trạng thái nút đóng hợp đồng dựa trên remaining_amount
        const remainingAmount = parseFloat(contract.remaining_amount) || 0;
        const $closeButton = $('#btnDongHopDongVayHo');

        if (remainingAmount <= 0) {
            // Có thể đóng hợp đồng
            $closeButton.prop('disabled', false)
                .removeClass('btn-secondary')
                .addClass('btn-success')
                .html('<i class="fa fa-check-circle"></i> Đóng hợp đồng');
        } else {
            // Chưa thể đóng hợp đồng
            $closeButton.prop('disabled', true)
                .removeClass('btn-success')
                .addClass('btn-secondary')
                .html('<i class="fa fa-lock"></i> Chưa thể đóng');
        }

        // Hiển thị thông báo trạng thái
        if (remainingAmount <= 0) {
            $('#dvDone').show();
            $('#dvPending').hide();
            $('#dvDone').html(`
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    Hợp đồng đã thanh toán đủ và có thể đóng!
                </div>
            `);
        } else {
            $('#dvDone').hide();
            $('#dvPending').show();
        }


        console.log('Contract details populated successfully');

    } catch (error) {
        console.error('Error populating contract details:', error);
        showErrorMessage('Lỗi khi hiển thị thông tin hợp đồng');
    }
}



function showLoadingState() {
    // Hiển thị loading cho các element chính
    const loadingElements = [
        '#lblCusName', '#lblTotalMoney', '#lblStrRate', '#lblFromDate',
        '#lblToDate', '#lblCustomerDebitMoney', '#lblLoanDebitMoney',
        '#lblTotalMoneyReceived', '#lblTotalMoneyPayment', '#lblPaymentMoney',
        '#lblTotalMoneyCurrent', '#lblTotalInterest', '#lblStatus'
    ];

    loadingElements.forEach(selector => {
        if ($(selector).length) {
            $(selector).html('<i class="fa fa-spinner fa-spin"></i> Đang tải...');
        }
    });
}

function hideLoadingState() {
    // Hàm này sẽ được gọi sau khi populate xong
    console.log('Loading state hidden');
}

async function loadPaymentSchedules() {
    $.ajax({
        url: API_BASE_URL + 'payment_schedule.php',
        method: 'POST',
        data: JSON.stringify({
            action: 'get_schedule',
            contract_id: currentContractId
        }),
        contentType: 'application/json',
        success: await function (response) {
            if (response.success && response.data) {
                currentPaymentSchedules = response.data;
                renderPaymentSchedulesTable(response.data);

            } else {
                showErrorMessage('Không thể tải lịch thanh toán: ' + (response.message || 'Lỗi không xác định'));
            }
        },
        error: function (xhr, status, error) {
            showErrorMessage('Lỗi khi tải lịch thanh toán');
            console.error('Error loading payment schedules:', error);
        }
    });
}

// function renderPaymentSchedulesTable(schedules) {
//     const tbody = $('#tbl_DongTien_list tbody');
//     tbody.empty();
//     schedules.forEach((schedule, index) => {
//         const row = `
//             <tr data-schedule-id="${schedule.id}">
//                 <td class="text-center">${index + 1}</td>
//                 <td class="text-center">${formatDate(schedule.from_date)}</td>
//                 <td class="text-center">-></td>
//                 <td class="text-center">${formatDate(schedule.to_date)}</td>
//                 <td class="text-right">${(schedule.amount_due)}</td>
//                 <td class="text-center">${schedule.payment_date ? formatDate(schedule.payment_date) : ''}</td>
//                 <td class="text-right">
//                     ${schedule.status === 'paid' ? (schedule.amount_remaining) :
//                 `<input type="text" class="form-control payment-amount" data-schedule-id="${schedule.id}" value="${(schedule.amount_remaining)}">`}
//                 </td>
//                 <td class="text-center">
//                     ${schedule.status === 'paid' ?
//                 `<button class="btn btn-sm btn-warning cancel-payment" data-schedule-id="${schedule.id}" title="Hủy thanh toán">
//                             <i class="fa fa-undo"></i> Hủy
//                         </button>` :
//                 `<button class="btn btn-sm btn-primary pay-schedule" data-schedule-id="${schedule.id}">
//                             <i class="fa fa-check"></i> Đóng
//                         </button>`
//             }
//                 </td>
//                 <td class="text-left">
//                     <span class="payment-status-${schedule.status}">
//                         ${getStatusText(schedule.status, schedule.due_date)}
//                     </span>
//                     ${schedule.note ? `<br><small class="text-muted">${schedule.note}</small>` : ''}
//                 </td>
//             </tr>
//         `;
//         tbody.append(row);
//     });
// }
function renderPaymentSchedulesTable(schedules) {
    const tbody = $('#tbl_DongTien_list tbody');
    tbody.empty();

    // Tìm kỳ gần nhất chưa thanh toán (pending) dựa trên period_number
    const pendingSchedules = schedules.filter(schedule => schedule.status === 'pending');
    const nearestPendingSchedule = pendingSchedules.length > 0
        ? pendingSchedules.reduce((min, curr) =>
            curr.period_number < min.period_number ? curr : min
        )
        : null;

    schedules.forEach((schedule, index) => {
        // Xác định giá trị hiển thị cho cột ngày thanh toán
        let displayDate = '-';
        if (schedule.status === 'paid') {
            // Nếu đã thanh toán, sử dụng from_date (hoặc bạn có thể thay đổi logic nếu có ngày khác)
            displayDate = formatDate(schedule.from_date);
        } else if (schedule.status === 'pending' && nearestPendingSchedule && schedule.id === nearestPendingSchedule.id) {
            // Nếu là kỳ gần nhất chưa thanh toán, sử dụng from_date
            displayDate = formatDate(schedule.from_date);
        }

        const row = `
            <tr data-schedule-id="${schedule.id}">
                <td class="text-center">${index + 1}</td>
                <td class="text-center">${formatDate(schedule.from_date)}</td>
                <td class="text-center">-></td>
                <td class="text-center">${formatDate(schedule.to_date)}</td>
                <td class="text-right">${schedule.amount_due}</td>
                <td class="text-center">${displayDate}</td>
                <td class="text-right">
                    ${schedule.status === 'paid' ? schedule.amount_remaining :
                `<input type="text" class="form-control payment-amount" data-schedule-id="${schedule.id}" value="${schedule.amount_remaining}">`}
                </td>
                <td class="text-center">
                    ${schedule.status === 'paid' ?
                `<button class="btn btn-sm btn-warning cancel-payment" data-schedule-id="${schedule.id}" title="Hủy thanh toán">
                            <i class="fa fa-undo"></i> Hủy
                        </button>` :
                `<button class="btn btn-sm btn-primary pay-schedule" data-schedule-id="${schedule.id}">
                            <i class="fa fa-check"></i> Đóng
                        </button>`
            }
                </td>
                <td class="text-left">
                    <span class="payment-status-${schedule.status}">
                        ${getStatusText(schedule.status, schedule.due_date)}
                    </span>
                    ${schedule.note ? `<br><small class="text-muted">${schedule.note}</small>` : ''}
                </td>
            </tr>
        `;
        tbody.append(row);
    });
}

function getStatusText(status, dueDate) {
    const today = new Date();
    const due = new Date(dueDate);

    switch (status) {
        case 'paid':
            return '<span class="badge badge-success">Đã đóng</span>';
        case 'partial_paid':
            return '<span class="badge badge-warning">Đóng một phần</span>';
        case 'pending':
            if (due < today) {
                const daysOverdue = Math.floor((today - due) / (1000 * 60 * 60 * 24));
                return `<span class="badge badge-danger">Quá hạn ${daysOverdue} ngày</span>`;
            } else if (due.toDateString() === today.toDateString()) {
                return '<span class="badge badge-info">Đến hạn hôm nay</span>';
            } else {
                return '<span class="badge badge-secondary">Chưa đến hạn</span>';
            }
        default:
            return '<span class="badge badge-light">Không xác định</span>';
    }
}

// Frontend - Cập nhật hàm loadPaymentHistory() để sử dụng POST
function loadPaymentHistory() {
    $.ajax({
        url: API_BASE_URL + 'payment_schedule.php',
        method: 'POST', // Đổi từ GET sang POST
        contentType: 'application/json',
        data: JSON.stringify({
            action: 'get_payment_history',
            contract_id: currentContractId
        }),
        success: function (response) {
            if (response.success && response.data) {
                currentPaymentHistory = response.data;
                renderPaymentHistoryTable(response.data);
            } else {
                showErrorMessage('Không thể tải lịch sử thanh toán');
            }
        },
        error: function () {
            showErrorMessage('Lỗi khi tải lịch sử thanh toán');
        }
    });
}

function renderPaymentHistoryTable(history) {
    const container = $('#tbl_Lichsu_listHistoryTransaction');
    let html = `
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Ngày</th>
                    <th>Kỳ</th>
                    <th>Số tiền</th>
                    <th>Phương thức</th>
                    <th>Mã GD</th>
                    <th>Trạng thái</th>
                </tr>
            </thead>
            <tbody>
    `;

    history.forEach(item => {
        const statusClass = item.status === 'cancelled' ? 'text-danger' : '';
        html += `
            <tr class="${statusClass}">
                <td>${item.formatted_created_at}</td>
                <td>Kỳ ${item.period_number || 'N/A'}</td>
                <td>${formatNumber(item.amount_paid)}</td>
                <td>${item.payment_method}</td>
                <td><small>${item.transaction_code}</small></td>
                <td>
                    ${item.status === 'cancelled' ?
                '<span class="badge badge-danger">Đã hủy</span>' :
                '<span class="badge badge-success">Thành công</span>'
            }
                </td>
                
            </tr>
        `;
    });

    html += '</tbody></table>';
    container.html(html);
}


// async function bindModalEvents() {
//     // Unbind all events first
//     $(document).off('click', '.pay-schedule');
//     $(document).off('click', '.cancel-payment');
//     $(document).off('click', '.cancel-transaction');
//     $(document).off('click', '#btnShow');
//     $(document).off('click', '#btnPayNeed_Save');
//     $(document).off('click', '#btnDongHopDongVayHo'); // ✅ Đã có
//     $(document).off('click', '#btnCloseContractInstallment_Save');

//     // ✅ THAY ĐỔI: Bind tất cả với $(document).on() để thống nhất

//     // Toggle pay need section
//     $(document).on('click', '#btnShow', function () {
//         $('.dvInfoPayNeed').toggle();
//     });

//     // Save pay need (update money per period)  
//     $(document).on('click', '#btnPayNeed_Save', function () {
//         const newAmount = parseFloat($('#txtDongTien_PayNeed').val().replace(/,/g, ''));
//         if (isNaN(newAmount) || newAmount <= 0) {
//             showErrorMessage('Số tiền không hợp lệ');
//             return;
//         }
//         updateMoneyPerPeriod(newAmount);
//     });

//     // Pay schedule button
//     $(document).on('click', '.pay-schedule', await function () {
//         const scheduleId = $(this).data('schedule-id');
//         const amountInput = $(this).closest('tr').find('.payment-amount');
//         const amount = parseFloat(amountInput.val().replace(/,/g, ''));

//         if (isNaN(amount) || amount <= 0) {
//             showErrorMessage('Số tiền thanh toán không hợp lệ');
//             return;
//         }
//         updatePayment(scheduleId, amount);
//     });

//     // Cancel payment button
//     $(document).on('click', '.cancel-payment', await function () {
//         const scheduleId = $(this).data('schedule-id');
//         cancelPayment(scheduleId);
//     });

//     // Cancel individual transaction
//     $(document).on('click', '.cancel-transaction', await function () {
//         const transactionId = $(this).data('transaction-id');
//         if (confirm('Bạn có chắc chắn muốn hủy giao dịch này?\nViệc này sẽ cập nhật lại số tiền còn nợ.')) {
//             cancelTransaction(transactionId);
//         }
//     });

//     // ✅ Close contract - THAY ĐỔI CÁCH BIND
//     $(document).on('click', '#btnDongHopDongVayHo', function (e) {
//         e.preventDefault();
//         e.stopPropagation();

//         // Thêm kiểm tra để tránh double-click
//         if ($(this).hasClass('processing')) {
//             console.log('Already processing, ignoring click');
//             return false;
//         }

//         console.log('Close contract button clicked'); // Debug log
//         $(this).addClass('processing');

//         confirmCloseInstallment();

//         // Remove processing class sau 3 giây
//         setTimeout(() => {
//             $(this).removeClass('processing');
//         }, 3000);
//     });

//     // Close contract installment
//     $(document).on('click', '#btnCloseContractInstallment_Save', function () {
//         const otherMoney = parseFloat($('#txtCloseInstallment_OtherMoney').val().replace(/,/g, '')) || 0;
//         closeContract(otherMoney);
//     });
// }

// Hàm cập nhật bind events để sử dụng async đúng cách
async function bindModalEvents() {
    // Unbind all events first
    $(document).off('click', '.pay-schedule');
    $(document).off('click', '.cancel-payment');
    $(document).off('click', '.cancel-transaction');
    $(document).off('click', '#btnShow');
    $(document).off('click', '#btnPayNeed_Save');
    $(document).off('click', '#btnDongHopDongVayHo');
    $(document).off('click', '#btnCloseContractInstallment_Save');

    // Toggle pay need section
    $(document).on('click', '#btnShow', function () {
        $('.dvInfoPayNeed').toggle();
    });

    // Save pay need (update money per period)  
    $(document).on('click', '#btnPayNeed_Save', function () {
        const newAmount = parseFloat($('#txtDongTien_PayNeed').val().replace(/,/g, ''));
        if (isNaN(newAmount) || newAmount <= 0) {
            showErrorMessage('Số tiền không hợp lệ');
            return;
        }
        updateMoneyPerPeriod(newAmount);
    });

    // Pay schedule button - SỬA: Không dùng await trong function callback
    $(document).on('click', '.pay-schedule', async function () {
        const scheduleId = $(this).data('schedule-id');
        const amountInput = $(this).closest('tr').find('.payment-amount');
        const amount = parseFloat(amountInput.val().replace(/,/g, ''));

        if (isNaN(amount) || amount <= 0) {
            showErrorMessage('Số tiền thanh toán không hợp lệ');
            return;
        }

        // Gọi async function từ sync context
        // Đợi updatePayment hoàn thành TRƯỚC khi reload data
        await updatePayment(scheduleId, amount);

        // Sau khi update thành công, mới reload financial data
        await loadFinancialData();
    });

    // Cancel payment button - SỬA: Không dùng await trong function callback
    $(document).on('click', '.cancel-payment', async function () {
        const scheduleId = $(this).data('schedule-id');
        // Gọi async function từ sync context
        await cancelPayment(scheduleId);
        await loadFinancialData();
    });

    // Cancel individual transaction - SỬA: Không dùng await trong function callback
    $(document).on('click', '.cancel-transaction', function () {
        const transactionId = $(this).data('transaction-id');
        // Gọi async function từ sync context
        cancelTransaction(transactionId);
    });

    // Close contract
    $(document).on('click', '#btnDongHopDongVayHo', function (e) {
        e.preventDefault();
        e.stopPropagation();

        if ($(this).hasClass('processing')) {
            console.log('Already processing, ignoring click');
            return false;
        }

        console.log('Close contract button clicked');
        $(this).addClass('processing');

        confirmCloseInstallment();

        setTimeout(() => {
            $(this).removeClass('processing');
        }, 3000);
    });

    // Close contract installment
    $(document).on('click', '#btnCloseContractInstallment_Save', function () {
        const otherMoney = parseFloat($('#txtCloseInstallment_OtherMoney').val().replace(/,/g, '')) || 0;
        closeContract(otherMoney);
    });
}

function confirmCloseInstallment() {
    console.log('confirmCloseInstallment called'); // Debug log

    // ✅ Kiểm tra flag global để tránh gọi nhiều lần
    if (window.isProcessingContractClose) {
        console.log('Contract close already in progress, skipping...');
        return;
    }

    // Kiểm tra có contract ID không
    if (!currentContractId) {
        showErrorMessage('Không xác định được hợp đồng cần đóng');
        return;
    }

    // Lấy số tiền còn phải đóng từ label hiện tại
    const remainingAmountText = $('#lblDongHD_TotalMoneyCurrent').text().replace(/[^0-9.-]/g, '');
    const remainingAmount = parseFloat(remainingAmountText) || 0;

    console.log('Remaining amount check:', remainingAmount);

    // Kiểm tra điều kiện đóng hợp đồng
    if (remainingAmount > 0) {
        showErrorMessage(`Không thể đóng hợp đồng. Còn phải thanh toán: ${formatNumber(remainingAmount)} VNĐ`);
        return;
    }

    // Xác nhận đóng hợp đồng
    if (!confirm(`Bạn có chắc chắn muốn đóng hợp đồng ${currentCodeId}?\n\nViệc này sẽ đánh dấu hợp đồng đã hoàn thành và không thể hoàn tác.`)) {
        return;
    }

    // ✅ Set flag để ngăn gọi lại
    window.isProcessingContractClose = true;
    closeContractProcess();
}

// ✅ CẬP NHẬT closeContractProcess để reset flag
async function closeContractProcess() {
    // Hiển thị loading
    if (typeof showLoading === 'function') showLoading();

    try {
        const response = await $.ajax({
            url: API_BASE_URL + 'payment_schedule.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                action: 'close_contract',
                contract_id: currentContractId
            })
        });

        if (response.success) {
            showSuccessMessage(response.message || 'Đóng hợp đồng thành công');
            updateUIAfterClose(response.completion_data);

            if (typeof loadContracts === 'function') {
                loadContracts();
            }

            setTimeout(() => {
                $('#modal_details_pawn').modal('hide');
            }, 2000);

        } else {
            showErrorMessage('Lỗi: ' + (response.message || 'Không thể đóng hợp đồng'));
        }

    } catch (xhr) {
        console.error('Error closing contract:', xhr);
        let errorMessage = 'Có lỗi xảy ra khi đóng hợp đồng';

        if (xhr.responseJSON && xhr.responseJSON.message) {
            errorMessage = xhr.responseJSON.message;
        } else {
            switch (xhr.status) {
                case 400:
                    errorMessage = 'Hợp đồng chưa thanh toán đủ hoặc dữ liệu không hợp lệ';
                    break;
                case 404:
                    errorMessage = 'Hợp đồng không tồn tại';
                    break;
                case 500:
                    errorMessage = 'Lỗi server. Vui lòng thử lại sau.';
                    break;
                case 0:
                    errorMessage = 'Không thể kết nối đến máy chủ';
                    break;
            }
        }

        showErrorMessage(errorMessage);
    } finally {
        // ✅ Reset tất cả flags và hide loading
        window.isProcessingContractClose = false;
        $('#btnDongHopDongVayHo').removeClass('processing');
        if (typeof hideLoading === 'function') hideLoading();
    }
}
function updateUIAfterClose(completionData) {
    // Cập nhật trạng thái hiển thị
    $('#lblStatus').text('Đã hoàn thành');
    $('#lblTotalMoneyCurrent').text('0');
    $('#lblDongHD_TotalMoneyCurrent').text('0');

    // Hiển thị section hoàn thành
    $('#dvDone').show();
    $('#dvPending').hide();

    // Disable nút đóng hợp đồng
    $('#btnDongHopDongVayHo').prop('disabled', true)
        .removeClass('btn-primary')
        .addClass('btn-secondary')
        .html('<i class="fa fa-check"></i> Đã hoàn thành');

    // Cập nhật text trong dvDone
    $('#dvDone').html(`
        <div class="alert alert-success">
            <i class="fa fa-check-circle"></i>
            Hợp đồng đã hoàn thành vào ngày ${new Date().toLocaleDateString('vi-VN')}!
            <br>Tổng số kỳ: ${completionData?.total_periods || 'N/A'}
            <br>Tổng tiền đã thanh toán: ${formatNumber(completionData?.total_paid_amount || 0)} VNĐ
        </div>
    `);
}
// NEW: Cancel Payment Function
// async function cancelPayment(scheduleId) {
//     $.ajax({
//         url: API_BASE_URL + 'payment_schedule.php',
//         method: 'POST',
//         contentType: 'application/json',
//         data: JSON.stringify({
//             action: 'cancel_payment',
//             schedule_id: scheduleId,
//             reason: 'User cancellation',
//             cancelled_by: sessionStorage.getItem('username') // Or get from session
//         }),
//         success: await function (response) {
//             if (response.success) {
//                 //showSuccessMessage('Đã hủy thanh toán thành công');
//                 loadPaymentSchedules(); // Refresh schedules
//                 loadPaymentHistory(); // Refresh history
//                 loadContractDetails(); // Update totals
//             } else {
//                 showErrorMessage('Lỗi: ' + response.message);
//             }
//         },
//         error: function (xhr, status, error) {
//             showErrorMessage('Lỗi khi hủy thanh toán: ' + error);
//         }
//     });
// }
// Cập nhật hàm cancelPayment với auto-update trạng thái
async function cancelPayment(scheduleId) {
    // if (!confirm('Bạn có chắc chắn muốn hủy thanh toán này?')) {
    //     return;
    // }

    try {
        const response = await $.ajax({
            url: API_BASE_URL + 'payment_schedule.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                action: 'cancel_payment',
                schedule_id: scheduleId,
                reason: 'User cancellation',
                cancelled_by: sessionStorage.getItem('username') || 'USER'
            })
        });

        if (response.success) {
            // Cập nhật trạng thái hợp đồng sau khi hủy thanh toán
            if (currentContractId) {
                try {
                    const statusResponse = await $.ajax({
                        url: API_BASE_URL + 'update_single_contract_status.php',
                        method: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify({
                            contract_id: currentContractId
                        })
                    });

                    if (statusResponse.success) {
                        console.log('Cập nhật trạng thái sau hủy thanh toán:', statusResponse.data);

                        // Cập nhật UI trạng thái
                        $('#lblStatus').text(statusResponse.data.new_status);

                        if (statusResponse.data.old_status !== statusResponse.data.new_status) {
                            // showSuccessMessage(
                            //     `Đã hủy thanh toán thành công! Trạng thái hợp đồng: "${statusResponse.data.old_status}" → "${statusResponse.data.new_status}"`
                            // );
                        } else {
                            //showSuccessMessage('Đã hủy thanh toán thành công!');
                        }
                    }
                } catch (statusError) {
                    console.error('Lỗi cập nhật trạng thái sau hủy:', statusError);
                    //showSuccessMessage('Đã hủy thanh toán, nhưng không thể cập nhật trạng thái hợp đồng');
                }
            }

            // Reload data theo thứ tự
            await loadPaymentSchedules();
            await loadContractDetails();
            await loadPaymentHistory();

            // Cập nhật contract list nếu có
            if (typeof loadContracts === 'function') {
                loadContracts();
            }

        } else {
            showErrorMessage('Lỗi: ' + (response.message || 'Không thể hủy thanh toán'));
        }
    } catch (error) {
        console.error('Error canceling payment:', error);
        showErrorMessage('Lỗi khi hủy thanh toán: ' + error.message);
    }
}
// NEW: Cancel Individual Transaction
// async function cancelTransaction(transactionId) {
//     $.ajax({
//         url: API_BASE_URL + 'payment_schedule.php',
//         method: 'POST',
//         contentType: 'application/json',
//         data: JSON.stringify({
//             action: 'cancel_transaction',
//             transaction_id: transactionId,
//             reason: 'User cancellation',
//             cancelled_by: 'USER'
//         }),
//         success: await function (response) {
//             if (response.success) {
//                 showSuccessMessage('Đã hủy giao dịch thành công');
//                 loadPaymentSchedules(); // Refresh schedules
//                 loadPaymentHistory(); // Refresh history
//                 loadContractDetails(); // Update totals
//             } else {
//                 showErrorMessage('Lỗi: ' + response.message);
//             }
//         },
//         error: function (xhr, status, error) {
//             showErrorMessage('Lỗi khi hủy giao dịch: ' + error);
//         }
//     });
// }
// Cập nhật hàm cancelTransaction với auto-update trạng thái
async function cancelTransaction(transactionId) {
    if (!confirm('Bạn có chắc chắn muốn hủy giao dịch này?\nViệc này sẽ cập nhật lại số tiền còn nợ.')) {
        return;
    }

    try {
        const response = await $.ajax({
            url: API_BASE_URL + 'payment_schedule.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                action: 'cancel_transaction',
                transaction_id: transactionId,
                reason: 'User cancellation',
                cancelled_by: sessionStorage.getItem('username') || 'USER'
            })
        });

        if (response.success) {
            // Cập nhật trạng thái hợp đồng sau khi hủy giao dịch
            if (currentContractId) {
                try {
                    const statusResponse = await $.ajax({
                        url: API_BASE_URL + 'update_single_contract_status.php',
                        method: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify({
                            contract_id: currentContractId
                        })
                    });

                    if (statusResponse.success && statusResponse.data.old_status !== statusResponse.data.new_status) {
                        // Cập nhật UI trạng thái
                        $('#lblStatus').text(statusResponse.data.new_status);

                        // showSuccessMessage(
                        //     `Đã hủy giao dịch thành công! Trạng thái hợp đồng: "${statusResponse.data.old_status}" → "${statusResponse.data.new_status}"`
                        // );
                    } else {
                        showSuccessMessage('Đã hủy giao dịch thành công!');
                    }
                } catch (statusError) {
                    console.error('Lỗi cập nhật trạng thái sau hủy giao dịch:', statusError);
                    //showSuccessMessage('Đã hủy giao dịch, nhưng không thể cập nhật trạng thái hợp đồng');
                }
            }

            // Reload data theo thứ tự
            await loadPaymentSchedules();
            await loadContractDetails();
            await loadPaymentHistory();

            // Cập nhật contract list nếu có
            if (typeof loadContracts === 'function') {
                loadContracts();
            }

        } else {
            showErrorMessage('Lỗi: ' + (response.message || 'Không thể hủy giao dịch'));
        }
    } catch (error) {
        console.error('Error canceling transaction:', error);
        showErrorMessage('Lỗi khi hủy giao dịch: ' + error.message);
    }
}

// Hàm tiện ích để cập nhật trạng thái hợp đồng riêng biệt
async function updateContractStatus(contractId = null, showMessage = false) {
    const targetContractId = contractId || currentContractId;

    if (!targetContractId) {
        console.warn('Không có contract ID để cập nhật trạng thái');
        return false;
    }

    try {
        const response = await $.ajax({
            url: API_BASE_URL + 'update_single_contract_status.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                contract_id: targetContractId
            })
        });

        if (response.success) {
            console.log('Cập nhật trạng thái thành công:', response.data);

            // Cập nhật UI nếu đang xem contract này
            if (targetContractId == currentContractId) {
                $('#lblStatus').text(response.data.new_status);

                // Cập nhật class CSS cho trạng thái
                const statusElement = $('#lblStatus')[0];
                if (statusElement) {
                    statusElement.className = statusElement.className.replace(/status-\w+/g, '');
                    statusElement.classList.add('status-' + response.data.new_status.toLowerCase().replace(/\s+/g, '-'));
                }
            }

            if (showMessage && response.data.old_status !== response.data.new_status) {
                //showSuccessMessage(`Trạng thái hợp đồng đã cập nhật: "${response.data.old_status}" → "${response.data.new_status}"`);
            }

            return response.data;
        } else {
            console.warn('Lỗi cập nhật trạng thái:', response.message);
            return false;
        }
    } catch (error) {
        console.error('Lỗi khi gọi API cập nhật trạng thái:', error);
        return false;
    }
}

// async function updatePayment(scheduleId, amount) {
//     // Disable button để tránh click nhiều lần
//     const $button = $(`.pay-schedule[data-schedule-id="${scheduleId}"]`);
//     $button.prop('disabled', true);

//     $.ajax({
//         url: API_BASE_URL + 'payment_schedule.php',
//         method: 'POST',
//         contentType: 'application/json',
//         data: JSON.stringify({
//             action: 'update_payment',
//             schedule_id: scheduleId,
//             amount_paid: amount,
//             payment_date: new Date().toISOString().split('T')[0],
//             payment_method: 'cash'
//         }),
//         success: await function (response) {  // ❌ Bỏ await ở đây
//             if (response.success) {
//                 loadPaymentSchedules();
//                 loadContractDetails();
//                 loadPaymentHistory();
//             } else {
//                 showErrorMessage(response.message);
//             }
//         },
//         error: function () {
//             showErrorMessage('Lỗi khi cập nhật thanh toán');
//         },
//         complete: function () {
//             // Re-enable button
//             $button.prop('disabled', false);
//         }
//     });
// }

async function updatePayment(scheduleId, amount) {
    // Disable button để tránh click nhiều lần
    const $button = $(`.pay-schedule[data-schedule-id="${scheduleId}"]`);
    $button.prop('disabled', true);

    try {
        // Thực hiện thanh toán
        const paymentResponse = await $.ajax({
            url: API_BASE_URL + 'payment_schedule.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                action: 'update_payment',
                schedule_id: scheduleId,
                amount_paid: amount,
                payment_date: new Date().toISOString().split('T')[0],
                payment_method: 'cash'
            })
        });

        if (paymentResponse.success) {
            // Sử dụng currentContractId từ biến global
            if (currentContractId) {
                // Cập nhật trạng thái hợp đồng
                try {
                    const statusResponse = await $.ajax({
                        url: API_BASE_URL + 'update_single_contract_status.php',
                        method: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify({
                            contract_id: currentContractId
                        })
                    });

                    if (statusResponse.success) {
                        console.log('Cập nhật trạng thái thành công:', statusResponse.data);

                        // Cập nhật UI trạng thái ngay lập tức
                        $('#lblStatus').text(statusResponse.data.new_status);

                        // Hiển thị thông báo về việc cập nhật trạng thái
                        if (statusResponse.data.old_status !== statusResponse.data.new_status) {
                            // showSuccessMessage(
                            //     `Thanh toán thành công! Trạng thái hợp đồng: "${statusResponse.data.old_status}" → "${statusResponse.data.new_status}"`
                            // );
                        } else {
                            //showSuccessMessage('Thanh toán thành công!');
                        }
                    } else {
                        console.warn('Lỗi cập nhật trạng thái:', statusResponse.message);
                        //showSuccessMessage('Thanh toán thành công, nhưng có lỗi khi cập nhật trạng thái hợp đồng');
                    }
                } catch (statusError) {
                    console.error('Lỗi khi gọi API cập nhật trạng thái:', statusError);
                    //showSuccessMessage('Thanh toán thành công, nhưng không thể cập nhật trạng thái hợp đồng');
                }
            }

            // Reload các thông tin liên quan theo thứ tự
            await loadPaymentSchedules();
            await loadContractDetails();
            await loadPaymentHistory();

            // Cập nhật lại contract list nếu có
            if (typeof loadContracts === 'function') {
                loadContracts();
            }

        } else {
            showErrorMessage(paymentResponse.message || 'Có lỗi xảy ra khi thanh toán');
        }

    } catch (error) {
        console.error('Lỗi khi thực hiện thanh toán:', error);
        showErrorMessage('Lỗi khi cập nhật thanh toán');
    } finally {
        // Re-enable button
        $button.prop('disabled', false);
    }
}


function closeContract(otherMoney = 0) {
    $.ajax({
        url: API_BASE_URL + 'payment_schedule.php',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            action: 'close_contract',
            contract_id: currentContractId,
            other_money: otherMoney
        }),
        success: function (response) {
            if (response.success) {
                showSuccessMessage('Đóng hợp đồng thành công');
                $('#modal_details_pawn').modal('hide');
                refreshContractList(); // From display_contracts.js
            } else {
                showErrorMessage(response.message);
            }
        },
        error: function () {
            showErrorMessage('Lỗi khi đóng hợp đồng');
        }
    });
}

// Utility functions (reuse from display_contracts.js)
function formatDate(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`;
}

function formatNumber(number) {
    // Kiểm tra nếu number không phải là số hoặc là undefined/null
    if (number == null || isNaN(number)) return '0';

    // Chuyển đổi thành số và định dạng theo kiểu Việt Nam
    return Number(number).toLocaleString('vi-VN', { minimumFractionDigits: 0 });
}

function showSuccessMessage(message) {
    // Implement your success message display
    alert('Thành công: ' + message);
}

function showErrorMessage(message) {
    // Implement your error message display
    alert('Lỗi: ' + message);
}

// Implement other functions like updateMoneyPerPeriod, confirmCloseContract, etc. similarly