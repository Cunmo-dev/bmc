// dashboard_v2.js - Enhanced Script with better error handling and debugging

/**
 * Format số tiền theo định dạng Việt Nam
 * @param {number} amount - Số tiền
 * @returns {string} - Số tiền đã format
 */
function formatCurrency(amount) {
    if (amount === null || amount === undefined) return '0';
    return new Intl.NumberFormat('vi-VN').format(Math.round(amount));
}

/**
 * Hiển thị loading state cho dashboard với animation
 */
function showDashboardLoading() {
    const elements = [
        'lblMoneyEndDate',
        'lblTotalContract',
        'lblTotalMoneyInvestment',
        'lblTotalInterestEarn'
    ];

    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Đang tải...';
            element.style.color = '#999';
            element.style.fontSize = '14px';
        }
    });
}

/**
 * Hiển thị dữ liệu dashboard lên giao diện với validation
 * @param {Object} data - Dữ liệu từ API
 */
function displayDashboardData(data) {
    console.log('Displaying dashboard data:', data);

    // Validate data structure
    if (!data || typeof data !== 'object') {
        console.error('Invalid data structure:', data);
        displayDashboardError('Dữ liệu không hợp lệ');
        return;
    }

    try {
        // Tổng quỹ tiền mặt
        const moneyEndDateElement = document.getElementById('lblMoneyEndDate');
        if (moneyEndDateElement) {
            const totalCashFund = parseFloat(data.total_cash_fund) || 0;
            moneyEndDateElement.textContent = formatCurrency(totalCashFund);
            moneyEndDateElement.style.color = totalCashFund >= 0 ? '#716aca' : '#fd397a';
            moneyEndDateElement.style.fontSize = '24px';
            moneyEndDateElement.style.fontWeight = 'bold';
        }

        // Số hợp đồng đang vay
        const totalContractElement = document.getElementById('lblTotalContract');
        if (totalContractElement) {
            const totalContracts = parseInt(data.total_active_contracts) || 0;
            totalContractElement.textContent = totalContracts.toString();
            totalContractElement.style.color = '#fd397a';
            totalContractElement.style.fontSize = '24px';
            totalContractElement.style.fontWeight = 'bold';
        }

        // Tiền đang cho vay
        const totalMoneyInvestmentElement = document.getElementById('lblTotalMoneyInvestment');
        if (totalMoneyInvestmentElement) {
            const totalInvestment = parseFloat(data.total_money_investment) || 0;
            totalMoneyInvestmentElement.textContent = formatCurrency(totalInvestment);
            totalMoneyInvestmentElement.style.color = '#36a3f7';
            totalMoneyInvestmentElement.style.fontSize = '24px';
            totalMoneyInvestmentElement.style.fontWeight = 'bold';
        }

        // Lãi đã thu trong tháng
        const totalInterestEarnElement = document.getElementById('lblTotalInterestEarn');
        if (totalInterestEarnElement) {
            const totalInterest = parseFloat(data.total_interest_earned_month) || 0;
            totalInterestEarnElement.textContent = formatCurrency(totalInterest);
            totalInterestEarnElement.style.color = '#34bfa3';
            totalInterestEarnElement.style.fontSize = '24px';
            totalInterestEarnElement.style.fontWeight = 'bold';
        }

        // Log dữ liệu để debug - CẬP NHẬT THEO LOGIC MỚI
        if (typeof console !== 'undefined' && console.log) {
            console.log('Dashboard Data Loaded Successfully:', {
                'Tổng quỹ tiền mặt': formatCurrency(data.total_cash_fund),
                'Số HĐ đang vay': data.total_active_contracts,
                'Tiền đang cho vay': formatCurrency(data.total_money_investment),
                'Lãi đã thu': formatCurrency(data.total_interest_earned_month || data.earned_interest),
                'Logic verification': {
                    'Capital': formatCurrency(data.raw_data?.capital),
                    'Total Disbursed': formatCurrency(data.raw_data?.total_disbursed),
                    'Total Paid': formatCurrency(data.raw_data?.total_paid),
                    'Total Owed': formatCurrency(data.raw_data?.total_owed),
                    'Earned Interest = Total Paid - Total Disbursed': formatCurrency((data.raw_data?.total_paid || 0) - (data.raw_data?.total_disbursed || 0)),
                    'Loan Amount = Total Owed - Total Paid': formatCurrency((data.raw_data?.total_owed || 0) - (data.raw_data?.total_paid || 0))
                },
                'Database Info': data.database_info,
                'Timestamp': data.timestamp
            });
        }

        // Show success indicator briefly
        showSuccessIndicator();

    } catch (error) {
        console.error('Error in displayDashboardData:', error);
        displayDashboardError('Lỗi hiển thị dữ liệu: ' + error.message);
    }
}

/**
 * Hiển thị indicator thành công
 */
function showSuccessIndicator() {
    // Có thể thêm small indicator để user biết data đã được refresh
    const timestamp = new Date().toLocaleTimeString('vi-VN');
    console.log(`Dashboard updated at ${timestamp}`);

    // Optional: Show small toast or update timestamp somewhere
    const indicator = document.getElementById('dashboard_last_updated');
    if (indicator) {
        indicator.textContent = `Cập nhật lúc: ${timestamp}`;
        indicator.style.color = '#28a745';
    }
}

/**
 * Hiển thị lỗi lên giao diện dashboard với retry option
 * @param {string} message - Thông báo lỗi
 */
function displayDashboardError(message) {
    const elements = [
        'lblMoneyEndDate',
        'lblTotalContract',
        'lblTotalMoneyInvestment',
        'lblTotalInterestEarn'
    ];

    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = '<i class="fa fa-exclamation-triangle"></i> Lỗi';
            element.style.color = '#fd397a';
            element.style.fontSize = '14px';
        }
    });

    // Enhanced error reporting
    console.error('Dashboard Error:', {
        message: message,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href
    });

    // Hiển thị thông báo lỗi với retry option
    if (typeof toastr !== 'undefined') {
        toastr.error(message + '<br><button onclick="reloadDashboardData()" class="btn btn-sm btn-light mt-2">Thử lại</button>',
            'Lỗi tải dữ liệu dashboard', {
            closeButton: true,
            timeOut: 10000,
            allowHtml: true
        });
    } else if (typeof showErrorMessage === 'function') {
        showErrorMessage(message);
    } else {
        console.error('Dashboard Error:', message);
        // Don't show alert immediately, try to retry first
        setTimeout(() => {
            if (confirm('Lỗi tải dữ liệu dashboard: ' + message + '\n\nBạn có muốn thử lại không?')) {
                reloadDashboardData();
            }
        }, 1000);
    }
}

/**
 * Lấy user ID với enhanced validation
 */
async function getUserId() {
    try {
        var userID = sessionStorage.getItem('user_id');
        console.log('Retrieved user_id from sessionStorage:', userID);

        if (!userID) {
            console.warn('No user_id found in sessionStorage');
            return null;
        }

        // Nếu là staff ID (bắt đầu bằng STF)
        if (String(userID).toUpperCase().startsWith('STF')) {
            console.log('Staff ID detected, getting owner user ID...');
            sessionStorage.setItem('user_id_staff', userID);

            // Lấy owner_user_id thay vì staff user_id
            const ownerUserId = await getOwnerUserId(userID);
            console.log('Owner user ID retrieved:', ownerUserId);
            return ownerUserId;
        }

        // Nếu là owner, trả về bình thường
        return userID;
    } catch (error) {
        console.error('Error in getUserId:', error);
        return null;
    }
}

/**
 * Hàm lấy user_id của owner từ staff_id thông qua API với retry logic
 */
async function getOwnerUserId(staffId) {
    const maxRetries = 3;
    let attempt = 0;

    while (attempt < maxRetries) {
        try {
            // Lấy API_BASE_URL từ global hoặc định nghĩa mặc định
            const apiBaseUrl = (typeof API_BASE_URL !== 'undefined') ? API_BASE_URL : './api/';

            console.log(`Attempting to get owner user ID (attempt ${attempt + 1}/${maxRetries})`);

            const response = await fetch(apiBaseUrl + 'get_owner_from_staff.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'staff_id=' + encodeURIComponent(staffId)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (result.success && result.owner_user_id) {
                console.log('Successfully retrieved owner user ID:', result.owner_user_id);
                return result.owner_user_id;
            } else {
                throw new Error(result.message || 'Unknown error from API');
            }

        } catch (error) {
            attempt++;
            console.error(`Attempt ${attempt} failed:`, error);

            if (attempt < maxRetries) {
                // Wait before retry (exponential backoff)
                const waitTime = Math.pow(2, attempt) * 1000;
                console.log(`Waiting ${waitTime}ms before retry...`);
                await new Promise(resolve => setTimeout(resolve, waitTime));
            } else {
                console.error('All attempts failed for getOwnerUserId');
                return null;
            }
        }
    }
}

/**
 * Lấy shop ID với validation
 */
function getShopId() {
    const selectedShopId = localStorage.getItem('selected_shop_id');
    const defaultShopId = localStorage.getItem('store_id');
    const shopId = selectedShopId || defaultShopId;

    console.log('Shop ID retrieved:', {
        selected: selectedShopId,
        default: defaultShopId,
        final: shopId
    });

    return shopId;
}

/**
 * Tải dữ liệu dashboard từ server với enhanced error handling
 */
async function loadDashboardData() {
    console.log('=== LOADING DASHBOARD DATA ===');
    const startTime = performance.now();

    try {
        // Hiển thị loading state
        showDashboardLoading();

        // Lấy thông tin cần thiết
        const userId = await getUserId();
        const shopId = getShopId();

        console.log('Dashboard load parameters:', { userId, shopId });

        if (!shopId) {
            throw new Error('Không tìm thấy thông tin shop. Vui lòng đăng nhập lại.');
        }

        // Tạo API URL
        const apiBaseUrl = (typeof API_BASE_URL !== 'undefined') ? API_BASE_URL : './api/';
        const url = `${apiBaseUrl}dashboard_data.php`;

        // Tạo parameters
        const params = new URLSearchParams({
            shopId: shopId,
            userId: userId || '',
            timestamp: new Date().getTime() // Để tránh cache
        });

        console.log('API call:', `${url}?${params}`);

        // Gọi API bằng fetch với timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

        const response = await fetch(`${url}?${params}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        // Kiểm tra response
        if (!response.ok) {
            const errorText = await response.text();
            console.error('API Error Response:', errorText);
            throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
        }

        const data = await response.json();
        const endTime = performance.now();
        console.log(`API call completed in ${(endTime - startTime).toFixed(2)}ms`);

        // Xử lý kết quả
        if (data.success) {
            displayDashboardData(data.data);
            console.log('Dashboard data loaded successfully:', data);
        } else {
            throw new Error(data.message || 'Không thể tải dữ liệu dashboard');
        }

    } catch (error) {
        const endTime = performance.now();
        console.error(`Dashboard load failed after ${(endTime - startTime).toFixed(2)}ms:`, error);

        if (error.name === 'AbortError') {
            displayDashboardError('Timeout: Tải dữ liệu quá lâu. Vui lòng thử lại.');
        } else if (error.message.includes('Failed to fetch')) {
            displayDashboardError('Lỗi kết nối: Không thể kết nối tới server.');
        } else {
            displayDashboardError(error.message);
        }
    }
}

/**
 * Hàm reload dữ liệu dashboard (có thể được gọi từ nút Reload)
 */
function reloadDashboardData() {
    console.log('=== RELOADING DASHBOARD DATA ===');
    loadDashboardData();
}

/**
 * Khởi tạo dashboard khi trang được tải với retry logic
 */
function initDashboard() {
    console.log('=== INITIALIZING DASHBOARD ===');

    // Check if required elements exist
    const requiredElements = [
        'lblMoneyEndDate',
        'lblTotalContract',
        'lblTotalMoneyInvestment',
        'lblTotalInterestEarn'
    ];

    const missingElements = requiredElements.filter(id => !document.getElementById(id));
    if (missingElements.length > 0) {
        console.error('Missing required DOM elements:', missingElements);
        setTimeout(() => initDashboard(), 1000); // Retry after 1 second
        return;
    }

    // Tải dữ liệu lần đầu
    loadDashboardData();

    // Thiết lập auto-refresh mỗi 5 phút (300000ms)
    // Có thể điều chỉnh hoặc tắt tùy theo nhu cầu
    const refreshInterval = setInterval(function () {
        console.log('=== AUTO-REFRESHING DASHBOARD ===');
        loadDashboardData();
    }, 300000); // 5 phút

    // Store interval ID để có thể clear sau này
    window.dashboardRefreshInterval = refreshInterval;

    console.log('Dashboard initialized successfully with auto-refresh enabled');
}

/**
 * Stop auto refresh (useful for cleanup)
 */
function stopDashboardAutoRefresh() {
    if (window.dashboardRefreshInterval) {
        clearInterval(window.dashboardRefreshInterval);
        window.dashboardRefreshInterval = null;
        console.log('Dashboard auto-refresh stopped');
    }
}

/**
 * Hàm được gọi sau khi cập nhật payment để refresh dashboard
 */
async function refreshDashboardAfterPayment() {
    try {
        console.log('=== REFRESHING DASHBOARD AFTER PAYMENT ===');
        await loadDashboardData();
    } catch (error) {
        console.error('Error refreshing dashboard after payment:', error);
    }
}

/**
 * Enhanced initialization with multiple fallbacks
 */
function safeInitDashboard() {
    console.log('=== SAFE DASHBOARD INITIALIZATION ===');

    // Check if document is ready
    if (document.readyState === 'loading') {
        console.log('Document still loading, waiting...');
        document.addEventListener('DOMContentLoaded', initDashboard);
        return;
    }

    // Document is ready, init immediately
    initDashboard();
}

/**
 * Health check function
 */
async function dashboardHealthCheck() {
    try {
        const shopId = getShopId();
        if (!shopId) {
            console.warn('Health check failed: No shop ID');
            return false;
        }

        const userId = await getUserId();
        console.log('Health check passed:', { shopId, userId });
        return true;
    } catch (error) {
        console.error('Health check failed:', error);
        return false;
    }
}

/**
 * Debug function để kiểm tra trạng thái dashboard
 */
function debugDashboard() {
    console.log('=== DASHBOARD DEBUG INFO ===');
    console.log('Current time:', new Date().toISOString());
    console.log('Page URL:', window.location.href);
    console.log('User Agent:', navigator.userAgent);

    const elements = [
        'lblMoneyEndDate',
        'lblTotalContract',
        'lblTotalMoneyInvestment',
        'lblTotalInterestEarn'
    ];

    elements.forEach(id => {
        const element = document.getElementById(id);
        console.log(`Element ${id}:`, {
            exists: !!element,
            content: element?.textContent,
            styles: element ? {
                color: element.style.color,
                fontSize: element.style.fontSize
            } : null
        });
    });

    console.log('SessionStorage contents:');
    for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        console.log(`  ${key}: ${sessionStorage.getItem(key)}`);
    }

    console.log('API_BASE_URL:', typeof API_BASE_URL !== 'undefined' ? API_BASE_URL : 'undefined');
    console.log('Auto-refresh active:', !!window.dashboardRefreshInterval);
}

// Event listeners với multiple fallbacks
document.addEventListener('DOMContentLoaded', function () {
    console.log('DOM loaded via addEventListener, initializing dashboard...');
    safeInitDashboard();
});

// Fallback cho jQuery nếu có
if (typeof $ !== 'undefined') {
    $(document).ready(function () {
        console.log('jQuery ready, initializing dashboard...');
        safeInitDashboard();
    });
}

// Fallback cho window.onload
window.addEventListener