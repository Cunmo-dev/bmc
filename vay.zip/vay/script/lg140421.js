// Configuration
function getApiBaseUrl() {
    const origin = window.location.origin;
    const hostname = window.location.hostname;

    // Cấu hình cho từng môi trường
    const environments = {
        // Local development
        'localhost': '/vay/api/',
        '127.0.0.1': '/vay/api/',

        // Hosting (thay 'yourdomain.com' bằng domain thực tế)
        'yourdomain.com': '/api/',
        'www.yourdomain.com': '/api/'
    };

    // Kiểm tra IP local (192.168.x.x)
    if (hostname.startsWith('192.168.')) {
        return `${origin}/vay/api/`;
    }

    // Lấy path từ config hoặc fallback
    const apiPath = environments[hostname] || '/api/';
    return `${origin}${apiPath}`;
}

const API_BASE_URL = getApiBaseUrl();
let sessionToken = null; // Không sử dụng localStorage cho session token
let isLoggedIn = false;
let sessionMonitorInterval = null;

// Sử dụng localStorage thay vì localStorage (tốt hơn cho bảo mật)
// hoặc lưu trong memory nếu không muốn sử dụng browser storage

// Check session on load
window.addEventListener('load', function () {
    // Kiểm tra session từ localStorage thay vì localStorage
    //sessionToken = localStorage.getItem('session_token');
    sessionToken = localStorage.getItem('session_token');
    if (sessionToken) {
        checkSession();
    }
});

function showForm(formType) {
    // Toggle active buttons
    document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    // Toggle active forms
    document.querySelectorAll('.form').forEach(form => form.classList.remove('active'));
    document.getElementById(formType + '-form').classList.add('active');

    // Clear messages and form errors
    clearMessages();
    clearFormErrors();
}

function showMessage(message, type) {
    const messageArea = document.getElementById('message-area');
    messageArea.innerHTML = `<div class="message ${type}">${message}</div>`;
}

function clearMessages() {
    document.getElementById('message-area').innerHTML = '';
}

function clearFormErrors() {
    document.querySelectorAll('.form-group input.error').forEach(input => {
        input.classList.remove('error');
    });
}

function setFieldError(fieldId) {
    const field = document.getElementById(fieldId);
    if (field) {
        field.classList.add('error');
        field.focus();
    }
}

// Utility function for API calls
async function apiCall(endpoint, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',

            },
            credentials: 'include'
        };

        if (data && method !== 'GET') {
            options.body = JSON.stringify(data);
        }

        console.log('API Call:', {
            endpoint: API_BASE_URL + endpoint,
            method: method,
            data: data
        });

        const response = await fetch(API_BASE_URL + endpoint, options);

        // Check if response is ok (status 200-299)
        if (!response.ok) {
            console.error('HTTP Error:', response.status, response.statusText);
            return { success: false, message: `HTTP Error: ${response.status}` };
        }

        // Check if response has content
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const textResponse = await response.text();
            console.error('Non-JSON response:', textResponse);
            return { success: false, message: 'Server trả về dữ liệu không hợp lệ!' };
        }

        const result = await response.json();
        console.log('API Response:', result);

        return result;
    } catch (error) {
        console.error('API Network Error:', error);
        return { success: false, message: 'Lỗi kết nối đến server!' };
    }
}

// Login form handler
document.getElementById('login-form').addEventListener('submit', async function (e) {
    e.preventDefault();
    clearFormErrors();

    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;

    // Validation
    if (!username) {
        showMessage('Vui lòng nhập tên đăng nhập!', 'error');
        setFieldError('login-username');
        return;
    }

    if (!password) {
        showMessage('Vui lòng nhập mật khẩu!', 'error');
        setFieldError('login-password');
        return;
    }

    // Show loading
    const submitBtn = this.querySelector('.submit-btn');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Đang đăng nhập...';
    submitBtn.disabled = true;

    try {
        const result = await apiCall('auth.php?action=login', 'POST', {
            username: username,
            password: password
        });

        if (result.success) {
            sessionToken = result.session_token;
            //localStorage.setItem('session_token', sessionToken);
            localStorage.setItem('session_token', sessionToken);

            // Lưu thông tin user với các ID mới
            if (result.user) {
                localStorage.setItem('user_id', result.user.user_id);     // Lưu user_id
                localStorage.setItem('store_id', result.user.store_id);   // Lưu store_id
                localStorage.setItem('username', result.user.username);
                localStorage.setItem('user_email', result.user.email);
                localStorage.setItem('store_name', result.user.store_name || '');

                // Log thông tin ID để debug (có thể xóa sau)
                console.log('User ID:', result.user.user_id);
                console.log('Store ID:', result.user.store_id);
            }

            showMessage('Đăng nhập thành công! Loading...', 'success');

            // Clear form
            this.reset();

            // Chuyển hướng đến dashboard.html sau 1.5 giây
            setTimeout(() => {
                window.location.href = './dashboard.html';
            }, 500);

        } else {
            showMessage(result.message || 'Đăng nhập thất bại!', 'error');
        }
    } catch (error) {
        showMessage('Lỗi kết nối đến server!', 'error');
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
});

// Register form handler
document.getElementById('register-form').addEventListener('submit', async function (e) {
    e.preventDefault();
    clearFormErrors();

    const storeName = document.getElementById('register-store-name').value.trim();
    const username = document.getElementById('register-username').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm').value;
    const initialCapital = document.getElementById('register-initial-capital').value;
    // Validation code (giữ nguyên)...
    if (!storeName) {
        showMessage('Vui lòng nhập tên cửa hàng!', 'error');
        setFieldError('register-store-name');
        return;
    }

    if (storeName.length < 2) {
        showMessage('Tên cửa hàng phải có ít nhất 2 ký tự!', 'error');
        setFieldError('register-store-name');
        return;
    }

    if (!username) {
        showMessage('Vui lòng nhập tên đăng nhập!', 'error');
        setFieldError('register-username');
        return;
    }

    if (username.length < 3) {
        showMessage('Tên đăng nhập phải có ít nhất 3 ký tự!', 'error');
        setFieldError('register-username');
        return;
    }

    if (!email) {
        showMessage('Vui lòng nhập địa chỉ email!', 'error');
        setFieldError('register-email');
        return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showMessage('Địa chỉ email không hợp lệ!', 'error');
        setFieldError('register-email');
        return;
    }

    if (!password) {
        showMessage('Vui lòng nhập mật khẩu!', 'error');
        setFieldError('register-password');
        return;
    }

    if (password.length < 6) {
        showMessage('Mật khẩu phải có ít nhất 6 ký tự!', 'error');
        setFieldError('register-password');
        return;
    }

    if (!confirmPassword) {
        showMessage('Vui lòng xác nhận mật khẩu!', 'error');
        setFieldError('register-confirm');
        return;
    }

    if (password !== confirmPassword) {
        showMessage('Mật khẩu xác nhận không khớp!', 'error');
        setFieldError('register-confirm');
        return;
    }
    if (!initialCapital) {
        showMessage('Vui lòng nhập vốn khởi tạo!', 'error');
        setFieldError('register-initial-capital');
        return;
    }

    const capitalAmount = parseFloat(initialCapital);
    if (isNaN(capitalAmount) || capitalAmount < 0) {
        showMessage('Vốn khởi tạo phải là số dương!', 'error');
        setFieldError('register-initial-capital');
        return;
    }

    if (capitalAmount < 100000) {
        showMessage('Vốn khởi tạo không được thấp hơn 100,000 VND!', 'error');
        setFieldError('register-initial-capital');
        return;
    }
    // Show loading
    const submitBtn = this.querySelector('.submit-btn');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Đang đăng ký...';
    submitBtn.disabled = true;

    // FIXED: Proper error handling
    const result = await apiCall('auth.php?action=register', 'POST', {
        store_name: storeName,
        username: username,
        email: email,
        password: password,
        initial_capital: capitalAmount
    });

    // Reset button state
    submitBtn.textContent = originalText;
    submitBtn.disabled = false;

    // Handle response
    if (result.success) {
        // Hiển thị thông tin ID mới được tạo
        let successMessage = 'Đăng ký thành công! Vui lòng đăng nhập.';

        if (result.user && result.user.user_id && result.user.store_id) {
            successMessage += `\nUser ID: ${result.user.user_id}\nStore ID: ${result.user.store_id}`;

            // Log thông tin ID được tạo
            console.log('Tài khoản mới được tạo:');
            console.log('User ID:', result.user.user_id);
            console.log('Store ID:', result.user.store_id);
            console.log('Username:', result.user.username);
            console.log('Store Name:', result.user.store_name);
        }

        showMessage(successMessage, 'success');

        // Chuyển sang form login và clear form
        showForm('login');
        this.reset();

    } else {
        // Handle error response
        showMessage(result.message || 'Đăng ký thất bại!', 'error');

        // Highlight specific field if error relates to it
        if (result.field) {
            setFieldError('register-' + result.field);
        }
    }
});

// Input event listeners for real-time validation
document.getElementById('register-store-name').addEventListener('input', function () {
    if (this.value.trim().length >= 2) {
        this.classList.remove('error');
    }
});

document.getElementById('register-username').addEventListener('input', function () {
    if (this.value.trim().length >= 3) {
        this.classList.remove('error');
    }
});

document.getElementById('register-email').addEventListener('input', function () {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (emailRegex.test(this.value.trim())) {
        this.classList.remove('error');
    }
});

document.getElementById('register-password').addEventListener('input', function () {
    if (this.value.length >= 6) {
        this.classList.remove('error');
    }
});

document.getElementById('register-confirm').addEventListener('input', function () {
    const password = document.getElementById('register-password').value;
    if (this.value === password && password.length >= 6) {
        this.classList.remove('error');
    }
});
// THÊM SAU CÁC EVENT LISTENER KHÁC
document.getElementById('register-initial-capital').addEventListener('input', function () {
    const value = parseFloat(this.value);
    if (!isNaN(value) && value >= 100000 && value <= 1000000000) {
        this.classList.remove('error');
    }
});
// Check session validity
async function checkSession() {
    if (!sessionToken) {
        return false;
    }

    try {
        const result = await apiCall(`auth.php?action=check_session&session_token=${sessionToken}`);

        if (result.success && result.user) {
            // Nếu đang ở trang login và có session hợp lệ, chuyển hướng đến dashboard
            if (window.location.pathname.includes('login') || window.location.pathname === '/' || window.location.pathname.includes('index')) {
                window.location.href = './dashboard.html';
            }
            return true;
        } else {
            // Invalid session, clear it
            localStorage.removeItem('session_token');
            localStorage.removeItem('user_id');
            localStorage.removeItem('store_id');
            localStorage.removeItem('username');
            localStorage.removeItem('user_email');
            localStorage.removeItem('store_name');
            sessionToken = null;
            return false;
        }
    } catch (error) {
        console.error('Session check error:', error);
        return false;
    }
}

// Display user info trên dashboard (nếu có các element này)
function showDashboard(userData) {
    if (document.getElementById('user-name')) {
        document.getElementById('user-name').textContent = userData.username;
    }
    if (document.getElementById('user-email')) {
        document.getElementById('user-email').textContent = userData.email;
    }
    if (document.getElementById('store-name')) {
        document.getElementById('store-name').textContent = userData.store_name;
    }
    if (document.getElementById('user-id-display')) {
        document.getElementById('user-id-display').textContent = userData.user_id;
    }
    if (document.getElementById('store-id-display')) {
        document.getElementById('store-id-display').textContent = userData.store_id || localStorage.getItem('store_id');
    }
    if (document.getElementById('login-time')) {
        document.getElementById('login-time').textContent = new Date().toLocaleString('vi-VN');
    }
    isLoggedIn = true;
    startSessionMonitoring();
}

function startSessionMonitoring() {
    if (sessionMonitorInterval) {
        clearInterval(sessionMonitorInterval);
    }

    sessionMonitorInterval = setInterval(async () => {
        if (isLoggedIn && sessionToken) {
            await checkConcurrentLogin();
        }
    }, 10000);
}

async function checkConcurrentLogin() {
    try {
        const result = await apiCall(`session_monitor.php?session_token=${sessionToken}`);

        if (!result.valid) {
            showMessage('Tài khoản của bạn đã được đăng nhập từ nơi khác. Bạn sẽ được đăng xuất tự động.', 'error');
            setTimeout(() => {
                forceLogout();
            }, 3000);
        }
    } catch (error) {
        console.error('Session monitor error:', error);
    }
}

async function logout() {
    if (sessionMonitorInterval) {
        clearInterval(sessionMonitorInterval);
        sessionMonitorInterval = null;
    }

    if (sessionToken) {
        try {
            await apiCall(`auth.php?action=logout&session_token=${sessionToken}`);
        } catch (error) {
            console.error('Logout API error:', error);
        }
    }

    // Clear all stored data
    localStorage.clear();

    sessionToken = null;
    isLoggedIn = false;

    window.location.href = './index.html';
    showMessage('Đã đăng xuất thành công!', 'success');
}

function forceLogout() {
    logout();
    showMessage('Bạn đã được đăng xuất do đăng nhập từ nơi khác!', 'error');
}

window.addEventListener('beforeunload', function () {
    if (sessionMonitorInterval) {
        clearInterval(sessionMonitorInterval);
    }
});

// Helper functions để lấy thông tin user
function getCurrentUserInfo() {
    return {
        user_id: localStorage.getItem('user_id'),
        store_id: localStorage.getItem('store_id'),
        username: localStorage.getItem('username'),
        email: localStorage.getItem('user_email'),
        store_name: localStorage.getItem('store_name')
    };
}

function displayUserIDs() {
    const userInfo = getCurrentUserInfo();
    console.log('Current User Info:', userInfo);
    return userInfo;
}

