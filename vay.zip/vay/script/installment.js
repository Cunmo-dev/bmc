// Script để hiển thị popup khi click vào button "Thêm mới"
document.addEventListener('DOMContentLoaded', function () {
    // Kiểm tra xem jQuery đã được load chưa
    if (typeof $ === 'undefined') {
        console.error('jQuery chưa được load. Vui lòng thêm jQuery trước script này.');
        return;
    }

    // Kiểm tra Bootstrap modal
    if (typeof $.fn.modal === 'undefined') {
        console.error('Bootstrap JS chưa được load. Vui lòng thêm Bootstrap JS để sử dụng modal.');
    }


    // Đợi jQuery sẵn sàng
    $(document).ready(function () {
        // Xử lý sự kiện click vào button "Thêm mới"
        $('#btnModalCreate').on('click', function () {
            // Kiểm tra Bootstrap modal có sẵn không
            if (typeof $.fn.modal !== 'undefined') {
                // Hiển thị modal popup
                $('#modal_create_pawn').modal('show');
            } else {
                // Fallback: hiển thị modal bằng CSS
                $('#modal_create_pawn').css('display', 'block').addClass('show');
                $('body').addClass('modal-open');

                // Thêm backdrop
                if ($('.modal-backdrop').length === 0) {
                    $('body').append('<div class="modal-backdrop fade show"></div>');
                }
            }

            // Reset form về trạng thái ban đầu
            resetForm();
        });

        // Hàm reset form về trạng thái mặc định
        function resetForm() {
            // Reset các input text
            $('#hfId').val('0');
            $('#txtCustomer').val('');
            $('#txt_NewContractCustomerName').val('');
            //$('#txtCodeID').val('');
            $('#txtInfoCusomer_NumberCard').val('');
            $('#txtInfoCusomer_Phone').val('');
            $('#txtInfoCusomer_CardDate').val('');
            $('#txtInfoCusomer_Place').val('');
            $('#txtInfoCusomer_Address').val('');
            $('#txtTotalMoney').val('0');
            $('#txtTotalMoneyReceived').val('0');
            $('#txtLoanTime').val('50');
            $('#txtFrequency').val('1');
            $('#txtStrFromDate').val('');
            $('#txtNote').val('');
            loadNextContractCode();
            // Reset radio buttons
            $('#re_ContractTypeCustomer-Success').prop('checked', true);
            $('#re_ContractTypeCustomer-Stop').prop('checked', false);

            // Reset checkbox
            $('#IsBefore').prop('checked', false);

            // Hiển thị/ẩn div theo mặc định
            $('#dv_oldContractCustomerName').show();
            $('#dv_newContractCustomerName').hide();
            $('#dv_cmndDetail').hide();

            // Reset select boxes về giá trị mặc định
            $('#m-select-ratetype_create').val('0').trigger('change');
            $('#m-select-staff').val($('#m-select-staff option:first').val()).trigger('change');
            $('#m_pawn_create_affID').val('0').trigger('change');
            $('#m_pawn_create_AffTypeMoney').val('2').trigger('change');

            // Ẩn các thông báo lỗi
            $('.text-danger[id$="-errorMess"]').hide();
            $('#lbl_error_interest').hide();
            $('#messageNotUpdate').hide();

            // Reset title modal
            $('#titleFormPawn').text('Thêm mới Hợp đồng');

            // Hiển thị button in
            $('#dvPrint').show();
        }

        // Xử lý sự kiện thay đổi loại khách hàng
        function onchangerContractTypeCustomer() {
            if ($('#re_ContractTypeCustomer-Stop').is(':checked')) {
                // Khách hàng mới
                $('#dv_oldContractCustomerName').hide();
                $('#dv_newContractCustomerName').show();
            } else {
                // Khách hàng cũ
                $('#dv_oldContractCustomerName').show();
                $('#dv_newContractCustomerName').hide();
            }
        }

        // Gán sự kiện cho radio buttons
        $('input[name="re_ContractTypeCustomer"]').on('change', onchangerContractTypeCustomer);

        // Xử lý đóng modal
        $('#btnCloseModalPawn, .btn-warning[data-dismiss="modal"]').on('click', function () {
            if (typeof $.fn.modal !== 'undefined') {
                $('#modal_create_pawn').modal('hide');
            } else {
                // Fallback: ẩn modal bằng CSS
                $('#modal_create_pawn').css('display', 'none').removeClass('show');
                $('body').removeClass('modal-open');
                $('.modal-backdrop').remove();
            }
        });

        // Xử lý click backdrop để đóng modal
        $(document).on('click', '.modal-backdrop', function () {
            if (typeof $.fn.modal !== 'undefined') {
                $('#modal_create_pawn').modal('hide');
            } else {
                $('#modal_create_pawn').css('display', 'none').removeClass('show');
                $('body').removeClass('modal-open');
                $('.modal-backdrop').remove();
            }
        });
    });
});

// Hàm có thể gọi từ ngoài để mở popup
function showCreatePawnModal() {
    if (typeof $ !== 'undefined') {
        if (typeof $.fn.modal !== 'undefined') {
            $('#modal_create_pawn').modal('show');
        } else {
            $('#modal_create_pawn').css('display', 'block').addClass('show');
            $('body').addClass('modal-open');
            if ($('.modal-backdrop').length === 0) {
                $('body').append('<div class="modal-backdrop fade show"></div>');
            }
        }
    }
}

// Hàm đóng popup
function hideCreatePawnModal() {
    if (typeof $ !== 'undefined') {
        if (typeof $.fn.modal !== 'undefined') {
            $('#modal_create_pawn').modal('hide');
        } else {
            $('#modal_create_pawn').css('display', 'none').removeClass('show');
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
        }
    }
}

// Hàm xử lý thay đổi loại khách hàng (để tương thích với onclick trong HTML)
function onchangerContractTypeCustomer() {
    if ($('#re_ContractTypeCustomer-Stop').is(':checked')) {
        $('#dv_oldContractCustomerName').hide();
        $('#dv_newContractCustomerName').show();
    } else {
        $('#dv_oldContractCustomerName').show();
        $('#dv_newContractCustomerName').hide();
    }
}
async function SaveInstallmentExcel() {
    try {
        // Kiểm tra xem có dữ liệu hiển thị không
        if (!contractsData || contractsData.length === 0) {
            showErrorMessage('Không có dữ liệu để xuất Excel');
            return;
        }

        // Gửi dữ liệu hiện tại đang hiển thị lên server
        const response = await fetch(API_BASE_URL + 'export_installment_contracts.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                contracts: JSON.stringify(contractsData),
                shopId: await getShopId(),
                userId: await getUserId(),
                searchInfo: buildSearchInfoString(), // Thông tin filter hiện tại
                format: 'xlsx'
            })
        });

        if (!response.ok) {
            throw new Error('Lỗi server: ' + response.status);
        }

        // Tạo blob và download file
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `Danh_sach_hop_dong_tra_gop_${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        window.URL.revokeObjectURL(url);

    } catch (error) {
        console.error('Excel export error:', error);
        showErrorMessage('Có lỗi xảy ra khi xuất Excel: ' + error.message);
    }
}

async function SaveInstallmentTommorowExcel1() {
    try {
        // Kiểm tra xem có dữ liệu hiển thị không
        if (!contractsData || contractsData.length === 0) {
            showErrorMessage('Không có dữ liệu để xuất Excel');
            return;
        }

        // Gửi dữ liệu hiện tại đang hiển thị lên server
        const response = await fetch(API_BASE_URL + 'export_installment_tomorrow_contracts.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                contracts: JSON.stringify(contractsData),
                shopId: await getShopId(),
                userId: await getUserId(),
                searchInfo: buildSearchInfoString(), // Thông tin filter hiện tại
                format: 'xlsx'
            })
        });

        if (!response.ok) {
            throw new Error('Lỗi server: ' + response.status);
        }

        // Tạo blob và download file
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `Danh_sach_hop_dong_tra_gop_${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        window.URL.revokeObjectURL(url);

    } catch (error) {
        console.error('Excel export error:', error);
        showErrorMessage('Có lỗi xảy ra khi xuất Excel: ' + error.message);
    }
}

function handleExportExcel() {
    if (isTomorrowInstallment) {
        SaveInstallmentTommorowExcel1(); // Gọi hàm xuất Excel cho "Ngày mai đóng họ"
    } else {
        SaveInstallmentExcel(); // Gọi hàm xuất Excel thông thường
    }
}

// Load XLSX library first
function ensureXLSXLibrary() {
    return new Promise((resolve, reject) => {
        if (typeof XLSX !== 'undefined') {
            resolve();
            return;
        }

        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
        script.onload = () => resolve();
        script.onerror = () => reject(new Error('Failed to load XLSX library'));
        document.head.appendChild(script);
    });
}

// Hàm moveDataExcel() - Mở popup upload dữ liệu Excel
async function moveDataExcel() {
    // Load XLSX library first
    try {
        await ensureXLSXLibrary();
        console.log('XLSX library loaded successfully');
    } catch (error) {
        console.warn('Failed to load XLSX library, will use CSV only mode');
    }

    // Lấy thông tin từ localStorage
    const userId = localStorage.getItem('user_id');
    const shopId = localStorage.getItem('selected_shop_id');

    // Tạo HTML cho modal popup
    const modalHTML = `
        <div class="modal fade" id="modalUploadExcel" tabindex="-1" role="dialog" aria-labelledby="modalUploadExcelLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalUploadExcelLabel">Upload Dữ Liệu Hợp Đồng</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Form upload -->
                        <form id="uploadFormModal" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="modal_user_id">User ID:</label>
                                        <input type="text" class="form-control" id="modal_user_id" name="user_id" value="${userId}" required readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="modal_shop_id">Shop ID:</label>
                                        <input type="text" class="form-control" id="modal_shop_id" name="shop_id" value="${shopId}" required readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Chọn file Excel (.xlsx, .xls) hoặc CSV:</label>
                                <div class="file-upload-area-modal" onclick="document.getElementById('modal_excel_file').click()">
                                    <div class="upload-icon-modal">📄</div>
                                    <div class="upload-text-modal">Nhấp để chọn file hoặc kéo thả file vào đây</div>
                                    <div class="file-types-modal">Hỗ trợ: .xlsx, .xls, .csv (Tối đa 10MB)</div>
                                </div>
                                <input type="file" id="modal_excel_file" name="excel_file" accept=".xlsx,.xls,.csv" style="display: none;" required>
                                <div id="modal-file-name" class="mt-2" style="display: none;"></div>
                            </div>

                            <!-- Progress bar -->
                            <div class="progress-container-modal" id="modalProgressContainer" style="display: none;">
                                <div class="progress">
                                    <div class="progress-bar bg-primary" id="modalProgressFill" role="progressbar" style="width: 0%"></div>
                                </div>
                                <div class="text-center mt-2" id="modalProgressText">Đang xử lý...</div>
                            </div>
                        </form>

                        <!-- Kết quả -->
                        <div id="modalResult"></div>

                        <!-- Hướng dẫn định dạng -->
                        <div class="mt-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="alert alert-info mt-2">
                                        <small>
                                            <strong>Lưu ý:</strong>
                                            <ul class="mb-0">
                                                <li>Dữ liệu là file excel được export từ tab Trả Góp trong trang 2gold</li>
                                            </ul>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                        <button type="button" class="btn btn-primary" id="modalUploadBtn">
                            <i class="fa fa-upload"></i> Upload Dữ Liệu
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;

    // CSS cho modal
    const modalCSS = `
        <style>
        .file-upload-area-modal {
            border: 2px dashed #ddd;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .file-upload-area-modal:hover {
            border-color: #007bff;
            background-color: #f0f8ff;
        }
        .file-upload-area-modal.dragover {
            border-color: #007bff;
            background-color: #f0f8ff;
            transform: scale(1.02);
        }
        .upload-icon-modal {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 15px;
        }
        .upload-text-modal {
            color: #666;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .file-types-modal {
            color: #999;
            font-size: 12px;
        }
        #modal-file-name {
            padding: 8px 12px;
            background: #e8f5e8;
            border-radius: 5px;
            color: #2d5a2d;
            font-size: 14px;
        }
        </style>
    `;

    // Thêm CSS vào head nếu chưa có
    if (!document.getElementById('uploadModalCSS')) {
        const styleElement = document.createElement('div');
        styleElement.id = 'uploadModalCSS';
        styleElement.innerHTML = modalCSS;
        document.head.appendChild(styleElement);
    }

    // Xóa modal cũ nếu tồn tại
    const existingModal = document.getElementById('modalUploadExcel');
    if (existingModal) {
        existingModal.remove();
    }

    // Thêm modal vào body
    document.body.insertAdjacentHTML('beforeend', modalHTML);

    // Setup event listeners cho modal
    setupModalEventListeners();

    // Hiển thị modal
    $('#modalUploadExcel').modal('show');
}

// Setup event listeners cho modal
function setupModalEventListeners() {
    const fileInput = document.getElementById('modal_excel_file');
    const fileUploadArea = document.querySelector('.file-upload-area-modal');
    const fileName = document.getElementById('modal-file-name');
    const uploadBtn = document.getElementById('modalUploadBtn');
    const resultDiv = document.getElementById('modalResult');
    const progressContainer = document.getElementById('modalProgressContainer');
    const progressFill = document.getElementById('modalProgressFill');
    const progressText = document.getElementById('modalProgressText');

    // Drag & drop functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, () => fileUploadArea.classList.add('dragover'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, () => fileUploadArea.classList.remove('dragover'), false);
    });

    fileUploadArea.addEventListener('drop', handleDrop, false);

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files.length > 0) {
            fileInput.files = files;
            displayFileName(files[0]);
        }
    }

    // File input change
    fileInput.addEventListener('change', function (e) {
        if (e.target.files.length > 0) {
            displayFileName(e.target.files[0]);
        }
    });

    function displayFileName(file) {
        const allowedTypes = ['.xlsx', '.xls', '.csv'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();

        if (!allowedTypes.includes(fileExtension)) {
            showModalAlert('Vui lòng chọn file Excel (.xlsx, .xls) hoặc CSV!', 'danger');
            fileInput.value = '';
            fileName.style.display = 'none';
            return;
        }

        if (file.size > 10 * 1024 * 1024) { // 10MB
            showModalAlert('File quá lớn! Vui lòng chọn file nhỏ hơn 10MB.', 'danger');
            fileInput.value = '';
            fileName.style.display = 'none';
            return;
        }

        fileName.textContent = `📄 ${file.name} (${formatFileSize(file.size)})`;
        fileName.style.display = 'block';
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Upload button click
    uploadBtn.addEventListener('click', function () {
        const userId = document.getElementById('modal_user_id').value.trim();
        const shopId = document.getElementById('modal_shop_id').value.trim();
        const file = fileInput.files[0];

        if (!userId || !shopId || !file) {
            showModalAlert('Vui lòng điền đầy đủ thông tin và chọn file!', 'danger');
            return;
        }

        // Show progress
        progressContainer.style.display = 'block';
        uploadBtn.disabled = true;

        // Process file
        processExcelFile(file, userId, shopId);
    });

    // Function to process Excel/CSV file
    function processExcelFile(file, userId, shopId) {
        progressFill.style.width = '10%';
        progressText.textContent = 'Đang đọc file...';

        const reader = new FileReader();
        const fileExtension = file.name.split('.').pop().toLowerCase();

        reader.onload = function (e) {
            try {
                progressFill.style.width = '30%';
                progressText.textContent = 'Đang xử lý dữ liệu...';

                let data;

                if (fileExtension === 'csv') {
                    // Process CSV
                    console.log('Processing CSV file');
                    data = processCSVData(e.target.result);
                } else if ((fileExtension === 'xlsx' || fileExtension === 'xls') && typeof XLSX !== 'undefined') {
                    // Process Excel with XLSX library
                    console.log('Processing Excel file with XLSX library');
                    const workbook = XLSX.read(e.target.result, { type: 'array' });
                    const firstSheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[firstSheetName];
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                    data = processExcelData(jsonData);
                } else {
                    // Fallback: try to parse as CSV even if it's Excel
                    console.log('XLSX library not available, trying CSV parsing');
                    showModalAlert('Thư viện XLSX chưa load. Vui lòng chọn file CSV hoặc thử lại sau.', 'warning');
                    uploadBtn.disabled = false;
                    progressContainer.style.display = 'none';
                    return;
                }

                if (!data || data.length === 0) {
                    throw new Error('Không có dữ liệu hợp lệ trong file');
                }

                progressFill.style.width = '60%';
                progressText.textContent = 'Đang chuyển đổi định dạng...';

                // Convert to TXT format and upload
                const txtData = convertToTXTFormat(data);

                if (!txtData || txtData.trim() === '') {
                    throw new Error('Không thể chuyển đổi dữ liệu sang định dạng TXT');
                }

                console.log('Converted TXT data preview:', txtData.substring(0, 200) + '...');
                uploadTXTData(txtData, userId, shopId);

            } catch (error) {
                console.error('Error processing file:', error);
                showModalAlert(`Lỗi xử lý file: ${error.message}. Vui lòng kiểm tra định dạng file.`, 'danger');
                uploadBtn.disabled = false;
                progressContainer.style.display = 'none';
            }
        };

        reader.onerror = function () {
            showModalAlert('Lỗi đọc file! Vui lòng thử lại.', 'danger');
            uploadBtn.disabled = false;
            progressContainer.style.display = 'none';
        };

        // Read file based on type
        if (fileExtension === 'csv') {
            reader.readAsText(file, 'UTF-8');
        } else {
            reader.readAsArrayBuffer(file);
        }
    }

    function processCSVData(csvText) {
        console.log('Processing CSV data...');
        const lines = csvText.split(/\r?\n/); // Handle both \r\n and \n
        const data = [];

        // Skip header row (index 0) and process data rows
        for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (line) {
                // Handle CSV with commas inside quotes
                const row = parseCSVLine(line);
                if (row.length > 0) {
                    data.push(row);
                }
            }
        }

        console.log('CSV processed, rows:', data.length);
        return data;
    }

    function parseCSVLine(line) {
        const result = [];
        let current = '';
        let inQuotes = false;
        let i = 0;

        while (i < line.length) {
            const char = line[i];

            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                result.push(current.trim());
                current = '';
            } else {
                current += char;
            }
            i++;
        }

        // Add the last field
        result.push(current.trim());

        return result.map(cell => cell.replace(/^"|"$/g, '')); // Remove quotes
    }

    function processExcelData(jsonData) {
        console.log('Processing Excel data...');
        const data = jsonData.slice(1).filter(row => {
            // Filter out empty rows
            return row && row.some(cell => cell !== null && cell !== undefined && cell !== '');
        });

        console.log('Excel processed, rows:', data.length);
        return data;
    }

    function convertToTXTFormat(data) {
        console.log('Converting to TXT format...');
        const txtLines = [];

        // Add header line first (server expects to skip this)
        const headerLine = "Mã HĐ|Tên KH|SĐT|Trả Góp|Tiền giao khách|Tỷ lệ|Ngày bốc|Ngày hết hạn|Đã đóng đến ngày|Đã đóng được|Tiền còn phải đóng|Ngày đóng họ tiếp theo|Tiền thu theo kỳ|Tiền nợ|CMND/CCCD";
        txtLines.push(headerLine);

        data.forEach((row, index) => {
            try {
                // Ensure we have exactly 15 columns
                const processedRow = [];

                for (let i = 0; i < 15; i++) {
                    let cellValue = '';

                    if (i < row.length && row[i] !== null && row[i] !== undefined) {
                        cellValue = String(row[i]).trim();

                        // Handle dates - convert if needed
                        if (i === 6 || i === 7 || i === 8 || i === 11) { // Date columns
                            cellValue = formatDate(cellValue);
                        }

                        // Handle numbers - remove extra formatting
                        if (i === 3 || i === 4 || i === 9 || i === 10 || i === 12 || i === 13) { // Number columns
                            cellValue = formatNumber(cellValue);
                        }
                    }

                    processedRow.push(cellValue);
                }

                // Join with | separator
                const txtLine = processedRow.join('|');
                txtLines.push(txtLine);

            } catch (error) {
                console.error(`Error processing row ${index}:`, error);
            }
        });

        const result = txtLines.join('\n');
        console.log('TXT conversion completed, total lines (including header):', txtLines.length);
        console.log('Data lines:', txtLines.length - 1);
        return result;
    }

    function formatDate(dateValue) {
        if (!dateValue) return '';

        // If already in dd-mm-yyyy format
        if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(dateValue)) {
            return dateValue;
        }

        // Try to parse various date formats
        let date;

        // Handle Excel serial date numbers
        if (typeof dateValue === 'number') {
            date = new Date((dateValue - 25569) * 86400 * 1000);
        } else {
            // Try common date formats
            const dateStr = String(dateValue);
            if (dateStr.includes('/')) {
                const parts = dateStr.split('/');
                if (parts.length === 3) {
                    // Assume mm/dd/yyyy or dd/mm/yyyy
                    date = new Date(parts[2], parts[1] - 1, parts[0]);
                }
            } else if (dateStr.includes('-')) {
                date = new Date(dateStr);
            }
        }

        if (date && !isNaN(date)) {
            // Format as dd-mm-yyyy
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const year = date.getFullYear();
            return `${day}-${month}-${year}`;
        }

        return String(dateValue);
    }

    function formatNumber(numValue) {
        if (!numValue) return '';

        // Remove any currency symbols and extra spaces
        let cleanValue = String(numValue).replace(/[₫$€£¥]/g, '').trim();

        // If it's already a clean number, return as is
        if (/^\d+(,\d{3})*(\.\d+)?$/.test(cleanValue)) {
            return cleanValue;
        }

        // Try to parse as number and format
        const parsed = parseFloat(cleanValue.replace(/,/g, ''));
        if (!isNaN(parsed)) {
            return parsed.toLocaleString('vi-VN');
        }

        return String(numValue);
    }

    function uploadTXTData(txtData, userId, shopId) {
        progressFill.style.width = '80%';
        progressText.textContent = 'Đang upload lên server...';

        // Create a blob with TXT data
        const blob = new Blob([txtData], { type: 'text/plain;charset=utf-8' });
        const formData = new FormData();

        formData.append('user_id', userId);
        formData.append('shop_id', shopId);
        formData.append('excel_file', blob, 'converted_data.txt');
        formData.append('action', 'upload_contracts');

        console.log('Uploading TXT data to server...');

        // Upload using XMLHttpRequest for progress tracking
        const xhr = new XMLHttpRequest();

        xhr.upload.addEventListener('progress', function (e) {
            if (e.lengthComputable) {
                const uploadProgress = 80 + (e.loaded / e.total) * 20; // 80% to 100%
                progressFill.style.width = uploadProgress + '%';
                progressText.textContent = `Đang upload... (${Math.round(uploadProgress)}%)`;
            }
        });

        xhr.addEventListener('load', function () {
            progressFill.style.width = '100%';
            progressText.textContent = 'Hoàn thành!';

            if (xhr.status === 200) {
                try {
                    console.log('Server response:', xhr.responseText);
                    const response = JSON.parse(xhr.responseText);
                    handleUploadResponse(response);
                } catch (error) {
                    console.error('JSON Parse Error:', error);
                    console.error('Response text:', xhr.responseText);

                    if (xhr.responseText.includes('<br />') || xhr.responseText.includes('<b>')) {
                        showModalAlert('Lỗi PHP trên server. Kiểm tra console để xem chi tiết.', 'danger');
                    } else {
                        showModalAlert('Lỗi xử lý phản hồi từ server!', 'danger');
                    }
                }
            } else {
                showModalAlert(`Lỗi HTTP: ${xhr.status} - ${xhr.statusText}`, 'danger');
            }

            setTimeout(() => {
                uploadBtn.disabled = false;
                progressContainer.style.display = 'none';
            }, 2000);
        });

        xhr.addEventListener('error', function () {
            showModalAlert('Lỗi kết nối! Vui lòng kiểm tra internet và thử lại.', 'danger');
            uploadBtn.disabled = false;
            progressContainer.style.display = 'none';
        });

        xhr.addEventListener('timeout', function () {
            showModalAlert('Quá thời gian chờ! Vui lòng thử lại.', 'danger');
            uploadBtn.disabled = false;
            progressContainer.style.display = 'none';
        });

        xhr.timeout = 120000; // 2 minutes timeout

        // Determine the correct API endpoint
        let apiEndpoint = API_BASE_URL + 'upload_process.php';

        // Fallback if API_BASE_URL is not defined
        if (typeof API_BASE_URL === 'undefined') {
            const origin = window.location.origin;
            apiEndpoint = origin + '/vay/api/upload_process.php';
        }

        console.log('API Endpoint:', apiEndpoint);
        xhr.open('POST', apiEndpoint, true);
        xhr.send(formData);
    }

    function handleUploadResponse(response) {
        if (response.success) {
            let successMessage = `
                <div class="alert alert-success">
                    <h5>✅ Upload thành công!</h5>
                    <p><strong>Tổng số dòng xử lý:</strong> ${response.total_rows}</p>
                    <p><strong>Số hợp đồng được tạo:</strong> ${response.success_count}</p>
                    <p><strong>Số lỗi:</strong> ${response.error_count}</p>
                </div>
            `;

            if (response.errors && response.errors.length > 0) {
                successMessage += '<div class="alert alert-danger"><h6>Chi tiết lỗi:</h6><ul>';
                response.errors.forEach(error => {
                    successMessage += `<li>Dòng ${error.row}: ${error.message}</li>`;
                });
                successMessage += '</ul></div>';
            }

            resultDiv.innerHTML = successMessage;

            // Reload contracts list if function exists
            if (typeof loadContracts === 'function') {
                setTimeout(() => {
                    loadContracts();
                }, 2000);
            }

        } else {
            showModalAlert(`Lỗi upload: ${response.message}`, 'danger');
        }
    }

    function showModalAlert(message, type) {
        const alertClass = `alert-${type}`;
        const alertHTML = `
            <div class="alert ${alertClass} alert-dismissible fade show">
                ${message}
                <button type="button" class="close" data-dismiss="alert">
                    <span>&times;</span>
                </button>
            </div>
        `;
        resultDiv.innerHTML = alertHTML;
    }
}

//--------------------------------

// Hàm addDataExcelNew() - Mở popup upload dữ liệu Excel với định dạng mới
async function addDataExcelNew() {
    // Load XLSX library first
    try {
        await ensureXLSXLibrary();
        console.log('XLSX library loaded successfully');
    } catch (error) {
        console.warn('Failed to load XLSX library, will use CSV only mode');
    }

    // Lấy thông tin từ localStorage
    const userId = localStorage.getItem('user_id');
    const shopId = localStorage.getItem('selected_shop_id');

    // Tạo HTML cho modal popup
    const modalHTML = `
        <div class="modal fade" id="modalUploadExcelNew" tabindex="-1" role="dialog" aria-labelledby="modalUploadExcelNewLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalUploadExcelNewLabel">Upload Dữ Liệu Hợp Đồng Mới</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Form upload -->
                        <form id="uploadFormModalNew" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="modal_new_user_id">User ID:</label>
                                        <input type="text" class="form-control" id="modal_new_user_id" name="user_id" value="${userId}" required readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="modal_new_shop_id">Shop ID:</label>
                                        <input type="text" class="form-control" id="modal_new_shop_id" name="shop_id" value="${shopId}" required readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Chọn file Excel (.xlsx, .xls) hoặc CSV:</label>
                                <div class="file-upload-area-modal-new" onclick="document.getElementById('modal_new_excel_file').click()">
                                    <div class="upload-icon-modal">📄</div>
                                    <div class="upload-text-modal">Nhấp để chọn file hoặc kéo thả file vào đây</div>
                                    <div class="file-types-modal">Hỗ trợ: .xlsx, .xls, .csv (Tối đa 10MB)</div>
                                </div>
                                <input type="file" id="modal_new_excel_file" name="excel_file" accept=".xlsx,.xls,.csv" style="display: none;" required>
                                <div id="modal-new-file-name" class="mt-2" style="display: none;"></div>
                            </div>

                            <!-- Progress bar -->
                            <div class="progress-container-modal" id="modalNewProgressContainer" style="display: none;">
                                <div class="progress">
                                    <div class="progress-bar bg-primary" id="modalNewProgressFill" role="progressbar" style="width: 0%"></div>
                                </div>
                                <div class="text-center mt-2" id="modalNewProgressText">Đang xử lý...</div>
                            </div>
                        </form>

                        <!-- Kết quả -->
                        <div id="modalNewResult"></div>

                        <!-- Hướng dẫn định dạng -->
                        <div class="mt-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="alert alert-info mt-2">
                                        <small>
                                            <strong>Lưu ý:</strong>
                                            <ul class="mb-0">
                                                <li>File Excel phải có định dạng với các cột: Ngày, Mã KH-Tên_Đời Máy, IMEI, Gói Vay, Doanh thu, Phí cài máy, Thực chi, Đóng trước, Ngày Đóng Trước, Số ngày, Tiền đóng/Ngài, Nhân viên cài đặt</li>
                                                <li>Dữ liệu bắt đầu từ dòng thứ 2 (dòng đầu là header)</li>
                                            </ul>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                        <button type="button" class="btn btn-primary" id="modalNewUploadBtn">
                            <i class="fa fa-upload"></i> Upload Dữ Liệu
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;

    // CSS cho modal (sử dụng lại CSS cũ với class mới)
    const modalCSS = `
        <style>
        .file-upload-area-modal-new {
            border: 2px dashed #ddd;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .file-upload-area-modal-new:hover {
            border-color: #007bff;
            background-color: #f0f8ff;
        }
        .file-upload-area-modal-new.dragover {
            border-color: #007bff;
            background-color: #f0f8ff;
            transform: scale(1.02);
        }
        </style>
    `;

    // Thêm CSS vào head nếu chưa có
    if (!document.getElementById('uploadModalNewCSS')) {
        const styleElement = document.createElement('div');
        styleElement.id = 'uploadModalNewCSS';
        styleElement.innerHTML = modalCSS;
        document.head.appendChild(styleElement);
    }

    // Xóa modal cũ nếu tồn tại
    const existingModal = document.getElementById('modalUploadExcelNew');
    if (existingModal) {
        existingModal.remove();
    }

    // Thêm modal vào body
    document.body.insertAdjacentHTML('beforeend', modalHTML);

    // Setup event listeners cho modal
    setupModalNewEventListeners();

    // Hiển thị modal
    $('#modalUploadExcelNew').modal('show');
}

// Setup event listeners cho modal mới
function setupModalNewEventListeners() {
    const fileInput = document.getElementById('modal_new_excel_file');
    const fileUploadArea = document.querySelector('.file-upload-area-modal-new');
    const fileName = document.getElementById('modal-new-file-name');
    const uploadBtn = document.getElementById('modalNewUploadBtn');
    const resultDiv = document.getElementById('modalNewResult');
    const progressContainer = document.getElementById('modalNewProgressContainer');
    const progressFill = document.getElementById('modalNewProgressFill');
    const progressText = document.getElementById('modalNewProgressText');

    // Drag & drop functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, () => fileUploadArea.classList.add('dragover'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, () => fileUploadArea.classList.remove('dragover'), false);
    });

    fileUploadArea.addEventListener('drop', handleDrop, false);

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files.length > 0) {
            fileInput.files = files;
            displayFileName(files[0]);
        }
    }

    // File input change
    fileInput.addEventListener('change', function (e) {
        if (e.target.files.length > 0) {
            displayFileName(e.target.files[0]);
        }
    });

    function displayFileName(file) {
        const allowedTypes = ['.xlsx', '.xls', '.csv'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();

        if (!allowedTypes.includes(fileExtension)) {
            showModalNewAlert('Vui lòng chọn file Excel (.xlsx, .xls) hoặc CSV!', 'danger');
            fileInput.value = '';
            fileName.style.display = 'none';
            return;
        }

        if (file.size > 10 * 1024 * 1024) { // 10MB
            showModalNewAlert('File quá lớn! Vui lòng chọn file nhỏ hơn 10MB.', 'danger');
            fileInput.value = '';
            fileName.style.display = 'none';
            return;
        }

        fileName.textContent = `📄 ${file.name} (${formatFileSize(file.size)})`;
        fileName.style.display = 'block';
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Upload button click
    uploadBtn.addEventListener('click', function () {
        const userId = document.getElementById('modal_new_user_id').value.trim();
        const shopId = document.getElementById('modal_new_shop_id').value.trim();
        const file = fileInput.files[0];

        if (!userId || !shopId || !file) {
            showModalNewAlert('Vui lòng điền đầy đủ thông tin và chọn file!', 'danger');
            return;
        }

        // Show progress
        progressContainer.style.display = 'block';
        uploadBtn.disabled = true;

        // Process file
        processExcelFileNew(file, userId, shopId);
    });

    // Function to process Excel/CSV file with new format
    function processExcelFileNew(file, userId, shopId) {
        progressFill.style.width = '10%';
        progressText.textContent = 'Đang đọc file...';

        const reader = new FileReader();
        const fileExtension = file.name.split('.').pop().toLowerCase();

        reader.onload = function (e) {
            try {
                progressFill.style.width = '30%';
                progressText.textContent = 'Đang xử lý dữ liệu...';

                let data;

                if (fileExtension === 'csv') {
                    // Process CSV
                    console.log('Processing CSV file with new format');
                    data = processCSVDataNew(e.target.result);
                } else if ((fileExtension === 'xlsx' || fileExtension === 'xls') && typeof XLSX !== 'undefined') {
                    // Process Excel with XLSX library
                    console.log('Processing Excel file with new format and XLSX library');
                    const workbook = XLSX.read(e.target.result, { type: 'array' });
                    const firstSheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[firstSheetName];
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                    data = processExcelDataNew(jsonData);
                } else {
                    console.log('XLSX library not available, trying CSV parsing');
                    showModalNewAlert('Thư viện XLSX chưa load. Vui lòng chọn file CSV hoặc thử lại sau.', 'warning');
                    uploadBtn.disabled = false;
                    progressContainer.style.display = 'none';
                    return;
                }

                if (!data || data.length === 0) {
                    throw new Error('Không có dữ liệu hợp lệ trong file');
                }

                progressFill.style.width = '60%';
                progressText.textContent = 'Đang chuyển đổi định dạng...';

                // Convert to contract format and upload
                convertAndUploadNewContracts(data, userId, shopId);

            } catch (error) {
                console.error('Error processing file:', error);
                showModalNewAlert(`Lỗi xử lý file: ${error.message}. Vui lòng kiểm tra định dạng file.`, 'danger');
                uploadBtn.disabled = false;
                progressContainer.style.display = 'none';
            }
        };

        reader.onerror = function () {
            showModalNewAlert('Lỗi đọc file! Vui lòng thử lại.', 'danger');
            uploadBtn.disabled = false;
            progressContainer.style.display = 'none';
        };

        // Read file based on type
        if (fileExtension === 'csv') {
            reader.readAsText(file, 'UTF-8');
        } else {
            reader.readAsArrayBuffer(file);
        }
    }

    function processCSVDataNew(csvText) {
        console.log('Processing CSV data with new format...');
        const lines = csvText.split(/\r?\n/);
        const data = [];

        // Skip header row (index 0) and process data rows
        for (let i = 2; i < lines.length; i++) { // Bắt đầu từ dòng thứ 3 (index 2)
            const line = lines[i].trim();
            if (line) {
                const row = parseCSVLine(line);
                if (row.length > 0) {
                    data.push(row);
                }
            }
        }

        console.log('CSV processed with new format, rows:', data.length);
        return data;
    }

    function parseCSVLine(line) {
        const result = [];
        let current = '';
        let inQuotes = false;
        let i = 0;

        while (i < line.length) {
            const char = line[i];

            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                result.push(current.trim());
                current = '';
            } else {
                current += char;
            }
            i++;
        }

        result.push(current.trim());
        return result.map(cell => cell.replace(/^"|"$/g, ''));
    }

    function processExcelDataNew(jsonData) {
        console.log('Processing Excel data with new format...');
        // Skip first 2 rows (header rows) and filter out empty rows
        const data = jsonData.slice(2).filter(row => {
            return row && row.some(cell => cell !== null && cell !== undefined && cell !== '');
        });

        console.log('Excel processed with new format, rows:', data.length);
        return data;
    }

    async function convertAndUploadNewContracts(data, userId, shopId) {
        console.log('Converting to contract format...');
        const contracts = [];
        let successCount = 0;
        let errorCount = 0;
        const errors = [];

        // Lấy mã hợp đồng đầu tiên
        let currentCode = await getNextContractCode();
        let baseCodeNumber = parseInt(currentCode.replace(/\D/g, '')) || 1; // Lấy số từ mã
        let codePrefix = currentCode.replace(/\d+/g, ''); // Lấy phần prefix (HD, HĐ, etc.)

        console.log('Starting with code:', currentCode, 'Base number:', baseCodeNumber, 'Prefix:', codePrefix);

        for (let i = 0; i < data.length; i++) {
            try {
                const row = data[i];

                // Tạo mã hợp đồng tuần tự
                const sequentialCode = codePrefix + (baseCodeNumber + i).toString();

                console.log(`Row ${i + 1}: Generated code ${sequentialCode}`);

                // Mapping theo định dạng mới:
                // B: Ngày, C: Mã KH-Tên_Đời Máy, D: IMEI, E: Gói Vay, F: Doanh thu, 
                // G: Phí cài máy, H: Thực chi, I: Đóng trước, J: Ngày Đóng Trước, 
                // K: Số ngày, L: Tiền đóng/Ngài, M: Nhân viên cài đặt

                const contractData = {
                    userId: userId,
                    shopId: shopId,
                    codeId: sequentialCode,
                    typeId: 1, // Default type
                    customerId: 0,
                    customerName: row[2] || '', // Cột C: Mã KH-Tên_Đời Máy
                    customerPhone: '',
                    customerNumberCard: row[3] || '', // Cột D: IMEI (sử dụng làm số điện thoại/CMND)
                    customerAddress: '',
                    customerCardDate: '',
                    customerPlace: '',
                    totalMoney: parseFloat(row[5]) || 0, // Cột F: Doanh thu (Trả Góp)
                    totalMoneyReceived: parseFloat(row[4]) || 0, // Cột E: Gói Vay (Tiền giao khách)
                    rateType: 1, // Default rate type
                    loanTime: parseInt(row[10]) || 30, // Cột K: Số ngày (loan_time)
                    frequency: parseInt(row[9]) || 1, // Cột I: Đóng trước (frequency)
                    fromDate: formatDateNew(row[1]) || new Date().toISOString().split('T')[0], // Cột B: Ngày
                    isBefore: false,
                    note: `IMEI: ${row[3] || ''}, Phí cài: ${row[6] || ''}, Thực chi: ${row[7] || ''}`,
                    staffId: row[13] || '', // Cột M: Nhân viên cài đặt
                    editLoan: 0
                };

                contracts.push(contractData);

            } catch (error) {
                errorCount++;
                errors.push({
                    row: i + 3, // +3 vì bắt đầu từ dòng thứ 3 trong Excel
                    message: error.message
                });
                console.error(`Error processing row ${i + 3}:`, error);
            }
        }

        if (contracts.length === 0) {
            throw new Error('Không có hợp đồng nào được tạo');
        }

        console.log(`Generated ${contracts.length} contracts with codes from ${contracts[0].codeId} to ${contracts[contracts.length - 1].codeId}`);

        progressFill.style.width = '80%';
        progressText.textContent = 'Đang upload lên server...';

        // Upload contracts to server
        uploadNewContracts(contracts, successCount, errorCount, errors);
    }

    function formatDateNew(dateValue) {
        if (!dateValue) return '';

        // If already in YYYY-MM-DD format
        if (/^\d{4}-\d{2}-\d{2}$/.test(dateValue)) {
            return dateValue;
        }

        // Handle Excel serial date numbers
        if (typeof dateValue === 'number') {
            const date = new Date((dateValue - 25569) * 86400 * 1000);
            if (!isNaN(date)) {
                return date.toISOString().split('T')[0];
            }
        }

        // Try to parse various date formats
        const dateStr = String(dateValue);
        let date;

        if (dateStr.includes('/')) {
            const parts = dateStr.split('/');
            if (parts.length === 3) {
                // Assume dd/mm/yyyy
                date = new Date(parts[2], parts[1] - 1, parts[0]);
            }
        } else if (dateStr.includes('-')) {
            date = new Date(dateStr);
        }

        if (date && !isNaN(date)) {
            return date.toISOString().split('T')[0];
        }

        return new Date().toISOString().split('T')[0];
    }

    async function getNextContractCode() {
        return new Promise((resolve, reject) => {
            getUserId1().then(function (userId) {
                var shopId = getShopId();

                console.log('Loading contract code with userId:', userId, 'shopId:', shopId);

                if (!userId || !shopId) {
                    console.error('Missing userId or shopId:', { userId, shopId });
                    resolve('HD' + Date.now().toString().slice(-8));
                    return;
                }

                $.ajax({
                    url: API_BASE_URL + 'get_next_contract_code.php',
                    method: 'GET',
                    data: {
                        userId: userId,
                        shopId: shopId
                    },
                    dataType: 'json',
                    success: function (response) {
                        if (response && response.success) {
                            resolve(response.next_code);
                            console.log('Auto-generated contract code:', response.next_code);
                        } else {
                            console.error('Error getting next contract code:', response.message);
                            resolve('HD' + Date.now().toString().slice(-8));
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('AJAX Error getting contract code:', error);
                        resolve('HD' + Date.now().toString().slice(-8));
                    }
                });
            }).catch(function (error) {
                console.error('Error getting userId:', error);
                resolve('HD' + Date.now().toString().slice(-8));
            });
        });
    }

    // Helper functions needed for getNextContractCode
    async function getUserId1() {
        var userID = localStorage.getItem('user_id');
        if (!userID) return null;

        // Nếu là staff ID (bắt đầu bằng STF)
        if (String(userID).toUpperCase().startsWith('STF')) {
            // Lấy owner_user_id thay vì staff user_id
            const ownerUserId = await getOwnerUserId(userID);
            console.log(ownerUserId);
            return ownerUserId;
        }

        // Nếu là owner, trả về bình thường
        return userID;
    }

    // Hàm lấy user_id của owner từ staff_id thông qua API
    async function getOwnerUserId(staffId) {
        try {
            const response = await fetch(API_BASE_URL + 'get_owner_from_staff.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'staff_id=' + encodeURIComponent(staffId)
            });

            const result = await response.json();

            if (result.success && result.owner_user_id) {
                return result.owner_user_id;
            } else {
                console.error('Lỗi lấy owner user_id từ staff_id:', result.message);
                return null;
            }
        } catch (error) {
            console.error('Lỗi kết nối API:', error);
            return null;
        }
    }

    function getShopId() {
        var selectedShopId = localStorage.getItem('selected_shop_id');
        var defaultShopId = localStorage.getItem('store_id');
        return selectedShopId;
    }

    function uploadNewContracts(contracts, successCount, errorCount, errors) {
        progressFill.style.width = '90%';
        progressText.textContent = 'Đang lưu hợp đồng...';

        // Create form data
        const formData = new FormData();
        formData.append('action', 'upload_new_contracts');
        formData.append('contracts', JSON.stringify(contracts));

        // Upload using XMLHttpRequest
        const xhr = new XMLHttpRequest();

        xhr.addEventListener('load', function () {
            progressFill.style.width = '100%';
            progressText.textContent = 'Hoàn thành!';

            if (xhr.status === 200) {
                try {
                    console.log('Raw server response:', xhr.responseText);

                    // Clean up response - remove any HTML warnings/errors before JSON
                    let cleanResponse = xhr.responseText;

                    // Find the start of JSON (first '{' character)
                    const jsonStart = cleanResponse.indexOf('{');
                    if (jsonStart > 0) {
                        console.log('Found HTML content before JSON, cleaning...');
                        cleanResponse = cleanResponse.substring(jsonStart);
                    }

                    console.log('Cleaned response:', cleanResponse);

                    const response = JSON.parse(cleanResponse);
                    handleNewUploadResponse(response, errors);
                } catch (error) {
                    console.error('JSON Parse Error:', error);
                    console.error('Response text:', xhr.responseText);

                    // Try to extract meaningful error from HTML response
                    if (xhr.responseText.includes('Warning') || xhr.responseText.includes('Error')) {
                        showModalNewAlert('Có lỗi PHP trên server. Kiểm tra console để xem chi tiết.', 'warning');
                    } else {
                        showModalNewAlert('Lỗi xử lý phản hồi từ server!', 'danger');
                    }
                }
            } else {
                showModalNewAlert(`Lỗi HTTP: ${xhr.status} - ${xhr.statusText}`, 'danger');
            }

            setTimeout(() => {
                uploadBtn.disabled = false;
                progressContainer.style.display = 'none';
            }, 2000);
        });

        xhr.addEventListener('error', function () {
            showModalNewAlert('Lỗi kết nối! Vui lòng kiểm tra internet và thử lại.', 'danger');
            uploadBtn.disabled = false;
            progressContainer.style.display = 'none';
        });

        xhr.addEventListener('timeout', function () {
            showModalNewAlert('Quá thời gian chờ! Vui lòng thử lại.', 'danger');
            uploadBtn.disabled = false;
            progressContainer.style.display = 'none';
        });

        xhr.timeout = 120000; // 2 minutes timeout

        // Determine the correct API endpoint
        let apiEndpoint = API_BASE_URL + 'upload_new_contracts.php';

        // Fallback if API_BASE_URL is not defined
        if (typeof API_BASE_URL === 'undefined') {
            const origin = window.location.origin;
            apiEndpoint = origin + '/vay/api/upload_new_contracts.php';
        }

        console.log('API Endpoint:', apiEndpoint);
        xhr.open('POST', apiEndpoint, true);
        xhr.send(formData);
    }

    function handleNewUploadResponse(response, processingErrors) {
        if (response.success) {
            let successMessage = `
                <div class="alert alert-success">
                    <h5>✅ Upload hoàn thành!</h5>
                    <p><strong>Tổng số hợp đồng xử lý:</strong> ${response.total_contracts}</p>
                    <p><strong>Số hợp đồng được tạo:</strong> ${response.success_count}</p>
                    <p><strong>Số hợp đồng trùng lặp (bỏ qua):</strong> ${response.duplicate_count || 0}</p>
                    <p><strong>Số lỗi:</strong> ${response.error_count}</p>
                </div>
            `;

            // Hiển thị thông tin tóm tắt chi tiết
            if (response.summary) {
                successMessage += `
                    <div class="alert alert-info">
                        <h6>📊 Thống kê chi tiết:</h6>
                        <ul class="mb-0">
                            <li>Đã xử lý: ${response.summary.processed} hợp đồng</li>
                            <li>Tạo mới thành công: ${response.summary.created} hợp đồng</li>
                            <li>Bỏ qua do trùng lặp: ${response.summary.duplicates_skipped} hợp đồng</li>
                            <li>Lỗi: ${response.summary.errors} hợp đồng</li>
                        </ul>
                    </div>
                `;
            }

            // Hiển thị cảnh báo nếu có trùng lặp
            if (response.duplicate_count && response.duplicate_count > 0) {
                successMessage += `
                    <div class="alert alert-warning">
                        <h6>⚠️ Cảnh báo:</h6>
                        <p>Có ${response.duplicate_count} hợp đồng bị trùng lặp mã và đã được bỏ qua. 
                        Điều này có thể do bạn đã upload file này trước đó.</p>
                    </div>
                `;
            }

            // Hiển thị lỗi từ quá trình xử lý file
            if (processingErrors && processingErrors.length > 0) {
                successMessage += '<div class="alert alert-warning"><h6>Lỗi xử lý file:</h6><ul>';
                processingErrors.forEach(error => {
                    successMessage += `<li>Dòng ${error.row}: ${error.message}</li>`;
                });
                successMessage += '</ul></div>';
            }

            // Hiển thị lỗi từ server (bao gồm cả duplicate)
            if (response.errors && response.errors.length > 0) {
                // Phân loại lỗi
                const duplicateErrors = response.errors.filter(error => error.includes('đã tồn tại'));
                const otherErrors = response.errors.filter(error => !error.includes('đã tồn tại'));

                // Hiển thị lỗi trùng lặp (chỉ hiển thị 10 đầu tiên để tránh quá dài)
                if (duplicateErrors.length > 0) {
                    successMessage += '<div class="alert alert-warning"><h6>📋 Hợp đồng trùng lặp (đã bỏ qua):</h6><ul>';
                    duplicateErrors.slice(0, 10).forEach(error => {
                        successMessage += `<li>${error}</li>`;
                    });
                    if (duplicateErrors.length > 10) {
                        successMessage += `<li><i>... và ${duplicateErrors.length - 10} hợp đồng trùng lặp khác</i></li>`;
                    }
                    successMessage += '</ul></div>';
                }

                // Hiển thị lỗi khác
                if (otherErrors.length > 0) {
                    successMessage += '<div class="alert alert-danger"><h6>❌ Lỗi xử lý:</h6><ul>';
                    otherErrors.forEach(error => {
                        successMessage += `<li>${error}</li>`;
                    });
                    successMessage += '</ul></div>';
                }
            }

            // Hiển thị gợi ý nếu tất cả đều trùng lặp
            if (response.duplicate_count === response.total_contracts) {
                successMessage += `
                    <div class="alert alert-info">
                        <h6>💡 Gợi ý:</h6>
                        <p>Tất cả hợp đồng trong file này đã tồn tại trong hệ thống. 
                        Vui lòng kiểm tra lại file hoặc sử dụng file dữ liệu mới.</p>
                    </div>
                `;
            }

            resultDiv.innerHTML = successMessage;

            // Reload contracts list if function exists
            if (typeof loadContracts === 'function') {
                setTimeout(() => {
                    loadContracts();
                }, 2000);
            }

        } else {
            showModalNewAlert(`Lỗi upload: ${response.message}`, 'danger');
        }
    }

    function showModalNewAlert(message, type) {
        const alertClass = `alert-${type}`;
        const alertHTML = `
            <div class="alert ${alertClass} alert-dismissible fade show">
                ${message}
                <button type="button" class="close" data-dismiss="alert">
                    <span>&times;</span>
                </button>
            </div>
        `;
        resultDiv.innerHTML = alertHTML;
    }
}