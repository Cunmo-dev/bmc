// ================== CONTRACTS DISPLAY MANAGER ==================
$(document).ready(function () {
    initializeContractsDisplay();
});

let currentPage = 1;
let currentLimit = 50;
let currentSearch = '';
let currentStatus = 'all';
let contractsData = [];

async function initializeContractsDisplay() {
    //console.log('Initializing Contracts Display...');

    // Load contracts on page load
    await loadContracts1();

    // Bind search events
    bindSearchEvents();

    // Bind filter events
    bindFilterEvents();

    // Bind pagination events
    bindPaginationEvents();

    // Auto refresh every 30 seconds
    // setInterval(function () {
    //     loadContracts1(false); // Silent refresh
    // }, 30000);
}
// Script để hiển thị datepicker khi click vào input ngày tháng
document.addEventListener('DOMContentLoaded', function () {
    // Kiểm tra jQuery
    if (typeof $ === 'undefined') {
        console.error('jQuery chưa được load. Vui lòng thêm jQuery trước script này.');
        return;
    }

    $(document).ready(function () {
        let currentDatepicker = null;
        let currentInput = null;

        // Khởi tạo datepicker cho các input có class m_datepicker
        $('.m_datepicker').on('click focus', function (e) {
            e.preventDefault();
            e.stopPropagation();

            currentInput = $(this);
            showDatepicker(this);
        });

        // Xử lý click vào icon calendar
        $('.la-calendar').parent().parent().on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();

            const input = $(this).closest('.m-input-icon').find('.m_datepicker');
            currentInput = input;
            showDatepicker(input[0]);
        });

        // Hàm hiển thị datepicker
        function showDatepicker(inputElement) {
            // Ẩn datepicker hiện tại nếu có
            hideDatepicker();

            const $input = $(inputElement);
            const offset = $input.offset();
            const height = $input.outerHeight();

            // Tạo datepicker HTML
            const datepickerHtml = createDatepickerHtml();

            // Thêm datepicker vào body
            $('body').append(datepickerHtml);

            currentDatepicker = $('.datepicker').last();

            // Định vị datepicker
            currentDatepicker.css({
                'position': 'absolute',
                'top': (offset.top + height + 5) + 'px',
                'left': offset.left + 'px',
                'z-index': '9999',
                'display': 'block'
            });

            // Thiết lập ngày hiện tại
            setupCurrentDate();

            // Gán sự kiện cho datepicker
            bindDatepickerEvents();
        }

        // Hàm tạo HTML datepicker
        function createDatepickerHtml() {
            const currentDate = new Date();
            const currentMonth = currentDate.getMonth();
            const currentYear = currentDate.getFullYear();
            const currentDay = currentDate.getDate();

            return `
                <div class="datepicker datepicker-dropdown dropdown-menu datepicker-orient-left datepicker-orient-bottom">
                    <div class="datepicker-days">
                        <table class="table-condensed">
                            <thead>
                                <tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr>
                                <tr>
                                    <th class="prev"><i class="la la-angle-left"></i></th>
                                    <th colspan="5" class="datepicker-switch">Tháng ${currentMonth + 1} ${currentYear}</th>
                                    <th class="next"><i class="la la-angle-right"></i></th>
                                </tr>
                                <tr>
                                    <th class="dow">CN</th><th class="dow">T2</th><th class="dow">T3</th>
                                    <th class="dow">T4</th><th class="dow">T5</th><th class="dow">T6</th><th class="dow">T7</th>
                                </tr>
                            </thead>
                            <tbody id="datepicker-calendar-body">
                                ${generateCalendarDays(currentYear, currentMonth, currentDay)}
                            </tbody>
                            <tfoot>
                                <tr><th colspan="7" class="today" style="display: table-cell;">Hôm nay</th></tr>
                                <tr><th colspan="7" class="clear" style="display: table-cell;">Xóa</th></tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            `;
        }

        // Hàm tạo các ngày trong tháng
        function generateCalendarDays(year, month, currentDay) {
            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const daysInMonth = lastDay.getDate();
            const startDay = firstDay.getDay(); // 0 = Sunday

            let html = '';
            let day = 1;

            // Tạo 6 tuần
            for (let week = 0; week < 6; week++) {
                html += '<tr>';

                // Tạo 7 ngày trong tuần
                for (let dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
                    if (week === 0 && dayOfWeek < startDay) {
                        // Ngày của tháng trước
                        const prevMonth = new Date(year, month, 0);
                        const prevDay = prevMonth.getDate() - (startDay - dayOfWeek - 1);
                        html += `<td class="old day" data-date="${new Date(year, month - 1, prevDay).getTime()}">${prevDay}</td>`;
                    } else if (day <= daysInMonth) {
                        // Ngày trong tháng hiện tại
                        const isToday = (day === currentDay && month === new Date().getMonth() && year === new Date().getFullYear());
                        const todayClass = isToday ? ' today' : '';
                        html += `<td class="day${todayClass}" data-date="${new Date(year, month, day).getTime()}">${day}</td>`;
                        day++;
                    } else {
                        // Ngày của tháng sau
                        const nextDay = day - daysInMonth;
                        html += `<td class="new day" data-date="${new Date(year, month + 1, nextDay).getTime()}">${nextDay}</td>`;
                        day++;
                    }
                }

                html += '</tr>';

                if (day > daysInMonth + 7) break;
            }

            return html;
        }

        // Hàm thiết lập ngày hiện tại
        function setupCurrentDate() {
            // Highlight ngày hôm nay
            currentDatepicker.find('.today').addClass('focused');
        }

        // Hàm gán sự kiện cho datepicker
        function bindDatepickerEvents() {
            // Click vào ngày
            currentDatepicker.on('click', '.day', function (e) {
                e.stopPropagation();
                const date = new Date(parseInt($(this).data('date')));
                const formattedDate = formatDate(date);

                if (currentInput) {
                    currentInput.val(formattedDate);
                    currentInput.trigger('change');
                }

                hideDatepicker();
            });

            // Click "Hôm nay"
            currentDatepicker.on('click', '.today', function (e) {
                e.stopPropagation();
                const today = new Date();
                const formattedDate = formatDate(today);

                if (currentInput) {
                    currentInput.val(formattedDate);
                    currentInput.trigger('change');
                }

                hideDatepicker();
            });

            // Click "Xóa"
            currentDatepicker.on('click', '.clear', function (e) {
                e.stopPropagation();

                if (currentInput) {
                    currentInput.val('');
                    currentInput.trigger('change');
                }

                hideDatepicker();
            });

            // Chuyển tháng
            currentDatepicker.on('click', '.prev', function (e) {
                e.stopPropagation();
                changeMonth(-1);
            });

            currentDatepicker.on('click', '.next', function (e) {
                e.stopPropagation();
                changeMonth(1);
            });
        }

        // Hàm thay đổi tháng
        function changeMonth(delta) {
            const currentTitle = currentDatepicker.find('.datepicker-switch').text();
            const [monthStr, year] = currentTitle.split(' ');
            const monthNames = ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6',
                'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'];

            let currentMonth = monthNames.indexOf(monthStr);
            let currentYear = parseInt(year);

            currentMonth += delta;

            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            } else if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }

            // Cập nhật tiêu đề
            currentDatepicker.find('.datepicker-switch').text(`${monthNames[currentMonth]} ${currentYear}`);

            // Cập nhật calendar
            const today = new Date();
            const currentDay = (currentMonth === today.getMonth() && currentYear === today.getFullYear()) ? today.getDate() : -1;
            currentDatepicker.find('#datepicker-calendar-body').html(generateCalendarDays(currentYear, currentMonth, currentDay));
        }

        // Hàm format ngày
        // function formatDate(date) {
        //     const day = String(date.getDate()).padStart(2, '0');
        //     const month = String(date.getMonth() + 1).padStart(2, '0');
        //     const year = date.getFullYear();
        //     return `${day}/${month}/${year}`;
        // }

        // Hàm ẩn datepicker
        function hideDatepicker() {
            if (currentDatepicker) {
                currentDatepicker.remove();
                currentDatepicker = null;
            }
        }

        // Ẩn datepicker khi click ra ngoài
        $(document).on('click', function (e) {
            if (!$(e.target).closest('.datepicker, .m_datepicker, .la-calendar').length) {
                hideDatepicker();
            }
        });

        // Ẩn datepicker khi nhấn Escape
        $(document).on('keydown', function (e) {
            if (e.key === 'Escape') {
                hideDatepicker();
            }
        });
    });
});

// JavaScript đơn giản để xử lý dropdown
document.addEventListener('DOMContentLoaded', function () {
    const loanTimeSelect = document.getElementById('m-search-loanTime');
    const statusSelect = document.getElementById('m-search-status');

    // Xử lý thay đổi thời gian
    loanTimeSelect.addEventListener('change', function () {
        const selectedValue = this.value;
        const selectedText = this.options[this.selectedIndex].text;

        console.log('Thời gian được chọn:', {
            value: selectedValue,
            text: selectedText
        });

        handleLoanTimeChange(selectedValue, selectedText);
    });

    // Xử lý thay đổi trạng thái
    statusSelect.addEventListener('change', function () {
        const selectedValue = this.value;
        const selectedText = this.options[this.selectedIndex].text;

        console.log('Trạng thái được chọn:', {
            value: selectedValue,
            text: selectedText
        });

        handleStatusChange(selectedValue, selectedText);
    });
});

// Hàm xử lý khi thay đổi thời gian
function handleLoanTimeChange(value, text) {
    console.log('Lọc theo thời gian:', value, text);

    // Thêm logic xử lý của bạn tại đây
    // Ví dụ: gọi API, filter dữ liệu, etc.

    applyFilters();
}

// Hàm xử lý khi thay đổi trạng thái
function handleStatusChange(value, text) {
    console.log('Lọc theo trạng thái:', value, text);

    // Thêm logic xử lý của bạn tại đây
    // Ví dụ: gọi API, filter dữ liệu, etc.

    applyFilters();
}

// Hàm áp dụng bộ lọc
function applyFilters() {
    const loanTime = document.getElementById('m-search-loanTime').value;
    const status = document.getElementById('m-search-status').value;

    const loanTimeText = document.getElementById('m-search-loanTime').options[document.getElementById('m-search-loanTime').selectedIndex].text;
    const statusText = document.getElementById('m-search-status').options[document.getElementById('m-search-status').selectedIndex].text;

    console.log('Áp dụng bộ lọc:', {
        loanTime: { value: loanTime, text: loanTimeText },
        status: { value: status, text: statusText }
    });

    // Thêm logic lọc dữ liệu chính của bạn tại đây
    // Ví dụ:
    // - Gọi API với parameters
    // - Filter table data
    // - Reload danh sách
}

// Hàm reset về mặc định
function resetFilters() {
    document.getElementById('m-search-loanTime').selectedIndex = 0;
    document.getElementById('m-search-status').selectedIndex = 0;
    applyFilters();
}

// Hàm lấy giá trị hiện tại
function getCurrentFilters() {
    return {
        loanTime: document.getElementById('m-search-loanTime').value,
        status: document.getElementById('m-search-status').value
    };
}

// Hàm set giá trị
function setFilters(loanTime, status) {
    if (loanTime !== undefined) {
        document.getElementById('m-search-loanTime').value = loanTime;
    }
    if (status !== undefined) {
        document.getElementById('m-search-status').value = status;
    }
    applyFilters();
}

// Script để hiển thị datepicker khi click vào input ngày tháng
document.addEventListener('DOMContentLoaded', function () {
    // Kiểm tra jQuery
    if (typeof $ === 'undefined') {
        console.error('jQuery chưa được load. Vui lòng thêm jQuery trước script này.');
        return;
    }

    $(document).ready(function () {
        let currentDatepicker = null;
        let currentInput = null;

        // Khởi tạo datepicker cho các input có class m_datepicker
        $('.m_datepicker').on('click focus', function (e) {
            e.preventDefault();
            e.stopPropagation();

            currentInput = $(this);
            showDatepicker(this);
        });

        // Xử lý click vào icon calendar
        $('.la-calendar').parent().parent().on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();

            const input = $(this).closest('.m-input-icon').find('.m_datepicker');
            currentInput = input;
            showDatepicker(input[0]);
        });

        // Hàm hiển thị datepicker
        function showDatepicker(inputElement) {
            // Ẩn datepicker hiện tại nếu có
            hideDatepicker();

            const $input = $(inputElement);
            const offset = $input.offset();
            const height = $input.outerHeight();

            // Tạo datepicker HTML
            const datepickerHtml = createDatepickerHtml();

            // Thêm datepicker vào body
            $('body').append(datepickerHtml);

            currentDatepicker = $('.datepicker').last();

            // Định vị datepicker
            currentDatepicker.css({
                'position': 'absolute',
                'top': (offset.top + height + 5) + 'px',
                'left': offset.left + 'px',
                'z-index': '9999',
                'display': 'block'
            });

            // Thiết lập ngày hiện tại
            setupCurrentDate();

            // Gán sự kiện cho datepicker
            bindDatepickerEvents();
        }

        // Hàm tạo HTML datepicker
        function createDatepickerHtml() {
            const currentDate = new Date();
            const currentMonth = currentDate.getMonth();
            const currentYear = currentDate.getFullYear();
            const currentDay = currentDate.getDate();

            return `
                <div class="datepicker datepicker-dropdown dropdown-menu datepicker-orient-left datepicker-orient-bottom">
                    <div class="datepicker-days">
                        <table class="table-condensed">
                            <thead>
                                <tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr>
                                <tr>
                                    <th class="prev"><i class="la la-angle-left"></i></th>
                                    <th colspan="5" class="datepicker-switch">Tháng ${currentMonth + 1} ${currentYear}</th>
                                    <th class="next"><i class="la la-angle-right"></i></th>
                                </tr>
                                <tr>
                                    <th class="dow">CN</th><th class="dow">T2</th><th class="dow">T3</th>
                                    <th class="dow">T4</th><th class="dow">T5</th><th class="dow">T6</th><th class="dow">T7</th>
                                </tr>
                            </thead>
                            <tbody id="datepicker-calendar-body">
                                ${generateCalendarDays(currentYear, currentMonth, currentDay)}
                            </tbody>
                            <tfoot>
                                <tr><th colspan="7" class="today" style="display: table-cell;">Hôm nay</th></tr>
                                <tr><th colspan="7" class="clear" style="display: table-cell;">Xóa</th></tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            `;
        }

        // Hàm tạo các ngày trong tháng
        function generateCalendarDays(year, month, currentDay) {
            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const daysInMonth = lastDay.getDate();
            const startDay = firstDay.getDay(); // 0 = Sunday

            let html = '';
            let day = 1;

            // Tạo 6 tuần
            for (let week = 0; week < 6; week++) {
                html += '<tr>';

                // Tạo 7 ngày trong tuần
                for (let dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
                    if (week === 0 && dayOfWeek < startDay) {
                        // Ngày của tháng trước
                        const prevMonth = new Date(year, month, 0);
                        const prevDay = prevMonth.getDate() - (startDay - dayOfWeek - 1);
                        html += `<td class="old day" data-date="${new Date(year, month - 1, prevDay).getTime()}">${prevDay}</td>`;
                    } else if (day <= daysInMonth) {
                        // Ngày trong tháng hiện tại
                        const isToday = (day === currentDay && month === new Date().getMonth() && year === new Date().getFullYear());
                        const todayClass = isToday ? ' today' : '';
                        html += `<td class="day${todayClass}" data-date="${new Date(year, month, day).getTime()}">${day}</td>`;
                        day++;
                    } else {
                        // Ngày của tháng sau
                        const nextDay = day - daysInMonth;
                        html += `<td class="new day" data-date="${new Date(year, month + 1, nextDay).getTime()}">${nextDay}</td>`;
                        day++;
                    }
                }

                html += '</tr>';

                if (day > daysInMonth + 7) break;
            }

            return html;
        }

        // Hàm thiết lập ngày hiện tại
        function setupCurrentDate() {
            // Highlight ngày hôm nay
            currentDatepicker.find('.today').addClass('focused');
        }

        // Hàm gán sự kiện cho datepicker
        function bindDatepickerEvents() {
            // Click vào ngày
            currentDatepicker.on('click', '.day', function (e) {
                e.stopPropagation();
                const date = new Date(parseInt($(this).data('date')));
                const formattedDate = formatDate(date);

                if (currentInput) {
                    currentInput.val(formattedDate);
                    currentInput.trigger('change');
                }

                hideDatepicker();
            });

            // Click "Hôm nay"
            currentDatepicker.on('click', '.today', function (e) {
                e.stopPropagation();
                const today = new Date();
                const formattedDate = formatDate(today);

                if (currentInput) {
                    currentInput.val(formattedDate);
                    currentInput.trigger('change');
                }

                hideDatepicker();
            });

            // Click "Xóa"
            currentDatepicker.on('click', '.clear', function (e) {
                e.stopPropagation();

                if (currentInput) {
                    currentInput.val('');
                    currentInput.trigger('change');
                }

                hideDatepicker();
            });

            // Chuyển tháng
            currentDatepicker.on('click', '.prev', function (e) {
                e.stopPropagation();
                changeMonth(-1);
            });

            currentDatepicker.on('click', '.next', function (e) {
                e.stopPropagation();
                changeMonth(1);
            });
        }

        // Hàm thay đổi tháng
        function changeMonth(delta) {
            const currentTitle = currentDatepicker.find('.datepicker-switch').text();
            const [monthStr, year] = currentTitle.split(' ');
            const monthNames = ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6',
                'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'];

            let currentMonth = monthNames.indexOf(monthStr);
            let currentYear = parseInt(year);

            currentMonth += delta;

            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            } else if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }

            // Cập nhật tiêu đề
            currentDatepicker.find('.datepicker-switch').text(`${monthNames[currentMonth]} ${currentYear}`);

            // Cập nhật calendar
            const today = new Date();
            const currentDay = (currentMonth === today.getMonth() && currentYear === today.getFullYear()) ? today.getDate() : -1;
            currentDatepicker.find('#datepicker-calendar-body').html(generateCalendarDays(currentYear, currentMonth, currentDay));
        }

        // Hàm format ngày
        function formatDate(date) {
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const year = date.getFullYear();
            return `${day}/${month}/${year}`;
        }

        // Hàm ẩn datepicker
        function hideDatepicker() {
            if (currentDatepicker) {
                currentDatepicker.remove();
                currentDatepicker = null;
            }
        }

        // Ẩn datepicker khi click ra ngoài
        $(document).on('click', function (e) {
            if (!$(e.target).closest('.datepicker, .m_datepicker, .la-calendar').length) {
                hideDatepicker();
            }
        });

        // Ẩn datepicker khi nhấn Escape
        $(document).on('keydown', function (e) {
            if (e.key === 'Escape') {
                hideDatepicker();
            }
        });
    });
});

// JavaScript đơn giản để xử lý dropdown
document.addEventListener('DOMContentLoaded', function () {
    const loanTimeSelect = document.getElementById('m-search-loanTime');
    const statusSelect = document.getElementById('m-search-status');

    // Xử lý thay đổi thời gian
    loanTimeSelect.addEventListener('change', function () {
        const selectedValue = this.value;
        const selectedText = this.options[this.selectedIndex].text;

        console.log('Thời gian được chọn:', {
            value: selectedValue,
            text: selectedText
        });

        handleLoanTimeChange(selectedValue, selectedText);
    });

    // Xử lý thay đổi trạng thái
    statusSelect.addEventListener('change', function () {
        const selectedValue = this.value;
        const selectedText = this.options[this.selectedIndex].text;

        console.log('Trạng thái được chọn:', {
            value: selectedValue,
            text: selectedText
        });

        handleStatusChange(selectedValue, selectedText);
    });
});

// Hàm xử lý khi thay đổi thời gian
function handleLoanTimeChange(value, text) {
    console.log('Lọc theo thời gian:', value, text);

    // Thêm logic xử lý của bạn tại đây
    // Ví dụ: gọi API, filter dữ liệu, etc.

    applyFilters();
}

// Hàm xử lý khi thay đổi trạng thái
function handleStatusChange(value, text) {
    console.log('Lọc theo trạng thái:', value, text);

    // Thêm logic xử lý của bạn tại đây
    // Ví dụ: gọi API, filter dữ liệu, etc.

    applyFilters();
}

// Hàm áp dụng bộ lọc
function applyFilters() {
    const loanTime = document.getElementById('m-search-loanTime').value;
    const status = document.getElementById('m-search-status').value;

    const loanTimeText = document.getElementById('m-search-loanTime').options[document.getElementById('m-search-loanTime').selectedIndex].text;
    const statusText = document.getElementById('m-search-status').options[document.getElementById('m-search-status').selectedIndex].text;

    console.log('Áp dụng bộ lọc:', {
        loanTime: { value: loanTime, text: loanTimeText },
        status: { value: status, text: statusText }
    });

    // Thêm logic lọc dữ liệu chính của bạn tại đây
    // Ví dụ:
    // - Gọi API với parameters
    // - Filter table data
    // - Reload danh sách
}

// Hàm reset về mặc định
function resetFilters() {
    document.getElementById('m-search-loanTime').selectedIndex = 0;
    document.getElementById('m-search-status').selectedIndex = 0;
    applyFilters();
}

// Hàm lấy giá trị hiện tại
function getCurrentFilters() {
    return {
        loanTime: document.getElementById('m-search-loanTime').value,
        status: document.getElementById('m-search-status').value
    };
}

// Hàm set giá trị
function setFilters(loanTime, status) {
    if (loanTime !== undefined) {
        document.getElementById('m-search-loanTime').value = loanTime;
    }
    if (status !== undefined) {
        document.getElementById('m-search-status').value = status;
    }
    applyFilters();
}

// ================== LOAD CONTRACTS ==================
async function loadContracts1(showLoading = true) {
    if (showLoading) {
        showLoadingState();
    }

    const params = {
        userId: await getUserId(),
        shopId: getShopId(),
        status: currentStatus
    };

    //console.log('Loading contracts with params:', params);

    $.ajax({
        url: API_BASE_URL + 'get_contracts1.php',
        method: 'GET',
        data: params,
        dataType: 'json',
        success: function (response) {
            //console.log('Contracts loaded successfully:', response);

            if (response.success) {
                contractsData = response.data;
                renderContractsTable(response.data);
                renderPagination(response.pagination);
                renderSummary(response.summary);
                //updateContractsCount(response.pagination.totalRecords);
            } else {
                showErrorMessage(response.message || 'Không thể tải danh sách hợp đồng');
                renderEmptyTable();
            }
        },
        error: function (xhr, status, error) {
            console.error('Error loading contracts:', error);
            console.error('Response:', xhr.responseText);

            let errorMessage = 'Có lỗi xảy ra khi tải danh sách hợp đồng';
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage += ': ' + xhr.responseJSON.message;
            }

            showErrorMessage(errorMessage);
            renderEmptyTable();
        }
    });
}

// ================== RENDER TABLE ==================
function renderContractsTable(contracts) {
    const tbody = $('#dtInstallment .m-datatable__body');
    let html = '';

    if (contracts && contracts.length > 0) {
        contracts.forEach((contract, index) => {
            html += generateContractRow(contract, index + 1);
        });

        // Add summary row
        html += generateSummaryRow();
    } else {
        html = generateEmptyRow();
    }

    tbody.html(html);

    // Hide loading state
    //hideLoadingState();
}
function generateContractRow(contract, rowNumber) {
    const statusClass = getStatusClass(contract.current_status);
    const nextPaymentDate = contract.next_payment_date || 'N/A';
    const remainingPeriods = Math.max(0, (contract.total_periods || 0) - (contract.paid_periods || 0));

    return `
        <tr data-row="${rowNumber - 1}" class="m-datatable__row" style="height: 0px;">
            <td data-field="RowID" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 40px;">${rowNumber}</span>
            </td>
            <td data-field="CodeID" style="text-align:left" class="m-datatable__cell">
                <span style="width: 60px;">
                    <a class="m-link" onclick="editContract(${contract.id})" 
                       style="color:#716aca;cursor: pointer">
                        ${contract.code_id || 'N/A'}
                    </a>
                </span>
            </td>
            <td data-field="CustomerName" style="text-align:left" class="m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <a onclick="editContract(${contract.id})"
                               class="m-card-user__email m-link font-cusName font-weight-bold"
                               style="color:#27408B; cursor: pointer;">
                                ${contract.customer_name || 'N/A'}
                            </a>
                            ${contract.customer_phone ? `<br><small>${contract.customer_phone}</small>` : ''}
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="TotalMoneyReceived" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">${formatNumber1(contract.total_money_received || 0)}</span>
            </td>
            <td data-field="StrRate" style="text-align:left" class="m-datatable__cell--left m-datatable__cell">
                <span style="width: 70px;">${contract.staff_id || 'N/A'}</span>
            </td>
            <td data-field="FromDate" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
    <span style="width: 130px;">
        <div class="text-center">
            <div class="m-card-user__details">
                ${formatDateRange(contract)}
            </div>
        </div>
    </span>
</td>
            <td data-field="PaymentMoney" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="m-card-user__name">${formatNumber1(contract.paid_amount || 0)}</span><br>
                            <a href="#" style="font-size: 12px;color:brown" class="m-card-user__email m-link small">
                                (${contract.paid_periods || 0} kỳ)
                            </a>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="DebitMoney" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 90px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="m-card-user__name">${formatNumber1(contract.money_should_pay)}</span><br>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="TotalMoneyCurrent" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="m-card-user__name">${formatNumber1(contract.remaining_amount || 0)}</span><br>
                            <a href="#" style="font-size: 12px;color:#909090" class="m-card-user__email m-link small">
                                (${remainingPeriods} kỳ)
                            </a>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="Status" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 110px;">
                    <span class="m-badge ${statusClass} m-badge--wide" style="font-size:12px">
                        ${contract.current_status}
                    </span>
                </span>
            </td>
            <td data-field="NextDate" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 90px;">
                    <a id="NextDate${contract.id}">
                        ${nextPaymentDate}
                    </a>
                </span>
            </td>
            <td data-field="Actions" style="text-align:left" class="m-datatable__cell">
                <span style="width: 130px;">
                    <button onclick="getDetailsPawn(${contract.id},${contract.id},'m_tab_lichdongtien')"
                            data-toggle="modal" data-target="#modal_details_pawn"
                            class="btn btn-secondary btn-sm" title="Đóng tiền">
                        <i class="icol-coins"></i>
                    </button>
                    <button onclick="editContract(${contract.id})"
                            class="btn btn-secondary btn-sm" title="Sửa hợp đồng">
                        <i class="icol-pencil"></i>
                    </button>
                    <button onclick="confirmDelete(${contract.id},'${contract.code_id || ''}')"
                            class="btn btn-secondary btn-sm" title="Xóa hợp đồng">
                        <i class="icol-cross"></i>
                    </button>
                </span>
            </td>
        </tr>
    `;
}
function formatDateRange(contract) {
    if (!contract.from_date || !contract.loan_time) {
        return 'N/A';
    }

    try {
        // Chuyển đổi from_date từ YYYY-MM-DD sang Date object
        const fromDate = new Date(contract.from_date);

        // Tính to_date bằng cách cộng loan_time (ngày)
        const toDate = new Date(fromDate);
        toDate.setDate(fromDate.getDate() + parseInt(contract.loan_time) - 1);

        // Format ngày theo dd/mm
        const formatDate = (date) => {
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0');
            return `${day}/${month}`;
        };

        const fromFormatted = formatDate(fromDate);
        const toFormatted = formatDate(toDate);
        const totalDays = contract.loan_time;

        return `
            <span>${fromFormatted}</span> 
            <i class="la la-arrow-right text-danger font-weight-bold" style="font-size:14px"></i> 
            <span>${toFormatted}</span>
            <div>(${totalDays} ngày)</div>
        `;
    } catch (error) {
        console.error('Error formatting date range:', error);
        return 'N/A';
    }
}
function generateSummaryRow() {
    // Tính tổng từ dữ liệu hiện tại với field name đúng
    const totalMoneyReceived = contractsData.reduce((sum, contract) =>
        sum + parseFloat(contract.total_money_received || 0), 0);
    const totalPaidAmount = contractsData.reduce((sum, contract) =>
        sum + parseFloat(contract.paid_amount || 0), 0);
    const totalRemainingAmount = contractsData.reduce((sum, contract) =>
        sum + parseFloat(contract.remaining_amount || 0), 0);
    const totalMoneyPerPeriod = contractsData.reduce((sum, contract) =>
        sum + parseFloat(contract.money_per_period || 0), 0);

    return `
        <tr data-row="${contractsData.length}" class="m-datatable__row" style="height: 0px;">
            <td data-field="RowID" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 40px;"></span>
            </td>
            <td data-field="CodeID" style="text-align:left" class="m-datatable__cell">
                <span style="width: 60px;"></span>
            </td>
            <td data-field="CustomerName" style="text-align:left" class="m-datatable__cell">
                <span style="width: 110px;">
                    <a style="color:brown"><b>Tổng Tiền</b></a>
                </span>
            </td>
            <td data-field="TotalMoneyReceived" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="text-danger font-weight-bold">${formatNumber1(totalMoneyReceived)}</span><br>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="StrRate" style="text-align:left" class="m-datatable__cell--left m-datatable__cell">
                <span style="width: 70px;"></span>
            </td>
            <td data-field="FromDate" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 130px;"></span>
            </td>
            <td data-field="PaymentMoney" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="text-danger font-weight-bold">${formatNumber1(totalPaidAmount)}</span><br>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="DebitMoney" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 90px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="text-danger font-weight-bold">0</span><br>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="TotalMoneyCurrent" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="text-danger font-weight-bold">${formatNumber1(totalRemainingAmount)}</span><br>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="Status" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 110px;"></span>
            </td>
            <td data-field="NextDate" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 90px;"></span>
            </td>
            <td data-field="Actions" style="text-align:left" class="m-datatable__cell">
                <span style="width: 130px;"></span>
            </td>
        </tr>
    `;
}

function generateEmptyRow() {
    return `
        <tr data-row="0" class="m-datatable__row">
            <td colspan="13" style="text-align:center; padding: 50px;" class="m-datatable__cell">
                <div style="color: #999; font-size: 16px;">
                    <i class="fa fa-inbox" style="font-size: 48px; margin-bottom: 15px;"></i><br>
                    Không có hợp đồng nào được tìm thấy
                </div>
            </td>
        </tr>
    `;
}

// ================== RENDER PAGINATION ==================
function renderPagination(pagination) {
    const pagerNav = $('.m-datatable__pager-nav');
    const pagerInfo = $('.m-datatable__pager-info .m-datatable__pager-detail');

    // Update pagination info
    pagerInfo.text(`Tổng số ${pagination.totalRecords} bản ghi - Trang ${pagination.currentPage}/${pagination.totalPages}`);

    // Generate pagination HTML
    let paginationHtml = '';

    // First page
    const firstDisabled = pagination.currentPage === 1 ? 'm-datatable__pager-link--disabled' : '';
    paginationHtml += `
        <li>
            <a title="Về trang đầu" 
               class="m-datatable__pager-link m-datatable__pager-link--first ${firstDisabled}"
               data-page="1" ${pagination.currentPage === 1 ? 'disabled="disabled"' : ''}>
                <i class="la la-angle-double-left"></i>
            </a>
        </li>
    `;

    // Previous page
    const prevDisabled = pagination.currentPage === 1 ? 'm-datatable__pager-link--disabled' : '';
    paginationHtml += `
        <li>
            <a title="Trang trước"
               class="m-datatable__pager-link m-datatable__pager-link--prev ${prevDisabled}"
               data-page="${pagination.currentPage - 1}" ${pagination.currentPage === 1 ? 'disabled="disabled"' : ''}>
                <i class="la la-angle-left"></i>
            </a>
        </li>
    `;

    // Page numbers
    const startPage = Math.max(1, pagination.currentPage - 2);
    const endPage = Math.min(pagination.totalPages, pagination.currentPage + 2);

    for (let i = startPage; i <= endPage; i++) {
        const activeClass = i === pagination.currentPage ? 'm-datatable__pager-link--active' : '';
        paginationHtml += `
            <li>
                <a class="m-datatable__pager-link m-datatable__pager-link-number ${activeClass}"
                   data-page="${i}" title="${i}">${i}</a>
            </li>
        `;
    }

    // Next page
    const nextDisabled = pagination.currentPage >= pagination.totalPages ? 'm-datatable__pager-link--disabled' : '';
    paginationHtml += `
        <li>
            <a title="Trang sau"
               class="m-datatable__pager-link m-datatable__pager-link--next ${nextDisabled}"
               data-page="${pagination.currentPage + 1}" ${pagination.currentPage >= pagination.totalPages ? 'disabled="disabled"' : ''}>
                <i class="la la-angle-right"></i>
            </a>
        </li>
    `;

    // Last page
    const lastDisabled = pagination.currentPage >= pagination.totalPages ? 'm-datatable__pager-link--disabled' : '';
    paginationHtml += `
        <li>
            <a title="Đến trang cuối"
               class="m-datatable__pager-link m-datatable__pager-link--last ${lastDisabled}"
               data-page="${pagination.totalPages}" ${pagination.currentPage >= pagination.totalPages ? 'disabled="disabled"' : ''}>
                <i class="la la-angle-double-right"></i>
            </a>
        </li>
    `;

    pagerNav.html(paginationHtml);

    // Show/hide pagination
    if (pagination.totalPages > 1) {
        pagerNav.show();
    } else {
        pagerNav.hide();
    }
}

// ================== RENDER SUMMARY ==================
function renderSummary(summary) {
    // Nếu có element để hiển thị summary thì update
    if ($('#contracts-summary').length) {
        $('#contracts-summary').html(`
            <div class="row">
                <div class="col-md-3">
                    <div class="m-portlet m-portlet--creative">
                        <div class="m-portlet__body">
                            <div class="m-widget24">
                                <div class="m-widget24__item">
                                    <h4 class="m-widget24__title">Tổng HĐ</h4>
                                    <span class="m-widget24__desc">${summary.totalContracts}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="m-portlet m-portlet--creative">
                        <div class="m-portlet__body">
                            <div class="m-widget24">
                                <div class="m-widget24__item">
                                    <h4 class="m-widget24__title">Đã cho vay</h4>
                                    <span class="m-widget24__desc">${formatNumber1(summary.totalMoneyGiven)}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="m-portlet m-portlet--creative">
                        <div class="m-portlet__body">
                            <div class="m-widget24">
                                <div class="m-widget24__item">
                                    <h4 class="m-widget24__title">Đã thu</h4>
                                    <span class="m-widget24__desc">${formatNumber1(summary.totalCollected)}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="m-portlet m-portlet--creative">
                        <div class="m-portlet__body">
                            <div class="m-widget24">
                                <div class="m-widget24__item">
                                    <h4 class="m-widget24__title">Còn phải thu</h4>
                                    <span class="m-widget24__desc">${formatNumber1(summary.totalRemaining)}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
    }
}

// ================== EVENT BINDING ==================
async function bindSearchEvents() {
    // Search input with debounce
    let searchTimeout;
    $('#contracts-search').on('input', function () {
        const searchValue = $(this).val().trim();

        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(function () {
            currentSearch = searchValue;
            currentPage = 1; // Reset to first page
            loadContracts1();
        }, 500);
    });

    // Search button
    $('#btn-search-contracts').on('click', function () {
        currentSearch = $('#contracts-search').val().trim();
        currentPage = 1;
        loadContracts1();
    });

    // Clear search
    $('#btn-clear-search').on('click', function () {
        $('#contracts-search').val('');
        currentSearch = '';
        currentPage = 1;
        loadContracts1();
    });
}

async function bindFilterEvents() {
    // Status filter
    $('#contracts-status-filter').on('change', function () {
        currentStatus = $(this).val();
        currentPage = 1;
        loadContracts1();
    });

    // Limit filter
    $('.m-datatable__pager-size').on('change', function () {
        currentLimit = parseInt($(this).val());
        currentPage = 1;
        loadContracts1();
    });
}

async function bindPaginationEvents() {
    // Pagination click events
    $(document).on('click', '.m-datatable__pager-link:not(.m-datatable__pager-link--disabled)', function (e) {
        e.preventDefault();

        const page = parseInt($(this).data('page'));
        if (page && page !== currentPage) {
            currentPage = page;
            loadContracts1();
        }
    });
}

// ================== UTILITY FUNCTIONS ==================
function getStatusClass(status) {
    switch (status) {
        case 'Đang vay':
        case 'Đến ngày đóng họ':
        case 'Ngày mai đóng họ':
            return 'm-badge--info';
        case 'Đã hoàn thành':
            return 'm-badge--success';
        case 'Quá hạn':
        case 'Chậm họ':
        case 'Trả gốc hôm nay':
        case 'Quá hạn trả gốc':
            return 'm-badge--danger';
        default:
            return 'm-badge--secondary';
    }
}

function formatNumber1(num) {
    if (!num || isNaN(num)) return '0';
    const number = parseFloat(num);
    return Math.round(number).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function showLoadingState() {
    const tbody = $('#dtInstallment .m-datatable__body');
    tbody.html(`
        <tr class="m-datatable__row">
            <td colspan="13" style="text-align:center; padding: 50px;" class="m-datatable__cell">
                <div style="color: #999; font-size: 16px;">
                    <i class="fa fa-spinner fa-spin" style="font-size: 48px; margin-bottom: 15px;"></i><br>
                    Đang tải dữ liệu...
                </div>
            </td>
        </tr>
    `);
}

function renderContractsTable(contracts) {
    const tbody = $('#dtInstallment .m-datatable__body');
    let html = '';

    // DEBUG: Kiểm tra dữ liệu
    //console.log('Contracts data received:', contracts);
    if (contracts && contracts.length > 0) {
        //console.log('First contract structure:', contracts[0]);
    }

    if (contracts && contracts.length > 0) {
        contracts.forEach((contract, index) => {
            html += generateContractRow(contract, index + 1);
        });
        html += generateSummaryRow();
    } else {
        html = generateEmptyRow();
    }

    tbody.html(html);
    //hideLoadingState();
}

function renderEmptyTable() {
    const tbody = $('#dtInstallment .m-datatable__body');
    tbody.html(generateEmptyRow());

    // Hide pagination
    $('.m-datatable__pager-nav').hide();
    $('.m-datatable__pager-detail').text('Tổng số 0 bản ghi');
}

function updateContractsCount(count) {
    // Update any counter elements
    $('.contracts-count').text(count);
}

// ================== CONTRACT ACTIONS ==================
function editContract(contractId) {
    console.log('Edit contract:', contractId);

    // Find contract data
    const contract = contractsData.find(c => c.id === contractId);
    console.log(contract.customerName);
    if (!contract) {
        showErrorMessage('Không tìm thấy thông tin hợp đồng');
        return;
    }

    // Fill form data
    fillContractForm(contract);

    // Show modal
    $('#modal_create_pawn').modal('show');
}

function fillContractForm(contract) {
    $('#hfId').val(contract.id);
    $('#txtCodeID').val(contract.code_id);  // Sửa từ codeId thành code_id
    $('#txtCustomer').val(contract.customer_name);  // Sửa từ customerName thành customer_name
    $('#txtCustomerPhone').val(contract.customer_phone);  // Sửa từ customerPhone thành customer_phone
    $('#hfCustomerNumberCard').val(contract.customer_number_card);  // Sửa từ customerNumberCard thành customer_number_card
    $('#hfCustomerAddress').val(contract.customer_address);  // Sửa từ customerAddress thành customer_address
    $('#txtTotalMoney').val(formatNumber1(contract.total_money));  // Sửa từ totalMoney thành total_money
    $('#txtTotalMoneyReceived').val(formatNumber1(contract.total_money_received));  // Sửa từ totalMoneyReceived thành total_money_received
    $('#txtLoanTime').val(contract.loan_time);  // Sửa từ loanTime thành loan_time
    $('#txtFrequency').val(contract.frequency);
    $('#txtStrFromDate').val(contract.from_date);  // Sửa từ fromDate thành from_date
    $('#txtNote').val(contract.note);

    // Set rate type
    $('#m-select-ratetype_create').val(contract.rate_type);  // Sửa từ rateType thành rate_type
    $('#ratetype-selected').text(contract.rate_type_text || '');  // Thêm fallback
    updateRateTypeUI(contract.rate_type);  // Sửa từ rateType thành rate_type

    // Set staff
    $('#m-select-staff').val(contract.staff_id);  // Sửa từ staffId thành staff_id
    $('#staff-selected').text(contract.staff_id);

    // Recalculate
    calculateInstallment();
}

async function deleteContract(contractId, codeId) {

    if (!confirm(`Bạn có chắc chắn muốn xóa hợp đồng ${codeId}?`)) {
        return;
    }
    if (typeof showLoading === 'function') showLoading();

    $.ajax({
        url: API_BASE_URL + 'payment_schedule.php', // Đổi thành endpoint chính xác
        method: 'POST', // Đổi thành POST thay vì DELETE
        data: JSON.stringify({
            action: 'delete_contracts',
            contract_id: contractId
        }),
        contentType: 'application/json',
        success: function (response) {
            if (typeof hideLoading === 'function') hideLoading();

            if (response.success) {
                // Hiển thị thông báo thành công với thông tin chi tiết
                let successMessage = response.message;
                showSuccessMessage(successMessage);

                // Refresh danh sách hợp đồng
                loadContracts1();

                // Hiển thị nút xem kho lưu trữ nếu cần
                if (typeof showArchiveButton === 'function') {
                    showArchiveButton();
                }
            } else {
                showErrorMessage('Lỗi: ' + (response.message || 'Không thể xóa hợp đồng'));
            }
        },
        error: function (xhr) {
            if (typeof hideLoading === 'function') hideLoading();
            console.error('Error deleting contract:', xhr);

            let errorMessage = 'Có lỗi xảy ra khi xóa hợp đồng';

            // Hiển thị thông báo lỗi chi tiết từ server
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage = xhr.responseJSON.message;
            } else if (xhr.status === 500) {
                errorMessage = 'Lỗi server. Vui lòng thử lại sau.';
            } else if (xhr.status === 404) {
                errorMessage = 'Hợp đồng không tồn tại.';
            }

            showErrorMessage(errorMessage);
        }
    });
}

// ================== GLOBAL FUNCTIONS (for compatibility) ==================


function getDetailsPawn(contractId, contractCode, tab) {
    console.log('Open payment modal:', contractId, contractCode, tab);
    // Implement payment modal
}

function ChangeNextDate(contractId, currentDate) {
    console.log('Change next payment date:', contractId, currentDate);
    // Implement change next date functionality
}

function confirmDelete(contractId, codeId) {
    deleteContract(contractId, codeId);
}

async function refreshContractList() {
    await loadContracts1();
}

// ================== NOTIFICATION FUNCTIONS (reuse from create script) ==================
function showSuccessMessage(message) {
    const toast = $(`
        <div class="toast-notification success" style="position: fixed; top: 20px; right: 20px; 
             background: #28a745; color: white; padding: 15px 20px; border-radius: 5px; 
             box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 10000; min-width: 300px;">
            <i class="fa fa-check-circle" style="margin-right: 10px;"></i>
            ${message}
        </div>
    `);

    $('body').append(toast);

    setTimeout(function () {
        toast.fadeOut(function () {
            toast.remove();
        });
    }, 3000);
}

function showErrorMessage(message) {
    const toast = $(`
        <div class="toast-notification error" style="position: fixed; top: 20px; right: 20px; 
             background: #dc3545; color: white; padding: 15px 20px; border-radius: 5px; 
             box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 10000; min-width: 300px;">
            <i class="fa fa-exclamation-circle" style="margin-right: 10px;"></i>
            ${message}
            <button type="button" style="float: right; background: none; border: none; color: white; font-size: 18px; cursor: pointer; margin-left: 10px;" onclick="$(this).closest('.toast-notification').remove()">×</button>
        </div>
    `);

    $('body').append(toast);

    setTimeout(function () {
        if (toast.is(':visible')) {
            toast.fadeOut(function () {
                toast.remove();
            });
        }
    }, 5000);
}

// ================== EXPORT FUNCTIONS ==================
async function exportContracts() {
    const params = {
        userId: await getUserId(),
        shopId: getShopId(),
        search: currentSearch,
        status: currentStatus,
        export: 'excel'
    };

    const queryString = $.param(params);
    const url = `${API_BASE_URL}get_contracts1.php?${queryString}`;

    // Create temporary link to download
    const link = document.createElement('a');
    link.href = url;
    link.download = `contracts_${new Date().toISOString().split('T')[0]}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

async function getUserId() {
    var userID = localStorage.getItem('user_id');

    if (!userID) return null;

    // Nếu là staff ID (bắt đầu bằng STF)
    if (String(userID).toUpperCase().startsWith('STF')) {
        localStorage.setItem('user_id_taff', userID);
        // Lấy owner_user_id thay vì staff user_id
        const ownerUserId = await getOwnerUserId(userID);
        //console.log(ownerUserId);
        return ownerUserId;
    }

    // Nếu là owner, trả về bình thường
    return userID;
}
// Hàm lấy user_id của owner từ staff_id thông qua API
async function getOwnerUserId(staffId) {
    try {
        const response = await fetch(API_BASE_URL + 'get_owner_from_staff.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'staff_id=' + encodeURIComponent(staffId)
        });

        const result = await response.json();

        if (result.success && result.owner_user_id) {
            return result.owner_user_id;
        } else {
            console.error('Lỗi lấy owner user_id từ staff_id:', result.message);
            return null;
        }
    } catch (error) {
        console.error('Lỗi kết nối API:', error);
        return null;
    }
}

function getShopId() {
    const selectedShopId = sessionStorage.getItem('selected_shop_id');
    const defaultShopId = sessionStorage.getItem('store_id');
    return selectedShopId || defaultShopId;
}

// ================== ENHANCED CONTRACT SEARCH ==================

// Thêm vào phần global variables
let searchTimeout;
let currentFromDate = '';
let currentToDate = '';
let currentLoanTime = '0';
let currentSearchStatus = '0';

// ================== INITIALIZE ENHANCED SEARCH ==================
async function initializeEnhancedSearch() {
    console.log('Initializing Enhanced Search...');

    // Bind search events
    bindEnhancedSearchEvents();

    // Bind filter events  
    bindEnhancedFilterEvents();
}

// ================== ENHANCED SEARCH EVENT BINDING ==================
function bindEnhancedSearchEvents() {
    // Tìm kiếm realtime cho generalSearch (tên khách hàng, mã HĐ)
    $('#generalSearch').on('input', function () {
        const searchValue = $(this).val().trim();

        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(function () {
            currentSearch = searchValue;
            currentPage = 1;
            loadContracts1WithEnhancedSearch();
        }, 500); // Debounce 3 seconds
    });

    // Xử lý sự kiện cho các date picker
    $('#txtFromDate').on('change', function () {
        currentFromDate = $(this).val();
    });

    $('#txtToDate').on('change', function () {
        currentToDate = $(this).val();
    });

    // Xử lý sự kiện cho dropdown loan time
    $('#m-search-loanTime').on('change', function () {
        currentLoanTime = $(this).val();
    });

    // Xử lý sự kiện cho dropdown status
    $('#m-search-status').on('change', function () {
        currentSearchStatus = $(this).val();
    });

    // Nút tìm kiếm chính - áp dụng tất cả bộ lọc
    $('#btnGetData').on('click', function (e) {
        e.preventDefault();
        performAdvancedSearch();
    });

    // Thêm nút reset bộ lọc
    addResetButton();
}

function bindEnhancedFilterEvents() {
    // Giữ nguyên các event binding cũ cho tương thích
    bindFilterEvents();
}

// ================== ADVANCED SEARCH EXECUTION ==================
function performAdvancedSearch() {
    console.log('Performing advanced search with filters:', {
        search: currentSearch,
        fromDate: currentFromDate,
        toDate: currentToDate,
        loanTime: currentLoanTime,
        status: currentSearchStatus
    });

    currentPage = 1; // Reset về trang đầu
    loadContracts1WithEnhancedSearch();
}

// ================== ENHANCED LOAD CONTRACTS ==================
async function loadContracts1WithEnhancedSearch(showLoading = true) {
    if (showLoading) {
        showLoadingState();
    }

    // Chuẩn bị parameters với enhanced search
    const params = {
        userId: await getUserId(),
        shopId: getShopId(),
        search: currentSearch || '', // Tìm kiếm tên KH, mã HĐ
        status: currentStatus, // Status cũ (để tương thích)

        // Enhanced search parameters
        fromDate: currentFromDate || '',
        toDate: currentToDate || '',
        loanTime: currentLoanTime || '0',
        searchStatus: currentSearchStatus || '0'
    };

    console.log('Loading contracts with enhanced params:', params);

    $.ajax({
        url: API_BASE_URL + 'get_contracts_enhanced.php', // API endpoint mới
        method: 'GET',
        data: params,
        dataType: 'json',
        success: function (response) {
            console.log('Enhanced search results:', response);

            if (response.success) {
                contractsData = response.data;
                renderContractsTable(response.data);
                renderPagination(response.pagination);
                renderSummary(response.summary);
                updateSearchResults(response.pagination.totalRecords);
            } else {
                showErrorMessage(response.message || 'Không thể tải danh sách hợp đồng');
                renderEmptyTable();
            }
        },
        error: function (xhr, status, error) {
            console.error('Error in enhanced search:', error);
            console.error('Response:', xhr.responseText);

            // Fallback to original search if enhanced search fails
            console.log('Falling back to original search...');
            loadContracts1(showLoading);
        }
    });
}

// ================== SEARCH UTILITIES ==================
function addResetButton() {
    // Thêm nút reset nếu chưa có
    if ($('#btnResetSearch').length === 0) {
        const resetButton = `
            <div class="col-lg-1 col-xl-1 col-sm-6 col-6 m--margin-top-10">
                <button class="btn btn-secondary m-btn m-btn--air" id="btnResetSearch">
                    <span>
                        <i class="fa fa-refresh"></i>
                        <span>Reset</span>
                    </span>
                </button>
            </div>
        `;
        $('#btnGetData').closest('.col-lg-1').after(resetButton);

        // Bind reset event
        $('#btnResetSearch').on('click', function (e) {
            e.preventDefault();
            resetAllSearchFilters();
        });
    }
}

function resetAllSearchFilters() {
    console.log('Resetting all search filters...');

    // Reset tất cả các trường tìm kiếm
    $('#generalSearch').val('');
    $('#txtFromDate').val('');
    $('#txtToDate').val('');
    $('#m-search-loanTime').val('0');
    $('#m-search-status').val('0');

    // Reset các biến global
    currentSearch = '';
    currentFromDate = '';
    currentToDate = '';
    currentLoanTime = '0';
    currentSearchStatus = '0';
    currentPage = 1;

    // Reload dữ liệu
    loadContracts1WithEnhancedSearch();

    showSuccessMessage('Đã reset tất cả bộ lọc tìm kiếm');
}

function updateSearchResults(totalRecords) {
    // Cập nhật thông tin kết quả tìm kiếm
    const searchInfo = buildSearchInfoString();
    if (searchInfo) {
        console.log(`Tìm thấy ${totalRecords} kết quả với điều kiện: ${searchInfo}`);
    }
}

function buildSearchInfoString() {
    const conditions = [];

    if (currentSearch) {
        conditions.push(`Từ khóa: "${currentSearch}"`);
    }

    if (currentFromDate && currentToDate) {
        conditions.push(`Từ ${currentFromDate} đến ${currentToDate}`);
    } else if (currentFromDate) {
        conditions.push(`Từ ngày ${currentFromDate}`);
    } else if (currentToDate) {
        conditions.push(`Đến ngày ${currentToDate}`);
    }

    if (currentLoanTime && currentLoanTime !== '0') {
        conditions.push(`Kỳ hạn ${currentLoanTime} ngày`);
    }

    if (currentSearchStatus && currentSearchStatus !== '0') {
        const statusText = $('#m-search-status option:selected').text();
        conditions.push(`Trạng thái: ${statusText}`);
    }

    return conditions.join(', ');
}

// ================== OVERRIDE ORIGINAL FUNCTIONS ==================
// Override hàm loadContracts1 gốc để sử dụng enhanced search
const originalloadContracts1 = loadContracts1;
loadContracts1 = function (showLoading = true) {
    // Nếu có bất kỳ enhanced filter nào được áp dụng, sử dụng enhanced search
    if (currentFromDate || currentToDate || (currentLoanTime && currentLoanTime !== '0') ||
        (currentSearchStatus && currentSearchStatus !== '0')) {
        return loadContracts1WithEnhancedSearch(showLoading);
    } else {
        return originalloadContracts1(showLoading);
    }
};

// Override hàm bindSearchEvents để tích hợp enhanced search
const originalBindSearchEvents = bindSearchEvents;
bindSearchEvents = async function () {
    await originalBindSearchEvents();
    bindEnhancedSearchEvents();
};

// ================== SMART SEARCH SUGGESTIONS ==================
function initializeSearchSuggestions() {
    // Thêm autocomplete cho generalSearch
    $('#generalSearch').on('input', function () {
        const query = $(this).val().trim();
        if (query.length >= 2) {
            getSearchSuggestions(query);
        } else {
            hideSearchSuggestions();
        }
    });

    // Ẩn suggestions khi click ra ngoài
    $(document).on('click', function (e) {
        if (!$(e.target).closest('#generalSearch, .search-suggestions').length) {
            hideSearchSuggestions();
        }
    });
}

async function getSearchSuggestions(query) {
    try {
        const response = await $.ajax({
            url: API_BASE_URL + 'get_search_suggestions.php',
            method: 'GET',
            data: {
                query: query,
                userId: await getUserId(),
                shopId: getShopId(),
                limit: 5
            },
            dataType: 'json'
        });

        if (response.success && response.suggestions.length > 0) {
            showSearchSuggestions(response.suggestions);
        } else {
            hideSearchSuggestions();
        }
    } catch (error) {
        console.error('Error getting search suggestions:', error);
        hideSearchSuggestions();
    }
}

function showSearchSuggestions(suggestions) {
    const suggestionsHtml = suggestions.map(item => `
        <div class="suggestion-item" data-value="${item.value}">
            <strong>${item.code_id}</strong> - ${item.customer_name}
            ${item.customer_phone ? `<small class="text-muted"> (${item.customer_phone})</small>` : ''}
        </div>
    `).join('');

    const suggestionsContainer = `
        <div class="search-suggestions" style="position: absolute; z-index: 1000; 
             background: white; border: 1px solid #ddd; border-radius: 4px; 
             box-shadow: 0 2px 10px rgba(0,0,0,0.1); max-height: 200px; overflow-y: auto;">
            ${suggestionsHtml}
        </div>
    `;

    // Remove existing suggestions
    $('.search-suggestions').remove();

    // Add new suggestions
    $('#generalSearch').after(suggestionsContainer);

    // Position suggestions
    const input = $('#generalSearch');
    const offset = input.offset();
    $('.search-suggestions').css({
        'top': offset.top + input.outerHeight(),
        'left': offset.left,
        'width': input.outerWidth()
    });

    // Bind click events for suggestions
    $('.suggestion-item').on('click', function () {
        const value = $(this).data('value');
        $('#generalSearch').val(value);
        hideSearchSuggestions();

        // Trigger search
        currentSearch = value;
        currentPage = 1;
        loadContracts1WithEnhancedSearch();
    });
}

function hideSearchSuggestions() {
    $('.search-suggestions').remove();
}



// ================== INITIALIZE ON DOCUMENT READY ==================
$(document).ready(function () {
    // Khởi tạo enhanced search sau khi document ready
    setTimeout(function () {
        initializeEnhancedSearch();
        initializeSearchSuggestions();
    }, 1000);

    // Style cho suggestions
    $('<style>')
        .prop('type', 'text/css')
        .html(`
            .search-suggestions {
                background: white;
                border: 1px solid #ddd;
                border-radius: 4px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                max-height: 200px;
                overflow-y: auto;
            }
            .suggestion-item {
                padding: 10px 15px;
                cursor: pointer;
                border-bottom: 1px solid #eee;
            }
            .suggestion-item:hover {
                background-color: #f8f9fa;
            }
            .suggestion-item:last-child {
                border-bottom: none;
            }
        `)
        .appendTo('head');
});

// ================== PUBLIC API ==================
// Export functions để có thể sử dụng từ bên ngoài
window.enhancedSearch = {
    performSearch: performAdvancedSearch,
    resetFilters: resetAllSearchFilters,
    getCurrentFilters: function () {
        return {
            search: currentSearch,
            fromDate: currentFromDate,
            toDate: currentToDate,
            loanTime: currentLoanTime,
            status: currentSearchStatus
        };
    }
};

//----------------------------------

// ================== SHOW INSTALLMENT TOMORROW ==================
async function ShowInstallmentTomorrow() {
    console.log('Loading contracts due tomorrow...');
    isTomorrowInstallment = true;
    try {
        // Hiển thị loading state
        showLoadingState();

        // Reset current filters để chỉ hiển thị hợp đồng ngày mai
        resetTomorrowFilters();

        const params = {
            userId: await getUserId(),
            shopId: getShopId(),

            status: currentStatus
        };

        console.log('Loading tomorrow contracts with params:', params);

        // Gọi API với endpoint đặc biệt hoặc thêm tham số vào API hiện tại
        const response = await $.ajax({
            url: API_BASE_URL + 'get_contracts1.php',
            method: 'GET',
            data: params,
            dataType: 'json'
        });

        if (response.success) {
            // Filter client-side để đảm bảo chỉ lấy hợp đồng ngày mai
            const tomorrowContracts = filterTomorrowContracts(response.data);
            contractsData = response.data;
            console.log('du lieu hop dong: ' + response.data.length);
            if (tomorrowContracts.length > 0) {
                // Hiển thị kết quả
                renderTomorrowContractsTable(tomorrowContracts);
                renderTomorrowSummary(tomorrowContracts);

                // Hiển thị thông báo
                showSuccessMessage(`Tìm thấy ${tomorrowContracts.length} hợp đồng đến kỳ thanh toán vào ngày mai`);

                // Update UI để hiển thị đang filter theo ngày mai
                updateTomorrowFilterUI(true);

            } else {
                renderEmptyTomorrowTable();
                showInfoMessage('Không có hợp đồng nào đến kỳ thanh toán vào ngày mai');
            }

            // Update pagination cho tomorrow view
            renderTomorrowPagination(response.pagination, tomorrowContracts.length);

        } else {
            showErrorMessage(response.message || 'Không thể tải danh sách hợp đồng ngày mai');
            renderEmptyTomorrowTable();
        }

    } catch (error) {
        console.error('Error loading tomorrow contracts:', error);
        showErrorMessage('Có lỗi xảy ra khi tải danh sách hợp đồng ngày mai');
        renderEmptyTomorrowTable();
    }
}

// ================== HELPER FUNCTIONS FOR TOMORROW ==================
function getTomorrowDate() {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    const day = String(tomorrow.getDate()).padStart(2, '0');
    const month = String(tomorrow.getMonth() + 1).padStart(2, '0');
    const year = tomorrow.getFullYear();

    return `${day}/${month}/${year}`; // hoặc format theo yêu cầu API
}

function getTomorrowDateSQL() {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    const year = tomorrow.getFullYear();
    const month = String(tomorrow.getMonth() + 1).padStart(2, '0');
    const day = String(tomorrow.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}

function filterTomorrowContracts(contracts) {
    if (!contracts || contracts.length === 0) return [];

    const tomorrowDateStr = getTomorrowDateSQL();
    console.log('Filtering for tomorrow date:', tomorrowDateStr);

    return contracts.filter(contract => {
        // Kiểm tra next_payment_date
        if (contract.next_payment_date) {
            // Chuyển đổi format nếu cần
            const nextPaymentDate = convertToSQLDate(contract.next_payment_date);
            return nextPaymentDate === tomorrowDateStr;
        }

        // Nếu không có next_payment_date, tính toán dựa trên from_date và frequency
        return calculateIsPaymentDueTomorrow(contract);
    });
}

function calculateIsPaymentDueTomorrow(contract) {
    try {
        if (!contract.from_date || !contract.frequency) return false;

        const fromDate = new Date(contract.from_date);
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);

        // Reset time để so sánh chính xác theo ngày
        fromDate.setHours(0, 0, 0, 0);
        tomorrow.setHours(0, 0, 0, 0);

        // Tính số ngày từ ngày bắt đầu đến ngày mai
        const diffTime = tomorrow.getTime() - fromDate.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

        // Kiểm tra xem ngày mai có phải là ngày đóng tiền không
        if (diffDays >= 0 && diffDays % contract.frequency === 0) {
            // Kiểm tra xem kỳ này đã được thanh toán chưa
            const periodNumber = Math.floor(diffDays / contract.frequency) + 1;
            const totalPeriods = Math.ceil(contract.loan_time / contract.frequency);

            return periodNumber <= totalPeriods && periodNumber > (contract.paid_periods || 0);
        }

        return false;

    } catch (error) {
        console.error('Error calculating payment due tomorrow:', error);
        return false;
    }
}

function convertToSQLDate(dateStr) {
    if (!dateStr) return null;

    // Nếu đã đúng format YYYY-MM-DD
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        return dateStr;
    }

    // Chuyển từ DD/MM/YYYY
    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateStr)) {
        const parts = dateStr.split('/');
        const day = parts[0].padStart(2, '0');
        const month = parts[1].padStart(2, '0');
        const year = parts[2];
        return `${year}-${month}-${day}`;
    }

    return null;
}

function renderTomorrowContractsTable(contracts) {
    const tbody = $('#dtInstallment .m-datatable__body');
    let html = '';

    contracts.forEach((contract, index) => {
        html += generateTomorrowContractRow(contract, index + 1);
    });

    // Thêm summary row cho tomorrow
    html += generateTomorrowSummaryRow(contracts);

    tbody.html(html);
}

function generateTomorrowContractRow(contract, rowNumber) {
    const statusClass = getStatusClass('Ngày mai đóng họ'); // Highlight đặc biệt cho ngày mai
    const tomorrowDate = getTomorrowDate();

    // Calculate amount due tomorrow
    const amountDueTomorrow = contract.money_per_period || 0;

    return `
        <tr data-row="${rowNumber - 1}" class="m-datatable__row tomorrow-row" style="height: 0px; background-color: #fff3cd;">
            <td data-field="RowID" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 40px;">${rowNumber}</span>
            </td>
            <td data-field="CodeID" style="text-align:left" class="m-datatable__cell">
                <span style="width: 60px;">
                    <a class="m-link" onclick="editContract(${contract.id})" 
                       style="color:#716aca;cursor: pointer">
                        ${contract.code_id || 'N/A'}
                    </a>
                </span>
            </td>
            <td data-field="CustomerName" style="text-align:left" class="m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <a onclick="editContract(${contract.id})"
                               class="m-card-user__email m-link font-cusName font-weight-bold"
                               style="color:#27408B; cursor: pointer;">
                                ${contract.customer_name || 'N/A'}
                            </a>
                            ${contract.customer_phone ? `<br><small>${contract.customer_phone}</small>` : ''}
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="TotalMoneyReceived" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">${formatNumber1(contract.total_money_received || 0)}</span>
            </td>
            <td data-field="StrRate" style="text-align:left" class="m-datatable__cell--left m-datatable__cell">
                <span style="width: 70px;">${contract.staff_id || 'N/A'}</span>
            </td>
            <td data-field="FromDate" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 130px;">
                    <div class="text-center">
                        <div class="m-card-user__details">
                            ${formatDateRange(contract)}
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="AmountDueTomorrow" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="text-warning font-weight-bold">${formatNumber1(amountDueTomorrow)}</span><br>
                            <small class="text-muted">Đóng ngày mai</small>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="PaymentMoney" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="m-card-user__name">${formatNumber1(contract.paid_amount || 0)}</span><br>
                            <small class="text-muted">(${contract.paid_periods || 0} kỳ)</small>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="TotalMoneyCurrent" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="m-card-user__name">${formatNumber1(contract.remaining_amount || 0)}</span><br>
                            <small class="text-muted">(${(contract.total_periods || 0) - (contract.paid_periods || 0)} kỳ)</small>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="Status" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 110px;">
                    <span class="m-badge m-badge--warning m-badge--wide" style="font-size:12px">
                        Ngày mai đóng họ
                    </span>
                </span>
            </td>
            <td data-field="NextDate" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 90px;">
                    <span class="text-warning font-weight-bold">${tomorrowDate}</span>
                </span>
            </td>
            <td data-field="Actions" style="text-align:left" class="m-datatable__cell">
                <span style="width: 130px;">
                    <button onclick="getDetailsPawn(${contract.id},${contract.id},'m_tab_lichdongtien')"
                            data-toggle="modal" data-target="#modal_details_pawn"
                            class="btn btn-warning btn-sm" title="Đóng tiền ngày mai">
                        <i class="icol-coins"></i> Đóng tiền
                    </button>
                    <button onclick="editContract(${contract.id})"
                            class="btn btn-secondary btn-sm" title="Sửa hợp đồng">
                        <i class="icol-pencil"></i>
                    </button>
                </span>
            </td>
        </tr>
    `;
}

function generateTomorrowSummaryRow(contracts) {
    const totalContracts = contracts.length;
    const totalAmountDueTomorrow = contracts.reduce((sum, contract) =>
        sum + parseFloat(contract.money_per_period || 0), 0);
    const totalRemainingAmount = contracts.reduce((sum, contract) =>
        sum + parseFloat(contract.remaining_amount || 0), 0);

    return `
        <tr data-row="${contracts.length}" class="m-datatable__row tomorrow-summary-row" style="height: 0px; background-color: #d4edda;">
            <td colspan="6" data-field="Summary" style="text-align:center" class="m-datatable__cell">
                <span class="font-weight-bold text-success">
                    TỔNG KẾT NGÀY MAI (${totalContracts} hợp đồng)
                </span>
            </td>
            <td data-field="TotalAmountDueTomorrow" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="text-danger font-weight-bold">${formatNumber1(totalAmountDueTomorrow)}</span><br>
                            <small class="text-muted">Cần thu ngày mai</small>
                        </div>
                    </div>
                </span>
            </td>
            <td colspan="2" data-field="EmptyColumns" class="m-datatable__cell">
            </td>
            <td data-field="TotalRemaining" style="text-align:right" class="m-datatable__cell--right m-datatable__cell">
                <span style="width: 110px;">
                    <div>
                        <div class="m-card-user__details">
                            <span class="text-info font-weight-bold">${formatNumber1(totalRemainingAmount)}</span><br>
                            <small class="text-muted">Tổng còn lại</small>
                        </div>
                    </div>
                </span>
            </td>
            <td colspan="2" data-field="EmptyActions" class="m-datatable__cell">
            </td>
        </tr>
    `;
}

function renderEmptyTomorrowTable() {
    const tbody = $('#dtInstallment .m-datatable__body');
    tbody.html(`
        <tr data-row="0" class="m-datatable__row">
            <td colspan="12" style="text-align:center; padding: 50px;" class="m-datatable__cell">
                <div style="color: #28a745; font-size: 16px;">
                    <i class="fa fa-calendar-check-o" style="font-size: 48px; margin-bottom: 15px;"></i><br>
                    Không có hợp đồng nào đến kỳ thanh toán vào ngày mai<br>
                    <small class="text-muted">Ngày mai: ${getTomorrowDate()}</small>
                </div>
            </td>
        </tr>
    `);
}

function renderTomorrowSummary(contracts) {
    const totalContracts = contracts.length;
    const totalAmountDue = contracts.reduce((sum, contract) =>
        sum + parseFloat(contract.money_per_period || 0), 0);

    // Hiển thị thông tin tóm tắt ở phần header hoặc sidebar
    if ($('#tomorrow-summary').length) {
        $('#tomorrow-summary').html(`
            <div class="alert alert-warning">
                <h5><i class="fa fa-calendar"></i> Lịch thanh toán ngày mai</h5>
                <p><strong>Số hợp đồng:</strong> ${totalContracts}</p>
                <p><strong>Tổng tiền cần thu:</strong> ${formatNumber1(totalAmountDue)}</p>
                <p><strong>Ngày:</strong> ${getTomorrowDate()}</p>
            </div>
        `);
    }
}

function renderTomorrowPagination(pagination, tomorrowCount) {
    const pagerInfo = $('.m-datatable__pager-info .m-datatable__pager-detail');
    pagerInfo.text(`Hiển thị ${tomorrowCount} hợp đồng đến kỳ thanh toán ngày mai (${getTomorrowDate()})`);

    // Ẩn pagination vì thường không cần thiết cho view ngày mai
    $('.m-datatable__pager-nav').hide();
}

function updateTomorrowFilterUI(isTomorrowView) {
    // Thêm indicator để người dùng biết đang xem view ngày mai
    if (isTomorrowView) {
        if ($('.tomorrow-filter-indicator').length === 0) {
            const indicator = `
                <div class="tomorrow-filter-indicator alert alert-info" style="margin-bottom: 10px;">
                    <i class="fa fa-filter"></i> 
                    Đang hiển thị hợp đồng đến hạn thanh toán ngày mai (${getTomorrowDate()})
                    <button type="button" class="close" onclick="clearTomorrowFilter()" style="margin-left: 15px;">
                        <span>×</span>
                    </button>
                </div>
            `;
            $('#dtInstallment').before(indicator);
        }
    } else {
        $('.tomorrow-filter-indicator').remove();
    }
}

function clearTomorrowFilter() {
    updateTomorrowFilterUI(false);
    // Reload lại danh sách bình thường
    loadContracts1();
}

function resetTomorrowFilters() {
    // Reset các filter hiện tại để tập trung vào ngày mai
    currentPage = 1;
    currentLimit = 100;
    currentSearch = '';
    currentStatus = 'all';
}

// ================== UTILITY FUNCTIONS ==================
function showInfoMessage(message) {
    const toast = $(`
        <div class="toast-notification info" style="position: fixed; top: 20px; right: 20px; 
             background: #17a2b8; color: white; padding: 15px 20px; border-radius: 5px; 
             box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 10000; min-width: 300px;">
            <i class="fa fa-info-circle" style="margin-right: 10px;"></i>
            ${message}
        </div>
    `);

    $('body').append(toast);

    setTimeout(function () {
        toast.fadeOut(function () {
            toast.remove();
        });
    }, 4000);
}
let isTomorrowInstallment = false;
// ================== ADDITIONAL FEATURES ==================

// Hàm tự động gọi ShowInstallmentTomorrow khi load trang (nếu cần)
function autoCheckTomorrowInstallments() {
    ShowInstallmentTomorrow();
}

// Hàm để thêm button "Xem ngày mai" vào UI
function addTomorrowButton() {
    if ($('#btn-tomorrow-installments').length === 0) {
        const tomorrowButton = `
            <button id="btn-tomorrow-installments" 
                    class="btn btn-warning m-btn m-btn--air" 
                    onclick="ShowInstallmentTomorrow()" 
                    title="Xem các hợp đồng đến kỳ thanh toán ngày mai">
                <span>
                    <i class="fa fa-calendar-plus-o"></i>
                    <span>Ngày Mai</span>
                </span>
            </button>
        `;

        // Thêm vào toolbar hoặc search area
        $('.m-portlet__head-tools').append(tomorrowButton);
    }
}

// Export hàm để có thể gọi từ bên ngoài
window.ShowInstallmentTomorrow = ShowInstallmentTomorrow;

// Khởi tạo khi document ready
$(document).ready(function () {
    // Thêm button ngày mai vào UI
    setTimeout(function () {
        addTomorrowButton();
    }, 1000);

    // Thêm CSS cho tomorrow rows
    $('<style>')
        .prop('type', 'text/css')
        .html(`
            .tomorrow-row {
                background-color: #fff3cd !important;
                border-left: 4px solid #ffc107;
            }
            .tomorrow-summary-row {
                background-color: #d4edda !important;
                border-left: 4px solid #28a745;
                font-weight: bold;
            }
            .tomorrow-filter-indicator {
                border-left: 4px solid #17a2b8;
            }
            .btn-tomorrow {
                background-color: #ffc107;
                border-color: #ffc107;
                color: #212529;
            }
            .btn-tomorrow:hover {
                background-color: #e0a800;
                border-color: #d39e00;
            }
        `)
        .appendTo('head');
});

