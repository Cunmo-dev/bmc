// Đảm bảo jQuery đã được load
(function () {
    // Kiểm tra jQuery có tồn tại không
    if (typeof jQuery === 'undefined') {
        console.error('jQuery is required but not loaded!');
        return;
    }

    jQuery(document).ready(function ($) {
        // Cấu hình URL - Thay đổi theo đường dẫn thực tế của bạn
        const SAVE_SHOP_URL = window.location.origin + '/vay/api/save_shop.php';

        // Khởi tạo validation cho form
        $('#btnSaveShop').on('click', function (e) {
            e.preventDefault();

            // Lấy dữ liệu từ form
            var shopName = $('#txtShopName').val().trim();
            var totalMoney = $('#txtTotalMoneyInSafe').val().trim();
            var status = $('input[name="cbStatus"]:checked').val();
            var shopId = $('#hddShopId').val();

            // Validate dữ liệu
            if (!validateForm(shopName, totalMoney)) {
                return false;
            }

            // Chuẩn bị dữ liệu gửi lên server
            var formData = {
                shopId: shopId,
                shopName: shopName,
                totalMoney: parseFloat(totalMoney.replace(/,/g, '')),
                status: status,
                action: shopId === '0' ? 'create' : 'update'
            };

            // Hiển thị loading
            showLoading(true);

            // Gửi AJAX request
            $.ajax({
                url: SAVE_SHOP_URL,
                type: 'POST',
                data: formData,
                timeout: 10000, // 10 seconds timeout
                success: function (data, textStatus, xhr) {
                    showLoading(false);

                    try {
                        // Thử parse JSON
                        var response;
                        if (typeof data === 'string') {
                            response = JSON.parse(data);
                        } else {
                            response = data;
                        }
                        handleResponse(response);
                    } catch (e) {
                        // Nếu không parse được JSON, hiển thị raw response để debug
                        console.error('Response is not valid JSON:', data);
                        console.error('Parse error:', e);

                        // Kiểm tra nếu response chứa HTML error
                        if (typeof data === 'string' && data.includes('<br />')) {
                            showAlert('error', 'Lỗi Server', 'Server trả về lỗi PHP. Vui lòng kiểm tra log!');
                        } else {
                            showAlert('error', 'Lỗi', 'Server trả về dữ liệu không hợp lệ!');
                        }
                    }
                },
                error: function (xhr, status, error) {
                    showLoading(false);

                    let errorMessage = 'Không thể kết nối đến server. Vui lòng thử lại!';

                    console.error('Ajax error details:', {
                        status: xhr.status,
                        statusText: xhr.statusText,
                        responseText: xhr.responseText,
                        error: error,
                        url: SAVE_SHOP_URL
                    });

                    if (xhr.status === 404) {
                        errorMessage = 'Không tìm thấy file save_shop.php. Đường dẫn: ' + SAVE_SHOP_URL;
                    } else if (xhr.status === 500) {
                        errorMessage = 'Lỗi server nội bộ. Kiểm tra file PHP và database!';
                    } else if (status === 'timeout') {
                        errorMessage = 'Kết nối quá thời gian chờ. Vui lòng thử lại!';
                    } else if (xhr.responseText) {
                        // Hiển thị một phần response text để debug
                        const preview = xhr.responseText.substring(0, 200);
                        errorMessage = 'Lỗi server: ' + preview + (xhr.responseText.length > 200 ? '...' : '');
                    }

                    showAlert('error', 'Lỗi kết nối', errorMessage);
                }
            });
        });

        // Format số tiền khi nhập
        $('#txtTotalMoneyInSafe').on('input', function () {
            var value = $(this).val().replace(/[^0-9]/g, '');
            if (value) {
                $(this).val(numberWithCommas(value));
            }
        });

        // Validate form
        function validateForm(shopName, totalMoney) {
            var isValid = true;

            // Reset previous errors
            clearErrors();

            // Validate tên cửa hàng
            if (!shopName) {
                showFieldError('#txtShopName', 'Vui lòng nhập tên cửa hàng');
                isValid = false;
            } else if (shopName.length < 2) {
                showFieldError('#txtShopName', 'Tên cửa hàng phải có ít nhất 2 ký tự');
                isValid = false;
            } else if (shopName.length > 255) {
                showFieldError('#txtShopName', 'Tên cửa hàng không được vượt quá 255 ký tự');
                isValid = false;
            }

            // Validate số vốn đầu tư
            if (!totalMoney) {
                showFieldError('#txtTotalMoneyInSafe', 'Vui lòng nhập số vốn đầu tư');
                isValid = false;
            } else {
                var moneyValue = parseFloat(totalMoney.replace(/,/g, ''));
                if (isNaN(moneyValue) || moneyValue <= 0) {
                    showFieldError('#txtTotalMoneyInSafe', 'Số vốn đầu tư phải là số dương');
                    isValid = false;
                } else if (moneyValue > 999999999999) {
                    showFieldError('#txtTotalMoneyInSafe', 'Số vốn đầu tư không được vượt quá 999,999,999,999');
                    isValid = false;
                }
            }

            return isValid;
        }

        // Clear all errors
        function clearErrors() {
            $('.form-control').removeClass('is-invalid');
            $('.invalid-feedback').remove();
            $('.alert').remove();
        }

        // Hiển thị lỗi cho field
        function showFieldError(fieldSelector, message) {
            $(fieldSelector).addClass('is-invalid');
            $(fieldSelector).after('<div class="invalid-feedback">' + message + '</div>');
        }

        // Format số với dấu phẩy
        function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        // Hiển thị/ẩn loading
        function showLoading(show) {
            if (show) {
                $('#btnSaveShop').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Đang xử lý...');
            } else {
                $('#btnSaveShop').prop('disabled', false).html('<i class="fa fa-save"></i> Lưu lại');
            }
        }

        // Xử lý response từ server
        function handleResponse(response) {
            if (response && response.success) {
                showAlert('success', 'Thành công!', response.message, function () {
                    // Redirect sau khi hiển thị thông báo
                    setTimeout(function () {
                        if (response.redirect) {
                            window.location.href = response.redirect;
                        } else {
                            window.location.href = './Index';
                        }
                    }, 1000);
                });
            } else {
                var errorMsg = response && response.message ? response.message : 'Có lỗi xảy ra!';
                showAlert('error', 'Lỗi', errorMsg);

                // Hiển thị lỗi validation nếu có
                if (response && response.errors) {
                    $.each(response.errors, function (field, message) {
                        var fieldId = '#txt' + field;
                        showFieldError(fieldId, message);
                    });
                }
            }
        }

        // Hiển thị alert
        function showAlert(type, title, message, callback) {
            var alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            var iconClass = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle';

            var alertHtml = `
            <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
                <i class="fa ${iconClass}"></i>
                <strong>${title}</strong> ${message}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        `;

            // Xóa alert cũ và thêm alert mới
            $('.alert').remove();
            $('.m-portlet__body').prepend(alertHtml);

            // Scroll to top để hiển thị alert
            $('html, body').animate({ scrollTop: 0 }, 300);

            // Auto hide và callback cho success
            if (type === 'success' && callback) {
                setTimeout(function () {
                    callback();
                }, 1500);
            }
        }

        // Reset form
        function resetForm() {
            $('#txtShopName').val('');
            $('#txtTotalMoneyInSafe').val('');
            $('#cbStatus-Success').prop('checked', true);
            clearErrors();
            formChanged = false;
        }

        // Event reset form
        $('button[type="reset"]:not(#btnSaveShop)').on('click', function (e) {
            e.preventDefault();
            if (confirm('Bạn có chắc muốn xóa tất cả dữ liệu đã nhập?')) {
                resetForm();
            }
        });

        // Track form changes
        var formChanged = false;
        $('#txtShopName, #txtTotalMoneyInSafe, input[name="cbStatus"]').on('change input', function () {
            formChanged = true;
        });

        // Warn before leaving page with unsaved changes
        $(window).on('beforeunload', function (e) {
            if (formChanged) {
                var message = 'Bạn có thay đổi chưa được lưu. Bạn có chắc muốn rời khỏi trang này?';
                e.returnValue = message;
                return message;
            }
        });

        // Clear form change flag on successful save
        $(document).ajaxSuccess(function (event, xhr, settings) {
            if (settings.url === SAVE_SHOP_URL) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response && response.success) {
                        formChanged = false;
                    }
                } catch (e) {
                    // Ignore JSON parse errors
                }
            }
        });

        // Focus vào field đầu tiên khi load trang
        $('#txtShopName').focus();

        // Enter key submit form
        $('#txtShopName, #txtTotalMoneyInSafe').on('keypress', function (e) {
            if (e.which === 13) { // Enter key
                $('#btnSaveShop').click();
            }
        });
    }); // End jQuery ready
})(); // End function wrapper

// Script để hiển thị popup khi click vào button "Thêm mới"
document.addEventListener('DOMContentLoaded', function () {
    // Kiểm tra xem jQuery đã được load chưa
    if (typeof $ === 'undefined') {
        console.error('jQuery chưa được load. Vui lòng thêm jQuery trước script này.');
        return;
    }

    // Kiểm tra Bootstrap modal
    if (typeof $.fn.modal === 'undefined') {
        console.error('Bootstrap JS chưa được load. Vui lòng thêm Bootstrap JS để sử dụng modal.');
    }

    // Đợi jQuery sẵn sàng
    $(document).ready(function () {
        // Xử lý sự kiện click vào button "Thêm mới"
        $('#btnModalCreate').on('click', function () {
            // Kiểm tra Bootstrap modal có sẵn không
            if (typeof $.fn.modal !== 'undefined') {
                // Hiển thị modal popup
                $('#modal_create_pawn').modal('show');
            } else {
                // Fallback: hiển thị modal bằng CSS
                $('#modal_create_pawn').css('display', 'block').addClass('show');
                $('body').addClass('modal-open');

                // Thêm backdrop
                if ($('.modal-backdrop').length === 0) {
                    $('body').append('<div class="modal-backdrop fade show"></div>');
                }
            }

            // Reset form về trạng thái ban đầu
            resetForm();
        });

        // Hàm reset form về trạng thái mặc định
        function resetForm() {
            // Reset các input text
            $('#hfId').val('0');
            $('#txtCustomer').val('');
            $('#txt_NewContractCustomerName').val('');
            $('#txtCodeID').val('');
            $('#txtInfoCusomer_NumberCard').val('');
            $('#txtInfoCusomer_Phone').val('');
            $('#txtInfoCusomer_CardDate').val('');
            $('#txtInfoCusomer_Place').val('');
            $('#txtInfoCusomer_Address').val('');
            $('#txtTotalMoney').val('0');
            $('#txtTotalMoneyReceived').val('0');
            $('#txtLoanTime').val('50');
            $('#txtFrequency').val('1');
            $('#txtStrFromDate').val('');
            $('#txtNote').val('');

            // Reset radio buttons
            $('#re_ContractTypeCustomer-Success').prop('checked', true);
            $('#re_ContractTypeCustomer-Stop').prop('checked', false);

            // Reset checkbox
            $('#IsBefore').prop('checked', false);

            // Hiển thị/ẩn div theo mặc định
            $('#dv_oldContractCustomerName').show();
            $('#dv_newContractCustomerName').hide();
            $('#dv_cmndDetail').hide();

            // Reset select boxes về giá trị mặc định
            $('#m-select-ratetype_create').val('0').trigger('change');
            $('#m-select-staff').val($('#m-select-staff option:first').val()).trigger('change');
            $('#m_pawn_create_affID').val('0').trigger('change');
            $('#m_pawn_create_AffTypeMoney').val('2').trigger('change');

            // Ẩn các thông báo lỗi
            $('.text-danger[id$="-errorMess"]').hide();
            $('#lbl_error_interest').hide();
            $('#messageNotUpdate').hide();

            // Reset title modal
            $('#titleFormPawn').text('Thêm mới Hợp đồng');

            // Hiển thị button in
            $('#dvPrint').show();
        }

        // Xử lý sự kiện thay đổi loại khách hàng
        function onchangerContractTypeCustomer() {
            if ($('#re_ContractTypeCustomer-Stop').is(':checked')) {
                // Khách hàng mới
                $('#dv_oldContractCustomerName').hide();
                $('#dv_newContractCustomerName').show();
            } else {
                // Khách hàng cũ
                $('#dv_oldContractCustomerName').show();
                $('#dv_newContractCustomerName').hide();
            }
        }

        // Gán sự kiện cho radio buttons
        $('input[name="re_ContractTypeCustomer"]').on('change', onchangerContractTypeCustomer);

        // Xử lý đóng modal
        $('#btnCloseModalPawn, .btn-warning[data-dismiss="modal"]').on('click', function () {
            if (typeof $.fn.modal !== 'undefined') {
                $('#modal_create_pawn').modal('hide');
            } else {
                // Fallback: ẩn modal bằng CSS
                $('#modal_create_pawn').css('display', 'none').removeClass('show');
                $('body').removeClass('modal-open');
                $('.modal-backdrop').remove();
            }
        });

        // Xử lý click backdrop để đóng modal
        $(document).on('click', '.modal-backdrop', function () {
            if (typeof $.fn.modal !== 'undefined') {
                $('#modal_create_pawn').modal('hide');
            } else {
                $('#modal_create_pawn').css('display', 'none').removeClass('show');
                $('body').removeClass('modal-open');
                $('.modal-backdrop').remove();
            }
        });
    });
});