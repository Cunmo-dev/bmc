// Staff List Management Script
class StaffList {
    constructor() {
        this.currentPage = 1;
        this.limit = 50;
        this.searchQuery = '';
        this.isLoading = false;

        this.init();
    }

    init() {
        // Load danh sách nhân viên khi trang được load
        document.addEventListener('DOMContentLoaded', () => {
            this.loadStaffList();
            this.bindEvents();
        });
    }

    bindEvents() {
        // Bind sự kiện cho pagination
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-page]')) {
                e.preventDefault();
                const page = parseInt(e.target.getAttribute('data-page'));
                if (page && page !== this.currentPage) {
                    this.currentPage = page;
                    this.loadStaffList();
                }
            }
        });

        // Bind sự kiện cho page size selector
        const pageSizeSelect = document.querySelector('.m-datatable__pager-size select');
        if (pageSizeSelect) {
            pageSizeSelect.addEventListener('change', (e) => {
                this.limit = parseInt(e.target.value) || 50;
                this.currentPage = 1;
                this.loadStaffList();
            });
        }

        // Bind sự kiện tìm kiếm (nếu có)
        const searchInput = document.querySelector('#staffSearch');
        if (searchInput) {
            searchInput.addEventListener('input', this.debounce((e) => {
                this.searchQuery = e.target.value.trim();
                this.currentPage = 1;
                this.loadStaffList();
            }, 500));
        }
    }

    // Debounce function để tránh call API quá nhiều khi search
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    async loadStaffList() {
        if (this.isLoading) return;

        this.isLoading = true;
        this.showLoading(true);

        try {
            const params = new URLSearchParams({
                page: this.currentPage,
                limit: this.limit
            });

            if (this.searchQuery) {
                params.append('search', this.searchQuery);
            }

            const response = await fetch(API_BASE_URL + `get_staff_list_All.php?${params.toString()}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'same-origin'
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (result.success) {
                // Xử lý cấu trúc dữ liệu mới từ PHP
                if (result.data && result.data.staff_list) {
                    // Cấu trúc mới: result.data.staff_list và result.data.pagination
                    this.renderStaffList(result.data.staff_list);
                    this.renderPagination(result.data.pagination);
                } else {
                    // Cấu trúc cũ: fallback
                    const staffList = result.data || [];
                    const totalRecords = result.total || 0;

                    const totalPages = Math.ceil(totalRecords / this.limit);
                    const pagination = {
                        current_page: this.currentPage,
                        total_pages: totalPages,
                        total_records: totalRecords,
                        per_page: this.limit,
                        has_prev_page: this.currentPage > 1,
                        has_next_page: this.currentPage < totalPages
                    };

                    this.renderStaffList(staffList);
                    this.renderPagination(pagination);
                }
            } else {
                this.showError(result.message);

                // Redirect nếu cần đăng nhập
                if (result.redirect) {
                    window.location.href = result.redirect;
                    return;
                }
            }

        } catch (error) {
            console.error('Error loading staff list:', error);
            this.showError('Lỗi khi tải danh sách nhân viên: ' + error.message);
        } finally {
            this.isLoading = false;
            this.showLoading(false);
        }
    }

    renderStaffList(staffList) {
        const tbody = document.querySelector('#dtStaff .m-datatable__body');
        if (!tbody) {
            console.error('Table body not found');
            return;
        }

        // Xóa nội dung cũ
        tbody.innerHTML = '';

        if (!staffList || staffList.length === 0) {
            tbody.innerHTML = `
                <tr class="m-datatable__row">
                    <td colspan="7" class="text-center" style="padding: 20px;">
                        <div class="m-portlet__body--empty">
                            <i class="la la-info-circle" style="font-size: 48px; color: #ccc;"></i>
                            <p style="margin-top: 10px; color: #999;">Chưa có nhân viên nào</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }

        // Tạo HTML cho từng nhân viên
        staffList.forEach((staff, index) => {
            const row = this.createStaffRow(staff, index + 1 + (this.currentPage - 1) * this.limit);
            tbody.appendChild(row);
        });
    }

    createStaffRow(staff, rowNumber) {
        const tr = document.createElement('tr');
        tr.className = 'm-datatable__row';
        tr.style.height = '56px';
        tr.setAttribute('data-row', rowNumber - 1);

        // Xác định status class và text
        const statusClass = staff.status == 1 ? 'success' : 'warning';
        const statusText = staff.status_text || (staff.status == 1 ? 'Hoạt động' : 'Tạm dừng');

        tr.innerHTML = `
            <td data-field="RowID" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 40px;">${rowNumber}</span>
            </td>
            <td data-field="ShopName" style="text-align:left" class="m-datatable__cell">
                <span style="width: 180px;">${this.escapeHtml(staff.shop_name)}</span>
            </td>
            <td data-field="Username" style="text-align:left" class="m-datatable__cell">
                <span style="width: 250px;">
                    <div>
                        <div class="m-card-user__details">
                            <a href="/Staff/Create?StaffID=${staff.id}" 
                               class="m-card-user__email m-link font-cusName font-weight-bold">
                                ${this.escapeHtml(staff.username)}
                            </a>
                        </div>
                    </div>
                </span>
            </td>
            <td data-field="FullName" style="text-align:left" class="m-datatable__cell">
                <span style="width: 100px;">${this.escapeHtml(staff.full_name || '')}</span>
            </td>
            <td data-field="CreateDate" style="text-align:center" class="m-datatable__cell--center m-datatable__cell">
                <span style="width: 80px;">${staff.created_date || ''}</span>
            </td>
            <td data-field="Status" style="text-align:left" class="m-datatable__cell">
                <span style="width: 110px;">
                    <span class="m-badge m-badge--${statusClass} m-badge--wide">
                        ${statusText}
                    </span>
                </span>
            </td>
            <td data-field="Actions" style="text-align:left" class="m-datatable__cell">
                <span style="overflow: visible; width: 140px;">
                    <button onclick="confirmDelete(${staff.id},'${this.escapeHtml(staff.username)}')" 
                            class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" 
                            title="Xóa nhân viên">
                        <i class="la la-trash"></i>
                    </button>
                </span>
            </td>
        `;

        return tr;
    }

    renderPagination(pagination) {
        const pagerNav = document.querySelector('.m-datatable__pager-nav');
        const pagerInfo = document.querySelector('.m-datatable__pager-info .m-datatable__pager-detail');

        if (!pagerNav || !pagerInfo) return;

        // Cập nhật thông tin tổng số bản ghi
        pagerInfo.textContent = `Tống số ${pagination.total_records} bản ghi`;

        // Hiển thị/ẩn pagination
        if (pagination.total_pages <= 1) {
            pagerNav.style.display = 'none';
            return;
        }

        pagerNav.style.display = 'flex';

        // Xóa nội dung cũ
        pagerNav.innerHTML = '';

        // Nút First
        const firstBtn = this.createPaginationButton('Về trang đầu', 1, 'first', 'la-angle-double-left', !pagination.has_prev_page);
        pagerNav.appendChild(firstBtn);

        // Nút Previous
        const prevBtn = this.createPaginationButton('Trang trước', pagination.current_page - 1, 'prev', 'la-angle-left', !pagination.has_prev_page);
        pagerNav.appendChild(prevBtn);

        // Các số trang
        const startPage = Math.max(1, pagination.current_page - 2);
        const endPage = Math.min(pagination.total_pages, pagination.current_page + 2);

        for (let i = startPage; i <= endPage; i++) {
            const pageBtn = this.createPaginationButton(i.toString(), i, 'number', '', false, i === pagination.current_page);
            pagerNav.appendChild(pageBtn);
        }

        // Nút Next
        const nextBtn = this.createPaginationButton('Trang sau', pagination.current_page + 1, 'next', 'la-angle-right', !pagination.has_next_page);
        pagerNav.appendChild(nextBtn);

        // Nút Last
        const lastBtn = this.createPaginationButton('Đến trang cuối', pagination.total_pages, 'last', 'la-angle-double-right', !pagination.has_next_page);
        pagerNav.appendChild(lastBtn);
    }

    createPaginationButton(title, page, type, iconClass, disabled, active = false) {
        const li = document.createElement('li');
        const a = document.createElement('a');

        a.setAttribute('title', title);
        a.className = `m-datatable__pager-link m-datatable__pager-link--${type}`;

        if (active) {
            a.className += ' m-datatable__pager-link--active';
            a.setAttribute('id', `_pageIndex_${page}`);
        }

        if (disabled) {
            a.className += ' m-datatable__pager-link--disabled';
            a.setAttribute('disabled', 'disabled');
        } else {
            a.setAttribute('data-page', page);
            a.style.cursor = 'pointer';
        }

        if (iconClass) {
            a.innerHTML = `<i class="la ${iconClass}"></i>`;
        } else {
            a.textContent = title;
        }

        li.appendChild(a);
        return li;
    }

    showLoading(show) {
        const tbody = document.querySelector('#dtStaff .m-datatable__body');
        if (!tbody) return;

        if (show) {
            tbody.innerHTML = `
                <tr class="m-datatable__row">
                    <td colspan="7" class="text-center" style="padding: 20px;">
                        <div class="m-loader m-loader--lg" style="display: inline-block;"></div>
                        <p style="margin-top: 10px;">Đang tải danh sách nhân viên...</p>
                    </td>
                </tr>
            `;
        }
    }

    showError(message) {
        const tbody = document.querySelector('#dtStaff .m-datatable__body');
        if (!tbody) return;

        tbody.innerHTML = `
            <tr class="m-datatable__row">
                <td colspan="7" class="text-center" style="padding: 20px;">
                    <div class="alert alert-danger" style="margin: 0;">
                        <i class="la la-warning"></i>
                        ${this.escapeHtml(message)}
                    </div>
                    <button class="btn btn-sm btn-secondary" onclick="staffListManager.loadStaffList()" style="margin-top: 10px;">
                        <i class="la la-refresh"></i> Thử lại
                    </button>
                </td>
            </tr>
        `;
    }

    // Helper function để escape HTML
    escapeHtml(text) {
        if (!text) return '';
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function (m) { return map[m]; });
    }
}

// Khởi tạo StaffList manager
const staffListManager = new StaffList();

function confirmDelete(staffId, username) {
    // Tạo HTML modal
    const modalHTML = `
        <div class="swal2-container swal2-center swal2-fade swal2-shown" style="overflow-y: auto;">
            <div role="dialog" aria-modal="true" aria-labelledby="swal2-title" aria-describedby="swal2-content" 
                 class="swal2-popup swal2-modal swal2-show" tabindex="-1" aria-live="assertive" 
                 style="width: 400px; padding: 2.5rem; background: rgb(255, 255, 255); display: flex;">
                
                <ul class="swal2-progresssteps" style="display: none;"></ul>
                
                <div class="swal2-icon swal2-error" style="display: none;">
                    <span class="swal2-x-mark">
                        <span class="swal2-x-mark-line-left"></span>
                        <span class="swal2-x-mark-line-right"></span>
                    </span>
                </div>
                
                <div class="swal2-icon swal2-question" style="display: none;">?</div>
                
                <div class="swal2-icon swal2-warning" style="display: block;">!</div>
                
                <div class="swal2-icon swal2-info" style="display: none;">i</div>
                
                <div class="swal2-icon swal2-success" style="display: none;">
                    <div class="swal2-success-circular-line-left" style="background: rgb(255, 255, 255);"></div>
                    <span class="swal2-success-line-tip"></span> 
                    <span class="swal2-success-line-long"></span>
                    <div class="swal2-success-ring"></div> 
                    <div class="swal2-success-fix" style="background: rgb(255, 255, 255);"></div>
                    <div class="swal2-success-circular-line-right" style="background: rgb(255, 255, 255);"></div>
                </div>
                
                <img class="swal2-image" style="display: none;">
                
                <div class="swal2-contentwrapper">
                    <h2 class="swal2-title" id="swal2-title">
                        Bạn có chắc chắn xóa nhân viên<br> 
                        <b class="text-danger">${username}</b> không. nhân viên xóa vĩnh viễn và không thể khôi phục lại?
                    </h2>
                    <div id="swal2-content" class="swal2-content" style="display: block;">
                        Bạn sẽ không thể khôi phục tài khoản này nữa!
                    </div>
                </div>
                
                <input class="swal2-input" style="display: none;">
                <input type="file" class="swal2-file" style="display: none;">
                <div class="swal2-range" style="display: none;">
                    <output></output>
                    <input type="range">
                </div>
                <select class="swal2-select" style="display: none;"></select>
                <div class="swal2-radio" style="display: none;"></div>
                <label for="swal2-checkbox" class="swal2-checkbox" style="display: none;">
                    <input type="checkbox">
                </label>
                <textarea class="swal2-textarea" style="display: none;"></textarea>
                <div class="swal2-validationerror" id="swal2-validationerror" style="display: none;"></div>
                
                <div class="swal2-buttonswrapper" style="display: flex;">
                    <button type="button" class="swal2-confirm btn btn-danger m-btn m-btn--pill m-btn--air m-btn--icon" aria-label="">
                        <span>
                            <i class="la la-check-circle"></i>
                            <span>Đồng ý xóa!</span>
                        </span>
                    </button>
                    <button type="button" class="swal2-cancel btn btn-secondary m-btn m-btn--pill m-btn--icon" aria-label="" style="display: inline-block;">
                        <span>
                            <i class="la la-minus-circle"></i>
                            <span>Nghĩ lại</span>
                        </span>
                    </button>
                </div>
                
                <button type="button" class="swal2-close" style="display: none;">×</button>
            </div>
        </div>
    `;

    // Thêm modal vào body
    const modalContainer = document.createElement('div');
    modalContainer.innerHTML = modalHTML;
    document.body.appendChild(modalContainer);

    // Lấy các nút
    const confirmBtn = modalContainer.querySelector('.swal2-confirm');
    const cancelBtn = modalContainer.querySelector('.swal2-cancel');
    const modalElement = modalContainer.querySelector('.swal2-container');

    // Xử lý sự kiện cho nút "Đồng ý xóa"
    confirmBtn.addEventListener('click', function () {
        // Xóa modal
        document.body.removeChild(modalContainer);
        // Gọi hàm deleteStaff
        deleteStaff(staffId, username);
    });

    // Xử lý sự kiện cho nút "Nghĩ lại"
    cancelBtn.addEventListener('click', function () {
        // Chỉ xóa modal
        document.body.removeChild(modalContainer);
    });

    // Xử lý sự kiện click bên ngoài modal để đóng
    modalElement.addEventListener('click', function (e) {
        if (e.target === modalElement) {
            document.body.removeChild(modalContainer);
        }
    });
}

// Function xóa nhân viên
async function deleteStaff(staffId, username) {
    try {
        const response = await fetch(API_BASE_URL + 'delete_staff.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            credentials: 'same-origin',
            body: `staffId=${encodeURIComponent(staffId)}`
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();

        if (result.success) {
            // Hiển thị thông báo thành công
            //alert(result.message || 'Xóa nhân viên thành công!');

            // Reload danh sách nhân viên
            staffListManager.loadStaffList();
        } else {
            alert(result.message || 'Có lỗi xảy ra khi xóa nhân viên!');
        }

    } catch (error) {
        console.error('Error deleting staff:', error);
        alert('Lỗi khi xóa nhân viên: ' + error.message);
    }
}

// Export để có thể sử dụng ở nơi khác
window.staffListManager = staffListManager;
window.confirmDelete = confirmDelete;