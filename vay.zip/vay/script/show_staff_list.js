$(document).ready(function () {
    // Biến global để lưu dữ liệu
    let staffList = [];
    let shopList = [];

    // Load danh sách nhân viên khi trang được load
    loadStaffList();
    loadShopList();

    // Load danh sách nhân viên từ database
    function loadStaffList() {
        $.ajax({
            url: API_BASE_URL + 'get_staff_list.php',
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    staffList = response.data;
                    populateStaffSelect();
                } else {
                    showAlert('error', response.message || 'Không thể tải danh sách nhân viên');
                }
            },
            error: function (xhr, status, error) {
                console.error('Error loading staff list:', error);
                showAlert('error', 'Lỗi kết nối khi tải danh sách nhân viên');
            }
        });
    }

    // Load danh sách shop từ database
    function loadShopList() {
        $.ajax({
            url: API_BASE_URL + 'get_shops.php?action=list',
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    shopList = response.data;
                    displayShopList();
                } else {
                    showAlert('error', response.message || 'Không thể tải danh sách cửa hàng');
                }
            },
            error: function (xhr, status, error) {
                console.error('Error loading shop list:', error);
                showAlert('error', 'Lỗi kết nối khi tải danh sách cửa hàng');
            }
        });
    }

    // Populate staff select dropdown
    function populateStaffSelect() {
        const selectElement = $('#m-select-staff-shop');
        selectElement.empty();
        selectElement.append('<option value="">Chọn nhân viên</option>');

        staffList.forEach(function (staff) {
            selectElement.append(`
                <option value="${staff.id}">${staff.full_name} (${staff.username})</option>
            `);
        });
    }

    // Display shop list with checkboxes
    function displayShopList() {
        const container = $('#shop-list-container');
        container.empty();

        shopList.forEach(function (shop) {
            const statusBadge = shop.status == 1
                ? '<span class="badge badge-success">Hoạt động</span>'
                : '<span class="badge badge-warning">Tạm đóng</span>';

            const shopCard = `
                <div class="shop-card" data-shop-id="${shop.shop_id}">
                    <div class="d-flex align-items-center">
                        <input type="checkbox" class="shop-checkbox" id="shop-${shop.shop_id}" value="${shop.shop_id}">
                        <div class="shop-info flex-grow-1">
                            <h5>${shop.name}</h5>
                            <p><i class="fa fa-money-bill text-primary"></i> 
                               ${shop.total_money_formatted} VND</p>
                        </div>
                        <div class="shop-status">
                            ${statusBadge}
                        </div>
                    </div>
                </div>
            `;
            container.append(shopCard);
        });

        // Bind events for shop cards
        bindShopCardEvents();
    }

    // Bind events cho shop cards
    function bindShopCardEvents() {
        // Click vào card để toggle checkbox
        $('.shop-card').on('click', function (e) {
            if (!$(e.target).is('input[type="checkbox"]')) {
                const checkbox = $(this).find('.shop-checkbox');
                checkbox.prop('checked', !checkbox.prop('checked'));
                checkbox.trigger('change');
            }
        });

        // Xử lý khi checkbox thay đổi
        $('.shop-checkbox').on('change', function () {
            const card = $(this).closest('.shop-card');
            if ($(this).prop('checked')) {
                card.addClass('selected');
            } else {
                card.removeClass('selected');
            }
            updateSelectedCount();
        });
    }

    // Cập nhật số lượng shop đã chọn
    function updateSelectedCount() {
        const selectedCount = $('.shop-checkbox:checked').length;
        $('#selected-count').text(`${selectedCount} đã chọn`);

        if (selectedCount > 0) {
            $('#selected-summary').show();
            $('#summary-text').text(`Đã chọn ${selectedCount} cửa hàng`);
        } else {
            $('#selected-summary').hide();
        }

        // Update select all button
        const totalShops = $('.shop-checkbox').length;
        const selectAllBtn = $('#select-all-btn');
        if (selectedCount === totalShops && totalShops > 0) {
            selectAllBtn.html('<i class="fa fa-minus-square"></i> Bỏ chọn tất cả');
        } else {
            selectAllBtn.html('<i class="fa fa-check-square"></i> Chọn tất cả');
        }
    }

    // Xử lý nút chọn tất cả
    $('#select-all-btn').on('click', function () {
        const allCheckboxes = $('.shop-checkbox');
        const selectedCount = $('.shop-checkbox:checked').length;
        const totalCount = allCheckboxes.length;

        if (selectedCount === totalCount) {
            // Bỏ chọn tất cả
            allCheckboxes.prop('checked', false);
            $('.shop-card').removeClass('selected');
        } else {
            // Chọn tất cả
            allCheckboxes.prop('checked', true);
            $('.shop-card').addClass('selected');
        }

        updateSelectedCount();
    });

    // Xử lý khi chọn nhân viên
    $('#m-select-staff-shop').on('change', function () {
        const staffId = $(this).val();
        if (staffId) {
            loadStaffShops(staffId);
        } else {
            // Reset tất cả checkbox nếu không chọn nhân viên
            $('.shop-checkbox').prop('checked', false);
            $('.shop-card').removeClass('selected');
            updateSelectedCount();
        }
    });

    // Load danh sách shop hiện tại của nhân viên
    function loadStaffShops(staffId) {
        // Hiển thị loading
        $('.loading-spinner').show();

        $.ajax({
            url: API_BASE_URL + 'get_staff_shops.php',
            type: 'GET',
            data: { staff_id: staffId },
            dataType: 'json',
            success: function (response) {
                $('.loading-spinner').hide();

                if (response.success) {
                    // Reset tất cả checkbox
                    $('.shop-checkbox').prop('checked', false);
                    $('.shop-card').removeClass('selected');

                    // Check các shop mà nhân viên hiện tại đang quản lý
                    response.data.forEach(function (shopId) {
                        const checkbox = $(`.shop-checkbox[value="${shopId}"]`);
                        checkbox.prop('checked', true);
                        checkbox.closest('.shop-card').addClass('selected');
                    });

                    updateSelectedCount();
                } else {
                    showAlert('warning', response.message || 'Không thể tải danh sách cửa hàng của nhân viên');
                }
            },
            error: function (xhr, status, error) {
                $('.loading-spinner').hide();
                console.error('Error loading staff shops:', error);
                showAlert('error', 'Lỗi kết nối khi tải danh sách cửa hàng của nhân viên');
            }
        });
    }

    // Xử lý nút lưu
    $('#btnSavePermissionShop').on('click', function () {
        const staffId = $('#m-select-staff-shop').val();

        if (!staffId) {
            showAlert('warning', 'Vui lòng chọn nhân viên!');
            return;
        }

        const selectedShops = [];
        $('.shop-checkbox:checked').each(function () {
            selectedShops.push($(this).val());
        });

        if (selectedShops.length === 0) {
            showAlert('warning', 'Vui lòng chọn ít nhất một cửa hàng!');
            return;
        }

        // Hiển thị loading
        const btnSave = $(this);
        const originalText = btnSave.html();
        btnSave.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Đang lưu...');

        // Gửi request lưu
        $.ajax({
            url: API_BASE_URL + 'save_staff_shops.php',
            type: 'POST',
            data: {
                staff_id: staffId,
                'shop_ids[]': selectedShops  // Gửi dạng array
            },
            dataType: 'json',
            success: function (response) {
                btnSave.prop('disabled', false).html(originalText);

                if (response.success) {
                    showAlert('success', response.message || 'Lưu thành công!');

                    // Redirect nếu có
                    if (response.redirect) {
                        setTimeout(function () {
                            window.location.href = response.redirect;
                        }, 1500);
                    }
                } else {
                    showAlert('error', response.message || 'Có lỗi xảy ra khi lưu!');
                }
            },
            error: function (xhr, status, error) {
                btnSave.prop('disabled', false).html(originalText);
                console.error('Error saving staff shops:', error);
                showAlert('error', 'Lỗi kết nối khi lưu dữ liệu!');
            }
        });
    });

    // Xử lý nút làm mới
    $('#btn-reset-form').on('click', function () {
        $('#m-select-staff-shop').val('').trigger('change');
        $('.shop-checkbox').prop('checked', false);
        $('.shop-card').removeClass('selected');
        updateSelectedCount();
        showAlert('info', 'Đã làm mới form!');
    });

    // Hàm hiển thị thông báo
    function showAlert(type, message) {
        // Remove existing alerts
        $('.custom-alert').remove();

        let alertClass = 'alert-info';
        let icon = 'fa-info-circle';

        switch (type) {
            case 'success':
                alertClass = 'alert-success';
                icon = 'fa-check-circle';
                break;
            case 'error':
                alertClass = 'alert-danger';
                icon = 'fa-exclamation-circle';
                break;
            case 'warning':
                alertClass = 'alert-warning';
                icon = 'fa-exclamation-triangle';
                break;
        }

        const alertHtml = `
            <div class="alert ${alertClass} alert-dismissible fade show custom-alert" role="alert" style="position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                <i class="fa ${icon}"></i> ${message}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        `;

        $('body').append(alertHtml);

        // Auto hide sau 5 giây
        setTimeout(function () {
            $('.custom-alert').fadeOut();
        }, 5000);
    }
});