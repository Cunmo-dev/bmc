
function getApiBaseUrl() {
    const origin = window.location.origin;
    const hostname = window.location.hostname;

    // Cấu hình cho từng môi trường
    const environments = {
        // Local development
        'localhost': '/vay/api/',
        '127.0.0.1': '/vay/api/',

        // Hosting (thay 'yourdomain.com' bằng domain thực tế)
        'yourdomain.com': '/api/',
        'www.yourdomain.com': '/api/'
    };

    // Kiểm tra IP local (192.168.x.x)
    if (hostname.startsWith('192.168.')) {
        return `${origin}/vay/api/`;
    }

    // Lấy path từ config hoặc fallback
    const apiPath = environments[hostname] || '/api/';
    return `${origin}${apiPath}`;
}

const API_BASE_URL = getApiBaseUrl();

//let sessionToken = localStorage.getItem('session_token');
let sessionToken = localStorage.getItem('session_token');
let sessionMonitorInterval = null;

// Kiểm tra session khi tải trang dashboard
window.addEventListener('load', function () {
    //////console.log('Dashboard loaded, checking session...');
    //////console.log('Session token:', sessionToken);

    if (!sessionToken) {
        //////console.log('No session token found, redirecting to login');
        showMessage('Không tìm thấy phiên đăng nhập!', 'error');
        setTimeout(() => {
            window.location.href = window.location.origin + '/vay/index.html';
        }, 2000);
        return;
    }

    // Kiểm tra session hợp lệ
    checkSessionAndLoadDashboard();
});

async function checkSessionAndLoadDashboard() {
    //////console.log('Checking session validity...');

    try {
        const result = await apiCall(`auth.php?action=check_session&session_token=${sessionToken}`);
        //////console.log('Session check result:', result);

        if (result.success && result.user) {
            //////console.log('Session valid, displaying user info');
            // Session hợp lệ, hiển thị thông tin user
            displayUserInfo(result.user);
            startSessionMonitoring();
            showContent();
        } else {
            //////console.log('Invalid session, redirecting to login');
            // Session không hợp lệ
            //localStorage.removeItem('session_token');
            localStorage.removeItem('session_token');
            showMessage('Phiên đăng nhập đã hết hạn!', 'error');
            setTimeout(() => {
                window.location.href = window.location.origin + '/vay/index.html';
            }, 2000);
        }
    } catch (error) {
        console.error('Session check error:', error);
        showMessage('Lỗi kiểm tra phiên đăng nhập!', 'error');
        // KHÔNG redirect ngay khi có lỗi DOM
        //////console.log('Error might be due to missing DOM elements, not redirecting immediately');

        // Thử hiển thị content anyway nếu có session token
        if (sessionToken) {
            setTimeout(() => {
                displayUserInfo({ username: 'User', email: 'user@example.com' });
                showContent();
            }, 1000);
        }
    }
}

function showContent() {
    //////console.log('Showing dashboard content');

    // NULL SAFE - kiểm tra element tồn tại trước khi thao tác
    const loadingEl = document.getElementById('loading');
    const contentEl = document.getElementById('content');
    const errorEl = document.getElementById('error');

    if (loadingEl) {
        loadingEl.style.display = 'none';
        //////console.log('Loading element hidden');
    } else {
        //console.warn('Loading element (#loading) not found in DOM');
    }

    if (contentEl) {
        contentEl.style.display = 'block';
        //////console.log('Content element shown');
    } else {
        //console.warn('Content element (#content) not found in DOM');
        // Nếu không có #content, thử hiển thị toàn bộ body
        document.body.style.display = 'block';
    }

    if (errorEl) {
        errorEl.style.display = 'none';
        //////console.log('Error element hidden');
    } else {
        //console.warn('Error element (#error) not found in DOM');
    }
}

function showError(message) {
    //////console.log('Showing error:', message);

    // NULL SAFE - kiểm tra từng element
    const loadingEl = document.getElementById('loading');
    const contentEl = document.getElementById('content');
    const errorEl = document.getElementById('error');
    const errorTextEl = document.querySelector('#error .error p');

    // Safely hide loading
    if (loadingEl) {
        loadingEl.style.display = 'none';
    } else {
        //console.warn('Loading element not found');
    }

    // Safely hide content
    if (contentEl) {
        contentEl.style.display = 'none';
    } else {
        //console.warn('Content element not found');
    }

    // Safely show error
    if (errorEl) {
        errorEl.style.display = 'block';
        //////console.log('Error element shown');
    } else {
        //console.warn('Error element not found - creating fallback');
        // Tạo error element tạm thời nếu không tồn tại
        createFallbackErrorElement(message);
    }

    // Safely update error message
    if (message && errorTextEl) {
        errorTextEl.textContent = message;
    } else if (message) {
        //console.warn('Error text element not found, message:', message);
        // Fallback: hiển thị alert nếu không có error element
        alert(message);
    }
}

// Tạo error element tạm thời nếu không có trong HTML
function createFallbackErrorElement(message) {
    // Kiểm tra xem đã có fallback error chưa
    let fallbackError = document.getElementById('fallback-error');

    if (!fallbackError) {
        fallbackError = document.createElement('div');
        fallbackError.id = 'fallback-error';
        fallbackError.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            z-index: 9999;
            max-width: 400px;
        `;
        document.body.appendChild(fallbackError);
    }

    fallbackError.innerHTML = `<strong>Lỗi:</strong> ${message}`;
    fallbackError.style.display = 'block';
}

function displayUserInfo(userData) {
    //////console.log('Displaying user info:', userData);
    // Kiểm tra nếu user khác với user trước đó
    const currentUserId = userData.user_id;
    const lastUserId = localStorage.getItem('last_user_id');

    if (lastUserId && lastUserId !== currentUserId) {
        // User khác nhau, xóa shop selection cũ
        localStorage.removeItem('selected_shop_id');
        localStorage.removeItem('selected_shop_name');
    }

    // Lưu user_id để check lần sau
    //localStorage.setItem('last_user_id', currentUserId);
    localStorage.setItem('last_user_id', currentUserId);
    // NULL SAFE - hiển thị thông tin user
    const userNameEl = document.getElementById('user-name');
    const userEmailEl = document.getElementById('user-email');
    const loginTimeEl = document.getElementById('login-time');

    if (userNameEl && userData.username) {
        userNameEl.textContent = userData.username;
        //////console.log('Username displayed:', userData.username);
    } else {
        //console.warn('Username element (#user-name) not found or no username data');
    }

    if (userEmailEl && userData.email) {
        userEmailEl.textContent = userData.email;
        //////console.log('Email displayed:', userData.email);
    } else {
        //console.warn('Email element (#user-email) not found or no email data');
    }

    if (loginTimeEl) {
        loginTimeEl.textContent = new Date().toLocaleString('vi-VN');
        //////console.log('Login time displayed');
    } else {
        //console.warn('Login time element (#login-time) not found');
    }
}

function showMessage(message, type) {
    const messageArea = document.getElementById('message-area');
    if (messageArea) {
        messageArea.innerHTML = `<div class="message ${type}">${message}</div>`;
        // Tự động ẩn message sau 5 giây
        setTimeout(() => {
            messageArea.innerHTML = '';
        }, 5000);
        //////console.log('Message displayed:', message, type);
    } else {
        //console.warn('Message area not found, using fallback');
        // Fallback: tạo message area tạm thời
        createFallbackMessage(message, type);
    }
}

function createFallbackMessage(message, type) {
    let fallbackMessage = document.getElementById('fallback-message');

    if (!fallbackMessage) {
        fallbackMessage = document.createElement('div');
        fallbackMessage.id = 'fallback-message';
        fallbackMessage.style.cssText = `
            position: fixed;
            top: 70px;
            right: 20px;
            padding: 15px;
            border-radius: 5px;
            z-index: 9999;
            max-width: 400px;
        `;
        document.body.appendChild(fallbackMessage);
    }

    // Style theo type
    if (type === 'error') {
        fallbackMessage.style.background = '#f8d7da';
        fallbackMessage.style.color = '#721c24';
        fallbackMessage.style.border = '1px solid #f5c6cb';
    } else {
        fallbackMessage.style.background = '#d4edda';
        fallbackMessage.style.color = '#155724';
        fallbackMessage.style.border = '1px solid #c3e6cb';
    }

    fallbackMessage.textContent = message;
    fallbackMessage.style.display = 'block';

    // Tự động ẩn sau 5 giây
    setTimeout(() => {
        fallbackMessage.style.display = 'none';
    }, 5000);
}

// Utility function for API calls
async function apiCall(endpoint, method = 'GET', data = null) {
    ////////console.log('Making API call:', endpoint, method, data);

    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('session_token') || ''}`
            }
        };

        if (data && method !== 'GET') {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(API_BASE_URL + endpoint, options);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        ////////console.log('API response:', result);
        return result;
    } catch (error) {
        console.error('API Error:', error);
        return { success: false, message: 'Lỗi kết nối đến server!' };
    }
}

// Start monitoring for concurrent sessions
function startSessionMonitoring() {
    //////console.log('Starting session monitoring...');

    if (sessionMonitorInterval) {
        clearInterval(sessionMonitorInterval);
    }

    sessionMonitorInterval = setInterval(async () => {
        await checkConcurrentLogin();
    }, 100000); // Kiểm tra mỗi 10 giây
}

// Check for concurrent login
async function checkConcurrentLogin() {
    try {
        const result = await apiCall(`session_monitor.php?session_token=${sessionToken}`);

        if (result && !result.valid) {
            showMessage('Tài khoản của bạn đã được đăng nhập từ nơi khác. Bạn sẽ được đăng xuất.', 'error');
            setTimeout(() => {
                forceLogout();
            }, 3000);
        }
    } catch (error) {
        console.error('Session monitor error:', error);
    }
}

// Logout function
async function logout() {
    //////console.log('Logging out...');

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.disabled = true;
        logoutBtn.textContent = 'Đang đăng xuất...';
    } else {
        //console.warn('Logout button not found');
    }

    if (sessionMonitorInterval) {
        clearInterval(sessionMonitorInterval);
        sessionMonitorInterval = null;
    }

    if (sessionToken) {
        try {
            await apiCall(`auth.php?action=logout&session_token=${sessionToken}`);
        } catch (error) {
            console.error('Logout API error:', error);
        }
    }

    localStorage.removeItem('session_token');
    sessionToken = null;
    localStorage.removeItem('user_id');     // Lưu user_id
    localStorage.removeItem('store_id');   // Lưu store_id
    localStorage.removeItem('username');
    localStorage.removeItem('user_email');
    localStorage.removeItem('store_name');
    showMessage('Đang đăng xuất...', 'success');
    setTimeout(() => {
        window.location.href = window.location.origin + '/vay/index.html';
    }, 1000);
}

function forceLogout() {
    logout();
}

function redirectToLogin() {
    window.location.href = window.location.origin + '/vay/index.html';
}

// NULL SAFE event listeners
document.addEventListener('DOMContentLoaded', function () {
    //////console.log('DOM Content Loaded - setting up event listeners');

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
        //////console.log('Logout button event listener added');
    } else {
        //console.warn('Logout button (#logout-btn) not found');
    }
    const logoutBtn1 = document.getElementById('mlogout-btn');
    if (logoutBtn1) {
        logoutBtn1.addEventListener('click', logout);
        //////console.log('Logout button event listener added');
    } else {
        //console.warn('Logout button (#logout-btn) not found');
    }
});

// Cleanup khi rời khỏi trang
window.addEventListener('beforeunload', function () {
    if (sessionMonitorInterval) {
        clearInterval(sessionMonitorInterval);
    }
});

// Debug: DOM structure
window.debugDOM = function () {
    //////console.log('=== DOM STRUCTURE DEBUG ===');
    const requiredElements = [
        'loading', 'content', 'error', 'user-name',
        'user-email', 'login-time', 'logout-btn', 'message-area'
    ];

    requiredElements.forEach(id => {
        const el = document.getElementById(id);
        //////console.log(`#${id}:`, el ? 'EXISTS' : 'MISSING');
        if (el) {
            //////console.log(`  - tagName: ${el.tagName}`);
            //////console.log(`  - className: ${el.className}`);
        }
    });
};

// Thêm CSS để tạo hiệu ứng smooth
const style = document.createElement('style');
style.textContent = `
    .m-menu__submenu {
        display: none;
        opacity: 0;
        transition: opacity 0.3s ease, transform 0.3s ease;
        transform: translateY(-10px);
    }
    
    .m-menu__item--open .m-menu__submenu {
        display: block !important;
        opacity: 1;
        transform: translateY(0);
    }
    
    .m-menu__ver-arrow {
        transition: transform 0.3s ease;
    }
    
    .m-menu__item--open .m-menu__ver-arrow {
        transform: rotate(90deg);
    }
    
    /* Hiệu ứng hover cho menu items */
    .m-menu__item--submenu .m-menu__toggle:hover {
        background-color: rgba(0, 0, 0, 0.05);
    }
    
    /* Style cho menu đang mở */
    .m-menu__item--open > .m-menu__toggle {
        background-color: rgba(0, 123, 255, 0.1);
    }
`;
document.head.appendChild(style);
// Toggle for minimizing the left aside on desktop
document.addEventListener('DOMContentLoaded', function () {
    const asideMinimizeToggle = document.getElementById('m_aside_left_minimize_toggle');
    const asideLeft = document.querySelector('.m-aside--left');

    if (asideMinimizeToggle) {
        asideMinimizeToggle.addEventListener('click', function (e) {
            e.preventDefault();
            document.body.classList.toggle('m-aside-left--minimize');
            const isMinimized = document.body.classList.contains('m-aside-left--minimize');
            localStorage.setItem('aside_left_minimize', isMinimized);
        });
    }
});

// Script kết hợp Mobile Menu Toggle + Shop List Display + Topbar Toggle - COMPLETE VERSION
document.addEventListener('DOMContentLoaded', function () {
    // Elements
    const mobileToggleBtn = document.getElementById('m_aside_header_menu_mobile_toggle');
    const headerMenu = document.getElementById('m_header_menu');
    const menuLinks = document.querySelectorAll('.m-menu__link.m-menu__toggle');
    const closeBtn = document.getElementById('m_aside_header_menu_mobile_close_btn');
    const shopListContainer = document.getElementById('result-listshop');
    const userProfileDropdown = document.querySelector('.m-topbar__user-profile');
    const leftOffcanvasToggle = document.getElementById('m_aside_left_offcanvas_toggle');

    // State variables
    let shopListData = [];
    let isShopListLoaded = false;
    let resizeTimeout;
    let lastActiveMenu = null; // Track which menu was last active

    ////console.log('Complete Combined Menu Script initialized');
    ////console.log('Found elements:');
    ////console.log('- Mobile toggle button:', !!mobileToggleBtn);
    ////console.log('- Header menu:', !!headerMenu);
    ////console.log('- Menu links:', menuLinks.length);
    ////console.log('- Shop list container:', !!shopListContainer);
    ////console.log('- Left offcanvas toggle:', !!leftOffcanvasToggle);

    // ===========================================
    // UTILITY FUNCTIONS
    // ===========================================

    function isDesktopView() {
        return window.innerWidth > 1024;
    }

    function isMobileView() {
        return window.innerWidth <= 1024;
    }

    function resetMenuDisplayStates() {
        // Reset inline styles để CSS tự xử lý responsive
        menuLinks.forEach(link => {
            link.style.display = '';
        });

        if (headerMenu) {
            headerMenu.style.display = '';
        }
    }

    function closeAllMenus() {
        // Đóng header menu
        if (headerMenu) {
            headerMenu.classList.remove('m-aside-header-menu-mobile--on');
        }
        document.body.classList.remove('m-aside-header-menu-mobile-on');

        // Đóng left aside nếu có
        document.body.classList.remove('m-aside-left--on');

        // Reset display states
        if (isMobileView()) {
            menuLinks.forEach(link => {
                link.style.display = 'none';
            });
        } else {
            resetMenuDisplayStates();
        }

        closeAllSubmenus();
        closeAllDropdowns();

        lastActiveMenu = null;
    }

    // ===========================================
    // IMPROVED RESIZE HANDLING
    // ===========================================

    window.addEventListener('resize', function () {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            const windowWidth = window.innerWidth;

            if (windowWidth > 1024) {
                // Desktop mode - reset tất cả mobile states
                closeAllMenus();
                resetMenuDisplayStates();

                // Ensure desktop menu visibility
                if (headerMenu) {
                    headerMenu.style.display = '';
                }

                ////console.log('Switched to desktop mode, reset all mobile states');
            } else {
                // Mobile mode - đảm bảo states được reset đúng
                if (lastActiveMenu === 'header' && headerMenu) {
                    // Nếu header menu đang active, khôi phục
                    headerMenu.classList.add('m-aside-header-menu-mobile--on');
                    document.body.classList.add('m-aside-header-menu-mobile-on');
                    menuLinks.forEach(link => {
                        link.style.display = 'block';
                    });
                }
            }
        }, 150);
    });

    // ===========================================
    // MOBILE MENU FUNCTIONALITY
    // ===========================================

    function handleMobileToggle(e) {
        e.preventDefault();
        ////console.log('Mobile header menu toggle clicked');

        // Đóng left aside nếu đang mở
        document.body.classList.remove('m-aside-left--on');

        const isCurrentlyVisible = headerMenu.classList.contains('m-aside-header-menu-mobile--on');

        if (!isCurrentlyVisible) {
            // Mở header menu
            headerMenu.classList.add('m-aside-header-menu-mobile--on');
            document.body.classList.add('m-aside-header-menu-mobile-on');
            lastActiveMenu = 'header';

            // ✅ Luôn hiển thị menu links khi mở menu
            menuLinks.forEach(link => {
                link.style.display = 'block';
            });

            // Load shop list nếu cần
            if (!isShopListLoaded) {
                loadShopList();
            }

            ////console.log('Header menu opened');
        } else {
            closeMobileMenu();
        }
    }

    function closeMobileMenu() {
        ////console.log('Closing mobile header menu');
        if (headerMenu) {
            headerMenu.classList.remove('m-aside-header-menu-mobile--on');
        }

        document.body.classList.remove('m-aside-header-menu-mobile-on');

        const asideLeft = document.getElementById('m_aside_left');
        const offcanvasToggle = document.getElementById('m_aside_left_offcanvas_toggle');

        if (offcanvasToggle && asideLeft) {

            // Handle outside click with proper variable scoping
            document.addEventListener('click', function (e) {
                if (asideLeft.classList.contains('m-aside-left--on')) {
                    setTimeout(() => {
                        if (!asideLeft.contains(e.target) && !offcanvasToggle.contains(e.target)) {
                            asideLeft.classList.remove('m-aside-left--on');
                        }
                    }, 0);
                }
            });
        }
        resetMenuDisplayStates();
        if (lastActiveMenu === 'header') {
            lastActiveMenu = null;
        }
    }

    // ===========================================
    // LEFT OFFCANVAS HANDLING
    // ===========================================

    function handleLeftOffcanvasToggle(e) {
        e.preventDefault();
        ////console.log('Left offcanvas toggle clicked');

        // Đóng header menu nếu đang mở
        closeMobileMenu();

        const asideLeft = document.getElementById('m_aside_left');

        if (asideLeft) {
            // ✅ Chỉ toggle class trực tiếp
            asideLeft.classList.toggle('m-aside-left--on');
            document.body.classList.toggle('m-aside-left--on'); // Nếu cần
            lastActiveMenu = asideLeft.classList.contains('m-aside-left--on') ? 'aside' : null;
        }
    }

    // ===========================================
    // MENU LINK HANDLING
    // ===========================================
    function handleMenuLinkClick(e) {
        ////console.log('Menu link clicked:', this);
        const parentItem = this.closest('.m-menu__item--submenu');
        const submenu = parentItem ? parentItem.querySelector('.m-menu__submenu') : null;
        const toggleType = parentItem ? parentItem.getAttribute('data-menu-submenu-toggle') : null;

        if (parentItem && submenu) {
            ////console.log('Submenu found, toggle type:', toggleType);
            e.preventDefault(); // Chỉ ngăn hành vi mặc định cho toggle type "click"
            const isOpen = parentItem.classList.contains('m-menu__item--open');
            ////console.log('Submenu is open:', isOpen);

            // Đóng các submenu khác
            document.querySelectorAll('.m-menu__item--submenu').forEach(item => {
                if (item !== parentItem) {
                    item.classList.remove('m-menu__item--open');
                    const otherSubmenu = item.querySelector('.m-menu__submenu');
                    if (otherSubmenu) {
                        otherSubmenu.style.display = 'none';
                    }
                }
            });

            // Toggle submenu hiện tại
            if (!isOpen) {
                parentItem.classList.add('m-menu__item--open');
                submenu.style.display = 'block';
                ////console.log('Submenu opened, display set to block, computed style:', getComputedStyle(submenu).display);
                if (parentItem.querySelector('#result-listshop')) {
                    loadShopList();
                }
            } else {
                parentItem.classList.remove('m-menu__item--open');
                submenu.style.display = 'none';
                ////console.log('Submenu closed, display set to none, computed style:', getComputedStyle(submenu).display);
            }
        } else {
            ////console.log('No submenu or toggle type is not click, allowing default behavior');
            // Không ngăn hành vi mặc định nếu không phải toggle type "click"
        }
    }

    function closeAllSubmenus() {
        const submenuItems = document.querySelectorAll('.m-menu__item--submenu');
        submenuItems.forEach(function (item) {
            item.classList.remove('m-menu__item--open');
            const submenu = item.querySelector('.m-menu__submenu');
            if (submenu) {
                if (isMobileView()) {
                    submenu.style.display = 'none';
                } else {
                    submenu.style.display = ''; // Reset về CSS
                }
            }
        });
    }

    // ===========================================
    // USER PROFILE DROPDOWN
    // ===========================================

    function handleUserProfileToggle(e) {
        e.preventDefault();
        e.stopPropagation();

        const dropdown = userProfileDropdown.querySelector('.m-dropdown__wrapper');
        if (dropdown) {
            const isOpen = userProfileDropdown.classList.contains('m-dropdown--open');
            closeAllDropdowns();

            if (!isOpen) {
                userProfileDropdown.classList.add('m-dropdown--open');
                dropdown.style.display = 'block';
                ////console.log('User profile dropdown opened');
            }
        }
    }

    function closeAllDropdowns() {
        const dropdowns = document.querySelectorAll('.m-dropdown--open');
        dropdowns.forEach(function (dropdown) {
            dropdown.classList.remove('m-dropdown--open');
            const wrapper = dropdown.querySelector('.m-dropdown__wrapper');
            if (wrapper) {
                wrapper.style.display = 'none';
            }
        });
    }

    // ===========================================
    // EVENT LISTENERS SETUP
    // ===========================================

    function addEventListeners() {
        // Mobile header menu toggle
        if (mobileToggleBtn && headerMenu) {
            mobileToggleBtn.removeEventListener('click', handleMobileToggle);
            mobileToggleBtn.addEventListener('click', handleMobileToggle);
        }

        // Left offcanvas toggle
        if (leftOffcanvasToggle) {
            leftOffcanvasToggle.removeEventListener('click', handleLeftOffcanvasToggle);
            leftOffcanvasToggle.addEventListener('click', handleLeftOffcanvasToggle);
        }

        // Close button
        if (closeBtn) {
            closeBtn.removeEventListener('click', handleCloseClick);
            closeBtn.addEventListener('click', handleCloseClick);
        }

        // Menu links
        menuLinks.forEach(function (menuLink) {
            menuLink.removeEventListener('click', handleMenuLinkClick);
            menuLink.addEventListener('click', handleMenuLinkClick);
        });

        // User profile dropdown
        if (userProfileDropdown) {
            const userProfileLink = userProfileDropdown.querySelector('.m-dropdown__toggle');
            if (userProfileLink) {
                userProfileLink.removeEventListener('click', handleUserProfileToggle);
                userProfileLink.addEventListener('click', handleUserProfileToggle);
            }
        }
    }

    function handleCloseClick(e) {
        e.preventDefault();
        closeAllMenus();
    }

    // Initialize event listeners
    addEventListeners();

    // ===========================================
    // OUTSIDE CLICK HANDLING
    // ===========================================

    document.addEventListener('click', function (e) {
        // Header menu outside click
        // Header menu outside click
        const verMenu = document.getElementById('m_ver_menu');
        const isAnyMenuOpen = (headerMenu && headerMenu.classList.contains('m-aside-header-menu-mobile--on')) ||
            document.body.classList.contains('m-aside-header-menu-mobile-on');

        if (isAnyMenuOpen) {
            const isClickInsideHeaderMenu = headerMenu && headerMenu.contains(e.target);
            const isClickInsideVerMenu = verMenu && verMenu.contains(e.target);
            const isClickOnToggle = mobileToggleBtn && mobileToggleBtn.contains(e.target);

            // ✅ Kiểm tra cả 2 menu
            if (!isClickInsideHeaderMenu && !isClickInsideVerMenu && !isClickOnToggle) {
                closeMobileMenu();
            }
        }

        // Left aside outside click
        if (document.body.classList.contains('m-aside-left--on')) {
            const leftAside = document.querySelector('.m-aside-left');
            const isClickInsideAside = leftAside && leftAside.contains(e.target);
            const isClickOnToggle = leftOffcanvasToggle && leftOffcanvasToggle.contains(e.target);

            if (!isClickInsideAside && !isClickOnToggle) {
                document.body.classList.remove('m-aside-left--on');
                if (lastActiveMenu === 'aside') {
                    lastActiveMenu = null;
                }
            }
        }

        // Submenu outside click
        const openSubmenu = document.querySelector('.m-menu__item--submenu.m-menu__item--open');
        if (openSubmenu) {
            const isClickInsideSubmenu = openSubmenu.contains(e.target);
            if (!isClickInsideSubmenu) {
                closeAllSubmenus();
            }
        }

        // User dropdown outside click
        if (userProfileDropdown && userProfileDropdown.classList.contains('m-dropdown--open')) {
            const isClickInsideDropdown = userProfileDropdown.contains(e.target);
            if (!isClickInsideDropdown) {
                closeAllDropdowns();
            }
        }
    });

    // ===========================================
    // DEVTOOLS DETECTION (IMPROVED)
    // ===========================================

    let devtools = { open: false };
    let devToolsCheckTimeout;
    const threshold = 160;

    const checkDevTools = () => {
        clearTimeout(devToolsCheckTimeout);
        devToolsCheckTimeout = setTimeout(() => {
            const heightDiff = window.outerHeight - window.innerHeight;
            const widthDiff = window.outerWidth - window.innerWidth;

            if (heightDiff > threshold || widthDiff > threshold) {
                if (!devtools.open) {
                    devtools.open = true;
                    ////console.log('DevTools opened - reinitializing...');
                    setTimeout(() => {
                        if (isShopListLoaded && shopListContainer) {
                            displayShopList(shopListData);
                        }
                        // Re-add event listeners
                        addEventListeners();
                    }, 200);
                }
            } else {
                if (devtools.open) {
                    devtools.open = false;
                    ////console.log('DevTools closed');
                }
            }
        }, 100);
    };

    setInterval(checkDevTools, 1000);

    // ===========================================
    // SHOP LIST FUNCTIONALITY
    // ===========================================

    async function loadShopList() {
        if (!shopListContainer) {
            console.warn('Shop list container not found');
            return;
        }

        ////console.log('Loading shop list...');
        showShopListLoading();

        try {
            loadShopListFromAPI();
            isShopListLoaded = true;
            ////console.log('Shop list loaded successfully');
        } catch (error) {
            console.error('Error loading shop list:', error);
            showShopListError('Lỗi tải danh sách cửa hàng');
        }
    }

    async function loadShopListFromAPI() {
        try {
            // Sử dụng apiCall thay vì fetch trực tiếp
            const result = await apiCall('get_shops.php?action=list', 'GET');

            if (result.success && result.data) {
                shopListData = result.data;
                ////console.log(shopListData);
                displayShopList(shopListData);
            } else {
                throw new Error(result.message || 'Không có dữ liệu cửa hàng');
            }
        } catch (error) {
            console.error('API Error:', error);
            displaySampleShopList();
        }
    }

    function showShopListLoading() {
        if (shopListContainer) {
            shopListContainer.innerHTML = `
                <div class="col-12 text-center p-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="sr-only">Đang tải...</span>
                    </div>
                    <p class="mt-2">Đang tải danh sách cửa hàng...</p>
                </div>
            `;
        }
    }

    function showShopListError(message) {
        if (shopListContainer) {
            shopListContainer.innerHTML = `
                <div class="col-12 text-center p-4">
                    <div class="alert alert-danger">
                        <i class="fa fa-exclamation-triangle"></i>
                        ${message}
                        <br>
                        <button class="btn btn-sm btn-primary mt-2" onclick="loadShopList()">
                            <i class="fa fa-refresh"></i> Thử lại
                        </button>
                    </div>
                </div>
            `;
        }
    }

    function displayShopList(shops) {

        // Thêm vào đầu hàm displayShopList()
        shops = shops.map(shop => ({
            id: shop.shop_id,
            name: shop.name || shop.shop_name, // PHP trả về shop_name
            address: shop.address || 'Địa chỉ không xác định',
            status: shop.status == 1 ? 'active' : 'inactive'
        }));

        if (!shopListContainer || !Array.isArray(shops)) {
            console.warn('Invalid shop data or container');
            return;
        }

        let html = '';
        if (shops.length === 0) {
            html = `
                <div class="col-12 text-center p-4">
                    <div class="alert alert-info">
                        <i class="fa fa-info-circle"></i>
                        Không có cửa hàng nào hoạt động
                    </div>
                </div>
            `;
        } else {
            shops.forEach(function (shop, index) {
                html += `
                    <div class="col-md-3 col-sm-6 col-12 mb-3">
                        <div class="card shop-item" data-shop-id="${shop.id || index}">
                            <div class="card-body text-center">
                                <div class="shop-icon mb-2">
                                    <i class="fa fa-store fa-2x text-primary"></i>
                                </div>
                                <h6 class="card-title">${shop.name || `Cửa hàng ${index + 1}`}</h6>
                                <div class="shop-status">
                                    <span class="badge ${shop.status === 'active' ? 'badge-success' : 'badge-warning'}">
                                        ${shop.status === 'active' ? 'Hoạt động' : 'Tạm nghỉ'}
                                    </span>
                                </div>
                                <button class="btn btn-sm btn-outline-primary mt-2" 
                                        onclick="selectShop('${shop.id || index}', '${shop.name || `Cửa hàng ${index + 1}`}')">
                                    <i class="fa fa-check"></i> Chọn
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });
        }

        shopListContainer.innerHTML = html;
        addShopItemListeners();

    }

    function displaySampleShopList() {
        const sampleShops = [
            { id: 1, name: 'Cửa hàng Trung tâm', address: '123 Đường ABC, Quận 1', status: 'active' },
            { id: 2, name: 'Chi nhánh Quận 2', address: '456 Đường DEF, Quận 2', status: 'active' },
            { id: 3, name: 'Chi nhánh Quận 3', address: '789 Đường GHI, Quận 3', status: 'inactive' },
            { id: 4, name: 'Chi nhánh Quận 7', address: '101 Đường JKL, Quận 7', status: 'active' }
        ];
        displayShopList(sampleShops);
    }

    function addShopItemListeners() {
        const shopItems = document.querySelectorAll('.shop-item');
        shopItems.forEach(function (item) {
            item.addEventListener('click', function (e) {
                if (e.target.tagName !== 'BUTTON') {
                    shopItems.forEach(si => si.classList.remove('active'));
                    this.classList.add('active');
                }
            });
        });
    }

    // ===========================================
    // GLOBAL FUNCTIONS
    // ===========================================
    // Thêm hàm này vào cuối file (trước dòng ////console.log cuối)
    function updateMenuShopName(shopName) {
        // ✅ Chỉ tìm trong menu ngang (horizontal menu)
        const horizontalMenu = document.getElementById('m_header_menu');
        if (horizontalMenu) {
            const menuShopName = horizontalMenu.querySelector('.m-menu__link-text');
            if (menuShopName) {
                menuShopName.textContent = shopName;
                ////console.log('Menu shop name updated to:', shopName);
            }
        }
    }
    window.selectShop = async function (shopId, shopName) {
        ////console.log('Shop selected:', shopId, shopName);
        localStorage.setItem('selected_shop_id', shopId);
        localStorage.setItem('selected_shop_name', shopName);
        updateMenuShopName(shopName);
        if (typeof showMessage === 'function') {
            showMessage(`Đã chọn cửa hàng: ${shopName}`, 'success');
        } else {
            alert(`Đã chọn cửa hàng: ${shopName}`);
        }

        closeAllSubmenus();
        if (isMobileView()) {
            closeMobileMenu();
        }

        document.dispatchEvent(new CustomEvent('shopSelected', {
            detail: { shopId: shopId, shopName: shopName }
        }));
        loadContractsForCurrentPage();
        await loadFinancialData();
    };
    // ✅ Function load contracts theo trang
    function loadContractsForCurrentPage() {
        const currentPath = window.location.pathname.toLowerCase();

        //console.log('Current path:', currentPath);
        //console.log('Checking page type...');

        // Kiểm tra trang Installment/Index
        if (currentPath.includes('installment') && (currentPath.includes('index'))) {
            //console.log('📋 Loading contracts for Installment page');
            if (typeof loadContracts === 'function') {
                loadContracts();
            } else {
                console.warn('loadContracts function not found');
            }
            return;
        }

        // Kiểm tra trang Calendar/Installment  
        if (currentPath.includes('calendar') && currentPath.includes('installment')) {
            //console.log('📅 Loading contracts for Calendar page');
            if (typeof loadContracts1 === 'function') {
                loadContracts1();
            } else {
                console.warn('loadContracts1 function not found');
            }
            return;
        }

        // Fallback: Kiểm tra function nào có sẵn
        //console.log('🔄 Unknown page, using fallback logic');

        if (typeof loadContracts === 'function') {
            //console.log('Calling loadContracts (fallback)');
            loadContracts();
        } else if (typeof loadContracts1 === 'function') {
            //console.log('Calling loadContracts1 (fallback)');
            loadContracts1();
        } else {
            //console.log('❌ No contract loading functions available');
        }
    }
    window.loadShopList = function () {
        isShopListLoaded = false;
        loadShopList();
    };

    window.getSelectedShop = function () {
        return {
            id: localStorage.getItem('selected_shop_id'),
            name: localStorage.getItem('selected_shop_name')
        };
    };

    window.toggleMobileMenu = function (forceState) {
        if (!headerMenu) return;
        const shouldShow = typeof forceState === 'boolean' ? forceState :
            !headerMenu.classList.contains('m-aside-header-menu-mobile--on');

        if (shouldShow) {
            // Close other menus first
            document.body.classList.remove('m-aside-left--on');

            headerMenu.classList.add('m-aside-header-menu-mobile--on');
            document.body.classList.add('m-aside-header-menu-mobile-on');
            lastActiveMenu = 'header';

            if (isMobileView()) {
                menuLinks.forEach(link => link.style.display = 'block');
            }
            if (!isShopListLoaded) loadShopList();
        } else {
            closeMobileMenu();
        }
    };



    // async function initializeDefaultShop() {
    //     try {
    //         if (!isShopListLoaded) {
    //             await loadShopListFromAPI();
    //         }

    //         const savedShopId = localStorage.getItem('selected_shop_id');
    //         const savedShopName = shopListData[0].name;

    //         //console.log(savedShopName);
    //         if (savedShopName == null) {
    //             // Kiểm tra loại user
    //             const userId = localStorage.getItem('user_id');
    //             //console.log('userid tìm kiếm hiển thị shop :' + userId);
    //             if (userId && userId.includes('STF')) {
    //                 selectShop(shopListData[0].shop_id, savedShopName);
    //                 updateMenuShopName(savedShopName);
    //                 loadContracts();

    //             } else {
    //                 // Admin/Owner - chọn shop đầu tiên
    //                 const firstShop = shopListData[0];
    //                 selectShop(firstShop.shop_id, firstShop.name);
    //                 updateMenuShopName(firstShop.name);
    //                 loadContracts();
    //             }
    //         } else {
    //             localStorage.setItem('selected_shop_id', shopListData[0].shop_id);
    //             updateMenuShopName(savedShopName);
    //             loadContracts();
    //         }

    //     } catch (error) {
    //         console.error('Error initializing default shop:', error);
    //     }
    // }

    // Gọi hàm khởi tạo

    async function initializeDefaultShop() {
        try {
            if (!isShopListLoaded) {
                await loadShopListFromAPI();
            }

            const savedShopId = localStorage.getItem('selected_shop_id');
            const savedShopName = localStorage.getItem('selected_shop_name');

            //console.log('Saved shop ID:', savedShopId);
            //console.log('Saved shop name:', savedShopName);

            // ✅ Kiểm tra đã có shop được chọn chưa
            if (savedShopId && savedShopName) {
                // Đã chọn shop rồi - sử dụng shop đã lưu
                updateMenuShopName(savedShopName);
                loadContracts();
                //console.log('Using saved shop:', savedShopName);
            } else {
                // ✅ Lần đăng nhập đầu tiên hoặc chưa có shop được chọn
                const userId = localStorage.getItem('user_id');
                //console.log('First login - User ID:', userId);

                if (userId && userId.includes('STF')) {
                    // Staff - chọn shop đầu tiên
                    const firstShop = shopListData[0];
                    selectShop(firstShop.shop_id, firstShop.name);
                    //console.log('Staff - Selected first shop:', firstShop.name);
                } else {
                    // Admin/Owner - chọn shop đầu tiên
                    const firstShop = shopListData[0];
                    selectShop(firstShop.shop_id, firstShop.name);
                    //console.log('Admin/Owner - Selected first shop:', firstShop.name);
                }
            }

        } catch (error) {
            console.error('Error initializing default shop:', error);
        }
    }

    // ✅ Thêm function để clear shop data khi logout (nếu cần)
    function clearShopSelection() {
        localStorage.removeItem('selected_shop_id');
        localStorage.removeItem('selected_shop_name');
        //console.log('Shop selection cleared');
    }

    initializeDefaultShop();
});

// Script để toggle topbar mobile khi click vào m_aside_header_topbar_mobile_toggle
document.addEventListener('DOMContentLoaded', function () {
    const topbarToggleBtn = document.getElementById('m_aside_header_topbar_mobile_toggle');
    const topbar = document.getElementById('m_header_topbar');
    const topbarNav = document.querySelector('.m-topbar__nav');
    let isTopbarOpen = false;

    ////console.log('Topbar Mobile Toggle Script initialized');
    ////console.log('Found elements:');
    ////console.log('- Topbar toggle button:', !!topbarToggleBtn);
    ////console.log('- Topbar container:', !!topbar);
    ////console.log('- Topbar nav:', !!topbarNav);

    if (topbarToggleBtn && topbar) {
        // Toggle topbar khi click vào mobile toggle button
        topbarToggleBtn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();

            ////console.log('Topbar mobile toggle clicked');

            isTopbarOpen = !isTopbarOpen;

            if (isTopbarOpen) {
                showMobileTopbar();
            } else {
                hideMobileTopbar();
            }
        });

        // Đóng topbar khi click outside
        document.addEventListener('click', function (e) {
            if (isTopbarOpen) {
                const isClickInsideTopbar = topbar.contains(e.target);
                const isClickOnToggle = topbarToggleBtn.contains(e.target);

                if (!isClickInsideTopbar && !isClickOnToggle) {
                    ////console.log('Clicked outside topbar, closing...');
                    hideMobileTopbar();
                }
            }
        });

        // Đóng topbar khi resize window (chuyển sang desktop)
        window.addEventListener('resize', function () {
            if (window.innerWidth > 1024 && isTopbarOpen) {
                ////console.log('Window resized to desktop, closing mobile topbar');
                hideMobileTopbar();
            }
        });

        // Đóng topbar khi scroll (optional)
        let scrollTimeout;
        window.addEventListener('scroll', function () {
            if (isTopbarOpen) {
                clearTimeout(scrollTimeout);
                scrollTimeout = setTimeout(() => {
                    ////console.log('Page scrolled, closing mobile topbar');
                    hideMobileTopbar();
                }, 150);
            }
        });
    }
    // Function lấy username từ session
    function getCurrentUsername() {
        // Phương pháp 1: Từ session storage (nếu có lưu)
        let username = localStorage.getItem('username');

        // Phương pháp 2: Từ server-side variable (nếu server render)
        if (!username && typeof window.currentUser !== 'undefined') {
            username = window.currentUser.username;
        }

        // Phương pháp 3: Từ cookie (nếu có lưu trong cookie)
        if (!username) {
            const cookies = document.cookie.split(';');
            for (let cookie of cookies) {
                const [name, value] = cookie.trim().split('=');
                if (name === 'username') {
                    username = decodeURIComponent(value);
                    break;
                }
            }
        }

        return username || 'User'; // Default fallback
    }

    // ===========================================
    // TOPBAR DISPLAY FUNCTIONS
    // ===========================================

    function showMobileTopbar() {
        ////console.log('Showing mobile topbar');

        // Thêm classes để hiển thị topbar mobile
        topbar.classList.add('m-topbar--mobile-on');
        document.body.classList.add('m-topbar-mobile-on');

        // Tạo mobile topbar overlay nếu chưa có
        createMobileTopbarOverlay();

        // Update toggle button state
        topbarToggleBtn.classList.add('m-topbar-toggle--active');

        isTopbarOpen = true;

        ////console.log('Mobile topbar shown');
    }

    function hideMobileTopbar() {
        ////console.log('Hiding mobile topbar');

        // Remove classes
        topbar.classList.remove('m-topbar--mobile-on');
        document.body.classList.remove('m-topbar-mobile-on');

        // Remove overlay
        removeMobileTopbarOverlay();

        // Update toggle button state
        topbarToggleBtn.classList.remove('m-topbar-toggle--active');

        isTopbarOpen = false;

        ////console.log('Mobile topbar hidden');
    }

    function createMobileTopbarOverlay() {
        // Kiểm tra xem overlay đã tồn tại chưa
        let overlay = document.getElementById('mobile-topbar-overlay');

        if (!overlay) {
            // Tạo backdrop overlay
            const backdrop = document.createElement('div');
            backdrop.id = 'mobile-topbar-backdrop';
            backdrop.className = 'mobile-topbar-backdrop';
            backdrop.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 9998;
                opacity: 0;
                transition: opacity 0.3s ease;
            `;
            document.body.appendChild(backdrop);

            // Fade in backdrop
            setTimeout(() => {
                backdrop.style.opacity = '1';
            }, 10);

            // Tạo mobile topbar container
            overlay = document.createElement('div');
            overlay.id = 'mobile-topbar-overlay';
            overlay.className = 'mobile-topbar-overlay';
            overlay.style.cssText = `
                position: fixed;
                top: 0;
                right: 0;
                width: 320px;
                max-width: 90vw;
                height: 100vh;
                background: white;
                box-shadow: -2px 0 10px rgba(0, 0, 0, 0.1);
                z-index: 9999;
                transform: translateX(100%);
                transition: transform 0.3s ease;
                overflow-y: auto;
                padding: 20px;
            `;

            // Clone và hiển thị nội dung topbar
            const topbarClone = cloneTopbarForMobile();
            overlay.appendChild(topbarClone);

            document.body.appendChild(overlay);

            // Slide in overlay
            setTimeout(() => {
                overlay.style.transform = 'translateX(0)';
            }, 10);

            // Close khi click backdrop
            backdrop.addEventListener('click', hideMobileTopbar);
        }
    }

    function removeMobileTopbarOverlay() {
        const overlay = document.getElementById('mobile-topbar-overlay');
        const backdrop = document.getElementById('mobile-topbar-backdrop');

        if (overlay) {
            overlay.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (overlay.parentNode) {
                    overlay.parentNode.removeChild(overlay);
                }
            }, 300);
        }

        if (backdrop) {
            backdrop.style.opacity = '0';
            setTimeout(() => {
                if (backdrop.parentNode) {
                    backdrop.parentNode.removeChild(backdrop);
                }
            }, 300);
        }
    }

    function cloneTopbarForMobile() {
        const container = document.createElement('div');
        container.className = 'mobile-topbar-content';

        // Header
        const header = document.createElement('div');
        header.className = 'mobile-topbar-header';
        header.style.cssText = `
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        `;
        header.innerHTML = `
            <h5 style="margin: 0; color: #333;">Menu</h5>
            <button type="button" class="btn-close-topbar" style="
                background: none;
                border: none;
                font-size: 24px;
                color: #999;
                cursor: pointer;
                padding: 0;
                width: 30px;
                height: 30px;
                display: flex;
                align-items: center;
                justify-content: center;
            ">&times;</button>
        `;

        // Close button event
        const closeBtn = header.querySelector('.btn-close-topbar');
        closeBtn.addEventListener('click', hideMobileTopbar);

        container.appendChild(header);

        // Quick Actions Section
        const quickActionsSection = document.createElement('div');
        quickActionsSection.className = 'mobile-topbar-section';
        quickActionsSection.innerHTML = `
            <h6 style="color: #666; margin-bottom: 15px; font-size: 14px; text-transform: uppercase;">Thao tác nhanh</h6>
        `;

        // Quick action items
        const quickActions = [
            {
                href: window.location.origin + '/vay/Calendar/Installment',
                icon: 'fa fa-bitbucket',
                title: 'Lịch trả góp',
                text: 'Lịch trả góp',
                hasCount: true,
                countId: 'lblCountTotalInstallment'
            }
        ];

        quickActions.forEach(action => {
            const item = document.createElement('a');
            item.href = action.href;
            item.className = 'mobile-topbar-item';
            item.title = action.title;
            item.style.cssText = `
                display: flex;
                align-items: center;
                padding: 15px 0;
                text-decoration: none;
                color: #333;
                border-bottom: 1px solid #f5f5f5;
                transition: background-color 0.2s;
            `;

            let countBadge = '';
            if (action.hasCount) {
                const originalCount = document.getElementById(action.countId);
                if (originalCount && originalCount.textContent.trim()) {
                    countBadge = `
                        <span class="badge badge-danger ml-auto" style="margin-left: auto;">
                            ${originalCount.textContent}
                        </span>
                    `;
                }
            }

            item.innerHTML = `
                <span class="mobile-topbar-icon" style="
                    width: 40px;
                    height: 40px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: #f8f9fa;
                    border-radius: 8px;
                    margin-right: 15px;
                    color: #007bff;
                ">
                    <i class="${action.icon}"></i>
                </span>
                <span class="mobile-topbar-text" style="flex: 1;">
                    ${action.text}
                </span>
                ${countBadge}
            `;

            // Hover effect
            item.addEventListener('mouseenter', function () {
                this.style.backgroundColor = '#f8f9fa';
            });
            item.addEventListener('mouseleave', function () {
                this.style.backgroundColor = 'transparent';
            });

            quickActionsSection.appendChild(item);
        });

        container.appendChild(quickActionsSection);

        // User Profile Section
        const userSection = document.createElement('div');
        userSection.className = 'mobile-topbar-section';
        userSection.style.marginTop = '30px';
        userSection.innerHTML = `
            <h6 style="color: #666; margin-bottom: 15px; font-size: 14px; text-transform: uppercase;">Tài khoản</h6>
        `;

        // User info
        const userInfo = document.createElement('div');
        userInfo.className = 'mobile-user-info';
        userInfo.style.cssText = `
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        `;

        const originalUsername = document.querySelector('.m-topbar__username');
        const username = getCurrentUsername();

        userInfo.innerHTML = `
            <div style="margin-bottom: 10px;">
                <i class="fa fa-user-circle" style="font-size: 48px; opacity: 0.9;"></i>
            </div>
            <div style="font-weight: bold; margin-bottom: 5px;">${username}</div>
            
        `;

        userSection.appendChild(userInfo);

        // User menu items
        const userMenuItems = [
            {
                href: '#',
                icon: 'flaticon-lock-1',
                text: 'Đổi Thông Tin Tài Khoản',
                modal: 'modal_change_profile'
            }
        ];

        userMenuItems.forEach(menuItem => {
            const item = document.createElement('a');
            item.href = menuItem.href;
            item.className = 'mobile-topbar-item';
            item.style.cssText = `
                display: flex;
                align-items: center;
                padding: 15px 0;
                text-decoration: none;
                color: #333;
                border-bottom: 1px solid #f5f5f5;
                transition: background-color 0.2s;
            `;

            if (menuItem.modal) {
                item.setAttribute('data-toggle', 'modal');
                item.setAttribute('data-target', `#${menuItem.modal}`);
            }

            item.innerHTML = `
                <span class="mobile-topbar-icon" style="
                    width: 40px;
                    height: 40px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: #f8f9fa;
                    border-radius: 8px;
                    margin-right: 15px;
                    color: #6c757d;
                ">
                    <i class="${menuItem.icon}"></i>
                </span>
                <span class="mobile-topbar-text">
                    ${menuItem.text}
                </span>
            `;

            // Hover effect
            item.addEventListener('mouseenter', function () {
                this.style.backgroundColor = '#f8f9fa';
            });
            item.addEventListener('mouseleave', function () {
                this.style.backgroundColor = 'transparent';
            });

            // Close topbar when item clicked
            item.addEventListener('click', function () {
                setTimeout(hideMobileTopbar, 100);
            });

            userSection.appendChild(item);
        });

        // Logout button
        const logoutBtn = document.createElement('a');
        logoutBtn.id = 'mlogout-btn';
        logoutBtn.className = 'btn btn-danger btn-block';
        logoutBtn.style.cssText = `
            margin-top: 20px;
            padding: 12px;
            text-align: center;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        `;
        logoutBtn.innerHTML = `
            <i class="fa fa-sign-out-alt"></i>
            Đăng xuất
        `;
        // QUAN TRỌNG: Gán event listener ngay tại đây
        logoutBtn.addEventListener('click', function (e) {
            e.preventDefault(); // Ngăn chặn hành vi mặc định của thẻ <a>
            logout();
        });
        userSection.appendChild(logoutBtn);
        container.appendChild(userSection);

        return container;
    }

    // ===========================================
    // GLOBAL FUNCTIONS
    // ===========================================

    // Global function để toggle topbar programmatically
    window.toggleMobileTopbar = function (forceState) {
        if (typeof forceState === 'boolean') {
            if (forceState && !isTopbarOpen) {
                showMobileTopbar();
            } else if (!forceState && isTopbarOpen) {
                hideMobileTopbar();
            }
        } else {
            if (isTopbarOpen) {
                hideMobileTopbar();
            } else {
                showMobileTopbar();
            }
        }
    };

    // Global function để check trạng thái
    window.isMobileTopbarOpen = function () {
        return isTopbarOpen;
    };
    // Function cập nhật username trên topbar
    function updateTopbarUsername() {
        const usernameElement = document.querySelector('.m-topbar__username');
        if (usernameElement) {
            const username = getCurrentUsername();
            usernameElement.innerHTML = `${username} <i class="fa fa-angle-down"></i>`;
        }
    }

    // Gọi ngay khi DOM loaded
    updateTopbarUsername();

    ////console.log('Topbar mobile toggle script setup completed');

});

// Close button for the left aside on tablet/mobile
document.getElementById('m_aside_left_close_btn').addEventListener('click', function () {
    const asideLeft = document.getElementById('m_aside_left');
    asideLeft.classList.remove('m-aside-left--on');
});

// Script ẩn các chức năng quản lý khi userID chứa "STF"
function hideManagementMenus() {
    // Lấy userID từ localStorage
    var userID = localStorage.getItem('user_id');

    // Kiểm tra nếu userID tồn tại và chứa "STF"
    if (userID && userID.includes('STF')) {
        //console.log('User có ID chứa STF, ẩn các menu quản lý');

        // Ẩn menu Quản lý cửa hàng
        var shopMenu = document.getElementById('menu_Shop');
        if (shopMenu) {
            shopMenu.style.display = 'none';
        }

        // Ẩn menu Quản lý thu chi
        var incomeExpenseMenu = document.getElementById('menu_IncomeAndExpense');
        if (incomeExpenseMenu) {
            incomeExpenseMenu.style.display = 'none';
        }

        // Ẩn menu Quản lý nhân viên
        var staffMenu = document.getElementById('menu_Staff');
        if (staffMenu) {
            staffMenu.style.display = 'none';
        }
    } else {
        //console.log('User không có ID chứa STF hoặc chưa đăng nhập');
    }
}

// Chạy script khi DOM đã load xong
document.addEventListener('DOMContentLoaded', function () {
    hideManagementMenus();
});

// Nếu cần chạy lại khi localStorage thay đổi
window.addEventListener('storage', function (e) {
    if (e.key === 'user_id') {
        hideManagementMenus();
    }
});

$(document).ready(function () {
    // Xử lý form submit
    $('#m_change_profile_submit').click(function (e) {
        e.preventDefault();

        var currentPassword = $('#changeprofile_current').val().trim();
        var newPassword = $('#changeprofile_new').val().trim();
        var confirmPassword = $('#changeprofile_confirm').val().trim();
        var displayName = $('#change_display_name').val().trim();

        // Reset alert
        $('#profile_change_alert').hide();

        // Validation
        if (!currentPassword) {
            showProfileAlert('Vui lòng nhập mật khẩu hiện tại!', 'danger');
            return;
        }

        // Nếu có nhập mật khẩu mới thì validate
        if (newPassword) {
            if (newPassword.length < 6) {
                showProfileAlert('Mật khẩu mới phải có ít nhất 6 ký tự!', 'danger');
                return;
            }

            if (newPassword !== confirmPassword) {
                showProfileAlert('Mật khẩu xác nhận không khớp!', 'danger');
                return;
            }
        }

        // Phải có ít nhất một thay đổi
        if (!newPassword && !displayName) {
            showProfileAlert('Vui lòng nhập thông tin cần thay đổi!', 'warning');
            return;
        }

        // Disable button
        var $btn = $(this);
        var originalText = $btn.html();
        $btn.prop('disabled', true).html('Đang xử lý...');

        // Prepare data
        var formData = {
            current_password: currentPassword,
            new_password: newPassword,
            confirm_password: confirmPassword,
            display_name: displayName
        };

        // Send AJAX request
        $.ajax({
            url: API_BASE_URL + 'change_profile.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    showProfileAlert(response.message, 'success');

                    // Reset form sau 2 giây
                    setTimeout(function () {
                        $('#modal_change_profile form')[0].reset();
                        $('#modal_change_profile').modal('hide');

                        // Reload nếu có yêu cầu
                        if (response.reload) {
                            location.reload();
                        }
                    }, 2000);
                } else {
                    showProfileAlert(response.message, 'danger');

                }
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', error);
                showProfileAlert('Lỗi kết nối! Vui lòng thử lại.', 'danger');
            },
            complete: function () {
                // Re-enable button
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });

    // Reset form khi đóng modal
    $('#modal_change_profile').on('hidden.bs.modal', function () {
        $(this).find('form')[0].reset();
        $('#profile_change_alert').hide();
    });
});

// Function hiển thị alert
function showProfileAlert(message, type) {
    var alertClass = 'alert-' + type;
    var alertHtml = '<div class="alert ' + alertClass + ' alert-dismissible fade show" role="alert">' +
        message +
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '</div>';

    $('#profile_change_alert').html(alertHtml).show();

    // Auto hide sau 5 giây
    setTimeout(function () {
        $('#profile_change_alert .alert').alert('close');
    }, 5000);
}

