// Script hiển thị giao dịch trong ngày
class TransactionDisplay {
    constructor() {
        this.container = document.getElementById('tblHistoryBlance');
        this.refreshInterval = 30000; // 30 giây
        this.init();
    }

    init() {
        this.loadTransactions();
        // Tự động refresh mỗi 30 giây
        setInterval(() => {
            this.loadTransactions();
        }, this.refreshInterval);
    }

    async loadTransactions() {
        try {
            const response = await fetch(API_BASE_URL + 'get_daily_transactions.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'get_daily_transactions',
                    date: new Date().toISOString().split('T')[0] // Ngày hôm nay
                })
            });

            const data = await response.json();

            if (data.success) {
                this.displayTransactions(data.data);
                this.updateSummary(data.summary);
            } else {
                console.error('Lỗi tải dữ liệu:', data.message);
                this.displayError(data.message);
            }
        } catch (error) {
            console.error('Lỗi kết nối:', error);
            this.displayError('Không thể kết nối đến server');
        }
    }

    displayTransactions(transactions) {
        if (!this.container) return;

        if (!transactions || transactions.length === 0) {
            this.container.innerHTML = `
                <div class="m-timeline-3__item">
                    <div class="m-timeline-3__item-detail">
                        <div class="m--font-info">Chưa có giao dịch nào trong ngày</div>
                    </div>
                </div>
            `;
            return;
        }

        let html = '';
        transactions.forEach(transaction => {
            const timeOnly = transaction.formatted_time || transaction.created_at;
            const isIncome = transaction.transaction_type === 'income';
            const isExpense = transaction.transaction_type === 'expense';

            // Xác định màu sắc và icon theo loại giao dịch
            let colorClass, icon, typeText;

            switch (transaction.transaction_type) {
                case 'income':
                    colorClass = 'm--font-success';
                    icon = 'fa-arrow-up';
                    typeText = 'Thu';
                    break;
                case 'expense':
                    colorClass = 'm--font-danger';
                    icon = 'fa-arrow-down';
                    typeText = 'Chi';
                    break;
                default:
                    colorClass = 'm--font-info';
                    icon = 'fa-exchange-alt';
                    typeText = 'Khác';
            }

            html += `
                <div class="m-timeline-3__item">
                    <span class="m-timeline-3__item-time">${timeOnly}</span>
                    <div class="m-timeline-3__item-desc">
                        <span class="m-timeline-3__item-text">
                            <i class="fa ${icon} ${colorClass}"></i>
                            ${typeText}: ${transaction.description || 'Không có mô tả'}
                        </span>
                        <br>
                        <span class="m-timeline-3__item-user-name">
                            <i class="la la-user-circle"></i> ${transaction.customer_name || transaction.created_by || 'Hệ thống'}
                        </span>
                    </div>
                    <div class="m-timeline-3__item-detail">
                        <span class="m-timeline-3__item-detail-text ${colorClass}">
                            ${isIncome ? '+' : (isExpense ? '-' : '')}${this.formatMoney(transaction.amount)}
                        </span>
                        <div class="m-timeline-3__item-detail-desc">
                            <strong>Mã:</strong> ${transaction.transaction_code}<br>
                            <strong>Danh mục:</strong> ${transaction.category || 'Không xác định'}<br>
                            <strong>Phương thức:</strong> ${this.getPaymentMethodText(transaction.payment_method)}
                        </div>
                    </div>
                </div>
            `;
        });

        this.container.innerHTML = html;
    }

    displayError(message) {
        if (!this.container) return;

        this.container.innerHTML = `
            <div class="m-timeline-3__item">
                <div class="m-timeline-3__item-detail">
                    <div class="m--font-danger">
                        <i class="fa fa-exclamation-triangle"></i> ${message}
                    </div>
                </div>
            </div>
        `;
    }

    updateSummary(summary) {
        if (!summary) return;

        // Cập nhật tổng thu chi trên header nếu có
        const summaryElement = document.querySelector('.transaction-summary');
        if (summaryElement) {
            summaryElement.innerHTML = `
                <div class="row">
                    <div class="col-4 text-center">
                        <div class="m--font-success">
                            <strong>+${this.formatMoney(summary.total_income || 0)}</strong>
                            <br><small>Thu</small>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="m--font-danger">
                            <strong>-${this.formatMoney(summary.total_expense || 0)}</strong>
                            <br><small>Chi</small>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="m--font-info">
                            <strong>${this.formatMoney(summary.net_amount || 0)}</strong>
                            <br><small>Còn lại</small>
                        </div>
                    </div>
                </div>
            `;
        }
    }

    formatMoney(amount) {
        if (!amount && amount !== 0) return '0';
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount);
    }

    getPaymentMethodText(method) {
        const methods = {
            'cash': 'Tiền mặt',
            'bank_transfer': 'Chuyển khoản',
            'card': 'Thẻ',
            'other': 'Khác'
        };
        return methods[method] || method || 'Tiền mặt';
    }

    // Phương thức để refresh thủ công
    refresh() {
        this.loadTransactions();
    }

    // Phương thức để thêm giao dịch mới (real-time update)
    addNewTransaction(transaction) {
        // Tải lại toàn bộ danh sách để đảm bảo thứ tự
        this.loadTransactions();
    }

    // Phương thức để cập nhật trạng thái khi có thay đổi
    updateTransaction(transactionId, newData) {
        this.loadTransactions();
    }
}

// Khởi tạo khi DOM loaded
document.addEventListener('DOMContentLoaded', function () {
    // Kiểm tra element có tồn tại không
    if (document.getElementById('tblHistoryBlance')) {
        window.transactionDisplay = new TransactionDisplay();

        // Thêm nút refresh nếu cần
        const refreshButton = document.querySelector('.m-portlet__nav-link[title="Xem tất cả"]');
        if (refreshButton) {
            refreshButton.addEventListener('click', function (e) {
                e.preventDefault();
                window.transactionDisplay.refresh();
            });
        }
    }
});

// Hàm helper cho các trang khác
function refreshTransactionDisplay() {
    if (window.transactionDisplay) {
        window.transactionDisplay.refresh();
    }
}

// Export cho module nếu cần
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TransactionDisplay;
}