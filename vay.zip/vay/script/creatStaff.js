$(document).ready(function () {

    // Hiển thị/ẩn mật khẩu
    $('#show_password').click(function () {
        var passwordField = $('#txtPassword');
        var icon = $(this).find('i');

        if (passwordField.attr('type') === 'password') {
            passwordField.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            passwordField.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });

    // Hiển thị/ẩn mật khẩu xác nhận
    $('#show_confirm_password').click(function () {
        var confirmPasswordField = $('#txtConfirmPassword');
        var icon = $(this).find('i');

        if (confirmPasswordField.attr('type') === 'password') {
            confirmPasswordField.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            confirmPasswordField.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });

    // Hiển thị input mật khẩu mới (cho chế độ chỉnh sửa)
    window.showPasswordInput = function () {
        $('.passwordinfo').show();
        $('.btnShowPassword').hide();
        $('#txtPassword').focus();
    };

    // Validate form
    function validateForm() {
        var errors = [];

        // Kiểm tra cửa hàng
        if (!$('#m-shop-create-staff').val()) {
            errors.push('Vui lòng chọn cửa hàng');
        }

        // Kiểm tra tên đăng nhập
        if (!$('#txtUserName').val().trim()) {
            errors.push('Vui lòng nhập tên đăng nhập');
        }

        // Kiểm tra mật khẩu (chỉ khi tạo mới hoặc đang hiển thị)
        if ($('.passwordinfo').is(':visible')) {
            if (!$('#txtPassword').val()) {
                errors.push('Vui lòng nhập mật khẩu');
            }

            if ($('#txtPassword').val().length < 6) {
                errors.push('Mật khẩu phải có ít nhất 6 ký tự');
            }

            if ($('#txtPassword').val() !== $('#txtConfirmPassword').val()) {
                errors.push('Mật khẩu xác nhận không khớp');
            }
        }

        // Kiểm tra họ tên
        if (!$('#txtFullName').val().trim()) {
            errors.push('Vui lòng nhập họ tên');
        }

        return errors;
    }

    // Hiển thị thông báo lỗi
    function showErrors(errors) {
        var errorHtml = '<div class="alert alert-danger"><ul class="mb-0">';
        errors.forEach(function (error) {
            errorHtml += '<li>' + error + '</li>';
        });
        errorHtml += '</ul></div>';

        // Tìm vị trí hiển thị lỗi (đầu form)
        if ($('.alert').length > 0) {
            $('.alert').remove();
        }
        $('.m-portlet__body').prepend(errorHtml);

        // Cuộn lên đầu form
        $('html, body').animate({
            scrollTop: $('.alert').offset().top - 50
        }, 300);
    }

    // Hiển thị thông báo thành công
    function showSuccess(message) {
        var successHtml = '<div class="alert alert-success">' + message + '</div>';

        if ($('.alert').length > 0) {
            $('.alert').remove();
        }
        $('.m-portlet__body').prepend(successHtml);

        $('html, body').animate({
            scrollTop: $('.alert').offset().top - 50
        }, 300);
        setTimeout(function () {

            window.location.href = './PermissionStaff';

        }, 1000);
    }

    // Xử lý lưu nhân viên
    $('#btnSaveStaff').click(function (e) {
        e.preventDefault();

        // Xóa thông báo cũ
        $('.alert').remove();

        // Validate form
        var errors = validateForm();
        if (errors.length > 0) {
            showErrors(errors);
            return;
        }

        // Hiển thị loading
        var $btn = $(this);
        var originalText = $btn.html();
        $btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Đang lưu...');

        // Chuẩn bị dữ liệu
        var formData = {
            staffId: $('#hddStaffId').val(),
            shopId: $('#m-shop-create-staff').val(),
            userName: $('#txtUserName').val().trim(),
            fullName: $('#txtFullName').val().trim(),
            status: $('input[name="cbStatus"]:checked').val()
        };

        // Thêm mật khẩu nếu đang hiển thị
        if ($('.passwordinfo').is(':visible')) {
            formData.password = $('#txtPassword').val();
            formData.confirmPassword = $('#txtConfirmPassword').val();
        }

        // Gửi request
        $.ajax({
            url: API_BASE_URL + 'save_staff.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    showSuccess(response.message);

                    // Nếu là tạo mới, reset form
                    if (formData.staffId == 0) {
                        resetForm();
                    }
                } else {
                    showErrors([response.message]);
                }
            },
            error: function (xhr, status, error) {
                showErrors(['Có lỗi xảy ra: ' + error]);
            },
            complete: function () {
                // Khôi phục button
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });

    // Reset form
    function resetForm() {
        $('#hddStaffId').val(0);
        $('#m-shop-create-staff').val('').trigger('change');
        $('#txtUserName').val('');
        $('#txtPassword').val('');
        $('#txtConfirmPassword').val('');
        $('#txtFullName').val('');
        $('#cbStatus-Success').prop('checked', true);
        $('.passwordinfo').show();
        $('.btnShowPassword').hide();
        $('.ahrefPermission').hide();
    }

    // ==================== XỬ LÝ MODAL CỬA HÀNG ====================

    // Validate form cửa hàng
    function validateShopForm() {
        var errors = [];

        if (!$('#txt_create_ShopName').val().trim()) {
            errors.push('Vui lòng nhập tên cửa hàng');
        }

        if (!$('#txt_create_ShopPhone').val().trim()) {
            errors.push('Vui lòng nhập số điện thoại');
        } else {
            var phoneRegex = /^[0-9]{10,11}$/;
            if (!phoneRegex.test($('#txt_create_ShopPhone').val().trim())) {
                errors.push('Số điện thoại không hợp lệ');
            }
        }

        if (!$('#txt_create_TotalMoneyInSafe').val().trim()) {
            errors.push('Vui lòng nhập số vốn đầu tư');
        } else {
            var money = $('#txt_create_TotalMoneyInSafe').val().replace(/[^0-9]/g, '');
            if (isNaN(money) || parseInt(money) <= 0) {
                errors.push('Số vốn đầu tư phải là số dương');
            }
        }

        return errors;
    }

    // Xử lý lưu cửa hàng
    $('#btnSaveShop').click(function (e) {
        e.preventDefault();

        // Xóa thông báo cũ trong modal
        $('#modal_createShop .alert').remove();

        // Validate form
        var errors = validateShopForm();
        if (errors.length > 0) {
            var errorHtml = '<div class="alert alert-danger"><ul class="mb-0">';
            errors.forEach(function (error) {
                errorHtml += '<li>' + error + '</li>';
            });
            errorHtml += '</ul></div>';
            $('.modal-body form .m-portlet__body').prepend(errorHtml);
            return;
        }

        // Hiển thị loading
        var $btn = $(this);
        var originalText = $btn.html();
        $btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Đang lưu...');

        // Chuẩn bị dữ liệu
        var formData = {
            shopId: $('#hddShopId').val(),
            shopName: $('#txt_create_ShopName').val().trim(),
            shopPhone: $('#txt_create_ShopPhone').val().trim(),
            totalMoneyInSafe: $('#txt_create_TotalMoneyInSafe').val().replace(/[^0-9]/g, '')
        };

        // Gửi request
        $.ajax({
            url: 'save_shop.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    // Thêm option mới vào dropdown
                    var newOption = new Option(response.shop.name, response.shop.id, false, true);
                    $('#m-shop-create-staff').append(newOption).trigger('change');

                    // Đóng modal
                    $('#modal_createShop').modal('hide');

                    // Reset form modal
                    resetShopForm();

                    // Hiển thị thông báo thành công
                    showSuccess('Thêm cửa hàng thành công!');
                } else {
                    var errorHtml = '<div class="alert alert-danger">' + response.message + '</div>';
                    $('.modal-body form .m-portlet__body').prepend(errorHtml);
                }
            },
            error: function (xhr, status, error) {
                var errorHtml = '<div class="alert alert-danger">Có lỗi xảy ra: ' + error + '</div>';
                $('.modal-body form .m-portlet__body').prepend(errorHtml);
            },
            complete: function () {
                // Khôi phục button
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });

    // Reset form cửa hàng
    function resetShopForm() {
        $('#hddShopId').val(0);
        $('#txt_create_ShopName').val('');
        $('#txt_create_ShopPhone').val('');
        $('#txt_create_TotalMoneyInSafe').val('');
        $('#modal_createShop .alert').remove();
    }

    // Reset form khi đóng modal
    $('#modal_createShop').on('hidden.bs.modal', function () {
        resetShopForm();
    });

    // Đóng popup (nếu có function closePop)
    window.closePop = function () {
        $('#modal_createShop').modal('hide');
    };

    // Format số tiền khi nhập
    $('#txt_create_TotalMoneyInSafe').on('input', function () {
        var value = $(this).val().replace(/[^0-9]/g, '');
        if (value) {
            // Format số với dấu phẩy
            var formatted = value.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            $(this).val(formatted);
        }
    });

    // Chỉ cho phép nhập số cho trường số điện thoại
    $('#txt_create_ShopPhone').on('input', function () {
        var value = $(this).val().replace(/[^0-9]/g, '');
        $(this).val(value);
    });

    // Tự động focus vào trường đầu tiên khi mở modal
    $('#modal_createShop').on('shown.bs.modal', function () {
        $('#txt_create_ShopName').focus();
    });
});

// Function để load dữ liệu nhân viên khi chỉnh sửa
function loadStaffData(staffId) {
    $.ajax({
        url: 'get_staff.php',
        method: 'GET',
        data: { id: staffId },
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                var staff = response.data;

                $('#hddStaffId').val(staff.id);
                $('#m-shop-create-staff').val(staff.shop_id).trigger('change');
                $('#txtUserName').val(staff.username);
                $('#txtFullName').val(staff.full_name);

                if (staff.status == 1) {
                    $('#cbStatus-Success').prop('checked', true);
                } else {
                    $('#cbStatus-Stop').prop('checked', true);
                }

                // Ẩn trường mật khẩu và hiển thị button tạo mật khẩu mới
                $('.passwordinfo').hide();
                $('.btnShowPassword').show();

                // Hiển thị link phân quyền nếu cần
                $('.ahrefPermission').show();
                $('#ahrefPermission').attr('href', 'permission.php?id=' + staff.id)
                    .text('Phân quyền cho ' + staff.full_name);
            }
        },
        error: function () {
            alert('Không thể tải dữ liệu nhân viên');
        }
    });
}

async function loadShopOptions() {
    try {
        const response = await fetch(API_BASE_URL + 'get_shops.php?action=list');
        const result = await response.json();

        const selectElement = document.getElementById('m-shop-create-staff');

        // Xóa các option cũ (trừ option đầu tiên)
        selectElement.innerHTML = '<option value="">Chọn cửa hàng</option>';

        if (result.success && result.data) {
            result.data.forEach(shop => {
                const option = document.createElement('option');
                option.value = shop.id;
                option.textContent = shop.name;
                selectElement.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Lỗi khi load danh sách cửa hàng:', error);
    }
}

// Load danh sách cửa hàng khi trang được tải
document.addEventListener('DOMContentLoaded', function () {
    loadShopOptions();
});

// Hàm để refresh lại danh sách cửa hàng sau khi thêm mới
function refreshShopOptions() {
    loadShopOptions();
}