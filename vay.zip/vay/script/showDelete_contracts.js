
// Biến global
let currentPage = 1;
let totalPages = 1;
let currentDeletedContractId = null;
let currentDeletedContractsData = [];
// Khởi tạo khi trang load
$(document).ready(function () {
    loadDeletedContracts();
    bindEvents();
});

// Bind các events
function bindEvents() {
    $('#btnGetData').click(function () {
        currentPage = 1;
        loadDeletedContracts();
    });

    $('#generalSearch').keypress(function (e) {
        if (e.which == 13) {
            currentPage = 1;
            loadDeletedContracts();
        }
    });

    $('#page-size-select').change(function () {
        currentPage = 1;
        loadDeletedContracts();
    });
}

// Load danh sách hợp đồng đã xóa
async function loadDeletedContracts() {
    try {

        const params = {
            shopId: await getShopId(),
            userId: await getUserId()
        };

        $.ajax({
            url: API_BASE_URL + 'get_deleted_contracts.php',
            method: 'GET',
            data: params,
            success: function (response) {


                if (response.success) {
                    renderDeletedContracts(response.data);
                    updatePagination(response.pagination);
                    updateStatistics(response.statistics);
                } else {
                    showErrorMessage('Lỗi: ' + response.message);
                }
            },
            error: function (xhr) {
                console.error('Error loading deleted contracts:', xhr);
                showErrorMessage('Có lỗi xảy ra khi tải dữ liệu');
            }
        });

    } catch (error) {
        console.error('Error:', error);
        showErrorMessage('Có lỗi xảy ra');
    }
}


function renderDeletedContracts(contracts) {
    currentDeletedContractsData = contracts;
    const tbody = $('#deleted-contracts-tbody');
    tbody.empty();

    if (contracts.length === 0) {
        tbody.append(`
            <tr>
                <td colspan="10" class="text-center">Không có dữ liệu</td>
            </tr>
        `);
        return;
    }

    contracts.forEach((contract, index) => {
        const rowNumber = (currentPage - 1) * $('#page-size-select').val() + index + 1;
        const remainingAmount = contract.total_money - contract.total_paid;

        // XÁC ĐỊNH TRẠNG THÁI DỰA TRÊN deletion_status
        let statusDisplay = '';
        let statusClass = '';
        let dateLabel = '';

        if (contract.deletion_status === 'closed') {
            // Hợp đồng đã hoàn thành
            statusDisplay = 'Đã hoàn thành';
            statusClass = 'm-badge--success';
            dateLabel = 'Đóng:';
        } else {
            // Hợp đồng bị xóa (mặc định)
            statusDisplay = 'Đã xóa';
            statusClass = 'm-badge--danger';
            dateLabel = 'Xóa:';
        }

        const row = `
            <tr data-row="${index}" class="m-datatable__row" style="height: 0px;">
                <td data-field="RowID" style="text-align:center" 
                    class="m-datatable__cell--center m-datatable__cell">
                    <span style="width: 40px;">${rowNumber}</span>
                </td>
                <td data-field="CodeID" style="text-align:left" 
                    class="m-datatable__cell">
                    <span style="width: 60px;">
                        <a class="m-link" onclick="showDeletedContractDetails(${contract.id})" 
                           style="color:#dc3545;cursor: pointer; font-weight: bold;">
                            ${contract.code_id}
                        </a>
                    </span>
                </td>
                <td data-field="CustomerName" style="text-align:left" 
                    class="m-datatable__cell">
                    <span style="width: 150px;">
                        <div>
                            <div class="m-card-user__details">
                                <a onclick="showDeletedContractDetails(${contract.id})"
                                   class="m-card-user__email m-link font-cusName font-weight-bold"
                                   style="color:#dc3545; cursor: pointer;">
                                    ${contract.customer_name}
                                </a><br>
                                <small class="text-muted">${contract.customer_phone || ''}</small>
                            </div>
                        </div>
                    </span>
                </td>
                <td data-field="TotalMoneyReceived" style="text-align:right" 
                    class="m-datatable__cell--right m-datatable__cell">
                    <span style="width: 110px;">${formatMoney(contract.total_money_received)}</span>
                </td>
                <td data-field="TotalMoney" style="text-align:right" 
                    class="m-datatable__cell--right m-datatable__cell">
                    <span style="width: 110px;">${formatMoney(contract.total_money)}</span>
                </td>
                <td data-field="TotalPaid" style="text-align:right" 
                    class="m-datatable__cell--right m-datatable__cell">
                    <span style="width: 110px;">
                        <div>
                            <div class="m-card-user__details">
                                <span class="m-card-user__name text-success font-weight-bold">
                                    ${formatMoney(contract.total_paid)}
                                </span><br>
                            </div>
                        </div>
                    </span>
                </td>
                <td data-field="RemainingAmount" style="text-align:right" 
                    class="m-datatable__cell--right m-datatable__cell">
                    <span style="width: 110px;">
                        <div>
                            <div class="m-card-user__details">
                                <span class="m-card-user__name ${remainingAmount > 0 ? 'text-danger' : 'text-success'} font-weight-bold">
                                    ${formatMoney(remainingAmount)}
                                </span><br>
                            </div>
                        </div>
                    </span>
                </td>
                <td data-field="Dates" style="text-align:center" 
                    class="m-datatable__cell--center m-datatable__cell">
                    <span style="width: 120px;">
                        <div class="text-center">
                            <div class="m-card-user__details">
                                <small><strong>Tạo:</strong> ${contract.formatted_created_at}</small>
                                <div><strong>${dateLabel}</strong> ${contract.formatted_deleted_at}</div>
                            </div>
                        </div>
                    </span>
                </td>
                <td data-field="Status" style="text-align:center" 
                    class="m-datatable__cell--center m-datatable__cell">
                    <span style="width: 100px;">
                        <span class="m-badge ${statusClass} m-badge--wide" style="font-size:12px">
                            ${statusDisplay}
                        </span>
                    </span>
                </td>
                <td data-field="Actions" style="text-align:left" 
                    class="m-datatable__cell">
                    <span style="width: 130px;">
                        <button onclick="showDeletedContractDetails(${contract.id})" 
                                class="btn btn-info btn-sm" title="Xem chi tiết">
                            <i class="la la-eye"></i>
                        </button>
                        <button onclick="confirmRestore(${contract.id}, '${contract.code_id}')" 
                                class="btn btn-warning btn-sm" title="Khôi phục hợp đồng">
                            <i class="fa fa-undo"></i>
                        </button>
                    </span>
                </td>
            </tr>
        `;
        tbody.append(row);
    });
}

// Cập nhật pagination
function updatePagination(pagination) {
    currentPage = pagination.currentPage;
    totalPages = pagination.totalPages;

    const nav = $('#pagination-nav');
    nav.empty();

    if (totalPages <= 1) {
        nav.hide();
        return;
    }

    nav.show();

    // Previous button
    const prevDisabled = currentPage === 1 ? 'disabled' : '';
    nav.append(`
                <li>
                    <a class="m-datatable__pager-link ${prevDisabled}" onclick="changePage(${currentPage - 1})" ${prevDisabled}>
                        <i class="la la-angle-left"></i>
                    </a>
                </li>
            `);

    // Page numbers
    for (let i = Math.max(1, currentPage - 2); i <= Math.min(totalPages, currentPage + 2); i++) {
        const activeClass = i === currentPage ? 'm-datatable__pager-link--active' : '';
        nav.append(`
                    <li>
                        <a class="m-datatable__pager-link ${activeClass}" onclick="changePage(${i})">${i}</a>
                    </li>
                `);
    }

    // Next button
    const nextDisabled = currentPage === totalPages ? 'disabled' : '';
    nav.append(`
                <li>
                    <a class="m-datatable__pager-link ${nextDisabled}" onclick="changePage(${currentPage + 1})" ${nextDisabled}>
                        <i class="la la-angle-right"></i>
                    </a>
                </li>
            `);

    // Update pager info
    $('#pager-info').text(`Tổng số ${pagination.totalRecords} bản ghi`);
}

// Chuyển trang
function changePage(page) {
    if (page < 1 || page > totalPages || page === currentPage) return;
    currentPage = page;
    loadDeletedContracts();
}

// Cập nhật thống kê
function updateStatistics(stats) {
    if (stats) {
        $('#lbl_total_deleted_contracts').text(stats.total_contracts || 0);
        $('#lbl_total_money_lent').text(formatMoney(stats.total_money_lent || 0));
        $('#lbl_total_money_collected').text(formatMoney(stats.total_money_collected || 0));
    }
}

// Hiển thị chi tiết hợp đồng đã xóa
async function showDeletedContractDetails(deletedContractId) {
    try {


        $.ajax({
            url: API_BASE_URL + 'get_deleted_contract_details.php',
            method: 'GET',
            data: { id: deletedContractId },
            success: function (response) {


                if (response.success) {
                    const contract = response.data;
                    currentDeletedContractId = deletedContractId;

                    // Điền thông tin cơ bản
                    $('#modal_contract_code').text(contract.code_id);
                    $('#detail_customer_name').text(contract.customer_name);
                    $('#detail_customer_phone').text(contract.customer_phone || 'Không có');
                    $('#detail_customer_address').text(contract.customer_address || 'Không có');
                    $('#detail_from_date').text(contract.formatted_from_date);
                    $('#detail_loan_time').text(contract.loan_time + ' ngày');
                    $('#detail_money_received').text(formatMoney(contract.total_money_received) + ' VNĐ');
                    $('#detail_total_money').text(formatMoney(contract.total_money) + ' VNĐ');
                    $('#detail_total_paid').text(formatMoney(contract.total_paid) + ' VNĐ');
                    $('#detail_deleted_at').text(contract.formatted_deleted_at);
                    $('#detail_deleted_by').text(contract.deleted_by);

                    // Render payment schedules
                    renderPaymentSchedules(contract.payment_schedules);

                    // Render payment transactions
                    renderPaymentTransactions(contract.payment_transactions);

                    $('#modal_deleted_contract_details').modal('show');
                } else {
                    showErrorMessage('Không thể tải chi tiết hợp đồng: ' + response.message);
                }
            },
            error: function (xhr) {

                showErrorMessage('Có lỗi xảy ra khi tải chi tiết hợp đồng');
            }
        });
    } catch (error) {

        showErrorMessage('Có lỗi xảy ra');
    }
}

// Render payment schedules
function renderPaymentSchedules(schedules) {
    const tbody = $('#payment_schedules_tbody');
    tbody.empty();

    if (!schedules || schedules.length === 0) {
        tbody.append('<tr><td colspan="5" class="text-center">Không có dữ liệu</td></tr>');
        return;
    }

    schedules.forEach(schedule => {
        const statusBadge = schedule.status === 'paid' ?
            '<span class="badge badge-success">Đã đóng</span>' :
            '<span class="badge badge-warning">Chưa đóng</span>';

        tbody.append(`
                    <tr>
                        <td>${schedule.period_number}</td>
                        <td>${formatDate(schedule.due_date)}</td>
                        <td class="text-right">${formatMoney(schedule.amount_due)}</td>
                        <td class="text-right">${formatMoney(schedule.amount_paid)}</td>
                        <td class="text-center">${statusBadge}</td>
                    </tr>
                `);
    });
}

// Render payment transactions
function renderPaymentTransactions(transactions) {
    const tbody = $('#payment_transactions_tbody');
    tbody.empty();

    if (!transactions || transactions.length === 0) {
        tbody.append('<tr><td colspan="4" class="text-center">Không có giao dịch</td></tr>');
        return;
    }

    transactions.forEach(transaction => {
        tbody.append(`
                    <tr>
                        <td>${formatDate(transaction.payment_date)}</td>
                        <td class="text-right">${formatMoney(transaction.amount_paid)}</td>
                        <td>${transaction.payment_method || 'Tiền mặt'}</td>
                        <td>${transaction.note || ''}</td>
                    </tr>
                `);
    });
}

// Xác nhận khôi phục
function confirmRestore(deletedContractId, codeId) {
    if (confirm(`Bạn có chắc chắn muốn khôi phục hợp đồng ${codeId}?\n\nHành động này sẽ đưa hợp đồng trở lại danh sách hoạt động.`)) {
        restoreContractById(deletedContractId);
    }
}

// Khôi phục hợp đồng
function restoreContract() {
    if (!currentDeletedContractId) {
        showErrorMessage('Không xác định được hợp đồng cần khôi phục');
        return;
    }
    restoreContractById(currentDeletedContractId);
}

// Khôi phục hợp đồng theo ID
async function restoreContractById(deletedContractId) {
    try {


        $.ajax({
            url: API_BASE_URL + 'restore_contract.php',
            method: 'POST',
            data: JSON.stringify({
                deleted_contract_id: deletedContractId,
                restored_by: await getUserId()
            }),
            contentType: 'application/json',
            success: function (response) {

                if (response.success) {
                    showSuccessMessage('Khôi phục hợp đồng thành công!');

                    // Đóng modal nếu đang mở
                    $('#modal_deleted_contract_details').modal('hide');

                    // Reload danh sách
                    loadDeletedContracts();
                } else {
                    showErrorMessage('Lỗi khôi phục: ' + response.message);
                }
            },
            error: function (xhr) {

                console.error('Error restoring contract:', xhr);

                let errorMessage = 'Có lỗi xảy ra khi khôi phục hợp đồng';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }
                showErrorMessage(errorMessage);
            }
        });
    } catch (error) {

        showErrorMessage('Có lỗi xảy ra');
    }
}

async function exportDeletedContracts() {
    try {
        // Kiểm tra xem có dữ liệu hiển thị không
        if (!currentDeletedContractsData || currentDeletedContractsData.length === 0) {
            showErrorMessage('Không có dữ liệu để xuất Excel');
            return;
        }

        // Gửi dữ liệu hiện tại đang hiển thị lên server
        const response = await fetch(API_BASE_URL + 'export_deleted_contracts.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                contracts: JSON.stringify(currentDeletedContractsData),
                shopId: await getShopId(),
                userId: await getUserId(),
                searchInfo: buildDeletedContractsSearchInfoString(), // Thông tin filter hiện tại
                format: 'xlsx'
            })
        });

        if (!response.ok) {
            throw new Error('Lỗi server: ' + response.status);
        }

        // Tạo blob và download file
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `Danh_sach_hop_dong_da_xoa_${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        window.URL.revokeObjectURL(url);

    } catch (error) {
        console.error('Excel export error:', error);
        showErrorMessage('Có lỗi xảy ra khi xuất Excel: ' + error.message);
    }
}

// Hàm tạo thông tin tìm kiếm hiện tại
function buildDeletedContractsSearchInfoString() {
    const searchInfo = {
        search: $('#generalSearch').val().trim(),
        from_date: $('#txtFromDate').val(),
        to_date: $('#txtToDate').val(),
        page_size: $('#page-size-select').val(),
        current_page: currentPage,
        total_records: currentDeletedContractsData.length
    };

    return JSON.stringify(searchInfo);
}

// Quay lại trang hợp đồng chính
function goBackToContracts() {
    window.location.href = 'index'; // Hoặc đường dẫn trang chính
}

// Utility functions
function formatMoney(amount) {
    if (!amount) return '0';
    return parseInt(amount).toLocaleString('vi-VN');
}

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN');
}

function showSuccessMessage(message) {
    alert('Thành công: ' + message);
}

function showErrorMessage(message) {
    alert('Lỗi: ' + message);
}

// ================== HELPER FUNCTIONS ==================
async function getUserId() {
    var userID = localStorage.getItem('user_id');

    if (!userID) return null;

    // Nếu là staff ID (bắt đầu bằng STF)
    if (String(userID).toUpperCase().startsWith('STF')) {
        // Lấy owner_user_id thay vì staff user_id
        const ownerUserId = await getOwnerUserId(userID);
        console.log(ownerUserId);
        return ownerUserId;
    }

    // Nếu là owner, trả về bình thường
    return userID;
}
// Hàm lấy user_id của owner từ staff_id thông qua API
async function getOwnerUserId(staffId) {
    try {
        const response = await fetch(API_BASE_URL + 'get_owner_from_staff.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'staff_id=' + encodeURIComponent(staffId)
        });

        const result = await response.json();

        if (result.success && result.owner_user_id) {
            return result.owner_user_id;
        } else {
            console.error('Lỗi lấy owner user_id từ staff_id:', result.message);
            return null;
        }
    } catch (error) {
        console.error('Lỗi kết nối API:', error);
        return null;
    }
}

function getShopId() {
    var selectedShopId = sessionStorage.getItem('selected_shop_id');
    var defaultShopId = sessionStorage.getItem('store_id');

    return selectedShopId;
}
