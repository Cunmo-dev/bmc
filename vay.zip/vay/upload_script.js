// upload_script.js
document.addEventListener('DOMContentLoaded', function () {
    const uploadForm = document.getElementById('uploadForm');
    const fileInput = document.getElementById('excel_file');
    const fileUploadArea = document.querySelector('.file-upload-area');
    const fileName = document.getElementById('file-name');
    const progressContainer = document.getElementById('progressContainer');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const submitBtn = document.getElementById('submitBtn');
    const resultDiv = document.getElementById('result');

    // Drag & drop functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        fileUploadArea.addEventListener(eventName, unhighlight, false);
    });

    fileUploadArea.addEventListener('drop', handleDrop, false);

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function highlight(e) {
        fileUploadArea.classList.add('dragover');
    }

    function unhighlight(e) {
        fileUploadArea.classList.remove('dragover');
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;

        if (files.length > 0) {
            fileInput.files = files;
            displayFileName(files[0]);
        }
    }

    // File input change event
    fileInput.addEventListener('change', function (e) {
        if (e.target.files.length > 0) {
            displayFileName(e.target.files[0]);
        }
    });

    function displayFileName(file) {
        const allowedTypes = ['.txt', '.csv'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();

        if (!allowedTypes.includes(fileExtension)) {
            showAlert('Vui lòng chọn file TXT hoặc CSV!', 'danger');
            fileInput.value = '';
            fileName.style.display = 'none';
            return;
        }

        if (file.size > 10 * 1024 * 1024) { // 10MB
            showAlert('File quá lớn! Vui lòng chọn file nhỏ hơn 10MB.', 'danger');
            fileInput.value = '';
            fileName.style.display = 'none';
            return;
        }

        fileName.textContent = `📄 ${file.name} (${formatFileSize(file.size)})`;
        fileName.style.display = 'block';
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Form submit event
    uploadForm.addEventListener('submit', function (e) {
        e.preventDefault();

        // Validate form
        const userId = document.getElementById('user_id').value.trim();
        const shopId = document.getElementById('shop_id').value.trim();
        const file = fileInput.files[0];

        if (!userId || !shopId || !file) {
            showAlert('Vui lòng điền đầy đủ thông tin và chọn file!', 'danger');
            return;
        }

        // Show progress
        showProgress(true);
        submitBtn.disabled = true;

        // Create FormData
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('shop_id', shopId);
        formData.append('excel_file', file);
        formData.append('action', 'upload_contracts');

        // Upload file
        uploadFile(formData);
    });

    function uploadFile(formData) {
        const xhr = new XMLHttpRequest();

        // Progress tracking
        xhr.upload.addEventListener('progress', function (e) {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                updateProgress(percentComplete, 'Đang upload file...');
            }
        });

        xhr.addEventListener('load', function () {
            if (xhr.status === 200) {
                try {
                    // Log response for debugging
                    console.log('Server response:', xhr.responseText);

                    const response = JSON.parse(xhr.responseText);
                    handleUploadResponse(response);
                } catch (error) {
                    console.error('JSON Parse Error:', error);
                    console.error('Response text:', xhr.responseText);

                    // Check if response contains HTML error
                    if (xhr.responseText.includes('<br />') || xhr.responseText.includes('<b>')) {
                        showAlert('Lỗi PHP trên server. Kiểm tra console để xem chi tiết.', 'danger');
                    } else {
                        showAlert('Lỗi xử lý phản hồi từ server!', 'danger');
                    }
                    resetForm();
                }
            } else {
                showAlert(`Lỗi HTTP: ${xhr.status} - ${xhr.statusText}`, 'danger');
                resetForm();
            }
        });

        xhr.addEventListener('error', function () {
            showAlert('Lỗi kết nối! Vui lòng kiểm tra internet và thử lại.', 'danger');
            resetForm();
        });

        xhr.addEventListener('timeout', function () {
            showAlert('Quá thời gian chờ! Vui lòng thử lại.', 'danger');
            resetForm();
        });

        xhr.timeout = 120000; // 2 minutes timeout
        xhr.open('POST', 'upload_process.php', true);
        xhr.send(formData);
    }

    function handleUploadResponse(response) {
        if (response.success) {
            updateProgress(100, 'Upload thành công!');

            let successMessage = `
                <div class="alert alert-success">
                    <h4>✅ Upload thành công!</h4>
                    <p><strong>Tổng số dòng xử lý:</strong> ${response.total_rows}</p>
                    <p><strong>Số hợp đồng được tạo:</strong> ${response.success_count}</p>
                    <p><strong>Số lỗi:</strong> ${response.error_count}</p>
                </div>
            `;

            if (response.errors && response.errors.length > 0) {
                successMessage += '<div class="alert alert-danger"><h5>Chi tiết lỗi:</h5><ul>';
                response.errors.forEach(error => {
                    successMessage += `<li>Dòng ${error.row}: ${error.message}</li>`;
                });
                successMessage += '</ul></div>';
            }

            if (response.warnings && response.warnings.length > 0) {
                successMessage += '<div class="alert alert-info"><h5>Cảnh báo:</h5><ul>';
                response.warnings.forEach(warning => {
                    successMessage += `<li>Dòng ${warning.row}: ${warning.message}</li>`;
                });
                successMessage += '</ul></div>';
            }

            resultDiv.innerHTML = successMessage;

            // Auto hide progress after 3 seconds
            setTimeout(() => {
                showProgress(false);
            }, 3000);

        } else {
            showAlert(`Lỗi upload: ${response.message}`, 'danger');

            if (response.errors && response.errors.length > 0) {
                let errorDetails = '<div class="alert alert-danger"><h5>Chi tiết lỗi:</h5><ul>';
                response.errors.forEach(error => {
                    errorDetails += `<li>${error.message || error}</li>`;
                });
                errorDetails += '</ul></div>';
                resultDiv.innerHTML = errorDetails;
            }
        }

        submitBtn.disabled = false;
    }

    function updateProgress(percent, text) {
        progressFill.style.width = percent + '%';
        progressText.textContent = `${text} (${Math.round(percent)}%)`;
    }

    function showProgress(show) {
        progressContainer.style.display = show ? 'block' : 'none';
        if (!show) {
            updateProgress(0, 'Đang xử lý...');
        }
    }

    function showAlert(message, type) {
        const alertClass = `alert-${type}`;
        const alertHTML = `
            <div class="alert ${alertClass}">
                ${message}
                <button type="button" style="float: right; background: none; border: none; font-size: 18px; cursor: pointer;" onclick="this.parentElement.style.display='none'">&times;</button>
            </div>
        `;

        resultDiv.innerHTML = alertHTML;

        // Auto hide success alerts after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                if (resultDiv.querySelector('.alert-success')) {
                    resultDiv.querySelector('.alert-success').style.display = 'none';
                }
            }, 5000);
        }
    }

    function resetForm() {
        submitBtn.disabled = false;
        showProgress(false);
    }

    // Validation helpers
    function validateUserId(userId) {
        return /^USR\d{8}$/.test(userId);
    }

    function validateShopId(shopId) {
        return /^SHP\d{8}$/.test(shopId);
    }

    // Real-time validation
    document.getElementById('user_id').addEventListener('input', function (e) {
        const value = e.target.value.trim();
        if (value && !validateUserId(value)) {
            e.target.style.borderColor = '#dc3545';
            showAlert('User ID phải có định dạng: USR + 8 số (VD: USR12345678)', 'danger');
        } else {
            e.target.style.borderColor = '#28a745';
            if (resultDiv.querySelector('.alert-danger')) {
                resultDiv.innerHTML = '';
            }
        }
    });

    document.getElementById('shop_id').addEventListener('input', function (e) {
        const value = e.target.value.trim();
        if (value && !validateShopId(value)) {
            e.target.style.borderColor = '#dc3545';
            showAlert('Shop ID phải có định dạng: SHP + 8 số (VD: SHP12345678)', 'danger');
        } else {
            e.target.style.borderColor = '#28a745';
            if (resultDiv.querySelector('.alert-danger')) {
                resultDiv.innerHTML = '';
            }
        }
    });
});